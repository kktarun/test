"use client"

import { StatsCards } from "./stats-cards"
import { RevenueChart } from "./charts/revenue-chart"
import { GatewayPerformance } from "./charts/gateway-performance"
import { TransactionVolume } from "./charts/transaction-volume"
import { RecentTransactions } from "./recent-transactions"
import { GatewayBreakdown } from "./gateway-breakdown"
import { TopFeeCategories } from "./top-fee-categories"
import { DateRangePicker } from "./date-range-picker"
import { ChargebackSummary } from "./chargeback-summary"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import {
  ArrowRight,
  CreditCard,
  TrendingUp,
  AlertCircle,
  DollarSign,
  Users,
  Clock,
  CheckCircle2,
} from "lucide-react"

export function DashboardContent() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Finance Infrastructure Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Complete payment orchestration, fee collection & financial management for educational institutions
          </p>
        </div>
        <DateRangePicker />
      </div>

      <StatsCards />

      {/* Key Metrics Grid */}
      <div className="grid gap-6 lg:grid-cols-4">
        <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <DollarSign className="h-4 w-4 text-primary" />
              Collections Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">₹8,45,200</p>
            <p className="text-xs text-muted-foreground mt-1">+12.5% from yesterday</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500/5 to-blue-500/10 border-blue-500/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <Users className="h-4 w-4 text-blue-600" />
              Active Students
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">2,450</p>
            <p className="text-xs text-muted-foreground mt-1">+5.2% this month</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/5 to-green-500/10 border-green-500/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              Settlement Success
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">98.2%</p>
            <p className="text-xs text-muted-foreground mt-1">-0.3% from last month</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500/5 to-orange-500/10 border-orange-500/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-medium">
              <AlertCircle className="h-4 w-4 text-orange-600" />
              Pending Dues
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">₹12,45,000</p>
            <p className="text-xs text-muted-foreground mt-1">-8.2% from last week</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid gap-6 lg:grid-cols-2">
        <RevenueChart />
        <TransactionVolume />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <GatewayPerformance />
        </div>
        <GatewayBreakdown />
      </div>

      {/* Module Quick Access Cards */}
      <div>
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-foreground">Quick Access - Key Modules</h2>
          <p className="text-sm text-muted-foreground">Navigate to important financial workflows</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {/* Fee Collection */}
          <Card className="hover:shadow-md transition-shadow cursor-pointer group">
            <Link href="/fees">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-sm">Fee Collection</CardTitle>
                    <CardDescription className="mt-1">Manage student fees</CardDescription>
                  </div>
                  <CreditCard className="h-5 w-5 text-primary group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  Collect, track, and reconcile student fee payments
                </p>
              </CardContent>
            </Link>
          </Card>

          {/* Student Financing */}
          <Card className="hover:shadow-md transition-shadow cursor-pointer group">
            <Link href="/financing">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-sm">Student Financing</CardTitle>
                    <CardDescription className="mt-1">Finance options</CardDescription>
                  </div>
                  <TrendingUp className="h-5 w-5 text-blue-600 group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  Manage student loans and financing programs
                </p>
              </CardContent>
            </Link>
          </Card>

          {/* Settlements */}
          <Card className="hover:shadow-md transition-shadow cursor-pointer group">
            <Link href="/settlements">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-sm">Settlements</CardTitle>
                    <CardDescription className="mt-1">Banking payouts</CardDescription>
                  </div>
                  <DollarSign className="h-5 w-5 text-green-600 group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  Track settlement schedules and bank transfers
                </p>
              </CardContent>
            </Link>
          </Card>

          {/* Reconciliation */}
          <Card className="hover:shadow-md transition-shadow cursor-pointer group">
            <Link href="/reconciliation">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-sm">Reconciliation</CardTitle>
                    <CardDescription className="mt-1">Bank matching</CardDescription>
                  </div>
                  <Clock className="h-5 w-5 text-purple-600 group-hover:translate-x-1 transition-transform" />
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">
                  Reconcile payments with bank statements
                </p>
              </CardContent>
            </Link>
          </Card>
        </div>
      </div>

      {/* Recent Transactions and Summary */}
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <RecentTransactions />
        </div>
        <div className="space-y-6">
          <TopFeeCategories />
          <ChargebackSummary />
        </div>
      </div>
    </div>
  )
}
