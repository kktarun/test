"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Search,
  Banknote,
  CreditCard,
  QrCode,
  Link as LinkIcon,
  FileText,
  CheckCircle2,
  User,
  Receipt,
  Printer,
  Send,
  Upload,
  AlertTriangle,
  History,
} from "lucide-react"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"

const paymentModes = [
  { id: "cash", label: "Cash", icon: Banknote, description: "Accept cash payment at counter" },
  { id: "cheque", label: "Cheque", icon: FileText, description: "Accept cheque with details" },
  { id: "dd", label: "Demand Draft", icon: FileText, description: "Accept DD with bank details" },
  { id: "pos", label: "POS Machine", icon: CreditCard, description: "Swipe debit/credit card" },
  { id: "qr", label: "Dynamic QR", icon: QrCode, description: "Generate QR for UPI payment" },
  { id: "link", label: "Payment Link", icon: LinkIcon, description: "Send payment link via SMS/WhatsApp" },
]

const denominations = [
  { value: 2000, type: "note" },
  { value: 500, type: "note" },
  { value: 200, type: "note" },
  { value: 100, type: "note" },
  { value: 50, type: "note" },
  { value: 20, type: "both" },
  { value: 10, type: "both" },
  { value: 5, type: "both" },
  { value: 2, type: "coin" },
  { value: 1, type: "coin" },
]

const bankAccounts = [
  { id: "acc1", name: "Fee Collection Account", bank: "HDFC Bank", accountNo: "****4521", type: "Current" },
  { id: "acc2", name: "Transport Fee Account", bank: "ICICI Bank", accountNo: "****7832", type: "Current" },
  { id: "acc3", name: "General Fund Account", bank: "SBI", accountNo: "****9012", type: "Savings" },
]

const posDevices = [
  { id: "pos1", provider: "Razorpay", deviceId: "RZP-POS-001", name: "Counter 1" },
  { id: "pos2", provider: "PayU", deviceId: "PYU-POS-002", name: "Counter 2" },
  { id: "pos3", provider: "Pine Labs", deviceId: "PL-TID-003", name: "Accounts Office" },
]

const mockStudents = [
  { id: "STU001", name: "Arjun Sharma", class: "10-A", totalDue: 45000, rollNo: "1001", previousDues: 12000 },
  { id: "STU002", name: "Priya Patel", class: "9-B", totalDue: 38500, rollNo: "902", previousDues: 0 },
  { id: "STU003", name: "Rahul Verma", class: "8-C", totalDue: 42000, rollNo: "803", previousDues: 8500 },
  { id: "STU004", name: "Ananya Gupta", class: "10-A", totalDue: 15000, rollNo: "1015", previousDues: 5000 },
  { id: "STU005", name: "Vikram Singh", class: "7-A", totalDue: 52000, rollNo: "705", previousDues: 0 },
]

const mockFeeHeads = [
  { id: "tuition", name: "Tuition Fee", amount: 25000, due: 25000 },
  { id: "transport", name: "Transport Fee", amount: 8000, due: 8000 },
  { id: "lab", name: "Lab Fee", amount: 5000, due: 5000 },
  { id: "library", name: "Library Fee", amount: 2000, due: 2000 },
  { id: "sports", name: "Sports Fee", amount: 3000, due: 3000 },
  { id: "exam", name: "Exam Fee", amount: 2000, due: 2000 },
]

const mockPreviousDues = [
  { id: "prev1", year: "2022-23", description: "Unpaid Tuition Fee", amount: 12000 },
  { id: "prev2", year: "2023-24", description: "Transport Arrears", amount: 8500 },
]

const relationshipOptions = [
  "Father", "Mother", "Guardian", "Self", "Grandparent", "Sibling", "Other"
]

export function CollectFee() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStudent, setSelectedStudent] = useState<typeof mockStudents[0] | null>(null)
  const [selectedMode, setSelectedMode] = useState<string>("cash")
  const [selectedFeeHeads, setSelectedFeeHeads] = useState<string[]>([])
  const [selectedPreviousDues, setSelectedPreviousDues] = useState<string[]>([])
  const [showSuccessDialog, setShowSuccessDialog] = useState(false)
  const [showQRDialog, setShowQRDialog] = useState(false)
  const [showLinkDialog, setShowLinkDialog] = useState(false)
  const [chequeDetails, setChequeDetails] = useState({ number: "", bank: "", date: "", branchCode: "" })
  const [ddDetails, setDdDetails] = useState({ number: "", bank: "", date: "" })
  const [partialAmount, setPartialAmount] = useState("")
  const [selectedBankAccount, setSelectedBankAccount] = useState("")
  const [selectedPosDevice, setSelectedPosDevice] = useState("")
  const [remarks, setRemarks] = useState("")
  const [uploadedFile, setUploadedFile] = useState<string | null>(null)
  const [denominationCounts, setDenominationCounts] = useState<Record<number, { note: number; coin: number }>>({})
  const [payerDetails, setPayerDetails] = useState({ name: "", email: "", phone: "", relationship: "" })
  const [linkContactDetails, setLinkContactDetails] = useState({ email: "", phone: "", sendSms: true, sendWhatsapp: true })

  const filteredStudents = mockStudents.filter(
    (student) =>
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.rollNo.includes(searchQuery)
  )

  const selectedTotal = selectedFeeHeads.reduce((sum, id) => {
    const feeHead = mockFeeHeads.find((f) => f.id === id)
    return sum + (feeHead?.due || 0)
  }, 0)

  const previousDuesTotal = selectedPreviousDues.reduce((sum, id) => {
    const due = mockPreviousDues.find((d) => d.id === id)
    return sum + (due?.amount || 0)
  }, 0)

  const grandTotal = selectedTotal + previousDuesTotal

  const calculateDenominationTotal = () => {
    let total = 0
    Object.entries(denominationCounts).forEach(([denom, counts]) => {
      total += Number(denom) * ((counts.note || 0) + (counts.coin || 0))
    })
    return total
  }

  const handleCollect = () => {
    if (selectedMode === "qr") {
      setShowQRDialog(true)
    } else if (selectedMode === "link") {
      setShowLinkDialog(true)
    } else {
      setShowSuccessDialog(true)
    }
  }

  const handleFeeHeadToggle = (feeHeadId: string) => {
    setSelectedFeeHeads((prev) =>
      prev.includes(feeHeadId)
        ? prev.filter((id) => id !== feeHeadId)
        : [...prev, feeHeadId]
    )
  }

  const handlePreviousDueToggle = (dueId: string) => {
    setSelectedPreviousDues((prev) =>
      prev.includes(dueId)
        ? prev.filter((id) => id !== dueId)
        : [...prev, dueId]
    )
  }

  const updateDenominationCount = (denom: number, type: 'note' | 'coin', value: number) => {
    setDenominationCounts(prev => ({
      ...prev,
      [denom]: {
        ...prev[denom],
        [type]: value
      }
    }))
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Collect Now</h1>
        <p className="text-sm text-muted-foreground">
          Collect fees directly at the counter using multiple payment modes
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Student Search */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">Search Student</CardTitle>
            <CardDescription>Search by name, ID, or roll number</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Enter student name or ID..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {searchQuery && filteredStudents.map((student) => (
                <button
                  key={student.id}
                  onClick={() => {
                    setSelectedStudent(student)
                    setSelectedFeeHeads([])
                    setSelectedPreviousDues([])
                  }}
                  className={`w-full rounded-lg border p-3 text-left transition-colors ${
                    selectedStudent?.id === student.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:bg-muted/50"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium text-sm">{student.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {student.id} | Roll: {student.rollNo} | Class: {student.class}
                      </p>
                      {student.previousDues > 0 && (
                        <div className="flex items-center gap-1 mt-1">
                          <AlertTriangle className="h-3 w-3 text-warning" />
                          <span className="text-xs text-warning">
                            Previous dues: {new Intl.NumberFormat("en-IN", {
                              style: "currency",
                              currency: "INR",
                              maximumFractionDigits: 0,
                            }).format(student.previousDues)}
                          </span>
                        </div>
                      )}
                    </div>
                    <Badge variant="secondary" className="text-xs">
                      {new Intl.NumberFormat("en-IN", {
                        style: "currency",
                        currency: "INR",
                        maximumFractionDigits: 0,
                      }).format(student.totalDue)}
                    </Badge>
                  </div>
                </button>
              ))}
              {searchQuery && filteredStudents.length === 0 && (
                <p className="text-center text-sm text-muted-foreground py-4">
                  No students found
                </p>
              )}
              {!searchQuery && (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <User className="h-10 w-10 text-muted-foreground/50 mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Start typing to search for a student
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Fee Selection & Payment */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-medium">
              {selectedStudent ? `Fee Collection - ${selectedStudent.name}` : "Fee Collection"}
            </CardTitle>
            <CardDescription>
              {selectedStudent
                ? `Class ${selectedStudent.class} | ${selectedStudent.id}`
                : "Select a student to begin fee collection"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedStudent ? (
              <div className="space-y-6">
                {/* Previous Dues Section */}
                {selectedStudent.previousDues > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <History className="h-4 w-4 text-warning" />
                      <Label className="text-sm font-medium text-warning">Previous Year Dues</Label>
                    </div>
                    <div className="rounded-lg border border-warning/30 bg-warning/5 p-3 space-y-2">
                      {mockPreviousDues.map((due) => (
                        <div
                          key={due.id}
                          className={`flex items-center justify-between rounded-lg border p-3 cursor-pointer transition-colors ${
                            selectedPreviousDues.includes(due.id)
                              ? "border-warning bg-warning/10"
                              : "border-border hover:bg-muted/50"
                          }`}
                          onClick={() => handlePreviousDueToggle(due.id)}
                        >
                          <div className="flex items-center gap-3">
                            <Checkbox
                              checked={selectedPreviousDues.includes(due.id)}
                              onCheckedChange={() => handlePreviousDueToggle(due.id)}
                            />
                            <div>
                              <p className="text-sm font-medium">{due.description}</p>
                              <p className="text-xs text-muted-foreground">Academic Year: {due.year}</p>
                            </div>
                          </div>
                          <span className="font-semibold text-warning">
                            {new Intl.NumberFormat("en-IN", {
                              style: "currency",
                              currency: "INR",
                              maximumFractionDigits: 0,
                            }).format(due.amount)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Current Fee Heads Selection */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Current Year Fee Heads</Label>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs"
                      onClick={() =>
                        setSelectedFeeHeads(
                          selectedFeeHeads.length === mockFeeHeads.length
                            ? []
                            : mockFeeHeads.map((f) => f.id)
                        )
                      }
                    >
                      {selectedFeeHeads.length === mockFeeHeads.length ? "Deselect All" : "Select All"}
                    </Button>
                  </div>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {mockFeeHeads.map((feeHead) => (
                      <div
                        key={feeHead.id}
                        className={`flex items-center justify-between rounded-lg border p-3 cursor-pointer transition-colors ${
                          selectedFeeHeads.includes(feeHead.id)
                            ? "border-primary bg-primary/5"
                            : "border-border hover:bg-muted/50"
                        }`}
                        onClick={() => handleFeeHeadToggle(feeHead.id)}
                      >
                        <div className="flex items-center gap-3">
                          <Checkbox
                            checked={selectedFeeHeads.includes(feeHead.id)}
                            onCheckedChange={() => handleFeeHeadToggle(feeHead.id)}
                          />
                          <div>
                            <p className="text-sm font-medium">{feeHead.name}</p>
                            <p className="text-xs text-muted-foreground">
                              Due: {new Intl.NumberFormat("en-IN", {
                                style: "currency",
                                currency: "INR",
                                maximumFractionDigits: 0,
                              }).format(feeHead.due)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Beneficiary Account */}
                <Field>
                  <FieldLabel>Deposit to Account</FieldLabel>
                  <Select value={selectedBankAccount} onValueChange={setSelectedBankAccount}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select beneficiary account" />
                    </SelectTrigger>
                    <SelectContent>
                      {bankAccounts.map((acc) => (
                        <SelectItem key={acc.id} value={acc.id}>
                          <div className="flex flex-col">
                            <span>{acc.name}</span>
                            <span className="text-xs text-muted-foreground">{acc.bank} - {acc.accountNo}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>

                {/* Payment Mode */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Payment Mode</Label>
                  <div className="grid gap-2 sm:grid-cols-3">
                    {paymentModes.map((mode) => (
                      <button
                        key={mode.id}
                        onClick={() => setSelectedMode(mode.id)}
                        className={`flex items-center gap-3 rounded-lg border p-3 text-left transition-colors ${
                          selectedMode === mode.id
                            ? "border-primary bg-primary/5"
                            : "border-border hover:bg-muted/50"
                        }`}
                      >
                        <div className={`rounded-lg p-2 ${
                          selectedMode === mode.id ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}>
                          <mode.icon className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">{mode.label}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1">{mode.description}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Cash Denomination */}
                {selectedMode === "cash" && (
                  <div className="space-y-4 p-4 rounded-lg border bg-muted/30">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Cash Denomination</Label>
                      <Badge variant="secondary">
                        Total: {new Intl.NumberFormat("en-IN", {
                          style: "currency",
                          currency: "INR",
                          maximumFractionDigits: 0,
                        }).format(calculateDenominationTotal())}
                      </Badge>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                      {denominations.map((d) => (
                        <div key={d.value} className="flex items-center gap-2 rounded-lg border bg-card p-2">
                          <span className="w-12 text-sm font-medium">₹{d.value}</span>
                          {(d.type === "note" || d.type === "both") && (
                            <div className="flex items-center gap-1">
                              <Input
                                type="number"
                                min="0"
                                className="h-8 w-16 text-center"
                                placeholder="0"
                                value={denominationCounts[d.value]?.note || ""}
                                onChange={(e) => updateDenominationCount(d.value, 'note', parseInt(e.target.value) || 0)}
                              />
                              <span className="text-xs text-muted-foreground">N</span>
                            </div>
                          )}
                          {(d.type === "coin" || d.type === "both") && (
                            <div className="flex items-center gap-1">
                              <Input
                                type="number"
                                min="0"
                                className="h-8 w-16 text-center"
                                placeholder="0"
                                value={denominationCounts[d.value]?.coin || ""}
                                onChange={(e) => updateDenominationCount(d.value, 'coin', parseInt(e.target.value) || 0)}
                              />
                              <span className="text-xs text-muted-foreground">C</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Cheque Fields */}
                {selectedMode === "cheque" && (
                  <div className="space-y-4 p-4 rounded-lg border bg-muted/30">
                    <FieldGroup>
                      <div className="grid gap-4 sm:grid-cols-2">
                        <Field>
                          <FieldLabel>Cheque Number</FieldLabel>
                          <Input
                            placeholder="Enter cheque number"
                            value={chequeDetails.number}
                            onChange={(e) => setChequeDetails({ ...chequeDetails, number: e.target.value })}
                          />
                        </Field>
                        <Field>
                          <FieldLabel>Bank Name</FieldLabel>
                          <Input
                            placeholder="Enter bank name"
                            value={chequeDetails.bank}
                            onChange={(e) => setChequeDetails({ ...chequeDetails, bank: e.target.value })}
                          />
                        </Field>
                        <Field>
                          <FieldLabel>Branch/IFSC Code</FieldLabel>
                          <Input
                            placeholder="Enter branch or IFSC code"
                            value={chequeDetails.branchCode}
                            onChange={(e) => setChequeDetails({ ...chequeDetails, branchCode: e.target.value })}
                          />
                        </Field>
                        <Field>
                          <FieldLabel>Cheque Date</FieldLabel>
                          <Input
                            type="date"
                            value={chequeDetails.date}
                            onChange={(e) => setChequeDetails({ ...chequeDetails, date: e.target.value })}
                          />
                        </Field>
                      </div>
                    </FieldGroup>
                  </div>
                )}

                {/* DD Fields */}
                {selectedMode === "dd" && (
                  <div className="grid gap-4 sm:grid-cols-3 p-4 rounded-lg border bg-muted/30">
                    <Field>
                      <FieldLabel>DD Number</FieldLabel>
                      <Input
                        placeholder="Enter DD number"
                        value={ddDetails.number}
                        onChange={(e) => setDdDetails({ ...ddDetails, number: e.target.value })}
                      />
                    </Field>
                    <Field>
                      <FieldLabel>Bank Name</FieldLabel>
                      <Input
                        placeholder="Enter bank name"
                        value={ddDetails.bank}
                        onChange={(e) => setDdDetails({ ...ddDetails, bank: e.target.value })}
                      />
                    </Field>
                    <Field>
                      <FieldLabel>DD Date</FieldLabel>
                      <Input
                        type="date"
                        value={ddDetails.date}
                        onChange={(e) => setDdDetails({ ...ddDetails, date: e.target.value })}
                      />
                    </Field>
                  </div>
                )}

                {/* POS Device Selection */}
                {selectedMode === "pos" && (
                  <div className="p-4 rounded-lg border bg-muted/30 space-y-4">
                    <Field>
                      <FieldLabel>Select POS Device</FieldLabel>
                      <Select value={selectedPosDevice} onValueChange={setSelectedPosDevice}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select POS device" />
                        </SelectTrigger>
                        <SelectContent>
                          {posDevices.map((device) => (
                            <SelectItem key={device.id} value={device.id}>
                              <div className="flex flex-col">
                                <span>{device.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {device.provider} | Device ID: {device.deviceId}
                                </span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </Field>
                  </div>
                )}

                {/* QR Code */}
                {selectedMode === "qr" && (
                  <div className="p-4 rounded-lg border bg-muted/30 space-y-4">
                    <Field>
                      <FieldLabel>Select QR Device</FieldLabel>
                      <Select value={selectedPosDevice} onValueChange={setSelectedPosDevice}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select DQR device" />
                        </SelectTrigger>
                        <SelectContent>
                          {posDevices.map((device) => (
                            <SelectItem key={device.id} value={device.id}>
                              <div className="flex flex-col">
                                <span>{device.name}</span>
                                <span className="text-xs text-muted-foreground">
                                  {device.provider} | Device ID: {device.deviceId}
                                </span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </Field>
                  </div>
                )}

                {/* Payment Link Contact Details */}
                {selectedMode === "link" && (
                  <div className="p-4 rounded-lg border bg-muted/30 space-y-4">
                    <Label className="text-sm font-medium">Send Payment Link To</Label>
                    <FieldGroup>
                      <div className="grid gap-4 sm:grid-cols-2">
                        <Field>
                          <FieldLabel>Phone Number</FieldLabel>
                          <Input
                            placeholder="+91 98765 43210"
                            value={linkContactDetails.phone}
                            onChange={(e) => setLinkContactDetails({ ...linkContactDetails, phone: e.target.value })}
                          />
                        </Field>
                        <Field>
                          <FieldLabel>Email Address</FieldLabel>
                          <Input
                            type="email"
                            placeholder="parent@email.com"
                            value={linkContactDetails.email}
                            onChange={(e) => setLinkContactDetails({ ...linkContactDetails, email: e.target.value })}
                          />
                        </Field>
                      </div>
                    </FieldGroup>
                    <div className="flex gap-4">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={linkContactDetails.sendSms}
                          onCheckedChange={(checked) => setLinkContactDetails({ ...linkContactDetails, sendSms: checked as boolean })}
                        />
                        <span className="text-sm">Send via SMS</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={linkContactDetails.sendWhatsapp}
                          onCheckedChange={(checked) => setLinkContactDetails({ ...linkContactDetails, sendWhatsapp: checked as boolean })}
                        />
                        <span className="text-sm">Send via WhatsApp</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Payer Details */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Payer Details</Label>
                  <div className="p-4 rounded-lg border bg-muted/30">
                    <FieldGroup>
                      <div className="grid gap-4 sm:grid-cols-2">
                        <Field>
                          <FieldLabel>Payer Name</FieldLabel>
                          <Input
                            placeholder="Enter payer name"
                            value={payerDetails.name}
                            onChange={(e) => setPayerDetails({ ...payerDetails, name: e.target.value })}
                          />
                        </Field>
                        <Field>
                          <FieldLabel>Relationship with Student</FieldLabel>
                          <Select value={payerDetails.relationship} onValueChange={(v) => setPayerDetails({ ...payerDetails, relationship: v })}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select relationship" />
                            </SelectTrigger>
                            <SelectContent>
                              {relationshipOptions.map((rel) => (
                                <SelectItem key={rel} value={rel.toLowerCase()}>{rel}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </Field>
                        <Field>
                          <FieldLabel>Phone Number</FieldLabel>
                          <Input
                            placeholder="+91 98765 43210"
                            value={payerDetails.phone}
                            onChange={(e) => setPayerDetails({ ...payerDetails, phone: e.target.value })}
                          />
                        </Field>
                        <Field>
                          <FieldLabel>Email Address</FieldLabel>
                          <Input
                            type="email"
                            placeholder="payer@email.com"
                            value={payerDetails.email}
                            onChange={(e) => setPayerDetails({ ...payerDetails, email: e.target.value })}
                          />
                        </Field>
                      </div>
                    </FieldGroup>
                  </div>
                </div>

                {/* Partial Payment */}
                <Field>
                  <FieldLabel>Partial Payment Amount (Optional)</FieldLabel>
                  <Input
                    type="number"
                    placeholder={`Max: ${grandTotal}`}
                    value={partialAmount}
                    onChange={(e) => setPartialAmount(e.target.value)}
                    className="max-w-xs"
                  />
                </Field>

                {/* Remarks & Document Upload */}
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field>
                    <FieldLabel>Remarks (Optional)</FieldLabel>
                    <Textarea
                      placeholder="Add any notes or remarks..."
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      rows={3}
                    />
                  </Field>
                  <Field>
                    <FieldLabel>Upload Document (Optional)</FieldLabel>
                    <div className="rounded-lg border-2 border-dashed border-border p-4 text-center hover:border-primary/50 cursor-pointer transition-colors">
                      <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">
                        {uploadedFile || "Click to upload receipt or document"}
                      </p>
                      <input
                        type="file"
                        className="hidden"
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={(e) => setUploadedFile(e.target.files?.[0]?.name || null)}
                      />
                    </div>
                  </Field>
                </div>

                {/* Summary & Action */}
                <div className="flex items-center justify-between rounded-lg border bg-muted/30 p-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Amount</p>
                    <p className="text-2xl font-bold">
                      {new Intl.NumberFormat("en-IN", {
                        style: "currency",
                        currency: "INR",
                        maximumFractionDigits: 0,
                      }).format(partialAmount ? Number(partialAmount) : grandTotal)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {selectedFeeHeads.length} fee head(s) + {selectedPreviousDues.length} previous due(s)
                    </p>
                  </div>
                  <Button
                    size="lg"
                    disabled={selectedFeeHeads.length === 0 && selectedPreviousDues.length === 0}
                    onClick={handleCollect}
                    className="gap-2"
                  >
                    <Receipt className="h-4 w-4" />
                    Collect Payment
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <div className="rounded-full bg-muted p-4 mb-4">
                  <Banknote className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-medium">No Student Selected</h3>
                <p className="text-sm text-muted-foreground max-w-sm mt-1">
                  Search and select a student from the left panel to begin collecting fees
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Success Dialog */}
      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
              <CheckCircle2 className="h-8 w-8 text-green-600 dark:text-green-400" />
            </div>
            <DialogTitle>Payment Successful</DialogTitle>
            <DialogDescription>
              Fee collection completed for {selectedStudent?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Amount Collected</span>
              <span className="font-medium">
                {new Intl.NumberFormat("en-IN", {
                  style: "currency",
                  currency: "INR",
                  maximumFractionDigits: 0,
                }).format(partialAmount ? Number(partialAmount) : grandTotal)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Payment Mode</span>
              <span className="font-medium capitalize">{selectedMode}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Receipt No</span>
              <span className="font-medium">RCP-2024-00156</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Deposited To</span>
              <span className="font-medium">
                {bankAccounts.find(a => a.id === selectedBankAccount)?.name || "Default Account"}
              </span>
            </div>
          </div>
          <DialogFooter className="flex gap-2 sm:gap-0">
            <Button variant="outline" className="flex-1 gap-2">
              <Printer className="h-4 w-4" />
              Print Receipt
            </Button>
            <Button className="flex-1 gap-2">
              <Send className="h-4 w-4" />
              Send via SMS
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* QR Code Dialog */}
      <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader className="text-center">
            <DialogTitle>Scan to Pay</DialogTitle>
            <DialogDescription>
              Ask the parent to scan this QR code using any UPI app
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center py-4">
            <div className="rounded-xl border-2 border-dashed border-muted-foreground/25 p-4 bg-card">
              <div className="h-48 w-48 bg-muted rounded-lg flex items-center justify-center">
                <QrCode className="h-32 w-32 text-foreground" />
              </div>
            </div>
            <p className="mt-4 text-2xl font-bold">
              {new Intl.NumberFormat("en-IN", {
                style: "currency",
                currency: "INR",
                maximumFractionDigits: 0,
              }).format(partialAmount ? Number(partialAmount) : grandTotal)}
            </p>
            <p className="text-sm text-muted-foreground">{selectedStudent?.name}</p>
          </div>
          <DialogFooter>
            <Button className="w-full" onClick={() => {
              setShowQRDialog(false)
              setShowSuccessDialog(true)
            }}>
              Payment Received
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Link Dialog */}
      <Dialog open={showLinkDialog} onOpenChange={setShowLinkDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Send Payment Link</DialogTitle>
            <DialogDescription>
              Payment link will be sent to the contact details provided
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-medium">
                  {new Intl.NumberFormat("en-IN", {
                    style: "currency",
                    currency: "INR",
                    maximumFractionDigits: 0,
                  }).format(partialAmount ? Number(partialAmount) : grandTotal)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Student</span>
                <span className="font-medium">{selectedStudent?.name}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Phone</span>
                <span className="font-medium">{linkContactDetails.phone || "Not provided"}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Email</span>
                <span className="font-medium">{linkContactDetails.email || "Not provided"}</span>
              </div>
            </div>
            <div className="flex gap-2">
              {linkContactDetails.sendSms && <Badge variant="secondary">SMS</Badge>}
              {linkContactDetails.sendWhatsapp && <Badge variant="secondary">WhatsApp</Badge>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLinkDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => {
              setShowLinkDialog(false)
              setShowSuccessDialog(true)
            }} className="gap-2">
              <Send className="h-4 w-4" />
              Send Link
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
