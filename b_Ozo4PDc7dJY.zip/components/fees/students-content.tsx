"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Plus, 
  Search, 
  Eye, 
  FileDown, 
  Filter, 
  Upload,
  Clock,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  ExternalLink,
  MoreHorizontal,
  Users,
  UserMinus,
  Link2,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import { StudentLedger } from "@/components/students/student-ledger"

// Available groups for assignment
const studentGroups = [
  { id: "GRP001", name: "Merit Scholarship Recipients", type: "scholarship" },
  { id: "GRP002", name: "Sports Quota Students", type: "quota" },
  { id: "GRP003", name: "Staff Children", type: "concession" },
  { id: "GRP004", name: "Transport Zone A", type: "transport" },
  { id: "GRP005", name: "EWS Category", type: "ews" },
]

const students = [
  {
    id: "STU001",
    name: "Arjun Sharma",
    admissionNo: "ADM2024001",
    class: "10-A",
    section: "A",
    parent: "Rajesh Sharma",
    phone: "+91 98765 43210",
    totalFee: 65000,
    paid: 52000,
    pending: 13000,
    previousDues: 12000,
    scholarship: "Merit - 10%",
    status: "partial",
    studentStatus: "active",
    siblingId: "STU006",
    isNewAdmission: false,
    groups: ["GRP001"],
  },
  {
    id: "STU002",
    name: "Priya Patel",
    admissionNo: "ADM2024002",
    class: "8-B",
    section: "B",
    parent: "Vikram Patel",
    phone: "+91 98765 43211",
    totalFee: 52000,
    paid: 52000,
    pending: 0,
    previousDues: 0,
    scholarship: null,
    status: "paid",
    studentStatus: "active",
    siblingId: null,
    isNewAdmission: false,
    groups: [],
  },
  {
    id: "STU003",
    name: "Rahul Kumar",
    admissionNo: "ADM2024003",
    class: "12-A",
    section: "A",
    parent: "Suresh Kumar",
    phone: "+91 98765 43212",
    totalFee: 85000,
    paid: 42500,
    pending: 42500,
    previousDues: 8500,
    scholarship: "Need Based - 15%",
    status: "partial",
    studentStatus: "active",
    siblingId: null,
    isNewAdmission: false,
    groups: ["GRP005"],
  },
  {
    id: "STU004",
    name: "Sneha Reddy",
    admissionNo: "ADM2024004",
    class: "9-C",
    section: "C",
    parent: "Kiran Reddy",
    phone: "+91 98765 43213",
    totalFee: 65000,
    paid: 0,
    previousDues: 5000,
    pending: 65000,
    scholarship: null,
    status: "unpaid",
    studentStatus: "active",
    siblingId: null,
    isNewAdmission: true,
    groups: [],
  },
  {
    id: "STU005",
    name: "Vikram Singh",
    admissionNo: "ADM2024005",
    class: "11-B",
    section: "B",
    parent: "Harpreet Singh",
    phone: "+91 98765 43214",
    totalFee: 85000,
    paid: 85000,
    pending: 0,
    scholarship: "Sports - 20%",
    status: "paid",
    studentStatus: "active",
    siblingId: null,
    isNewAdmission: false,
    groups: ["GRP002"],
  },
]

export function StudentsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStudent, setSelectedStudent] = useState<typeof students[0] | null>(null)

  const stats = [
    {
      title: "Total Students",
      value: "2,450",
      icon: CheckCircle2,
      color: "text-primary",
    },
    {
      title: "Fee Paid",
      value: "1,820",
      icon: CheckCircle2,
      color: "text-success",
    },
    {
      title: "Partial Paid",
      value: "412",
      icon: Clock,
      color: "text-warning",
    },
    {
      title: "Defaulters",
      value: "218",
      icon: AlertCircle,
      color: "text-destructive",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Students</h1>
          <p className="text-muted-foreground">
            Manage student records and financial profiles
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Upload className="mr-2 h-4 w-4" />
            Import
          </Button>
          <Button variant="outline">
            <FileDown className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Student
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`rounded-lg bg-muted p-2 ${stat.color}`}>
                <stat.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <TabsList>
            <TabsTrigger value="all">All Students</TabsTrigger>
            <TabsTrigger value="paid">Paid</TabsTrigger>
            <TabsTrigger value="partial">Partial</TabsTrigger>
            <TabsTrigger value="defaulters">Defaulters</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <div className="relative w-full md:w-72">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search students..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select defaultValue="all">
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((cls) => (
                  <SelectItem key={cls} value={cls.toString()}>
                    Class {cls}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <TabsContent value="all">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Admission No</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Parent</TableHead>
                    <TableHead>Fee Progress</TableHead>
                    <TableHead>Previous Dues</TableHead>
                    <TableHead>Groups</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-primary/10 text-primary text-xs">
                              {student.name.split(" ").map((n) => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{student.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {student.admissionNo}
                      </TableCell>
                      <TableCell>{student.class}</TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm">{student.parent}</p>
                          <p className="text-xs text-muted-foreground">{student.phone}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="w-32 space-y-1">
                          <Progress
                            value={(student.paid / student.totalFee) * 100}
                            className="h-2"
                          />
                          <div className="flex justify-between text-xs">
                            <span className="text-muted-foreground">
                              ₹{(student.paid / 1000).toFixed(0)}K
                            </span>
                            <span className="font-medium">
                              ₹{(student.totalFee / 1000).toFixed(0)}K
                            </span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {student.previousDues > 0 ? (
                          <div className="flex items-center gap-1">
                            <AlertTriangle className="h-3 w-3 text-warning" />
                            <span className="text-sm font-medium text-warning">
                              ₹{student.previousDues.toLocaleString()}
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">None</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {student.groups && student.groups.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {student.groups.map((gId) => {
                              const group = studentGroups.find((g) => g.id === gId)
                              return group ? (
                                <Badge key={gId} variant="outline" className="text-xs">
                                  {group.name.length > 12 ? group.name.substring(0, 12) + "..." : group.name}
                                </Badge>
                              ) : null
                            })}
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">No groups</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            student.status === "paid"
                              ? "default"
                              : student.status === "partial"
                              ? "secondary"
                              : "destructive"
                          }
                          className="capitalize"
                        >
                          {student.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Link href={`/students/${student.id}`}>
                            <Button variant="ghost" size="sm">
                              <ExternalLink className="mr-2 h-4 w-4" />
                              Profile
                            </Button>
                          </Link>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => setSelectedStudent(student)}>
                                <Eye className="mr-2 h-4 w-4" />
                                View Ledger
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">
                                Assign to Group
                              </div>
                              {studentGroups.map((group) => (
                                <DropdownMenuItem key={group.id} className="pl-4">
                                  <Users className="mr-2 h-4 w-4" />
                                  {group.name}
                                  {student.groups?.includes(group.id) && (
                                    <CheckCircle2 className="ml-auto h-4 w-4 text-primary" />
                                  )}
                                </DropdownMenuItem>
                              ))}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Link2 className="mr-2 h-4 w-4" />
                                Link Sibling
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive">
                                <UserMinus className="mr-2 h-4 w-4" />
                                Deactivate Student
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="paid">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">
                Students with fully paid fees will appear here
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="partial">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">
                Students with partial fee payments will appear here
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="defaulters">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">
                Students with overdue fees will appear here
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
