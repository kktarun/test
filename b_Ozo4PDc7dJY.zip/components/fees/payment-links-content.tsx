"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { 
  Plus, 
  Search, 
  Link2,
  Copy,
  Send,
  CheckCircle2,
  Clock,
  XCircle,
  Eye,
  MoreHorizontal,
  Mail,
  MessageSquare,
  Smartphone,
  QrCode,
  Download,
  RefreshCw,
  IndianRupee,
  Calendar,
  User,
  ExternalLink,
  Trash2,
  Users,
  FileDown,
  Filter,
  Loader2,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const paymentLinks = [
  {
    id: "PL001",
    studentId: "STU001",
    studentName: "Arjun Sharma",
    class: "10-A",
    amount: 13000,
    feeHeads: ["Tuition Fee Q4", "Lab Fee"],
    description: "Pending Q4 fees",
    shortUrl: "https://pay.feeflo.in/abc123",
    fullUrl: "https://pay.feeflo.in/l/abc123xyz789",
    status: "active",
    createdAt: "2024-03-15",
    expiresAt: "2024-03-25",
    viewCount: 5,
    sentVia: ["sms", "whatsapp"],
    paidAt: null,
    batchId: null,
  },
  {
    id: "PL002",
    studentId: "STU003",
    studentName: "Rahul Kumar",
    class: "12-A",
    amount: 42500,
    feeHeads: ["Tuition Fee", "Exam Fee", "Lab Fee"],
    description: "Annual fee payment",
    shortUrl: "https://pay.feeflo.in/def456",
    fullUrl: "https://pay.feeflo.in/l/def456uvw321",
    status: "paid",
    createdAt: "2024-03-10",
    expiresAt: "2024-03-20",
    viewCount: 3,
    sentVia: ["email"],
    paidAt: "2024-03-12",
    batchId: null,
  },
  {
    id: "PL003",
    studentId: "STU004",
    studentName: "Sneha Reddy",
    class: "9-C",
    amount: 25000,
    feeHeads: ["Admission Fee"],
    description: "New admission fee",
    shortUrl: "https://pay.feeflo.in/ghi789",
    fullUrl: "https://pay.feeflo.in/l/ghi789rst654",
    status: "expired",
    createdAt: "2024-03-01",
    expiresAt: "2024-03-10",
    viewCount: 0,
    sentVia: [],
    paidAt: null,
    batchId: null,
  },
  {
    id: "PL004",
    studentId: "STU002",
    studentName: "Priya Patel",
    class: "8-B",
    amount: 8000,
    feeHeads: ["Transport Fee Q4"],
    description: "Bus fee for Q4",
    shortUrl: "https://pay.feeflo.in/jkl012",
    fullUrl: "https://pay.feeflo.in/l/jkl012mno345",
    status: "active",
    createdAt: "2024-03-16",
    expiresAt: "2024-03-30",
    viewCount: 2,
    sentVia: ["sms"],
    paidAt: null,
    batchId: "BATCH001",
  },
]

const bulkBatches = [
  {
    id: "BATCH001",
    name: "Q4 Fee Collection - Class 8",
    createdAt: "2024-03-16",
    totalStudents: 45,
    totalAmount: 360000,
    sent: 45,
    delivered: 43,
    paid: 28,
    feeHeads: ["Tuition Fee Q4", "Transport Fee Q4"],
    channels: ["sms", "whatsapp"],
    status: "active",
  },
  {
    id: "BATCH002",
    name: "Annual Fee - Class 10",
    createdAt: "2024-03-10",
    totalStudents: 60,
    totalAmount: 3900000,
    sent: 60,
    delivered: 58,
    paid: 42,
    feeHeads: ["Tuition Fee", "Lab Fee", "Activity Fee"],
    channels: ["sms", "whatsapp", "email"],
    status: "active",
  },
  {
    id: "BATCH003",
    name: "Exam Fee - Class 12",
    createdAt: "2024-03-05",
    totalStudents: 80,
    totalAmount: 200000,
    sent: 80,
    delivered: 80,
    paid: 75,
    feeHeads: ["Exam Fee"],
    channels: ["email"],
    status: "completed",
  },
]

const students = [
  { id: "STU001", name: "Arjun Sharma", class: "10-A", phone: "+91 98765 43210", email: "rajesh.sharma@email.com", pendingAmount: 13000 },
  { id: "STU002", name: "Priya Patel", class: "8-B", phone: "+91 98765 43211", email: "vikram.patel@email.com", pendingAmount: 8000 },
  { id: "STU003", name: "Rahul Kumar", class: "12-A", phone: "+91 98765 43212", email: "suresh.kumar@email.com", pendingAmount: 42500 },
  { id: "STU004", name: "Sneha Reddy", class: "9-C", phone: "+91 98765 43213", email: "kiran.reddy@email.com", pendingAmount: 65000 },
  { id: "STU005", name: "Vikram Singh", class: "11-B", phone: "+91 98765 43214", email: "harpreet.singh@email.com", pendingAmount: 0 },
  { id: "STU006", name: "Ananya Gupta", class: "8-B", phone: "+91 98765 43215", email: "amit.gupta@email.com", pendingAmount: 12000 },
  { id: "STU007", name: "Rohan Mehta", class: "8-B", phone: "+91 98765 43216", email: "nitin.mehta@email.com", pendingAmount: 8000 },
  { id: "STU008", name: "Kavya Iyer", class: "10-A", phone: "+91 98765 43217", email: "srinivas.iyer@email.com", pendingAmount: 15000 },
]

const feeHeads = [
  { id: "FH001", name: "Tuition Fee", pending: 15000 },
  { id: "FH002", name: "Lab Fee", pending: 3000 },
  { id: "FH003", name: "Exam Fee", pending: 2500 },
  { id: "FH004", name: "Transport Fee", pending: 8000 },
  { id: "FH005", name: "Library Fee", pending: 1500 },
  { id: "FH006", name: "Activity Fee", pending: 2000 },
  { id: "FH007", name: "Admission Fee", pending: 25000 },
]

const classes = ["1-A", "1-B", "2-A", "2-B", "3-A", "3-B", "4-A", "4-B", "5-A", "5-B", "6-A", "6-B", "7-A", "7-B", "8-A", "8-B", "9-A", "9-B", "9-C", "10-A", "10-B", "11-A", "11-B", "12-A", "12-B"]

export function PaymentLinksContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [isBulkOpen, setIsBulkOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState<string>("")
  const [selectedFeeHeads, setSelectedFeeHeads] = useState<string[]>([])
  const [customAmount, setCustomAmount] = useState(false)
  const [amount, setAmount] = useState("")
  const [expiryDays, setExpiryDays] = useState("10")
  const [description, setDescription] = useState("")
  const [sendSms, setSendSms] = useState(true)
  const [sendWhatsapp, setSendWhatsapp] = useState(true)
  const [sendEmail, setSendEmail] = useState(false)
  const [linkGenerated, setLinkGenerated] = useState(false)
  const [generatedLink, setGeneratedLink] = useState("")
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)
  const [previewLink, setPreviewLink] = useState<typeof paymentLinks[0] | null>(null)
  
  // Bulk link states
  const [bulkStep, setBulkStep] = useState(1)
  const [bulkName, setBulkName] = useState("")
  const [bulkClassFilter, setBulkClassFilter] = useState<string[]>([])
  const [bulkSelectedStudents, setBulkSelectedStudents] = useState<string[]>([])
  const [bulkFeeHeads, setBulkFeeHeads] = useState<string[]>([])
  const [bulkAmountType, setBulkAmountType] = useState<"pending" | "custom">("pending")
  const [bulkCustomAmount, setBulkCustomAmount] = useState("")
  const [bulkSendSms, setBulkSendSms] = useState(true)
  const [bulkSendWhatsapp, setBulkSendWhatsapp] = useState(true)
  const [bulkSendEmail, setBulkSendEmail] = useState(false)
  const [bulkExpiryDays, setBulkExpiryDays] = useState("10")
  const [bulkGenerating, setBulkGenerating] = useState(false)
  const [bulkComplete, setBulkComplete] = useState(false)
  const [bulkResults, setBulkResults] = useState({ total: 0, success: 0, failed: 0 })

  const filteredLinks = paymentLinks.filter(link => {
    const matchesSearch = link.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      link.studentId.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || link.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalAmount = selectedFeeHeads.reduce((sum, id) => {
    const head = feeHeads.find(h => h.id === id)
    return sum + (head?.pending || 0)
  }, 0)

  const filteredStudentsForBulk = students.filter(s => {
    if (bulkClassFilter.length === 0) return s.pendingAmount > 0
    return bulkClassFilter.includes(s.class) && s.pendingAmount > 0
  })

  const bulkTotalAmount = bulkSelectedStudents.reduce((sum, id) => {
    const student = students.find(s => s.id === id)
    return sum + (student?.pendingAmount || 0)
  }, 0)

  const handleGenerateLink = () => {
    const randomId = Math.random().toString(36).substring(2, 8)
    setGeneratedLink(`https://pay.feeflo.in/${randomId}`)
    setLinkGenerated(true)
  }

  const handleCopyLink = (link: string) => {
    navigator.clipboard.writeText(link)
  }

  const handleBulkGenerate = () => {
    setBulkGenerating(true)
    // Simulate bulk generation
    setTimeout(() => {
      setBulkGenerating(false)
      setBulkComplete(true)
      setBulkResults({
        total: bulkSelectedStudents.length,
        success: bulkSelectedStudents.length - 1,
        failed: 1,
      })
    }, 3000)
  }

  const resetBulkDialog = () => {
    setBulkStep(1)
    setBulkName("")
    setBulkClassFilter([])
    setBulkSelectedStudents([])
    setBulkFeeHeads([])
    setBulkAmountType("pending")
    setBulkCustomAmount("")
    setBulkSendSms(true)
    setBulkSendWhatsapp(true)
    setBulkSendEmail(false)
    setBulkExpiryDays("10")
    setBulkGenerating(false)
    setBulkComplete(false)
  }

  const stats = {
    total: paymentLinks.length,
    active: paymentLinks.filter(l => l.status === "active").length,
    paid: paymentLinks.filter(l => l.status === "paid").length,
    expired: paymentLinks.filter(l => l.status === "expired").length,
    totalValue: paymentLinks.filter(l => l.status === "active").reduce((sum, l) => sum + l.amount, 0),
    collected: paymentLinks.filter(l => l.status === "paid").reduce((sum, l) => sum + l.amount, 0),
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Payment Links</h1>
          <p className="text-sm text-muted-foreground">
            Create and manage payment links for students
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={isBulkOpen} onOpenChange={(open) => {
            setIsBulkOpen(open)
            if (!open) resetBulkDialog()
          }}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Users className="mr-2 h-4 w-4" />
                Bulk Create
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Bulk Payment Links</DialogTitle>
                <DialogDescription>
                  Generate payment links for multiple students at once and send via SMS, WhatsApp, or Email
                </DialogDescription>
              </DialogHeader>
              
              {!bulkComplete ? (
                <>
                  {/* Progress Steps */}
                  <div className="flex items-center justify-between py-4 border-b">
                    <div className="flex items-center gap-2">
                      <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${bulkStep >= 1 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                        1
                      </div>
                      <span className={`text-sm ${bulkStep >= 1 ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>Select Students</span>
                    </div>
                    <div className="h-px w-8 bg-border" />
                    <div className="flex items-center gap-2">
                      <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${bulkStep >= 2 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                        2
                      </div>
                      <span className={`text-sm ${bulkStep >= 2 ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>Configure Fees</span>
                    </div>
                    <div className="h-px w-8 bg-border" />
                    <div className="flex items-center gap-2">
                      <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${bulkStep >= 3 ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'}`}>
                        3
                      </div>
                      <span className={`text-sm ${bulkStep >= 3 ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>Send Options</span>
                    </div>
                  </div>

                  {bulkStep === 1 && (
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Batch Name</Label>
                        <Input 
                          placeholder="e.g., Q4 Fee Collection - Class 8"
                          value={bulkName}
                          onChange={(e) => setBulkName(e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Filter by Class</Label>
                        <div className="flex flex-wrap gap-2">
                          {["8-A", "8-B", "9-A", "9-B", "9-C", "10-A", "10-B", "11-A", "11-B", "12-A", "12-B"].map((cls) => (
                            <Badge
                              key={cls}
                              variant={bulkClassFilter.includes(cls) ? "default" : "outline"}
                              className="cursor-pointer"
                              onClick={() => {
                                if (bulkClassFilter.includes(cls)) {
                                  setBulkClassFilter(bulkClassFilter.filter(c => c !== cls))
                                } else {
                                  setBulkClassFilter([...bulkClassFilter, cls])
                                }
                              }}
                            >
                              {cls}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Select classes to filter students, or leave empty to show all with pending fees
                        </p>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label>Select Students ({bulkSelectedStudents.length} selected)</Label>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setBulkSelectedStudents(filteredStudentsForBulk.map(s => s.id))}
                            >
                              Select All
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setBulkSelectedStudents([])}
                            >
                              Clear
                            </Button>
                          </div>
                        </div>
                        <div className="rounded-lg border max-h-64 overflow-y-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead className="w-12">
                                  <Checkbox
                                    checked={bulkSelectedStudents.length === filteredStudentsForBulk.length && filteredStudentsForBulk.length > 0}
                                    onCheckedChange={(checked) => {
                                      if (checked) {
                                        setBulkSelectedStudents(filteredStudentsForBulk.map(s => s.id))
                                      } else {
                                        setBulkSelectedStudents([])
                                      }
                                    }}
                                  />
                                </TableHead>
                                <TableHead>Student</TableHead>
                                <TableHead>Class</TableHead>
                                <TableHead>Contact</TableHead>
                                <TableHead className="text-right">Pending</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {filteredStudentsForBulk.map((student) => (
                                <TableRow key={student.id}>
                                  <TableCell>
                                    <Checkbox
                                      checked={bulkSelectedStudents.includes(student.id)}
                                      onCheckedChange={(checked) => {
                                        if (checked) {
                                          setBulkSelectedStudents([...bulkSelectedStudents, student.id])
                                        } else {
                                          setBulkSelectedStudents(bulkSelectedStudents.filter(id => id !== student.id))
                                        }
                                      }}
                                    />
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Avatar className="h-8 w-8">
                                        <AvatarFallback className="text-xs bg-primary/10 text-primary">
                                          {student.name.split(" ").map(n => n[0]).join("")}
                                        </AvatarFallback>
                                      </Avatar>
                                      <div>
                                        <p className="text-sm font-medium">{student.name}</p>
                                        <p className="text-xs text-muted-foreground">{student.id}</p>
                                      </div>
                                    </div>
                                  </TableCell>
                                  <TableCell>{student.class}</TableCell>
                                  <TableCell>
                                    <div className="text-xs">
                                      <p>{student.phone}</p>
                                      <p className="text-muted-foreground">{student.email}</p>
                                    </div>
                                  </TableCell>
                                  <TableCell className="text-right font-medium">
                                    ₹{student.pendingAmount.toLocaleString()}
                                  </TableCell>
                                </TableRow>
                              ))}
                              {filteredStudentsForBulk.length === 0 && (
                                <TableRow>
                                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                                    No students with pending fees found
                                  </TableCell>
                                </TableRow>
                              )}
                            </TableBody>
                          </Table>
                        </div>
                      </div>

                      {bulkSelectedStudents.length > 0 && (
                        <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                          <div>
                            <p className="text-sm font-medium">{bulkSelectedStudents.length} students selected</p>
                            <p className="text-xs text-muted-foreground">Total pending amount</p>
                          </div>
                          <p className="text-lg font-semibold">₹{bulkTotalAmount.toLocaleString()}</p>
                        </div>
                      )}
                    </div>
                  )}

                  {bulkStep === 2 && (
                    <div className="space-y-4 py-4">
                      <div className="space-y-3">
                        <Label>Select Fee Heads to Include</Label>
                        <div className="rounded-lg border p-4 space-y-3">
                          {feeHeads.map((head) => (
                            <div key={head.id} className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <Checkbox
                                  id={`bulk-${head.id}`}
                                  checked={bulkFeeHeads.includes(head.id)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      setBulkFeeHeads([...bulkFeeHeads, head.id])
                                    } else {
                                      setBulkFeeHeads(bulkFeeHeads.filter(id => id !== head.id))
                                    }
                                  }}
                                />
                                <label htmlFor={`bulk-${head.id}`} className="text-sm font-medium cursor-pointer">
                                  {head.name}
                                </label>
                              </div>
                            </div>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Leave empty to include all pending fee heads for each student
                        </p>
                      </div>

                      <div className="space-y-3">
                        <Label>Amount Type</Label>
                        <div className="grid grid-cols-2 gap-4">
                          <div
                            className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${bulkAmountType === "pending" ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}`}
                            onClick={() => setBulkAmountType("pending")}
                          >
                            <div className="flex items-center gap-2 mb-2">
                              <IndianRupee className="h-5 w-5 text-primary" />
                              <span className="font-medium">Pending Amount</span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Use each student&apos;s actual pending fee amount
                            </p>
                          </div>
                          <div
                            className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${bulkAmountType === "custom" ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"}`}
                            onClick={() => setBulkAmountType("custom")}
                          >
                            <div className="flex items-center gap-2 mb-2">
                              <IndianRupee className="h-5 w-5 text-primary" />
                              <span className="font-medium">Fixed Amount</span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Set a fixed amount for all students
                            </p>
                          </div>
                        </div>
                      </div>

                      {bulkAmountType === "custom" && (
                        <div className="space-y-2">
                          <Label>Fixed Amount (₹)</Label>
                          <Input
                            type="number"
                            placeholder="Enter amount"
                            value={bulkCustomAmount}
                            onChange={(e) => setBulkCustomAmount(e.target.value)}
                          />
                        </div>
                      )}

                      <div className="space-y-2">
                        <Label>Link Expiry</Label>
                        <Select value={bulkExpiryDays} onValueChange={setBulkExpiryDays}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="3">3 days</SelectItem>
                            <SelectItem value="7">7 days</SelectItem>
                            <SelectItem value="10">10 days</SelectItem>
                            <SelectItem value="15">15 days</SelectItem>
                            <SelectItem value="30">30 days</SelectItem>
                            <SelectItem value="60">60 days</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  {bulkStep === 3 && (
                    <div className="space-y-4 py-4">
                      <div className="space-y-3">
                        <Label>Send Payment Links Via</Label>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100 dark:bg-green-900/30">
                                <MessageSquare className="h-5 w-5 text-green-600" />
                              </div>
                              <div>
                                <p className="font-medium">WhatsApp</p>
                                <p className="text-sm text-muted-foreground">Send via WhatsApp Business API</p>
                              </div>
                            </div>
                            <Switch
                              checked={bulkSendWhatsapp}
                              onCheckedChange={setBulkSendWhatsapp}
                            />
                          </div>
                          <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900/30">
                                <Smartphone className="h-5 w-5 text-blue-600" />
                              </div>
                              <div>
                                <p className="font-medium">SMS</p>
                                <p className="text-sm text-muted-foreground">Send via SMS gateway</p>
                              </div>
                            </div>
                            <Switch
                              checked={bulkSendSms}
                              onCheckedChange={setBulkSendSms}
                            />
                          </div>
                          <div className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-red-100 dark:bg-red-900/30">
                                <Mail className="h-5 w-5 text-red-600" />
                              </div>
                              <div>
                                <p className="font-medium">Email</p>
                                <p className="text-sm text-muted-foreground">Send to parent email</p>
                              </div>
                            </div>
                            <Switch
                              checked={bulkSendEmail}
                              onCheckedChange={setBulkSendEmail}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="p-4 bg-muted/50 rounded-lg space-y-3">
                        <h4 className="font-medium">Summary</h4>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground">Batch Name</p>
                            <p className="font-medium">{bulkName || "Unnamed Batch"}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Total Students</p>
                            <p className="font-medium">{bulkSelectedStudents.length}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Total Amount</p>
                            <p className="font-medium">
                              {bulkAmountType === "pending" 
                                ? `₹${bulkTotalAmount.toLocaleString()}` 
                                : `₹${(parseInt(bulkCustomAmount || "0") * bulkSelectedStudents.length).toLocaleString()}`}
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Channels</p>
                            <p className="font-medium">
                              {[
                                bulkSendWhatsapp && "WhatsApp",
                                bulkSendSms && "SMS",
                                bulkSendEmail && "Email"
                              ].filter(Boolean).join(", ") || "None"}
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Link Expiry</p>
                            <p className="font-medium">{bulkExpiryDays} days</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground">Fee Heads</p>
                            <p className="font-medium">
                              {bulkFeeHeads.length > 0 
                                ? bulkFeeHeads.map(id => feeHeads.find(f => f.id === id)?.name).join(", ")
                                : "All pending"}
                            </p>
                          </div>
                        </div>
                      </div>

                      {bulkGenerating && (
                        <div className="p-6 text-center space-y-4">
                          <Loader2 className="h-10 w-10 animate-spin mx-auto text-primary" />
                          <div>
                            <p className="font-medium">Generating payment links...</p>
                            <p className="text-sm text-muted-foreground">This may take a moment</p>
                          </div>
                          <Progress value={45} className="w-full" />
                        </div>
                      )}
                    </div>
                  )}

                  <DialogFooter>
                    <div className="flex items-center justify-between w-full">
                      <Button
                        variant="outline"
                        onClick={() => setBulkStep(Math.max(1, bulkStep - 1))}
                        disabled={bulkStep === 1 || bulkGenerating}
                      >
                        Back
                      </Button>
                      {bulkStep < 3 ? (
                        <Button
                          onClick={() => setBulkStep(bulkStep + 1)}
                          disabled={bulkStep === 1 && bulkSelectedStudents.length === 0}
                        >
                          Continue
                        </Button>
                      ) : (
                        <Button
                          onClick={handleBulkGenerate}
                          disabled={bulkGenerating || (!bulkSendSms && !bulkSendWhatsapp && !bulkSendEmail)}
                        >
                          {bulkGenerating ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Generating...
                            </>
                          ) : (
                            <>
                              <Send className="mr-2 h-4 w-4" />
                              Generate & Send
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </DialogFooter>
                </>
              ) : (
                <div className="py-8 text-center space-y-6">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30 mx-auto">
                    <CheckCircle2 className="h-8 w-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Bulk Links Created Successfully</h3>
                    <p className="text-muted-foreground">Payment links have been generated and sent</p>
                  </div>
                  <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <p className="text-2xl font-bold text-primary">{bulkResults.total}</p>
                      <p className="text-xs text-muted-foreground">Total Links</p>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">{bulkResults.success}</p>
                      <p className="text-xs text-muted-foreground">Sent</p>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg">
                      <p className="text-2xl font-bold text-destructive">{bulkResults.failed}</p>
                      <p className="text-xs text-muted-foreground">Failed</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-center gap-2">
                    <Button variant="outline" onClick={() => setIsBulkOpen(false)}>
                      Close
                    </Button>
                    <Button variant="outline">
                      <FileDown className="mr-2 h-4 w-4" />
                      Download Report
                    </Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
          
          <Dialog open={isCreateOpen} onOpenChange={(open) => {
            setIsCreateOpen(open)
            if (!open) {
              setSelectedStudent("")
              setSelectedFeeHeads([])
              setCustomAmount(false)
              setAmount("")
              setDescription("")
              setLinkGenerated(false)
              setGeneratedLink("")
            }
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Link
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Payment Link</DialogTitle>
                <DialogDescription>
                  Generate a payment link for a specific student and fee heads
                </DialogDescription>
              </DialogHeader>
              
              {!linkGenerated ? (
                <div className="space-y-6 py-4">
                  <div className="space-y-2">
                    <Label>Select Student</Label>
                    <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                      <SelectTrigger>
                        <SelectValue placeholder="Search and select student" />
                      </SelectTrigger>
                      <SelectContent>
                        {students.map((student) => (
                          <SelectItem key={student.id} value={student.id}>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{student.name}</span>
                              <span className="text-muted-foreground">({student.class})</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedStudent && (
                    <>
                      <div className="space-y-3">
                        <Label>Select Fee Heads</Label>
                        <div className="rounded-lg border p-4 space-y-3">
                          {feeHeads.map((head) => (
                            <div key={head.id} className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <Checkbox
                                  id={head.id}
                                  checked={selectedFeeHeads.includes(head.id)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      setSelectedFeeHeads([...selectedFeeHeads, head.id])
                                    } else {
                                      setSelectedFeeHeads(selectedFeeHeads.filter(id => id !== head.id))
                                    }
                                  }}
                                />
                                <label htmlFor={head.id} className="text-sm font-medium cursor-pointer">
                                  {head.name}
                                </label>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                Pending: ₹{head.pending.toLocaleString()}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                        <span className="font-medium">Total Amount</span>
                        <span className="text-lg font-semibold">₹{totalAmount.toLocaleString()}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <Switch
                          id="custom-amount"
                          checked={customAmount}
                          onCheckedChange={setCustomAmount}
                        />
                        <Label htmlFor="custom-amount">Use custom amount (partial payment)</Label>
                      </div>

                      {customAmount && (
                        <div className="space-y-2">
                          <Label>Custom Amount (₹)</Label>
                          <Input
                            type="number"
                            placeholder="Enter amount"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                          />
                        </div>
                      )}

                      <div className="space-y-2">
                        <Label>Description (Optional)</Label>
                        <Textarea
                          placeholder="Add a note for the parent..."
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Link Expiry</Label>
                        <Select value={expiryDays} onValueChange={setExpiryDays}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="3">3 days</SelectItem>
                            <SelectItem value="7">7 days</SelectItem>
                            <SelectItem value="10">10 days</SelectItem>
                            <SelectItem value="15">15 days</SelectItem>
                            <SelectItem value="30">30 days</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-3">
                        <Label>Send Via</Label>
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2">
                            <Checkbox
                              id="sms"
                              checked={sendSms}
                              onCheckedChange={(checked) => setSendSms(!!checked)}
                            />
                            <label htmlFor="sms" className="text-sm flex items-center gap-1">
                              <Smartphone className="h-4 w-4" />
                              SMS
                            </label>
                          </div>
                          <div className="flex items-center gap-2">
                            <Checkbox
                              id="whatsapp"
                              checked={sendWhatsapp}
                              onCheckedChange={(checked) => setSendWhatsapp(!!checked)}
                            />
                            <label htmlFor="whatsapp" className="text-sm flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              WhatsApp
                            </label>
                          </div>
                          <div className="flex items-center gap-2">
                            <Checkbox
                              id="email"
                              checked={sendEmail}
                              onCheckedChange={(checked) => setSendEmail(!!checked)}
                            />
                            <label htmlFor="email" className="text-sm flex items-center gap-1">
                              <Mail className="h-4 w-4" />
                              Email
                            </label>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="py-8 text-center space-y-6">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30 mx-auto">
                    <CheckCircle2 className="h-8 w-8 text-green-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">Payment Link Created</h3>
                    <p className="text-muted-foreground">Link has been sent to the parent</p>
                  </div>
                  <div className="flex items-center gap-2 p-3 bg-muted rounded-lg max-w-md mx-auto">
                    <Input value={generatedLink} readOnly className="bg-background" />
                    <Button variant="outline" size="icon" onClick={() => handleCopyLink(generatedLink)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                    {sendSms && (
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        SMS Sent
                      </span>
                    )}
                    {sendWhatsapp && (
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        WhatsApp Sent
                      </span>
                    )}
                    {sendEmail && (
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        Email Sent
                      </span>
                    )}
                  </div>
                </div>
              )}

              <DialogFooter>
                {!linkGenerated ? (
                  <Button
                    onClick={handleGenerateLink}
                    disabled={!selectedStudent || selectedFeeHeads.length === 0}
                  >
                    <Link2 className="mr-2 h-4 w-4" />
                    Generate Link
                  </Button>
                ) : (
                  <Button onClick={() => setIsCreateOpen(false)}>
                    Done
                  </Button>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Links</p>
                <p className="text-2xl font-bold">{stats.active}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <Link2 className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Paid</p>
                <p className="text-2xl font-bold">{stats.paid}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Value</p>
                <p className="text-2xl font-bold">₹{(stats.totalValue / 1000).toFixed(0)}K</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-yellow-100 dark:bg-yellow-900/30">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Collected</p>
                <p className="text-2xl font-bold">₹{(stats.collected / 1000).toFixed(0)}K</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                <IndianRupee className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="links" className="space-y-4">
        <TabsList>
          <TabsTrigger value="links">Payment Links</TabsTrigger>
          <TabsTrigger value="batches">Bulk Batches</TabsTrigger>
        </TabsList>

        <TabsContent value="links" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by student name or ID..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="expired">Expired</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="icon">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Links Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Fee Heads</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Expires</TableHead>
                    <TableHead>Sent Via</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLinks.map((link) => (
                    <TableRow key={link.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{link.studentName}</p>
                          <p className="text-xs text-muted-foreground">{link.class}</p>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">
                        ₹{link.amount.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1 max-w-[150px]">
                          {link.feeHeads.slice(0, 2).map((head, i) => (
                            <Badge key={i} variant="secondary" className="text-xs">
                              {head}
                            </Badge>
                          ))}
                          {link.feeHeads.length > 2 && (
                            <Badge variant="secondary" className="text-xs">
                              +{link.feeHeads.length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{link.createdAt}</TableCell>
                      <TableCell className="text-sm">{link.expiresAt}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {link.sentVia.includes("sms") && (
                            <Smartphone className="h-4 w-4 text-blue-500" />
                          )}
                          {link.sentVia.includes("whatsapp") && (
                            <MessageSquare className="h-4 w-4 text-green-500" />
                          )}
                          {link.sentVia.includes("email") && (
                            <Mail className="h-4 w-4 text-red-500" />
                          )}
                          {link.sentVia.length === 0 && (
                            <span className="text-xs text-muted-foreground">Not sent</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            link.status === "paid"
                              ? "default"
                              : link.status === "active"
                              ? "secondary"
                              : "destructive"
                          }
                          className={
                            link.status === "paid"
                              ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                              : ""
                          }
                        >
                          {link.status === "paid" && <CheckCircle2 className="mr-1 h-3 w-3" />}
                          {link.status === "active" && <Clock className="mr-1 h-3 w-3" />}
                          {link.status === "expired" && <XCircle className="mr-1 h-3 w-3" />}
                          {link.status.charAt(0).toUpperCase() + link.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleCopyLink(link.shortUrl)}>
                              <Copy className="mr-2 h-4 w-4" />
                              Copy Link
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <QrCode className="mr-2 h-4 w-4" />
                              Show QR Code
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <MessageSquare className="mr-2 h-4 w-4" />
                              Resend WhatsApp
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Smartphone className="mr-2 h-4 w-4" />
                              Resend SMS
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Mail className="mr-2 h-4 w-4" />
                              Resend Email
                            </DropdownMenuItem>
                            {link.status === "expired" && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <RefreshCw className="mr-2 h-4 w-4" />
                                  Regenerate Link
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="batches" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bulk Payment Link Batches</CardTitle>
              <CardDescription>
                Track and manage bulk payment link campaigns
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Batch Name</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Total Amount</TableHead>
                    <TableHead>Delivery</TableHead>
                    <TableHead>Collection</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bulkBatches.map((batch) => (
                    <TableRow key={batch.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{batch.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {batch.feeHeads.join(", ")}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{batch.createdAt}</TableCell>
                      <TableCell>{batch.totalStudents}</TableCell>
                      <TableCell className="font-medium">
                        ₹{(batch.totalAmount / 100000).toFixed(1)}L
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Progress 
                              value={(batch.delivered / batch.sent) * 100} 
                              className="w-16 h-2" 
                            />
                            <span className="text-xs text-muted-foreground">
                              {batch.delivered}/{batch.sent}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            {batch.channels.includes("sms") && (
                              <Smartphone className="h-3 w-3 text-blue-500" />
                            )}
                            {batch.channels.includes("whatsapp") && (
                              <MessageSquare className="h-3 w-3 text-green-500" />
                            )}
                            {batch.channels.includes("email") && (
                              <Mail className="h-3 w-3 text-red-500" />
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Progress 
                              value={(batch.paid / batch.totalStudents) * 100} 
                              className="w-16 h-2" 
                            />
                            <span className="text-xs text-muted-foreground">
                              {batch.paid}/{batch.totalStudents}
                            </span>
                          </div>
                          <span className="text-xs text-green-600">
                            {Math.round((batch.paid / batch.totalStudents) * 100)}% collected
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={batch.status === "completed" ? "default" : "secondary"}
                          className={
                            batch.status === "completed"
                              ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                              : ""
                          }
                        >
                          {batch.status === "completed" ? "Completed" : "Active"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <FileDown className="mr-2 h-4 w-4" />
                              Download Report
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Send className="mr-2 h-4 w-4" />
                              Resend to Unpaid
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <RefreshCw className="mr-2 h-4 w-4" />
                              Regenerate Expired
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
