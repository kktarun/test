"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  MessageSquare,
  Mail,
  Smartphone,
  Send,
  Plus,
  Clock,
  CheckCircle2,
  XCircle,
  Users,
  FileText,
  Edit2,
  Trash2,
  Copy,
  Eye,
  Wallet,
} from "lucide-react"

const communicationStats = [
  { label: "SMS Balance", value: "2,450", icon: Smartphone, color: "text-blue-600 dark:text-blue-400" },
  { label: "WhatsApp Balance", value: "1,800", icon: MessageSquare, color: "text-green-600 dark:text-green-400" },
  { label: "Email Balance", value: "5,000", icon: Mail, color: "text-orange-600 dark:text-orange-400" },
  { label: "Total Sent (This Month)", value: "856", icon: Send, color: "text-primary" },
]

const templates = [
  {
    id: 1,
    name: "Fee Due Reminder",
    type: "SMS",
    status: "approved",
    content: "Dear Parent, fee dues of Rs. {amount} for {student_name} is pending. Please pay before {due_date}. - FeeFlo",
    lastUsed: "2024-03-08",
    sentCount: 245,
  },
  {
    id: 2,
    name: "Payment Confirmation",
    type: "WhatsApp",
    status: "approved",
    content: "Thank you for paying Rs. {amount} for {student_name}. Receipt No: {receipt_no}. Download: {link}",
    lastUsed: "2024-03-10",
    sentCount: 156,
  },
  {
    id: 3,
    name: "Overdue Notice",
    type: "Email",
    status: "pending",
    content: "Dear Parent,\n\nThis is to inform you that fee payment for your ward {student_name} is overdue by {days} days...",
    lastUsed: null,
    sentCount: 0,
  },
  {
    id: 4,
    name: "Installment Reminder",
    type: "SMS",
    status: "approved",
    content: "Reminder: Installment {installment_no} of Rs. {amount} for {student_name} is due on {due_date}. - FeeFlo",
    lastUsed: "2024-03-05",
    sentCount: 89,
  },
]

const reminderHistory = [
  { id: 1, type: "SMS", recipients: 156, sent: "2024-03-10 10:30 AM", status: "delivered", template: "Fee Due Reminder" },
  { id: 2, type: "WhatsApp", recipients: 89, sent: "2024-03-09 02:15 PM", status: "delivered", template: "Payment Confirmation" },
  { id: 3, type: "Email", recipients: 45, sent: "2024-03-08 09:00 AM", status: "partial", template: "Overdue Notice" },
  { id: 4, type: "SMS", recipients: 234, sent: "2024-03-07 11:45 AM", status: "delivered", template: "Fee Due Reminder" },
  { id: 5, type: "WhatsApp", recipients: 67, sent: "2024-03-06 04:30 PM", status: "failed", template: "Installment Reminder" },
]

export function RemindersContent() {
  const [activeTab, setActiveTab] = useState("templates")
  const [showNewTemplate, setShowNewTemplate] = useState(false)
  const [showSendReminder, setShowSendReminder] = useState(false)
  const [selectedTemplate, setSelectedTemplate] = useState<typeof templates[0] | null>(null)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Reminders & Communication</h1>
          <p className="text-sm text-muted-foreground">
            Send fee reminders via SMS, WhatsApp, and Email
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Wallet className="h-4 w-4" />
            Recharge Wallet
          </Button>
          <Button className="gap-2" onClick={() => setShowSendReminder(true)}>
            <Send className="h-4 w-4" />
            Send Reminder
          </Button>
        </div>
      </div>

      {/* Communication Wallet Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {communicationStats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
                <div className={`rounded-lg bg-muted p-2.5 ${stat.color}`}>
                  <stat.icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="templates" className="gap-2">
            <FileText className="h-4 w-4" />
            Templates
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <Clock className="h-4 w-4" />
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-4">
              <div>
                <CardTitle className="text-base font-medium">Message Templates</CardTitle>
                <CardDescription>Create and manage reminder templates</CardDescription>
              </div>
              <Button size="sm" className="gap-2" onClick={() => setShowNewTemplate(true)}>
                <Plus className="h-4 w-4" />
                New Template
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Template Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Used</TableHead>
                    <TableHead>Sent Count</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {templates.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{template.name}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1 max-w-xs">
                            {template.content}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-normal">
                          {template.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={template.status === "approved" ? "default" : "secondary"}
                          className={template.status === "approved" ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" : ""}
                        >
                          {template.status === "approved" ? "Approved" : "Pending Approval"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {template.lastUsed || "Never"}
                      </TableCell>
                      <TableCell>{template.sentCount.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-base font-medium">Reminder History</CardTitle>
              <CardDescription>View all sent reminders and their delivery status</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Template</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Recipients</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reminderHistory.map((reminder) => (
                    <TableRow key={reminder.id}>
                      <TableCell className="text-muted-foreground">{reminder.sent}</TableCell>
                      <TableCell className="font-medium">{reminder.template}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="font-normal">
                          {reminder.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Users className="h-3.5 w-3.5 text-muted-foreground" />
                          {reminder.recipients}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            reminder.status === "delivered"
                              ? "border-green-200 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-900/30 dark:text-green-400"
                              : reminder.status === "partial"
                              ? "border-yellow-200 bg-yellow-50 text-yellow-700 dark:border-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
                              : "border-red-200 bg-red-50 text-red-700 dark:border-red-800 dark:bg-red-900/30 dark:text-red-400"
                          }
                        >
                          {reminder.status === "delivered" && <CheckCircle2 className="mr-1 h-3 w-3" />}
                          {reminder.status === "partial" && <Clock className="mr-1 h-3 w-3" />}
                          {reminder.status === "failed" && <XCircle className="mr-1 h-3 w-3" />}
                          {reminder.status.charAt(0).toUpperCase() + reminder.status.slice(1)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* New Template Dialog */}
      <Dialog open={showNewTemplate} onOpenChange={setShowNewTemplate}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Template</DialogTitle>
            <DialogDescription>
              Create a message template for fee reminders. Templates require approval before use.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Template Name</Label>
              <Input placeholder="e.g., Monthly Fee Reminder" />
            </div>
            <div className="space-y-2">
              <Label>Channel</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select channel" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Message Content</Label>
              <Textarea
                placeholder="Enter your message. Use {student_name}, {amount}, {due_date}, {receipt_no}, {link} as placeholders."
                rows={4}
              />
              <p className="text-xs text-muted-foreground">
                Available variables: {"{student_name}"}, {"{amount}"}, {"{due_date}"}, {"{receipt_no}"}, {"{link}"}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewTemplate(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowNewTemplate(false)}>
              Submit for Approval
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send Reminder Dialog */}
      <Dialog open={showSendReminder} onOpenChange={setShowSendReminder}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Send Reminder</DialogTitle>
            <DialogDescription>
              Select recipients and template to send fee reminders
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Select Template</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a template" />
                </SelectTrigger>
                <SelectContent>
                  {templates
                    .filter((t) => t.status === "approved")
                    .map((template) => (
                      <SelectItem key={template.id} value={template.id.toString()}>
                        {template.name} ({template.type})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Recipients</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select recipient group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-dues">All Students with Dues</SelectItem>
                  <SelectItem value="overdue">Overdue Only (30+ days)</SelectItem>
                  <SelectItem value="upcoming">Upcoming Due (Next 7 days)</SelectItem>
                  <SelectItem value="class-10">Class 10 Students</SelectItem>
                  <SelectItem value="custom">Custom Selection</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-lg border bg-muted/30 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Selected Recipients</span>
                <span className="font-medium">156 students</span>
              </div>
              <div className="flex items-center justify-between text-sm mt-2">
                <span className="text-muted-foreground">Estimated Cost</span>
                <span className="font-medium">156 SMS credits</span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSendReminder(false)}>
              Cancel
            </Button>
            <Button className="gap-2" onClick={() => setShowSendReminder(false)}>
              <Send className="h-4 w-4" />
              Send Reminders
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
