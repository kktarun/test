"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  IndianRupee, 
  Users, 
  TrendingUp, 
  AlertCircle, 
  CreditCard, 
  Link2, 
  ArrowRight,
  CheckCircle2,
  Clock,
  XCircle,
  Bell,
  GraduationCap,
  BookOpen,
  ArrowUpRight,
  Repeat,
  Eye
} from "lucide-react"
import { 
  getFeeCollectionStats, 
  studentsWithFees, 
  feeStructures, 
  paymentLinks,
  scholarships,
  unifiedTransactions
} from "@/lib/shared-data"
import Link from "next/link"

const formatCurrency = (amount: number) => {
  if (amount >= 10000000) return `${(amount / 10000000).toFixed(2)} Cr`
  if (amount >= 100000) return `${(amount / 100000).toFixed(1)} L`
  if (amount >= 1000) return `${(amount / 1000).toFixed(1)} K`
  return amount.toLocaleString()
}

export function FeesDashboard() {
  const stats = getFeeCollectionStats()

  // Get recent fee-related transactions from the unified transactions
  const recentFeeTransactions = unifiedTransactions
    .filter(t => t.feeType && t.status === "success")
    .slice(0, 5)

  const statCards = [
    {
      title: "Total Fees",
      value: `₹${formatCurrency(stats.totalFees)}`,
      subtitle: `${stats.totalStudents} students`,
      icon: IndianRupee,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      href: "/fees/students",
    },
    {
      title: "Collected",
      value: `₹${formatCurrency(stats.collectedAmount)}`,
      subtitle: `${stats.collectionRate}% collection rate`,
      icon: CheckCircle2,
      color: "text-green-600",
      bgColor: "bg-green-50",
      href: "/transactions",
    },
    {
      title: "Pending",
      value: `₹${formatCurrency(stats.pendingAmount)}`,
      subtitle: `${stats.pendingStudents + stats.partialStudents} students`,
      icon: Clock,
      color: "text-amber-600",
      bgColor: "bg-amber-50",
      href: "/fees/students?status=pending",
    },
    {
      title: "Overdue",
      value: `${stats.overdueStudents}`,
      subtitle: "students with overdue fees",
      icon: AlertCircle,
      color: "text-red-600",
      bgColor: "bg-red-50",
      href: "/fees/students?status=overdue",
    },
  ]

  const quickActions = [
    {
      title: "Collect Now",
      description: "Collect fee from a student",
      href: "/fees/collect",
      icon: CreditCard,
      color: "bg-primary text-primary-foreground hover:bg-primary/90",
    },
    {
      title: "Send Payment Link",
      description: "Create and send payment links",
      href: "/fees/payment-links",
      icon: Link2,
      color: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    },
    {
      title: "Send Reminder",
      description: "Notify parents about dues",
      href: "/fees/reminders",
      icon: Bell,
      color: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
    },
  ]

  // Get recent payments using students with recent payments
  const recentPayments = studentsWithFees
    .filter(s => s.paidAmount > 0)
    .slice(0, 5)
    .map(s => ({
      id: s.id,
      studentName: s.name,
      class: `${s.class} ${s.division}`,
      amount: s.paidAmount,
      date: s.lastPaymentDate || "2024-03-15",
      status: "success" as const,
    }))

  // Fee status distribution for chart
  const feeStatusData = [
    { status: "Paid", count: stats.paidStudents, color: "bg-green-500" },
    { status: "Partial", count: stats.partialStudents, color: "bg-amber-500" },
    { status: "Pending", count: stats.pendingStudents, color: "bg-blue-500" },
    { status: "Overdue", count: stats.overdueStudents, color: "bg-red-500" },
  ]

  const totalForPercentage = stats.paidStudents + stats.partialStudents + stats.pendingStudents + stats.overdueStudents

  // Module links for navigation
  const moduleLinks = [
    {
      title: "Students",
      description: "Manage student fee records",
      href: "/fees/students",
      icon: Users,
      stats: `${stats.totalStudents} students`,
    },
    {
      title: "Fee Structure",
      description: "Configure fee heads & structures",
      href: "/fees/structure",
      icon: BookOpen,
      stats: `${feeStructures.length} structures`,
    },
    {
      title: "Payment Links",
      description: "Create & track payment links",
      href: "/fees/payment-links",
      icon: Link2,
      stats: `${stats.activePaymentLinks} active`,
    },
    {
      title: "Scholarships",
      description: "Manage scholarships & discounts",
      href: "/fees/scholarships",
      icon: GraduationCap,
      stats: `${scholarships.filter(s => s.isActive).length} active`,
    },
    {
      title: "Reminders",
      description: "Send fee notifications",
      href: "/fees/reminders",
      icon: Bell,
      stats: "Templates & automation",
    },
    {
      title: "Auto Debit",
      description: "Manage autopay mandates",
      href: "/auto-debit",
      icon: Repeat,
      stats: "NACH & UPI AutoPay",
    },
  ]

  return (
    <div className="flex flex-col gap-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Fee Collection Dashboard</h1>
          <p className="text-sm text-muted-foreground">Academic Year 2024-25</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" asChild>
            <Link href="/fees/structure">
              <BookOpen className="mr-2 h-4 w-4" />
              Fee Structure
            </Link>
          </Button>
          <Button asChild>
            <Link href="/fees/collect">
              <CreditCard className="mr-2 h-4 w-4" />
              Collect Fee
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => (
          <Link key={stat.title} href={stat.href}>
            <Card className="transition-colors hover:border-primary/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <p className="mt-1 text-2xl font-bold">{stat.value}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{stat.subtitle}</p>
                  </div>
                  <div className={`flex h-12 w-12 items-center justify-center rounded-full ${stat.bgColor}`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Quick Actions */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {quickActions.map((action) => (
              <Link
                key={action.title}
                href={action.href}
                className={`flex items-center justify-between rounded-lg p-4 transition-colors ${action.color}`}
              >
                <div className="flex items-center gap-3">
                  <action.icon className="h-5 w-5" />
                  <div>
                    <p className="font-medium">{action.title}</p>
                    <p className="text-xs opacity-80">{action.description}</p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4" />
              </Link>
            ))}
          </CardContent>
        </Card>

        {/* Fee Status Distribution */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Fee Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {feeStatusData.map((item) => (
                <div key={item.status}>
                  <div className="mb-1 flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{item.status}</span>
                    <span className="font-medium">{item.count} students</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-secondary">
                    <div
                      className={`h-full ${item.color}`}
                      style={{ width: `${(item.count / totalForPercentage) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex items-center justify-between border-t pt-4">
              <span className="text-sm text-muted-foreground">Total Students</span>
              <span className="text-lg font-bold">{totalForPercentage}</span>
            </div>
          </CardContent>
        </Card>

        {/* Active Payment Links */}
        <Card className="lg:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Active Payment Links</CardTitle>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/fees/payment-links">View All</Link>
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {paymentLinks.slice(0, 4).map((link) => (
                <div key={link.id} className="flex items-center justify-between">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{link.student.name}</p>
                    <p className="text-xs text-muted-foreground">{link.student.class}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">₹{link.amount.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">
                      {link.viewCount > 0 ? `${link.viewCount} views` : "Not viewed"}
                    </p>
                  </div>
                </div>
              ))}
              {paymentLinks.length === 0 && (
                <p className="text-center text-sm text-muted-foreground">No active payment links</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Module Navigation */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Fee Collection Modules</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {moduleLinks.map((module) => (
              <Link
                key={module.title}
                href={module.href}
                className="flex items-center gap-4 rounded-lg border p-4 transition-colors hover:bg-secondary/50"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <module.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium">{module.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{module.description}</p>
                </div>
                <div className="text-right">
                  <Badge variant="secondary" className="text-xs">{module.stats}</Badge>
                </div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Payments - Linked to Transactions */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Recent Fee Payments</CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/transactions">
              View All Transactions
              <ArrowUpRight className="ml-1 h-3 w-3" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-muted-foreground">
                  <th className="pb-3 font-medium">Student</th>
                  <th className="pb-3 font-medium">Fee Type</th>
                  <th className="pb-3 font-medium">Amount</th>
                  <th className="pb-3 font-medium">Payment Mode</th>
                  <th className="pb-3 font-medium">Date</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {recentFeeTransactions.length > 0 ? (
                  recentFeeTransactions.map((txn) => (
                    <tr key={txn.id} className="text-sm">
                      <td className="py-3">
                        <div>
                          <p className="font-medium">{txn.student.name}</p>
                          <p className="text-xs text-muted-foreground">{txn.student.class}</p>
                        </div>
                      </td>
                      <td className="py-3 text-muted-foreground">{txn.feeType}</td>
                      <td className="py-3 font-semibold">₹{txn.orderAmount.toLocaleString()}</td>
                      <td className="py-3">
                        <Badge variant="outline" className="text-xs">{txn.paymentMode}</Badge>
                      </td>
                      <td className="py-3 text-muted-foreground">{txn.date}</td>
                      <td className="py-3">
                        <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700">
                          <CheckCircle2 className="h-3 w-3" />
                          Success
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/transactions/${txn.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  recentPayments.map((payment) => (
                    <tr key={payment.id} className="text-sm">
                      <td className="py-3 font-medium">{payment.studentName}</td>
                      <td className="py-3 text-muted-foreground">{payment.class}</td>
                      <td className="py-3 font-semibold">₹{payment.amount.toLocaleString()}</td>
                      <td className="py-3">
                        <Badge variant="outline" className="text-xs">Online</Badge>
                      </td>
                      <td className="py-3 text-muted-foreground">{payment.date}</td>
                      <td className="py-3">
                        <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2 py-1 text-xs font-medium text-green-700">
                          <CheckCircle2 className="h-3 w-3" />
                          Success
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <Button variant="ghost" size="icon">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Fee Structures Overview */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Active Fee Structures</CardTitle>
          <Button variant="ghost" size="sm" asChild>
            <Link href="/fees/structure">Manage Structures</Link>
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {feeStructures.filter(fs => fs.status === "active").map((structure) => (
              <div
                key={structure.id}
                className="rounded-lg border bg-card p-4"
              >
                <h3 className="font-medium">{structure.name}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{structure.classes.join(", ")}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total Fee</span>
                  <span className="font-semibold">₹{structure.totalAmount.toLocaleString()}</span>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Fee Heads</span>
                  <span className="text-sm">{structure.feeHeads.length}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
