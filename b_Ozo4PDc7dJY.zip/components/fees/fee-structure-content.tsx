"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Copy, 
  FileDown, 
  MoreHorizontal,
  CheckCircle2,
  Clock,
  XCircle,
  Eye,
  Send,
  GitBranch,
  ChevronDown,
  ChevronRight,
  IndianRupee,
  Users,
  Calendar,
  AlertCircle,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Checkbox } from "@/components/ui/checkbox"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

// Master Fee Heads - defined in Fee Heads page with amounts and due dates
// This is the single source of truth for fee configuration
const masterFeeHeads = [
  { 
    id: "FH001", 
    name: "Tuition Fee", 
    code: "TUI", 
    frequency: "Quarterly", 
    amount: 7500, 
    dueDate: "10th of quarter month",
    isMandatory: true,
    allowPartial: true,
    finePerDay: 50,
    status: "active"
  },
  { 
    id: "FH002", 
    name: "Admission Fee", 
    code: "ADM", 
    frequency: "One-time", 
    amount: 5000, 
    dueDate: "At admission",
    isMandatory: true,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
  { 
    id: "FH003", 
    name: "Activity Fee", 
    code: "ACT", 
    frequency: "Annual", 
    amount: 3000, 
    dueDate: "April 30",
    isMandatory: true,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
  { 
    id: "FH004", 
    name: "Library Fee", 
    code: "LIB", 
    frequency: "Annual", 
    amount: 2000, 
    dueDate: "April 15",
    isMandatory: true,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
  { 
    id: "FH005", 
    name: "Lab Fee", 
    code: "LAB", 
    frequency: "Annual", 
    amount: 4000, 
    dueDate: "May 15",
    isMandatory: true,
    allowPartial: true,
    finePerDay: 30,
    status: "active"
  },
  { 
    id: "FH006", 
    name: "Computer Lab Fee", 
    code: "COMP", 
    frequency: "Annual", 
    amount: 3500, 
    dueDate: "May 15",
    isMandatory: true,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
  { 
    id: "FH007", 
    name: "Sports Fee", 
    code: "SPT", 
    frequency: "Annual", 
    amount: 2500, 
    dueDate: "April 30",
    isMandatory: true,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
  { 
    id: "FH008", 
    name: "Exam Fee", 
    code: "EXM", 
    frequency: "Half-yearly", 
    amount: 1500, 
    dueDate: "Before exam",
    isMandatory: true,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
  { 
    id: "FH009", 
    name: "Development Fee", 
    code: "DEV", 
    frequency: "Annual", 
    amount: 3000, 
    dueDate: "April 30",
    isMandatory: true,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
  { 
    id: "FH010", 
    name: "Science Lab Fee", 
    code: "SCI", 
    frequency: "Annual", 
    amount: 5000, 
    dueDate: "May 15",
    isMandatory: true,
    allowPartial: true,
    finePerDay: 30,
    status: "active"
  },
  { 
    id: "FH011", 
    name: "Smart Class Fee", 
    code: "SMT", 
    frequency: "Annual", 
    amount: 2500, 
    dueDate: "April 30",
    isMandatory: false,
    allowPartial: false,
    finePerDay: 0,
    status: "active"
  },
]

// Fee Structures - link fee heads to classes
// amountOverride is optional - if null, uses master fee head amount
const feeStructures = [
  {
    id: "FS001",
    name: "Primary Classes (1-5)",
    classes: ["1", "2", "3", "4", "5"],
    academicYear: "2024-25",
    status: "active",
    approvalStatus: "approved",
    students: 450,
    createdBy: "Admin",
    approvedBy: "Principal",
    installmentPlan: "IP001",
    feeHeads: [
      { feeHeadId: "FH001", amountOverride: 6000 }, // Lower tuition for primary
      { feeHeadId: "FH002", amountOverride: null }, // Uses master: 5000
      { feeHeadId: "FH003", amountOverride: 2500 }, // Lower activity fee
      { feeHeadId: "FH004", amountOverride: 1500 }, // Lower library fee
      { feeHeadId: "FH006", amountOverride: 2000 }, // Lower computer fee
      { feeHeadId: "FH007", amountOverride: 1500 }, // Lower sports fee
      { feeHeadId: "FH008", amountOverride: 1000 }, // Lower exam fee
      { feeHeadId: "FH009", amountOverride: 2500 }, // Lower dev fee
    ],
  },
  {
    id: "FS002",
    name: "Middle School (6-8)",
    classes: ["6", "7", "8"],
    academicYear: "2024-25",
    status: "active",
    approvalStatus: "approved",
    students: 320,
    createdBy: "Admin",
    approvedBy: "Principal",
    installmentPlan: "IP001",
    feeHeads: [
      { feeHeadId: "FH001", amountOverride: null }, // Uses master: 7500
      { feeHeadId: "FH002", amountOverride: null }, // Uses master: 5000
      { feeHeadId: "FH003", amountOverride: null }, // Uses master: 3000
      { feeHeadId: "FH004", amountOverride: null }, // Uses master: 2000
      { feeHeadId: "FH005", amountOverride: 3500 }, // Lab fee for middle school
      { feeHeadId: "FH006", amountOverride: null }, // Uses master: 3500
      { feeHeadId: "FH007", amountOverride: null }, // Uses master: 2500
      { feeHeadId: "FH008", amountOverride: null }, // Uses master: 1500
      { feeHeadId: "FH009", amountOverride: null }, // Uses master: 3000
    ],
  },
  {
    id: "FS003",
    name: "Secondary (9-10)",
    classes: ["9", "10"],
    academicYear: "2024-25",
    status: "active",
    approvalStatus: "approved",
    students: 280,
    createdBy: "Admin",
    approvedBy: "Principal",
    installmentPlan: "IP002",
    feeHeads: [
      { feeHeadId: "FH001", amountOverride: 9000 }, // Higher tuition
      { feeHeadId: "FH002", amountOverride: 6000 }, // Higher admission
      { feeHeadId: "FH003", amountOverride: 3500 },
      { feeHeadId: "FH004", amountOverride: 2500 },
      { feeHeadId: "FH005", amountOverride: 5000 }, // More lab work
      { feeHeadId: "FH006", amountOverride: 4000 },
      { feeHeadId: "FH007", amountOverride: 3000 },
      { feeHeadId: "FH008", amountOverride: 2000 },
      { feeHeadId: "FH009", amountOverride: 4000 },
      { feeHeadId: "FH010", amountOverride: 4000 }, // Science lab
    ],
  },
  {
    id: "FS004",
    name: "Senior Secondary - Science (11-12)",
    classes: ["11-Sci", "12-Sci"],
    academicYear: "2024-25",
    status: "draft",
    approvalStatus: "pending_approver",
    students: 180,
    createdBy: "Finance Team",
    approvedBy: null,
    installmentPlan: "IP002",
    feeHeads: [
      { feeHeadId: "FH001", amountOverride: 12000 },
      { feeHeadId: "FH002", amountOverride: 8000 },
      { feeHeadId: "FH003", amountOverride: 4000 },
      { feeHeadId: "FH004", amountOverride: 3000 },
      { feeHeadId: "FH005", amountOverride: 8000 }, // Higher lab fees
      { feeHeadId: "FH006", amountOverride: 5000 },
      { feeHeadId: "FH007", amountOverride: 3500 },
      { feeHeadId: "FH008", amountOverride: 2500 },
      { feeHeadId: "FH009", amountOverride: 5000 },
      { feeHeadId: "FH010", amountOverride: 6000 }, // Science lab
      { feeHeadId: "FH011", amountOverride: null }, // Smart class
    ],
  },
  {
    id: "FS005",
    name: "Senior Secondary - Commerce (11-12)",
    classes: ["11-Com", "12-Com"],
    academicYear: "2024-25",
    status: "draft",
    approvalStatus: "pending_checker",
    students: 150,
    createdBy: "Finance Team",
    approvedBy: null,
    installmentPlan: "IP002",
    feeHeads: [
      { feeHeadId: "FH001", amountOverride: 10000 },
      { feeHeadId: "FH002", amountOverride: 7000 },
      { feeHeadId: "FH003", amountOverride: 3500 },
      { feeHeadId: "FH004", amountOverride: 2500 },
      { feeHeadId: "FH006", amountOverride: 4500 },
      { feeHeadId: "FH007", amountOverride: 3000 },
      { feeHeadId: "FH008", amountOverride: 2000 },
      { feeHeadId: "FH009", amountOverride: 4500 },
      { feeHeadId: "FH011", amountOverride: null }, // Smart class
    ],
  },
]

// Installment Plans
const installmentPlans = [
  {
    id: "IP001",
    name: "Quarterly Plan",
    installments: [
      { name: "Q1 (Apr-Jun)", percentage: 25, dueDate: "April 10" },
      { name: "Q2 (Jul-Sep)", percentage: 25, dueDate: "July 10" },
      { name: "Q3 (Oct-Dec)", percentage: 25, dueDate: "October 10" },
      { name: "Q4 (Jan-Mar)", percentage: 25, dueDate: "January 10" },
    ],
  },
  {
    id: "IP002",
    name: "Half-Yearly Plan",
    installments: [
      { name: "Term 1 (Apr-Sep)", percentage: 50, dueDate: "April 10" },
      { name: "Term 2 (Oct-Mar)", percentage: 50, dueDate: "October 10" },
    ],
  },
  {
    id: "IP003",
    name: "Annual (One-time)",
    installments: [
      { name: "Full Year", percentage: 100, dueDate: "April 30" },
    ],
  },
]

const pendingApprovals = [
  {
    id: "PA001",
    structureId: "FS004",
    structureName: "Senior Secondary - Science (11-12)",
    action: "Create",
    changes: "New structure with 11 fee heads",
    submittedBy: "Finance Team",
    submittedDate: "2024-03-15",
    currentLevel: "Approver",
  },
  {
    id: "PA002",
    structureId: "FS005",
    structureName: "Senior Secondary - Commerce (11-12)",
    action: "Create",
    changes: "New structure with 9 fee heads",
    submittedBy: "Finance Team",
    submittedDate: "2024-03-14",
    currentLevel: "Checker",
  },
]

export function FeeStructureContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [expandedStructures, setExpandedStructures] = useState<string[]>(["FS001"])
  const [selectedFeeHeads, setSelectedFeeHeads] = useState<string[]>([])
  const [feeHeadOverrides, setFeeHeadOverrides] = useState<Record<string, string>>({})

  const toggleExpand = (id: string) => {
    setExpandedStructures(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    )
  }

  const getFeeHead = (id: string) => masterFeeHeads.find(fh => fh.id === id)

  const getAppliedAmount = (feeHeadId: string, amountOverride: number | null) => {
    const master = getFeeHead(feeHeadId)
    if (!master) return 0
    return amountOverride ?? master.amount
  }

  const calculateAnnualTotal = (structure: typeof feeStructures[0]) => {
    let total = 0
    structure.feeHeads.forEach(sfh => {
      const master = getFeeHead(sfh.feeHeadId)
      if (!master) return
      const amount = getAppliedAmount(sfh.feeHeadId, sfh.amountOverride)
      
      // Annualize based on frequency
      switch (master.frequency) {
        case "Quarterly":
          total += amount * 4
          break
        case "Half-yearly":
          total += amount * 2
          break
        case "Monthly":
          total += amount * 12
          break
        default: // Annual, One-time
          total += amount
      }
    })
    return total
  }

  const getApprovalBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-success/10 text-success border-success/20">Approved</Badge>
      case "pending_checker":
        return <Badge variant="outline" className="border-warning text-warning">Pending Checker</Badge>
      case "pending_approver":
        return <Badge variant="outline" className="border-primary text-primary">Pending Approver</Badge>
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>
      default:
        return <Badge variant="secondary">Draft</Badge>
    }
  }

  const getInstallmentPlan = (planId: string) => installmentPlans.find(p => p.id === planId)

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Fee Structure</h1>
          <p className="text-sm text-muted-foreground">
            Link fee heads to classes - amounts and due dates are inherited from Fee Heads
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <FileDown className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Create Structure
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Fee Structure</DialogTitle>
                <DialogDescription>
                  Select fee heads to include. Amounts and due dates are pulled from Fee Heads settings.
                  You can optionally override amounts for this specific structure.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-6 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Structure Name</FieldLabel>
                      <Input placeholder="e.g., Primary Classes (1-5)" />
                    </Field>
                  </FieldGroup>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Academic Year</FieldLabel>
                      <Select defaultValue="2024-25">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="2024-25">2024-25</SelectItem>
                          <SelectItem value="2025-26">2025-26</SelectItem>
                        </SelectContent>
                      </Select>
                    </Field>
                  </FieldGroup>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Select Classes</FieldLabel>
                  <div className="flex flex-wrap gap-2">
                    {["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11-Sci", "11-Com", "12-Sci", "12-Com"].map((cls) => (
                      <label 
                        key={cls}
                        className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 cursor-pointer hover:bg-muted/50 transition-colors"
                      >
                        <Checkbox />
                        <span className="text-sm font-medium">{cls}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <FieldLabel>Select Fee Heads</FieldLabel>
                    <p className="text-xs text-muted-foreground">
                      Override amounts are optional - leave blank to use master amount
                    </p>
                  </div>
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-muted/50">
                          <TableHead className="w-12"></TableHead>
                          <TableHead>Fee Head</TableHead>
                          <TableHead>Frequency</TableHead>
                          <TableHead>Due Date</TableHead>
                          <TableHead className="text-right">Master Amount</TableHead>
                          <TableHead className="text-right">Override Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {masterFeeHeads.filter(fh => fh.status === "active").map((fh) => (
                          <TableRow key={fh.id} className="hover:bg-muted/30">
                            <TableCell>
                              <Checkbox 
                                checked={selectedFeeHeads.includes(fh.id)}
                                onCheckedChange={(checked) => {
                                  setSelectedFeeHeads(prev => 
                                    checked 
                                      ? [...prev, fh.id]
                                      : prev.filter(x => x !== fh.id)
                                  )
                                  if (!checked) {
                                    setFeeHeadOverrides(prev => {
                                      const updated = { ...prev }
                                      delete updated[fh.id]
                                      return updated
                                    })
                                  }
                                }}
                              />
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{fh.name}</span>
                                <Badge variant="outline" className="text-xs">{fh.code}</Badge>
                                {fh.isMandatory && (
                                  <Badge variant="secondary" className="text-xs">Mandatory</Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground">{fh.frequency}</TableCell>
                            <TableCell className="text-muted-foreground">{fh.dueDate}</TableCell>
                            <TableCell className="text-right font-medium">
                              ₹{fh.amount.toLocaleString()}
                            </TableCell>
                            <TableCell className="text-right">
                              <Input
                                type="number"
                                placeholder="Use master"
                                className="h-8 w-28 text-sm text-right ml-auto"
                                disabled={!selectedFeeHeads.includes(fh.id)}
                                value={feeHeadOverrides[fh.id] || ""}
                                onChange={(e) => setFeeHeadOverrides(prev => ({
                                  ...prev,
                                  [fh.id]: e.target.value
                                }))}
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  {selectedFeeHeads.length > 0 && (
                    <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <span className="text-sm font-medium">
                        {selectedFeeHeads.length} fee heads selected
                      </span>
                      <span className="text-sm">
                        Estimated Annual Total: <span className="font-semibold">
                          ₹{selectedFeeHeads.reduce((sum, id) => {
                            const fh = getFeeHead(id)
                            if (!fh) return sum
                            const amount = feeHeadOverrides[id] ? parseInt(feeHeadOverrides[id]) : fh.amount
                            const multiplier = fh.frequency === "Quarterly" ? 4 : fh.frequency === "Half-yearly" ? 2 : 1
                            return sum + (amount * multiplier)
                          }, 0).toLocaleString()}
                        </span>
                      </span>
                    </div>
                  )}
                </div>

                <FieldGroup>
                  <Field>
                    <FieldLabel>Installment Plan</FieldLabel>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select installment plan" />
                      </SelectTrigger>
                      <SelectContent>
                        {installmentPlans.map((plan) => (
                          <SelectItem key={plan.id} value={plan.id}>
                            {plan.name} ({plan.installments.length} installments)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </Field>
                </FieldGroup>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button variant="outline">
                  <Eye className="mr-2 h-4 w-4" />
                  Preview
                </Button>
                <Button>
                  <Send className="mr-2 h-4 w-4" />
                  Submit for Approval
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <IndianRupee className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Structures</p>
                <p className="text-2xl font-semibold">{feeStructures.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                <CheckCircle2 className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Active</p>
                <p className="text-2xl font-semibold">{feeStructures.filter(s => s.status === "active").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                <Clock className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending Approval</p>
                <p className="text-2xl font-semibold">{pendingApprovals.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                <Users className="h-5 w-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-semibold">{feeStructures.reduce((sum, s) => sum + s.students, 0).toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="structures" className="space-y-4">
        <TabsList>
          <TabsTrigger value="structures">Fee Structures</TabsTrigger>
          <TabsTrigger value="approvals" className="relative">
            Pending Approvals
            {pendingApprovals.length > 0 && (
              <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-xs text-destructive-foreground">
                {pendingApprovals.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="installments">Installment Plans</TabsTrigger>
          <TabsTrigger value="comparison">Class Comparison</TabsTrigger>
        </TabsList>

        <TabsContent value="structures" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-3">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search structures..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select defaultValue="2024-25">
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024-25">2024-25</SelectItem>
                    <SelectItem value="2023-24">2023-24</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {feeStructures.map((structure) => {
                const isExpanded = expandedStructures.includes(structure.id)
                const annualTotal = calculateAnnualTotal(structure)
                const plan = getInstallmentPlan(structure.installmentPlan)
                
                return (
                  <Collapsible 
                    key={structure.id} 
                    open={isExpanded}
                    onOpenChange={() => toggleExpand(structure.id)}
                  >
                    <Card className="border">
                      <CollapsibleTrigger asChild>
                        <div className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/30 transition-colors">
                          <div className="flex items-center gap-3">
                            {isExpanded ? (
                              <ChevronDown className="h-5 w-5 text-muted-foreground" />
                            ) : (
                              <ChevronRight className="h-5 w-5 text-muted-foreground" />
                            )}
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="font-medium">{structure.name}</h3>
                                {getApprovalBadge(structure.approvalStatus)}
                              </div>
                              <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                                <span>Classes: {structure.classes.join(", ")}</span>
                                <span className="text-border">|</span>
                                <span>{structure.students} students</span>
                                <span className="text-border">|</span>
                                <span>{structure.feeHeads.length} fee heads</span>
                                {plan && (
                                  <>
                                    <span className="text-border">|</span>
                                    <span>{plan.name}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <div className="text-lg font-semibold">₹{annualTotal.toLocaleString()}</div>
                              <div className="text-xs text-muted-foreground">Annual Total</div>
                            </div>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Details
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Edit Structure
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Copy className="mr-2 h-4 w-4" />
                                  Duplicate for Next Year
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-destructive">
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="border-t px-4 py-3 bg-muted/20">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Fee Head</TableHead>
                                <TableHead>Frequency</TableHead>
                                <TableHead>Due Date</TableHead>
                                <TableHead className="text-right">Master Amount</TableHead>
                                <TableHead className="text-right">Applied Amount</TableHead>
                                <TableHead className="text-right">Annualized</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {structure.feeHeads.map((sfh) => {
                                const master = getFeeHead(sfh.feeHeadId)
                                if (!master) return null
                                const appliedAmount = sfh.amountOverride ?? master.amount
                                const hasOverride = sfh.amountOverride !== null
                                const multiplier = master.frequency === "Quarterly" ? 4 : master.frequency === "Half-yearly" ? 2 : 1
                                const annualized = appliedAmount * multiplier
                                
                                return (
                                  <TableRow key={sfh.feeHeadId}>
                                    <TableCell>
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium">{master.name}</span>
                                        <Badge variant="outline" className="text-xs">{master.code}</Badge>
                                        {master.isMandatory && (
                                          <Badge variant="secondary" className="text-xs">Mandatory</Badge>
                                        )}
                                      </div>
                                    </TableCell>
                                    <TableCell className="text-muted-foreground">{master.frequency}</TableCell>
                                    <TableCell className="text-muted-foreground">{master.dueDate}</TableCell>
                                    <TableCell className="text-right text-muted-foreground">
                                      ₹{master.amount.toLocaleString()}
                                    </TableCell>
                                    <TableCell className="text-right">
                                      <TooltipProvider>
                                        <Tooltip>
                                          <TooltipTrigger asChild>
                                            <span className={hasOverride ? "text-primary font-medium cursor-help" : ""}>
                                              ₹{appliedAmount.toLocaleString()}
                                              {hasOverride && (
                                                <AlertCircle className="inline ml-1 h-3 w-3" />
                                              )}
                                            </span>
                                          </TooltipTrigger>
                                          {hasOverride && (
                                            <TooltipContent>
                                              <p>Override from master amount (₹{master.amount.toLocaleString()})</p>
                                            </TooltipContent>
                                          )}
                                        </Tooltip>
                                      </TooltipProvider>
                                    </TableCell>
                                    <TableCell className="text-right font-medium">
                                      ₹{annualized.toLocaleString()}
                                      {multiplier > 1 && (
                                        <span className="text-xs text-muted-foreground ml-1">
                                          (x{multiplier})
                                        </span>
                                      )}
                                    </TableCell>
                                  </TableRow>
                                )
                              })}
                              <TableRow className="bg-muted/30 font-semibold">
                                <TableCell colSpan={5}>Annual Total</TableCell>
                                <TableCell className="text-right text-lg">₹{annualTotal.toLocaleString()}</TableCell>
                              </TableRow>
                            </TableBody>
                          </Table>
                        </div>
                      </CollapsibleContent>
                    </Card>
                  </Collapsible>
                )
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approvals">
          <Card>
            <CardHeader>
              <CardTitle>Pending Approvals</CardTitle>
              <CardDescription>Review and approve fee structure changes</CardDescription>
            </CardHeader>
            <CardContent>
              {pendingApprovals.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No pending approvals
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingApprovals.map((approval) => (
                    <Card key={approval.id} className="border">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium">{approval.structureName}</h3>
                              <Badge variant="outline">{approval.action}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{approval.changes}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <span>Submitted by: {approval.submittedBy}</span>
                              <span className="text-border">|</span>
                              <span>Date: {approval.submittedDate}</span>
                            </div>
                            {/* Workflow Progress */}
                            <div className="flex items-center gap-2 pt-2">
                              <div className="flex items-center gap-1">
                                <div className="h-6 w-6 rounded-full bg-success flex items-center justify-center">
                                  <CheckCircle2 className="h-4 w-4 text-success-foreground" />
                                </div>
                                <span className="text-xs">Maker</span>
                              </div>
                              <div className="h-px w-6 bg-border" />
                              <div className="flex items-center gap-1">
                                <div className={`h-6 w-6 rounded-full flex items-center justify-center ${
                                  approval.currentLevel === "Checker" ? "bg-warning" : "bg-success"
                                }`}>
                                  {approval.currentLevel === "Checker" ? (
                                    <Clock className="h-4 w-4 text-warning-foreground" />
                                  ) : (
                                    <CheckCircle2 className="h-4 w-4 text-success-foreground" />
                                  )}
                                </div>
                                <span className="text-xs">Checker</span>
                              </div>
                              <div className="h-px w-6 bg-border" />
                              <div className="flex items-center gap-1">
                                <div className={`h-6 w-6 rounded-full flex items-center justify-center ${
                                  approval.currentLevel === "Approver" ? "bg-warning" : "bg-muted"
                                }`}>
                                  {approval.currentLevel === "Approver" ? (
                                    <Clock className="h-4 w-4 text-warning-foreground" />
                                  ) : (
                                    <GitBranch className="h-4 w-4 text-muted-foreground" />
                                  )}
                                </div>
                                <span className="text-xs">Approver</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button variant="outline" size="sm">
                              <Eye className="mr-2 h-4 w-4" />
                              View
                            </Button>
                            <Button variant="outline" size="sm" className="text-destructive border-destructive hover:bg-destructive/10">
                              <XCircle className="mr-2 h-4 w-4" />
                              Reject
                            </Button>
                            <Button size="sm">
                              <CheckCircle2 className="mr-2 h-4 w-4" />
                              Approve
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="installments">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Installment Plans</CardTitle>
                  <CardDescription>Configure payment schedules for fee structures</CardDescription>
                </div>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Plan
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                {installmentPlans.map((plan) => (
                  <Card key={plan.id} className="border">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">{plan.name}</CardTitle>
                        <Badge variant="secondary">{plan.installments.length} installments</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-2">
                        {plan.installments.map((inst, idx) => (
                          <div key={idx} className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-3 w-3 text-muted-foreground" />
                              <span>{inst.name}</span>
                            </div>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <span>{inst.dueDate}</span>
                              <Badge variant="outline" className="text-xs">{inst.percentage}%</Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="pt-2 border-t">
                        <p className="text-xs text-muted-foreground">
                          Used by: {feeStructures.filter(s => s.installmentPlan === plan.id).length} structures
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Edit className="mr-2 h-3 w-3" />
                          Edit
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="comparison">
          <Card>
            <CardHeader>
              <CardTitle>Class-wise Fee Comparison</CardTitle>
              <CardDescription>
                Compare applied amounts across structures. Highlighted values indicate overrides from master amount.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[180px] sticky left-0 bg-card">Fee Head</TableHead>
                      <TableHead className="text-center">Master</TableHead>
                      {feeStructures.map((structure) => (
                        <TableHead key={structure.id} className="text-center min-w-[120px]">
                          <div className="text-xs leading-tight">{structure.name}</div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {masterFeeHeads.filter(fh => fh.status === "active").map((fh) => (
                      <TableRow key={fh.id}>
                        <TableCell className="sticky left-0 bg-card">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{fh.name}</span>
                            <Badge variant="outline" className="text-xs">{fh.frequency}</Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-center font-medium">
                          ₹{fh.amount.toLocaleString()}
                        </TableCell>
                        {feeStructures.map((structure) => {
                          const structureFeeHead = structure.feeHeads.find(sfh => sfh.feeHeadId === fh.id)
                          if (!structureFeeHead) {
                            return (
                              <TableCell key={structure.id} className="text-center text-muted-foreground">
                                -
                              </TableCell>
                            )
                          }
                          const amount = structureFeeHead.amountOverride ?? fh.amount
                          const hasOverride = structureFeeHead.amountOverride !== null
                          return (
                            <TableCell key={structure.id} className="text-center">
                              <span className={hasOverride ? "text-primary font-medium" : ""}>
                                ₹{amount.toLocaleString()}
                              </span>
                            </TableCell>
                          )
                        })}
                      </TableRow>
                    ))}
                    <TableRow className="bg-muted/30 font-semibold">
                      <TableCell className="sticky left-0 bg-muted/30">Annual Total</TableCell>
                      <TableCell className="text-center">-</TableCell>
                      {feeStructures.map((structure) => (
                        <TableCell key={structure.id} className="text-center">
                          ₹{calculateAnnualTotal(structure).toLocaleString()}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
