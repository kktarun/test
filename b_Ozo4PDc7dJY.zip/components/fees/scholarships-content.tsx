"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Gift, 
  Users, 
  Percent, 
  IndianRupee,
  CheckCircle2,
  Clock,
  XCircle,
  FileText,
  MoreHorizontal,
  Eye,
  GitBranch,
  UserCheck,
  AlertCircle,
} from "lucide-react"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const scholarships = [
  {
    id: "SCH001",
    name: "Merit Scholarship",
    type: "Merit Based",
    discountType: "Percentage",
    value: 10,
    appliedOn: "Tuition Fee",
    eligibility: "90%+ in previous exam",
    beneficiaries: 45,
    totalSaved: 292500,
    status: "active",
    workflowEnabled: true,
    approvalLevel: 2,
  },
  {
    id: "SCH002",
    name: "Need Based Scholarship",
    type: "Need Based",
    discountType: "Percentage",
    value: 15,
    appliedOn: "Total Fee",
    eligibility: "Family income < 3L/year",
    beneficiaries: 28,
    totalSaved: 273000,
    status: "active",
    workflowEnabled: true,
    approvalLevel: 3,
  },
  {
    id: "SCH003",
    name: "Sports Scholarship",
    type: "Sports",
    discountType: "Percentage",
    value: 20,
    appliedOn: "Tuition Fee",
    eligibility: "District/State level",
    beneficiaries: 12,
    totalSaved: 156000,
    status: "active",
    workflowEnabled: true,
    approvalLevel: 2,
  },
  {
    id: "SCH004",
    name: "Staff Ward Concession",
    type: "Staff Ward",
    discountType: "Percentage",
    value: 50,
    appliedOn: "Total Fee",
    eligibility: "Staff children",
    beneficiaries: 8,
    totalSaved: 260000,
    status: "active",
    workflowEnabled: false,
    approvalLevel: 1,
  },
  {
    id: "SCH005",
    name: "Sibling Discount",
    type: "Sibling",
    discountType: "Fixed",
    value: 5000,
    appliedOn: "Tuition Fee",
    eligibility: "Second child onwards",
    beneficiaries: 65,
    totalSaved: 325000,
    status: "active",
    workflowEnabled: false,
    approvalLevel: 1,
  },
  {
    id: "SCH006",
    name: "Early Payment Discount",
    type: "Early Bird",
    discountType: "Percentage",
    value: 5,
    appliedOn: "Annual Fee",
    eligibility: "Full year payment by April",
    beneficiaries: 120,
    totalSaved: 390000,
    status: "active",
    workflowEnabled: false,
    approvalLevel: 1,
  },
]

const pendingApprovals = [
  {
    id: "REQ001",
    studentName: "Arjun Sharma",
    studentId: "STU001",
    class: "10-A",
    scholarshipType: "Merit Scholarship",
    requestedValue: 10,
    appliedOn: "Tuition Fee",
    requestedBy: "Class Teacher",
    requestedDate: "2024-03-15",
    status: "pending_l1",
    documents: ["Marksheet.pdf", "Certificate.pdf"],
    remarks: "Scored 95% in annual exams",
  },
  {
    id: "REQ002",
    studentName: "Priya Patel",
    studentId: "STU002",
    class: "8-B",
    scholarshipType: "Need Based Scholarship",
    requestedValue: 15,
    appliedOn: "Total Fee",
    requestedBy: "Admin",
    requestedDate: "2024-03-14",
    status: "pending_l2",
    documents: ["Income_Certificate.pdf"],
    remarks: "Family income verified: 2.5L/year",
  },
  {
    id: "REQ003",
    studentName: "Rahul Kumar",
    studentId: "STU003",
    class: "12-A",
    scholarshipType: "Sports Scholarship",
    requestedValue: 20,
    appliedOn: "Tuition Fee",
    requestedBy: "Sports Coach",
    requestedDate: "2024-03-12",
    status: "approved",
    documents: ["Sports_Certificate.pdf", "Medal_Photo.jpg"],
    remarks: "State level cricket champion",
  },
  {
    id: "REQ004",
    studentName: "Sneha Reddy",
    studentId: "STU004",
    class: "9-C",
    scholarshipType: "Need Based Scholarship",
    requestedValue: 15,
    appliedOn: "Total Fee",
    requestedBy: "Admin",
    requestedDate: "2024-03-10",
    status: "rejected",
    documents: ["Income_Certificate.pdf"],
    remarks: "Income above threshold",
  },
]

const workflows = [
  {
    id: "WF001",
    name: "Merit Scholarship Workflow",
    scholarshipType: "Merit Based",
    levels: [
      { level: 1, role: "Class Teacher", action: "Verify Documents" },
      { level: 2, role: "Academic Head", action: "Final Approval" },
    ],
    autoApproveBelow: 5,
    status: "active",
  },
  {
    id: "WF002",
    name: "Need Based Workflow",
    scholarshipType: "Need Based",
    levels: [
      { level: 1, role: "Admin", action: "Document Verification" },
      { level: 2, role: "Finance Head", action: "Income Verification" },
      { level: 3, role: "Principal", action: "Final Approval" },
    ],
    autoApproveBelow: 0,
    status: "active",
  },
  {
    id: "WF003",
    name: "Sports Scholarship Workflow",
    scholarshipType: "Sports",
    levels: [
      { level: 1, role: "Sports Coach", action: "Verify Achievement" },
      { level: 2, role: "Principal", action: "Final Approval" },
    ],
    autoApproveBelow: 10,
    status: "active",
  },
]

export function ScholarshipsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isWorkflowDialogOpen, setIsWorkflowDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("scholarships")

  const totalBeneficiaries = scholarships.reduce((sum, s) => sum + s.beneficiaries, 0)
  const totalSaved = scholarships.reduce((sum, s) => sum + s.totalSaved, 0)
  const pendingCount = pendingApprovals.filter(p => p.status.startsWith("pending")).length

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending_l1":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-300">Pending L1</Badge>
      case "pending_l2":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">Pending L2</Badge>
      case "pending_l3":
        return <Badge variant="outline" className="bg-purple-50 text-purple-700 dark:bg-purple-950 dark:text-purple-300">Pending L3</Badge>
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300">Approved</Badge>
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300">Rejected</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Scholarships & Discounts</h1>
          <p className="text-muted-foreground">
            Manage scholarship programs, discount schemes, and approval workflows
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={isWorkflowDialogOpen} onOpenChange={setIsWorkflowDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <GitBranch className="mr-2 h-4 w-4" />
                Manage Workflows
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Approval Workflows</DialogTitle>
                <DialogDescription>
                  Configure multi-level approval workflows for scholarships and concessions
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                {workflows.map((workflow) => (
                  <div key={workflow.id} className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <p className="font-medium">{workflow.name}</p>
                        <p className="text-sm text-muted-foreground">{workflow.scholarshipType}</p>
                      </div>
                      <Badge variant={workflow.status === "active" ? "default" : "secondary"}>
                        {workflow.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 mb-3">
                      {workflow.levels.map((level, index) => (
                        <div key={level.level} className="flex items-center">
                          <div className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2">
                            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                              {level.level}
                            </span>
                            <div>
                              <p className="text-sm font-medium">{level.role}</p>
                              <p className="text-xs text-muted-foreground">{level.action}</p>
                            </div>
                          </div>
                          {index < workflow.levels.length - 1 && (
                            <div className="mx-2 h-0.5 w-4 bg-border" />
                          )}
                        </div>
                      ))}
                    </div>
                    {workflow.autoApproveBelow > 0 && (
                      <p className="text-xs text-muted-foreground">
                        Auto-approve for discounts below {workflow.autoApproveBelow}%
                      </p>
                    )}
                    <div className="flex justify-end mt-3">
                      <Button variant="ghost" size="sm">
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
                <Button variant="outline" className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Create New Workflow
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Scholarship
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Scholarship / Concession</DialogTitle>
                <DialogDescription>
                  Add a new scholarship or discount scheme with approval workflow
                </DialogDescription>
              </DialogHeader>
              <Tabs defaultValue="basic" className="mt-4">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basic">Basic Info</TabsTrigger>
                  <TabsTrigger value="eligibility">Eligibility</TabsTrigger>
                  <TabsTrigger value="workflow">Workflow</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basic" className="space-y-4 pt-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Scholarship Name</FieldLabel>
                        <Input placeholder="e.g., Merit Scholarship" />
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Type</FieldLabel>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="merit">Merit Based</SelectItem>
                            <SelectItem value="need">Need Based</SelectItem>
                            <SelectItem value="sports">Sports</SelectItem>
                            <SelectItem value="staff">Staff Ward</SelectItem>
                            <SelectItem value="sibling">Sibling Discount</SelectItem>
                            <SelectItem value="early">Early Bird</SelectItem>
                            <SelectItem value="custom">Custom</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </FieldGroup>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Discount Type</FieldLabel>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select discount type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="percentage">Percentage</SelectItem>
                            <SelectItem value="fixed">Fixed Amount</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Value</FieldLabel>
                        <Input type="number" placeholder="0" />
                      </Field>
                    </FieldGroup>
                  </div>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Applied On</FieldLabel>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select fee heads" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="total">Total Fee</SelectItem>
                          <SelectItem value="tuition">Tuition Fee Only</SelectItem>
                          <SelectItem value="annual">Annual Fee</SelectItem>
                          <SelectItem value="custom">Select Specific Fee Heads</SelectItem>
                        </SelectContent>
                      </Select>
                    </Field>
                  </FieldGroup>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Description</FieldLabel>
                      <Textarea placeholder="Brief description of this scholarship..." />
                    </Field>
                  </FieldGroup>
                </TabsContent>

                <TabsContent value="eligibility" className="space-y-4 pt-4">
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Eligibility Criteria</FieldLabel>
                      <Textarea placeholder="e.g., 90%+ in previous exam" />
                    </Field>
                  </FieldGroup>
                  <div className="space-y-3">
                    <p className="text-sm font-medium">Required Documents</p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Checkbox id="marksheet" />
                        <label htmlFor="marksheet" className="text-sm">Marksheet / Report Card</label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox id="income" />
                        <label htmlFor="income" className="text-sm">Income Certificate</label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox id="sports" />
                        <label htmlFor="sports" className="text-sm">Sports Certificate / Medal</label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox id="staff" />
                        <label htmlFor="staff" className="text-sm">Staff ID / Employment Proof</label>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-3 w-3" />
                      Add Custom Document
                    </Button>
                  </div>
                  <div className="space-y-3">
                    <p className="text-sm font-medium">Applicable To</p>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <FieldGroup>
                        <Field>
                          <FieldLabel>Classes</FieldLabel>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select classes" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Classes</SelectItem>
                              <SelectItem value="primary">Primary (1-5)</SelectItem>
                              <SelectItem value="middle">Middle (6-8)</SelectItem>
                              <SelectItem value="secondary">Secondary (9-10)</SelectItem>
                              <SelectItem value="senior">Senior Secondary (11-12)</SelectItem>
                            </SelectContent>
                          </Select>
                        </Field>
                      </FieldGroup>
                      <FieldGroup>
                        <Field>
                          <FieldLabel>Student Groups</FieldLabel>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select groups" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Students</SelectItem>
                              <SelectItem value="new">New Admissions</SelectItem>
                              <SelectItem value="transport">Transport Students</SelectItem>
                              <SelectItem value="hostel">Hostel Students</SelectItem>
                            </SelectContent>
                          </Select>
                        </Field>
                      </FieldGroup>
                    </div>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <p className="font-medium text-sm">Auto-detect Sibling</p>
                      <p className="text-xs text-muted-foreground">
                        Automatically apply to siblings based on parent details
                      </p>
                    </div>
                    <Switch />
                  </div>
                </TabsContent>

                <TabsContent value="workflow" className="space-y-4 pt-4">
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div>
                      <p className="font-medium">Enable Approval Workflow</p>
                      <p className="text-sm text-muted-foreground">
                        Require approval before applying this scholarship
                      </p>
                    </div>
                    <Switch />
                  </div>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Select Workflow</FieldLabel>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select workflow" />
                        </SelectTrigger>
                        <SelectContent>
                          {workflows.map((wf) => (
                            <SelectItem key={wf.id} value={wf.id}>
                              {wf.name} ({wf.levels.length} levels)
                            </SelectItem>
                          ))}
                          <SelectItem value="new">+ Create New Workflow</SelectItem>
                        </SelectContent>
                      </Select>
                    </Field>
                  </FieldGroup>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Auto-approve below (%)</FieldLabel>
                      <Input type="number" placeholder="0" min="0" max="100" />
                      <p className="text-xs text-muted-foreground mt-1">
                        Scholarships below this percentage will be auto-approved
                      </p>
                    </Field>
                  </FieldGroup>
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <p className="font-medium text-sm">Notify on Approval</p>
                      <p className="text-xs text-muted-foreground">
                        Send notification to parent when approved
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </TabsContent>
              </Tabs>
              <DialogFooter className="mt-6">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsCreateDialogOpen(false)}>
                  Create Scholarship
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Gift className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-bold">{scholarships.length}</div>
                <p className="text-sm text-muted-foreground">Active Schemes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100 dark:bg-green-950">
                <Users className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <div className="text-2xl font-bold">{totalBeneficiaries}</div>
                <p className="text-sm text-muted-foreground">Beneficiaries</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-950">
                <IndianRupee className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <div className="text-2xl font-bold">₹{(totalSaved / 100000).toFixed(1)}L</div>
                <p className="text-sm text-muted-foreground">Total Concession</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-100 dark:bg-yellow-950">
                <Clock className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
              </div>
              <div>
                <div className="text-2xl font-bold">{pendingCount}</div>
                <p className="text-sm text-muted-foreground">Pending Approvals</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="scholarships">Scholarships</TabsTrigger>
          <TabsTrigger value="approvals" className="relative">
            Pending Approvals
            {pendingCount > 0 && (
              <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-xs text-destructive-foreground">
                {pendingCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="history">Approval History</TabsTrigger>
        </TabsList>

        <TabsContent value="scholarships" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search scholarships..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="merit">Merit Based</SelectItem>
                    <SelectItem value="need">Need Based</SelectItem>
                    <SelectItem value="sports">Sports</SelectItem>
                    <SelectItem value="sibling">Sibling</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Scholarship</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Discount</TableHead>
                    <TableHead>Applied On</TableHead>
                    <TableHead>Beneficiaries</TableHead>
                    <TableHead>Workflow</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scholarships.map((scholarship) => (
                    <TableRow key={scholarship.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{scholarship.name}</p>
                          <p className="text-xs text-muted-foreground">{scholarship.eligibility}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{scholarship.type}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {scholarship.discountType === "Percentage" ? (
                            <>
                              <Percent className="h-3 w-3" />
                              {scholarship.value}
                            </>
                          ) : (
                            <>
                              <IndianRupee className="h-3 w-3" />
                              {scholarship.value.toLocaleString()}
                            </>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{scholarship.appliedOn}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{scholarship.beneficiaries}</p>
                          <p className="text-xs text-muted-foreground">
                            ₹{(scholarship.totalSaved / 1000).toFixed(0)}K saved
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {scholarship.workflowEnabled ? (
                          <Badge variant="secondary">
                            <GitBranch className="mr-1 h-3 w-3" />
                            {scholarship.approvalLevel} Level
                          </Badge>
                        ) : (
                          <span className="text-sm text-muted-foreground">None</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={scholarship.status === "active" ? "default" : "secondary"}>
                          {scholarship.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Users className="mr-2 h-4 w-4" />
                              View Beneficiaries
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approvals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Approval Requests</CardTitle>
              <CardDescription>
                Review and approve scholarship/concession requests
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingApprovals
                  .filter((p) => p.status.startsWith("pending"))
                  .map((request) => (
                    <div key={request.id} className="rounded-lg border p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>
                              {request.studentName.split(" ").map((n) => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{request.studentName}</p>
                            <p className="text-sm text-muted-foreground">
                              {request.studentId} &bull; Class {request.class}
                            </p>
                          </div>
                        </div>
                        {getStatusBadge(request.status)}
                      </div>
                      <div className="grid gap-4 sm:grid-cols-3 mb-3">
                        <div>
                          <p className="text-xs text-muted-foreground">Scholarship Type</p>
                          <p className="text-sm font-medium">{request.scholarshipType}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Discount</p>
                          <p className="text-sm font-medium">{request.requestedValue}% on {request.appliedOn}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Requested By</p>
                          <p className="text-sm font-medium">{request.requestedBy}</p>
                        </div>
                      </div>
                      <div className="mb-3">
                        <p className="text-xs text-muted-foreground mb-1">Remarks</p>
                        <p className="text-sm">{request.remarks}</p>
                      </div>
                      <div className="flex items-center gap-2 mb-4">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        {request.documents.map((doc) => (
                          <Badge key={doc} variant="secondary" className="text-xs">
                            {doc}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm">
                          <XCircle className="mr-2 h-4 w-4" />
                          Reject
                        </Button>
                        <Button size="sm">
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          Approve
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Approval History</CardTitle>
              <CardDescription>
                Past scholarship approval decisions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Scholarship</TableHead>
                    <TableHead>Discount</TableHead>
                    <TableHead>Requested By</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingApprovals
                    .filter((p) => !p.status.startsWith("pending"))
                    .map((request) => (
                      <TableRow key={request.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{request.studentName}</p>
                            <p className="text-xs text-muted-foreground">Class {request.class}</p>
                          </div>
                        </TableCell>
                        <TableCell>{request.scholarshipType}</TableCell>
                        <TableCell>{request.requestedValue}%</TableCell>
                        <TableCell>{request.requestedBy}</TableCell>
                        <TableCell>{request.requestedDate}</TableCell>
                        <TableCell>{getStatusBadge(request.status)}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Eye className="mr-2 h-4 w-4" />
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
