"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Plus,
  Users,
  Edit2,
  Trash2,
  UserPlus,
  UserMinus,
  FileText,
  MoreHorizontal,
  Filter,
  Download,
  Upload,
  ChevronRight,
  Eye,
  X,
  CheckCircle2,
  AlertCircle,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ScrollArea } from "@/components/ui/scroll-area"

// Master fee structures available
const feeStructures = [
  { id: "FS001", name: "Class 1-5 Standard", totalFee: 45000 },
  { id: "FS002", name: "Class 6-8 Standard", totalFee: 52000 },
  { id: "FS003", name: "Class 9-10 Standard", totalFee: 65000 },
  { id: "FS004", name: "Class 11-12 Science", totalFee: 85000 },
  { id: "FS005", name: "Merit Scholar Structure", totalFee: 40500, discount: "10%" },
  { id: "FS006", name: "Sports Quota Structure", totalFee: 52000, discount: "20%" },
  { id: "FS007", name: "Staff Children Structure", totalFee: 32500, discount: "50%" },
  { id: "FS008", name: "EWS Fee Structure", totalFee: 0, discount: "100%" },
]

// All students in the system
const allStudents = [
  { id: "STU001", name: "Arjun Sharma", class: "10-A", rollNo: "1001", admissionNo: "ADM2024001", phone: "+91 98765 43210", groups: ["GRP001"] },
  { id: "STU002", name: "Priya Patel", class: "9-B", rollNo: "902", admissionNo: "ADM2024002", phone: "+91 98765 43211", groups: [] },
  { id: "STU003", name: "Rahul Verma", class: "8-C", rollNo: "803", admissionNo: "ADM2024003", phone: "+91 98765 43212", groups: ["GRP002"] },
  { id: "STU004", name: "Ananya Gupta", class: "10-A", rollNo: "1015", admissionNo: "ADM2024004", phone: "+91 98765 43213", groups: ["GRP001"] },
  { id: "STU005", name: "Vikram Singh", class: "7-A", rollNo: "705", admissionNo: "ADM2024005", phone: "+91 98765 43214", groups: ["GRP002"] },
  { id: "STU006", name: "Sneha Reddy", class: "9-A", rollNo: "912", admissionNo: "ADM2024006", phone: "+91 98765 43215", groups: [] },
  { id: "STU007", name: "Karan Mehta", class: "8-B", rollNo: "825", admissionNo: "ADM2024007", phone: "+91 98765 43216", groups: ["GRP003"] },
  { id: "STU008", name: "Nisha Jain", class: "10-B", rollNo: "1045", admissionNo: "ADM2024008", phone: "+91 98765 43217", groups: [] },
  { id: "STU009", name: "Amit Desai", class: "12-A", rollNo: "1201", admissionNo: "ADM2024009", phone: "+91 98765 43218", groups: ["GRP004"] },
  { id: "STU010", name: "Pooja Sharma", class: "11-B", rollNo: "1108", admissionNo: "ADM2024010", phone: "+91 98765 43219", groups: ["GRP001", "GRP004"] },
  { id: "STU011", name: "Ravi Kumar", class: "6-A", rollNo: "601", admissionNo: "ADM2024011", phone: "+91 98765 43220", groups: ["GRP005"] },
  { id: "STU012", name: "Meera Iyer", class: "5-B", rollNo: "512", admissionNo: "ADM2024012", phone: "+91 98765 43221", groups: ["GRP003"] },
]

// Student groups with linked students
const studentGroups = [
  {
    id: "GRP001",
    name: "Merit Scholarship Recipients",
    description: "Students receiving merit-based scholarships based on academic performance",
    type: "scholarship",
    feeStructureId: "FS005",
    feeStructureName: "Merit Scholar Structure",
    studentIds: ["STU001", "STU004", "STU010"],
    criteria: "Academic score > 90%",
    createdAt: "2024-01-15",
    createdBy: "Admin",
    status: "active",
  },
  {
    id: "GRP002",
    name: "Sports Quota Students",
    description: "Students admitted under sports quota with special fees",
    type: "quota",
    feeStructureId: "FS006",
    feeStructureName: "Sports Quota Structure",
    studentIds: ["STU003", "STU005"],
    criteria: "Sports achievement at state/national level",
    createdAt: "2024-01-20",
    createdBy: "Admin",
    status: "active",
  },
  {
    id: "GRP003",
    name: "Staff Children",
    description: "Children of school staff members",
    type: "concession",
    feeStructureId: "FS007",
    feeStructureName: "Staff Children Structure",
    studentIds: ["STU007", "STU012"],
    criteria: "Parent employed at institution",
    createdAt: "2024-02-01",
    createdBy: "HR Manager",
    status: "active",
  },
  {
    id: "GRP004",
    name: "Transport Zone A",
    description: "Students from Zone A (0-5 km radius)",
    type: "transport",
    feeStructureId: null,
    feeStructureName: null,
    transportSlabId: "TS001",
    studentIds: ["STU009", "STU010"],
    criteria: "Distance from school: 0-5 km",
    createdAt: "2024-02-10",
    createdBy: "Transport Manager",
    status: "active",
  },
  {
    id: "GRP005",
    name: "EWS Category",
    description: "Economically weaker section students under RTE",
    type: "ews",
    feeStructureId: "FS008",
    feeStructureName: "EWS Fee Structure",
    studentIds: ["STU011"],
    criteria: "Annual family income < 1 Lakh",
    createdAt: "2024-02-15",
    createdBy: "Admin",
    status: "active",
  },
]

const groupTypes = [
  { value: "scholarship", label: "Scholarship" },
  { value: "quota", label: "Quota" },
  { value: "concession", label: "Concession" },
  { value: "transport", label: "Transport" },
  { value: "ews", label: "EWS/RTE" },
  { value: "sibling", label: "Sibling Discount" },
  { value: "custom", label: "Custom" },
]

export function StudentGroupsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showCreateGroup, setShowCreateGroup] = useState(false)
  const [showManageStudents, setShowManageStudents] = useState(false)
  const [showGroupDetails, setShowGroupDetails] = useState(false)
  const [selectedGroup, setSelectedGroup] = useState<typeof studentGroups[0] | null>(null)
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([])
  const [studentSearch, setStudentSearch] = useState("")
  const [classFilter, setClassFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")

  // New group form state
  const [newGroup, setNewGroup] = useState({
    name: "",
    description: "",
    type: "",
    feeStructureId: "",
    criteria: "",
  })

  const filteredGroups = studentGroups.filter((group) => {
    const matchesSearch =
      group.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      group.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || group.type === typeFilter
    return matchesSearch && matchesType
  })

  const getGroupStudents = (groupId: string) => {
    const group = studentGroups.find((g) => g.id === groupId)
    if (!group) return []
    return allStudents.filter((s) => group.studentIds.includes(s.id))
  }

  const getAvailableStudents = () => {
    if (!selectedGroup) return allStudents
    return allStudents.filter((s) => !selectedGroup.studentIds.includes(s.id))
  }

  const filteredAvailableStudents = getAvailableStudents().filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
      student.id.toLowerCase().includes(studentSearch.toLowerCase()) ||
      student.admissionNo.toLowerCase().includes(studentSearch.toLowerCase())
    const matchesClass = classFilter === "all" || student.class.startsWith(classFilter)
    return matchesSearch && matchesClass
  })

  const handleStudentToggle = (studentId: string) => {
    setSelectedStudentIds((prev) =>
      prev.includes(studentId)
        ? prev.filter((id) => id !== studentId)
        : [...prev, studentId]
    )
  }

  const handleSelectAll = () => {
    if (selectedStudentIds.length === filteredAvailableStudents.length) {
      setSelectedStudentIds([])
    } else {
      setSelectedStudentIds(filteredAvailableStudents.map((s) => s.id))
    }
  }

  const openManageStudents = (group: typeof studentGroups[0]) => {
    setSelectedGroup(group)
    setSelectedStudentIds([])
    setStudentSearch("")
    setClassFilter("all")
    setShowManageStudents(true)
  }

  const openGroupDetails = (group: typeof studentGroups[0]) => {
    setSelectedGroup(group)
    setShowGroupDetails(true)
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "scholarship":
        return "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
      case "quota":
        return "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
      case "concession":
        return "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400"
      case "transport":
        return "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400"
      case "ews":
        return "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
      default:
        return "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Student Groups</h1>
          <p className="text-sm text-muted-foreground">
            Create groups and assign special fee structures to students
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="gap-2">
            <Upload className="h-4 w-4" />
            Import
          </Button>
          <Button className="gap-2" onClick={() => setShowCreateGroup(true)}>
            <Plus className="h-4 w-4" />
            Create Group
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Groups</p>
                <p className="text-2xl font-bold">{studentGroups.length}</p>
              </div>
              <div className="rounded-lg bg-primary/10 p-2.5 text-primary">
                <Users className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Students in Groups</p>
                <p className="text-2xl font-bold">
                  {new Set(studentGroups.flatMap((g) => g.studentIds)).size}
                </p>
              </div>
              <div className="rounded-lg bg-green-100 p-2.5 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                <UserPlus className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Unassigned Students</p>
                <p className="text-2xl font-bold">
                  {allStudents.filter((s) => s.groups.length === 0).length}
                </p>
              </div>
              <div className="rounded-lg bg-amber-100 p-2.5 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400">
                <AlertCircle className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Fee Structures Linked</p>
                <p className="text-2xl font-bold">
                  {new Set(studentGroups.filter((g) => g.feeStructureId).map((g) => g.feeStructureId)).size}
                </p>
              </div>
              <div className="rounded-lg bg-blue-100 p-2.5 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                <FileText className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search groups..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[180px]">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {groupTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Groups Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredGroups.map((group) => {
          const groupStudents = getGroupStudents(group.id)
          return (
            <Card key={group.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <CardTitle className="text-base font-semibold">{group.name}</CardTitle>
                    <Badge className={getTypeColor(group.type)} variant="secondary">
                      {groupTypes.find((t) => t.value === group.type)?.label || group.type}
                    </Badge>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => openGroupDetails(group)}>
                        <Eye className="mr-2 h-4 w-4" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => openManageStudents(group)}>
                        <UserPlus className="mr-2 h-4 w-4" />
                        Manage Students
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Edit2 className="mr-2 h-4 w-4" />
                        Edit Group
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete Group
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {group.description}
                </p>

                {group.feeStructureName && (
                  <div className="rounded-lg bg-muted/50 p-3">
                    <p className="text-xs text-muted-foreground">Linked Fee Structure</p>
                    <p className="text-sm font-medium">{group.feeStructureName}</p>
                  </div>
                )}

                <div className="flex items-center justify-between border-t pt-3">
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {groupStudents.slice(0, 3).map((student) => (
                        <Avatar key={student.id} className="h-7 w-7 border-2 border-background">
                          <AvatarFallback className="text-xs">
                            {student.name.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                      ))}
                      {groupStudents.length > 3 && (
                        <div className="flex h-7 w-7 items-center justify-center rounded-full border-2 border-background bg-muted text-xs font-medium">
                          +{groupStudents.length - 3}
                        </div>
                      )}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {groupStudents.length} student{groupStudents.length !== 1 ? "s" : ""}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="gap-1"
                    onClick={() => openManageStudents(group)}
                  >
                    Manage
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Create Group Dialog */}
      <Dialog open={showCreateGroup} onOpenChange={setShowCreateGroup}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Create Student Group</DialogTitle>
            <DialogDescription>
              Create a new group to assign special fee structures to students
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Group Name</Label>
              <Input
                id="name"
                placeholder="e.g., Merit Scholarship 2024"
                value={newGroup.name}
                onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Group Type</Label>
              <Select
                value={newGroup.type}
                onValueChange={(value) => setNewGroup({ ...newGroup, type: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {groupTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe the group and eligibility criteria..."
                value={newGroup.description}
                onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="feeStructure">Link Fee Structure</Label>
              <Select
                value={newGroup.feeStructureId}
                onValueChange={(value) => setNewGroup({ ...newGroup, feeStructureId: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select fee structure" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No specific structure</SelectItem>
                  {feeStructures.map((fs) => (
                    <SelectItem key={fs.id} value={fs.id}>
                      {fs.name} {fs.discount && `(${fs.discount} off)`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Students in this group will be assigned this fee structure
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="criteria">Eligibility Criteria</Label>
              <Input
                id="criteria"
                placeholder="e.g., Academic score > 90%"
                value={newGroup.criteria}
                onChange={(e) => setNewGroup({ ...newGroup, criteria: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateGroup(false)}>
              Cancel
            </Button>
            <Button>Create Group</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Manage Students Dialog */}
      <Dialog open={showManageStudents} onOpenChange={setShowManageStudents}>
        <DialogContent className="max-w-4xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle>Manage Students - {selectedGroup?.name}</DialogTitle>
            <DialogDescription>
              Add or remove students from this group. Changes will update their fee structure.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="current" className="mt-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="current">
                Current Members ({selectedGroup?.studentIds.length || 0})
              </TabsTrigger>
              <TabsTrigger value="add">
                Add Students
              </TabsTrigger>
            </TabsList>

            <TabsContent value="current" className="mt-4">
              <div className="rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Admission No</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedGroup && getGroupStudents(selectedGroup.id).map((student) => (
                      <TableRow key={student.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="text-xs">
                                {student.name.split(" ").map((n) => n[0]).join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{student.name}</p>
                              <p className="text-xs text-muted-foreground">{student.id}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{student.admissionNo}</TableCell>
                        <TableCell>{student.class}</TableCell>
                        <TableCell className="text-sm">{student.phone}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                            <UserMinus className="mr-2 h-4 w-4" />
                            Remove
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {selectedGroup && getGroupStudents(selectedGroup.id).length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          <p className="text-muted-foreground">No students in this group yet</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="add" className="mt-4 space-y-4">
              {/* Filters */}
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by name, ID, or admission no..."
                    className="pl-9"
                    value={studentSearch}
                    onChange={(e) => setStudentSearch(e.target.value)}
                  />
                </div>
                <Select value={classFilter} onValueChange={setClassFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Classes</SelectItem>
                    {Array.from({ length: 12 }, (_, i) => i + 1).map((c) => (
                      <SelectItem key={c} value={c.toString()}>
                        Class {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Selection summary */}
              {selectedStudentIds.length > 0 && (
                <div className="flex items-center justify-between rounded-lg bg-primary/10 px-4 py-2">
                  <span className="text-sm font-medium">
                    {selectedStudentIds.length} student{selectedStudentIds.length !== 1 ? "s" : ""} selected
                  </span>
                  <Button size="sm" onClick={() => setSelectedStudentIds([])}>
                    Clear Selection
                  </Button>
                </div>
              )}

              {/* Students list */}
              <ScrollArea className="h-[350px] rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox
                          checked={
                            filteredAvailableStudents.length > 0 &&
                            selectedStudentIds.length === filteredAvailableStudents.length
                          }
                          onCheckedChange={handleSelectAll}
                        />
                      </TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Admission No</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Current Groups</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAvailableStudents.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedStudentIds.includes(student.id)}
                            onCheckedChange={() => handleStudentToggle(student.id)}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="text-xs">
                                {student.name.split(" ").map((n) => n[0]).join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{student.name}</p>
                              <p className="text-xs text-muted-foreground">{student.id}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{student.admissionNo}</TableCell>
                        <TableCell>{student.class}</TableCell>
                        <TableCell>
                          {student.groups.length === 0 ? (
                            <span className="text-xs text-muted-foreground">None</span>
                          ) : (
                            <div className="flex flex-wrap gap-1">
                              {student.groups.map((gId) => {
                                const g = studentGroups.find((sg) => sg.id === gId)
                                return g ? (
                                  <Badge key={gId} variant="outline" className="text-xs">
                                    {g.name.length > 15 ? g.name.substring(0, 15) + "..." : g.name}
                                  </Badge>
                                ) : null
                              })}
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredAvailableStudents.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="h-24 text-center">
                          <p className="text-muted-foreground">No students available to add</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </TabsContent>
          </Tabs>

          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setShowManageStudents(false)}>
              Cancel
            </Button>
            <Button disabled={selectedStudentIds.length === 0}>
              <UserPlus className="mr-2 h-4 w-4" />
              Add {selectedStudentIds.length} Student{selectedStudentIds.length !== 1 ? "s" : ""}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Group Details Dialog */}
      <Dialog open={showGroupDetails} onOpenChange={setShowGroupDetails}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedGroup?.name}</DialogTitle>
            <DialogDescription>{selectedGroup?.description}</DialogDescription>
          </DialogHeader>
          {selectedGroup && (
            <div className="space-y-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg border p-4">
                  <p className="text-sm text-muted-foreground">Group Type</p>
                  <Badge className={getTypeColor(selectedGroup.type)} variant="secondary">
                    {groupTypes.find((t) => t.value === selectedGroup.type)?.label}
                  </Badge>
                </div>
                <div className="rounded-lg border p-4">
                  <p className="text-sm text-muted-foreground">Total Students</p>
                  <p className="text-xl font-semibold">{selectedGroup.studentIds.length}</p>
                </div>
                <div className="rounded-lg border p-4">
                  <p className="text-sm text-muted-foreground">Linked Fee Structure</p>
                  <p className="font-medium">{selectedGroup.feeStructureName || "None"}</p>
                </div>
                <div className="rounded-lg border p-4">
                  <p className="text-sm text-muted-foreground">Eligibility Criteria</p>
                  <p className="font-medium">{selectedGroup.criteria}</p>
                </div>
              </div>

              <div>
                <h4 className="mb-3 font-medium">Students in this Group</h4>
                <div className="rounded-lg border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Student</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead>Admission No</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getGroupStudents(selectedGroup.id).map((student) => (
                        <TableRow key={student.id}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-7 w-7">
                                <AvatarFallback className="text-xs">
                                  {student.name.split(" ").map((n) => n[0]).join("")}
                                </AvatarFallback>
                              </Avatar>
                              {student.name}
                            </div>
                          </TableCell>
                          <TableCell>{student.class}</TableCell>
                          <TableCell>{student.admissionNo}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div className="flex items-center justify-between border-t pt-4 text-sm text-muted-foreground">
                <span>Created by {selectedGroup.createdBy} on {selectedGroup.createdAt}</span>
                <Badge variant={selectedGroup.status === "active" ? "default" : "secondary"}>
                  {selectedGroup.status}
                </Badge>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
