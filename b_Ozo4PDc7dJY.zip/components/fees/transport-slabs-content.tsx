"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Plus, Search, Edit, Trash2, Bus, MapPin, Route, Users, IndianRupee, Calendar, Clock } from "lucide-react"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"

const distanceSlabs = [
  { id: "DS001", range: "0 - 3 km", minDistance: 0, maxDistance: 3, monthlyAmount: 1000, quarterlyAmount: 2850, yearlyAmount: 11000, students: 85, status: "active", applicableFrom: "Apr 2024", applicableTo: "Mar 2025" },
  { id: "DS002", range: "3 - 7 km", minDistance: 3, maxDistance: 7, monthlyAmount: 2000, quarterlyAmount: 5700, yearlyAmount: 22000, students: 120, status: "active", applicableFrom: "Apr 2024", applicableTo: "Mar 2025" },
  { id: "DS003", range: "7 - 12 km", minDistance: 7, maxDistance: 12, monthlyAmount: 3000, quarterlyAmount: 8550, yearlyAmount: 33000, students: 95, status: "active", applicableFrom: "Apr 2024", applicableTo: "Mar 2025" },
  { id: "DS004", range: "12 - 20 km", minDistance: 12, maxDistance: 20, monthlyAmount: 4000, quarterlyAmount: 11400, yearlyAmount: 44000, students: 45, status: "active", applicableFrom: "Apr 2024", applicableTo: "Mar 2025" },
  { id: "DS005", range: "20+ km", minDistance: 20, maxDistance: 50, monthlyAmount: 5000, quarterlyAmount: 14250, yearlyAmount: 55000, students: 15, status: "active", applicableFrom: "Apr 2024", applicableTo: "Mar 2025" },
]

const fixedRateSlabs = [
  { id: "FR001", name: "Short Distance", minKm: 0, maxKm: 5, ratePerKm: 200, baseAmount: 500, students: 65, status: "active" },
  { id: "FR002", name: "Medium Distance", minKm: 5, maxKm: 15, ratePerKm: 180, baseAmount: 1000, students: 120, status: "active" },
  { id: "FR003", name: "Long Distance", minKm: 15, maxKm: 30, ratePerKm: 150, baseAmount: 2000, students: 58, status: "active" },
]

const stops = [
  { id: "ST001", name: "Sector 15 Gate", route: "Route A", distance: "2.5 km", monthlyAmount: 1200, students: 12, pickupTime: "7:15 AM", dropTime: "2:45 PM", status: "active" },
  { id: "ST002", name: "Central Market", route: "Route A", distance: "4.8 km", monthlyAmount: 2000, students: 18, pickupTime: "7:25 AM", dropTime: "2:55 PM", status: "active" },
  { id: "ST003", name: "Railway Station", route: "Route B", distance: "6.2 km", monthlyAmount: 2400, students: 22, pickupTime: "7:00 AM", dropTime: "3:05 PM", status: "active" },
  { id: "ST004", name: "City Hospital", route: "Route B", distance: "8.5 km", monthlyAmount: 2800, students: 15, pickupTime: "7:10 AM", dropTime: "3:15 PM", status: "active" },
  { id: "ST005", name: "Mall Road", route: "Route C", distance: "10.2 km", monthlyAmount: 3200, students: 20, pickupTime: "6:55 AM", dropTime: "3:25 PM", status: "active" },
  { id: "ST006", name: "Industrial Area", route: "Route C", distance: "12.8 km", monthlyAmount: 3600, students: 8, pickupTime: "6:45 AM", dropTime: "3:35 PM", status: "active" },
]

const routes = [
  { id: "RT001", name: "Route A - North Delhi", stops: 8, distance: "15 km", students: 65, amount: 3000, status: "active" },
  { id: "RT002", name: "Route B - South Delhi", stops: 10, distance: "18 km", students: 72, amount: 3500, status: "active" },
  { id: "RT003", name: "Route C - East Delhi", stops: 6, distance: "12 km", students: 48, amount: 2500, status: "active" },
  { id: "RT004", name: "Route D - West Delhi", stops: 9, distance: "16 km", students: 58, amount: 3000, status: "active" },
  { id: "RT005", name: "Route E - Gurgaon", stops: 12, distance: "25 km", students: 42, amount: 4500, status: "active" },
  { id: "RT006", name: "Route F - Noida", stops: 11, distance: "22 km", students: 38, amount: 4000, status: "active" },
]

const stats = [
  { title: "Total Routes", value: "6", icon: Route },
  { title: "Total Stops", value: "56", icon: MapPin },
  { title: "Transport Students", value: "360", icon: Users },
  { title: "Monthly Collection", value: "₹10.8L", icon: IndianRupee },
]

const frequencyOptions = [
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly" },
  { value: "half-yearly", label: "Half-Yearly" },
  { value: "yearly", label: "Yearly" },
]

export function TransportSlabsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [createType, setCreateType] = useState<"distance" | "fixed" | "stop" | "route">("distance")

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Transport Fee Management</h1>
          <p className="text-sm text-muted-foreground">
            Configure distance slabs, fixed rates, stops, and bus routes
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Configuration
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add Transport Configuration</DialogTitle>
              <DialogDescription>
                Create a new transport fee slab, stop, or route
              </DialogDescription>
            </DialogHeader>
            <Tabs value={createType} onValueChange={(v) => setCreateType(v as typeof createType)} className="mt-4">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="distance">Per KM Slab</TabsTrigger>
                <TabsTrigger value="fixed">Fixed Rate</TabsTrigger>
                <TabsTrigger value="stop">Per Stop</TabsTrigger>
                <TabsTrigger value="route">Bus Route</TabsTrigger>
              </TabsList>

              {/* Distance-based Slab */}
              <TabsContent value="distance" className="space-y-4 mt-4">
                <FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <Field>
                      <FieldLabel>Min Distance (km)</FieldLabel>
                      <Input type="number" placeholder="0" />
                    </Field>
                    <Field>
                      <FieldLabel>Max Distance (km)</FieldLabel>
                      <Input type="number" placeholder="5" />
                    </Field>
                  </div>
                </FieldGroup>
                <div className="grid grid-cols-3 gap-4">
                  <Field>
                    <FieldLabel>Monthly Fee</FieldLabel>
                    <div className="relative">
                      <IndianRupee className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="1000" className="pl-8" />
                    </div>
                  </Field>
                  <Field>
                    <FieldLabel>Quarterly Fee</FieldLabel>
                    <div className="relative">
                      <IndianRupee className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="2850" className="pl-8" />
                    </div>
                  </Field>
                  <Field>
                    <FieldLabel>Yearly Fee</FieldLabel>
                    <div className="relative">
                      <IndianRupee className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="11000" className="pl-8" />
                    </div>
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Applicable From</FieldLabel>
                    <Input type="month" />
                  </Field>
                  <Field>
                    <FieldLabel>Applicable To</FieldLabel>
                    <Input type="month" />
                  </Field>
                </div>
                <Field>
                  <FieldLabel>Payment Frequency</FieldLabel>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      {frequencyOptions.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              </TabsContent>

              {/* Fixed Rate Slab */}
              <TabsContent value="fixed" className="space-y-4 mt-4">
                <Field>
                  <FieldLabel>Slab Name</FieldLabel>
                  <Input placeholder="e.g., Short Distance" />
                </Field>
                <FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <Field>
                      <FieldLabel>Min Distance (km)</FieldLabel>
                      <Input type="number" placeholder="0" />
                    </Field>
                    <Field>
                      <FieldLabel>Max Distance (km)</FieldLabel>
                      <Input type="number" placeholder="5" />
                    </Field>
                  </div>
                </FieldGroup>
                <FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <Field>
                      <FieldLabel>Base Amount</FieldLabel>
                      <div className="relative">
                        <IndianRupee className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="500" className="pl-8" />
                      </div>
                    </Field>
                    <Field>
                      <FieldLabel>Rate per KM</FieldLabel>
                      <div className="relative">
                        <IndianRupee className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input placeholder="200" className="pl-8" />
                      </div>
                    </Field>
                  </div>
                </FieldGroup>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Applicable Period From</FieldLabel>
                    <Input type="month" />
                  </Field>
                  <Field>
                    <FieldLabel>Applicable Period To</FieldLabel>
                    <Input type="month" />
                  </Field>
                </div>
                <Field>
                  <FieldLabel>Payment Frequency</FieldLabel>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      {frequencyOptions.map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              </TabsContent>

              {/* Stop-based Fee */}
              <TabsContent value="stop" className="space-y-4 mt-4">
                <FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <Field>
                      <FieldLabel>Stop Name</FieldLabel>
                      <Input placeholder="e.g., Sector 15 Gate" />
                    </Field>
                    <Field>
                      <FieldLabel>Assign to Route</FieldLabel>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select route" />
                        </SelectTrigger>
                        <SelectContent>
                          {routes.map((route) => (
                            <SelectItem key={route.id} value={route.id}>{route.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </Field>
                  </div>
                </FieldGroup>
                <Field>
                  <FieldLabel>Distance from School (km)</FieldLabel>
                  <Input type="number" step="0.1" placeholder="2.5" />
                </Field>
                <Field>
                  <FieldLabel>Monthly Fee</FieldLabel>
                  <div className="relative">
                    <IndianRupee className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="1200" className="pl-8" />
                  </div>
                </Field>
                <FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <Field>
                      <FieldLabel>Pickup Time</FieldLabel>
                      <Input type="time" />
                    </Field>
                    <Field>
                      <FieldLabel>Drop Time</FieldLabel>
                      <Input type="time" />
                    </Field>
                  </div>
                </FieldGroup>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Applicable From</FieldLabel>
                    <Input type="month" />
                  </Field>
                  <Field>
                    <FieldLabel>Applicable To</FieldLabel>
                    <Input type="month" />
                  </Field>
                </div>
              </TabsContent>

              {/* Route */}
              <TabsContent value="route" className="space-y-4 mt-4">
                <Field>
                  <FieldLabel>Route Name</FieldLabel>
                  <Input placeholder="e.g., Route A - North Delhi" />
                </Field>
                <FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <Field>
                      <FieldLabel>Number of Stops</FieldLabel>
                      <Input type="number" placeholder="8" />
                    </Field>
                    <Field>
                      <FieldLabel>Total Distance</FieldLabel>
                      <Input placeholder="15 km" />
                    </Field>
                  </div>
                </FieldGroup>
                <Field>
                  <FieldLabel>Monthly Fee</FieldLabel>
                  <div className="relative">
                    <IndianRupee className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input placeholder="3000" className="pl-8" />
                  </div>
                </Field>
                <div className="grid grid-cols-2 gap-4">
                  <Field>
                    <FieldLabel>Applicable From</FieldLabel>
                    <Input type="month" />
                  </Field>
                  <Field>
                    <FieldLabel>Applicable To</FieldLabel>
                    <Input type="month" />
                  </Field>
                </div>
              </TabsContent>
            </Tabs>
            <DialogFooter className="mt-4">
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsCreateDialogOpen(false)}>
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="rounded-lg bg-primary/10 p-3">
                <stat.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="distance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="distance">Per KM Slabs</TabsTrigger>
          <TabsTrigger value="fixed">Fixed Rate Slabs</TabsTrigger>
          <TabsTrigger value="stops">Per Stop Fees</TabsTrigger>
          <TabsTrigger value="routes">Bus Routes</TabsTrigger>
        </TabsList>

        {/* Distance Slabs Tab */}
        <TabsContent value="distance">
          <Card>
            <CardHeader>
              <CardTitle>Distance-based Fee Slabs</CardTitle>
              <CardDescription>
                Transport fees based on distance from school with applicable period
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Slab ID</TableHead>
                    <TableHead>Distance Range</TableHead>
                    <TableHead className="text-right">Monthly</TableHead>
                    <TableHead className="text-right">Quarterly</TableHead>
                    <TableHead className="text-right">Yearly</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {distanceSlabs.map((slab) => (
                    <TableRow key={slab.id}>
                      <TableCell className="font-mono text-sm">{slab.id}</TableCell>
                      <TableCell className="font-medium">{slab.range}</TableCell>
                      <TableCell className="text-right font-semibold">
                        ₹{slab.monthlyAmount.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        ₹{slab.quarterlyAmount.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        ₹{slab.yearlyAmount.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {slab.applicableFrom} - {slab.applicableTo}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{slab.students}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={slab.status === "active" ? "default" : "secondary"}>
                          {slab.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fixed Rate Slabs Tab */}
        <TabsContent value="fixed">
          <Card>
            <CardHeader>
              <CardTitle>Fixed Rate Fee Slabs</CardTitle>
              <CardDescription>
                Base amount plus per-kilometer rate within distance range
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Slab ID</TableHead>
                    <TableHead>Slab Name</TableHead>
                    <TableHead>Distance Range</TableHead>
                    <TableHead className="text-right">Base Amount</TableHead>
                    <TableHead className="text-right">Rate/KM</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fixedRateSlabs.map((slab) => (
                    <TableRow key={slab.id}>
                      <TableCell className="font-mono text-sm">{slab.id}</TableCell>
                      <TableCell className="font-medium">{slab.name}</TableCell>
                      <TableCell>{slab.minKm} - {slab.maxKm} km</TableCell>
                      <TableCell className="text-right font-semibold">
                        ₹{slab.baseAmount.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        ₹{slab.ratePerKm}/km
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{slab.students}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={slab.status === "active" ? "default" : "secondary"}>
                          {slab.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Stops Tab */}
        <TabsContent value="stops">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Stop-based Fees</CardTitle>
                  <CardDescription>
                    Fixed fees per pickup/drop stop with timings
                  </CardDescription>
                </div>
                <div className="relative w-72">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search stops..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Stop ID</TableHead>
                    <TableHead>Stop Name</TableHead>
                    <TableHead>Route</TableHead>
                    <TableHead>Distance</TableHead>
                    <TableHead className="text-right">Monthly Fee</TableHead>
                    <TableHead>Pickup</TableHead>
                    <TableHead>Drop</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stops.map((stop) => (
                    <TableRow key={stop.id}>
                      <TableCell className="font-mono text-sm">{stop.id}</TableCell>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          {stop.name}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{stop.route}</Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{stop.distance}</TableCell>
                      <TableCell className="text-right font-semibold">
                        ₹{stop.monthlyAmount.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs">
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          {stop.pickupTime}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs">
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          {stop.dropTime}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{stop.students}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={stop.status === "active" ? "default" : "secondary"}>
                          {stop.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Routes Tab */}
        <TabsContent value="routes">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Bus Routes</CardTitle>
                  <CardDescription>
                    Route-based transport fee configuration
                  </CardDescription>
                </div>
                <div className="relative w-72">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search routes..."
                    className="pl-8"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Route ID</TableHead>
                    <TableHead>Route Name</TableHead>
                    <TableHead>Stops</TableHead>
                    <TableHead>Distance</TableHead>
                    <TableHead className="text-right">Monthly Fee</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {routes.map((route) => (
                    <TableRow key={route.id}>
                      <TableCell className="font-mono text-sm">{route.id}</TableCell>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <Bus className="h-4 w-4 text-muted-foreground" />
                          {route.name}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          {route.stops}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{route.distance}</TableCell>
                      <TableCell className="text-right font-semibold">
                        ₹{route.amount.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{route.students}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={route.status === "active" ? "default" : "secondary"}>
                          {route.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
