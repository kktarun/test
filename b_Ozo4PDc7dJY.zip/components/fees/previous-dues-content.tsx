"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Search,
  History,
  AlertCircle,
  CheckCircle2,
  Download,
  Upload,
  ArrowRight,
  IndianRupee,
  Calendar,
  FileText,
} from "lucide-react"

const previousDuesStats = [
  { label: "Total Previous Dues", value: "12,45,000", trend: "from 2023-24", icon: History },
  { label: "Collected", value: "8,32,500", trend: "67% recovered", icon: CheckCircle2 },
  { label: "Pending", value: "4,12,500", trend: "123 students", icon: AlertCircle },
]

const previousDues = [
  {
    id: "STU001",
    name: "Arjun Sharma",
    class: "10-A",
    previousYear: "2023-24",
    previousClass: "9-A",
    totalDue: 25000,
    collected: 15000,
    pending: 10000,
    lastPayment: "2024-02-15",
    status: "partial",
  },
  {
    id: "STU002",
    name: "Priya Patel",
    class: "9-B",
    previousYear: "2023-24",
    previousClass: "8-B",
    totalDue: 18500,
    collected: 18500,
    pending: 0,
    lastPayment: "2024-03-01",
    status: "cleared",
  },
  {
    id: "STU003",
    name: "Rahul Verma",
    class: "8-C",
    previousYear: "2023-24",
    previousClass: "7-C",
    totalDue: 32000,
    collected: 0,
    pending: 32000,
    lastPayment: null,
    status: "unpaid",
  },
  {
    id: "STU004",
    name: "Ananya Gupta",
    class: "10-A",
    previousYear: "2023-24",
    previousClass: "9-A",
    totalDue: 15000,
    collected: 8000,
    pending: 7000,
    lastPayment: "2024-01-20",
    status: "partial",
  },
  {
    id: "STU005",
    name: "Vikram Singh",
    class: "7-A",
    previousYear: "2023-24",
    previousClass: "6-A",
    totalDue: 28000,
    collected: 28000,
    pending: 0,
    lastPayment: "2024-02-28",
    status: "cleared",
  },
]

export function PreviousDuesContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [yearFilter, setYearFilter] = useState("2023-24")
  const [showCollectDialog, setShowCollectDialog] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState<typeof previousDues[0] | null>(null)
  const [showImportDialog, setShowImportDialog] = useState(false)

  const filteredDues = previousDues.filter((due) => {
    const matchesSearch =
      due.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      due.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || due.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Previous Dues</h1>
          <p className="text-sm text-muted-foreground">
            Carry forward and collect dues from previous academic years
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setShowImportDialog(true)}>
            <Upload className="h-4 w-4" />
            Import Dues
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        {previousDuesStats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.trend}</p>
                </div>
                <div className={`rounded-lg p-2.5 ${
                  stat.label.includes("Pending")
                    ? "bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400"
                    : stat.label.includes("Collected")
                    ? "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400"
                    : "bg-primary/10 text-primary"
                }`}>
                  <stat.icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by name or ID..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Select value={yearFilter} onValueChange={setYearFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2023-24">2023-24</SelectItem>
                  <SelectItem value="2022-23">2022-23</SelectItem>
                  <SelectItem value="2021-22">2021-22</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="unpaid">Unpaid</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                  <SelectItem value="cleared">Cleared</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dues Table */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-medium">Previous Year Dues - {yearFilter}</CardTitle>
          <CardDescription>
            {filteredDues.length} student(s) with previous year dues
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Previous Class</TableHead>
                <TableHead className="text-right">Total Due</TableHead>
                <TableHead className="text-right">Collected</TableHead>
                <TableHead className="text-right">Pending</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDues.map((due) => (
                <TableRow key={due.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{due.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {due.id} | Current: {due.class}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2 text-sm">
                      <span className="text-muted-foreground">{due.previousClass}</span>
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      <span>{due.class}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatCurrency(due.totalDue)}
                  </TableCell>
                  <TableCell className="text-right text-green-600 dark:text-green-400">
                    {formatCurrency(due.collected)}
                  </TableCell>
                  <TableCell className="text-right text-orange-600 dark:text-orange-400 font-medium">
                    {formatCurrency(due.pending)}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        due.status === "cleared"
                          ? "border-green-200 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-900/30 dark:text-green-400"
                          : due.status === "partial"
                          ? "border-yellow-200 bg-yellow-50 text-yellow-700 dark:border-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
                          : "border-red-200 bg-red-50 text-red-700 dark:border-red-800 dark:bg-red-900/30 dark:text-red-400"
                      }
                    >
                      {due.status === "cleared" && <CheckCircle2 className="mr-1 h-3 w-3" />}
                      {due.status === "partial" && <History className="mr-1 h-3 w-3" />}
                      {due.status === "unpaid" && <AlertCircle className="mr-1 h-3 w-3" />}
                      {due.status.charAt(0).toUpperCase() + due.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      size="sm"
                      variant={due.status === "cleared" ? "outline" : "default"}
                      disabled={due.status === "cleared"}
                      onClick={() => {
                        setSelectedStudent(due)
                        setShowCollectDialog(true)
                      }}
                    >
                      {due.status === "cleared" ? "Cleared" : "Collect"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Collect Dialog */}
      <Dialog open={showCollectDialog} onOpenChange={setShowCollectDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Collect Previous Dues</DialogTitle>
            <DialogDescription>
              {selectedStudent?.name} - {selectedStudent?.previousYear}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Total Previous Due</span>
                <span className="font-medium">{formatCurrency(selectedStudent?.totalDue || 0)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Already Collected</span>
                <span className="font-medium text-green-600 dark:text-green-400">
                  {formatCurrency(selectedStudent?.collected || 0)}
                </span>
              </div>
              <div className="border-t pt-3 flex justify-between text-sm">
                <span className="text-muted-foreground">Pending Amount</span>
                <span className="font-bold text-orange-600 dark:text-orange-400">
                  {formatCurrency(selectedStudent?.pending || 0)}
                </span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Amount to Collect</Label>
              <Input
                type="number"
                placeholder={`Max: ${selectedStudent?.pending}`}
                defaultValue={selectedStudent?.pending}
              />
            </div>
            <div className="space-y-2">
              <Label>Payment Mode</Label>
              <Select defaultValue="cash">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                  <SelectItem value="online">Online Transfer</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Remarks (Optional)</Label>
              <Input placeholder="Any remarks for this collection" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCollectDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowCollectDialog(false)}>
              Collect Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Import Previous Dues</DialogTitle>
            <DialogDescription>
              Upload a CSV or Excel file with previous year dues data
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Academic Year</Label>
              <Select defaultValue="2023-24">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2023-24">2023-24</SelectItem>
                  <SelectItem value="2022-23">2022-23</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-lg border-2 border-dashed border-muted-foreground/25 p-8 text-center">
              <FileText className="mx-auto h-10 w-10 text-muted-foreground/50 mb-3" />
              <p className="text-sm font-medium">Drop your file here or click to browse</p>
              <p className="text-xs text-muted-foreground mt-1">
                Supports CSV and Excel files
              </p>
              <Button variant="outline" size="sm" className="mt-4">
                Choose File
              </Button>
            </div>
            <Button variant="link" className="text-xs p-0 h-auto">
              Download sample template
            </Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImportDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowImportDialog(false)}>
              Import Data
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
