"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  FileDown, 
  IndianRupee, 
  Settings2,
  MoreHorizontal,
  Copy,
  Eye,
  EyeOff,
  ArrowUpDown,
  GripVertical,
  Calendar,
} from "lucide-react"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Checkbox } from "@/components/ui/checkbox"

const feeHeads = [
  {
    id: "FH001",
    name: "Tuition Fee",
    code: "TUI",
    frequency: "Quarterly",
    amount: 7500,
    isRecurring: true,
    isMandatory: true,
    taxable: false,
    status: "active",
    appliedTo: "All Classes",
    paymentMode: "both",
    allowPartial: true,
    minPartialAmount: 2500,
    paymentOrder: 1,
    dueDate: "10th of month",
    fineApplicable: true,
    finePerDay: 50,
    maxFine: 500,
  },
  {
    id: "FH002",
    name: "Admission Fee",
    code: "ADM",
    frequency: "One-time",
    amount: 5000,
    isRecurring: false,
    isMandatory: true,
    taxable: false,
    status: "active",
    appliedTo: "New Admissions",
    paymentMode: "both",
    allowPartial: false,
    minPartialAmount: 0,
    paymentOrder: 2,
    dueDate: "At admission",
    fineApplicable: false,
    finePerDay: 0,
    maxFine: 0,
  },
  {
    id: "FH003",
    name: "Transport Fee",
    code: "TRN",
    frequency: "Quarterly",
    amount: 4500,
    isRecurring: true,
    isMandatory: false,
    taxable: true,
    status: "active",
    appliedTo: "Transport Students",
    paymentMode: "online",
    allowPartial: true,
    minPartialAmount: 1500,
    paymentOrder: 3,
    dueDate: "15th of month",
    fineApplicable: true,
    finePerDay: 25,
    maxFine: 250,
  },
  {
    id: "FH004",
    name: "Activity Fee",
    code: "ACT",
    frequency: "Annual",
    amount: 3000,
    isRecurring: false,
    isMandatory: true,
    taxable: false,
    status: "active",
    appliedTo: "All Classes",
    paymentMode: "both",
    allowPartial: false,
    minPartialAmount: 0,
    paymentOrder: 4,
    dueDate: "April 30",
    fineApplicable: false,
    finePerDay: 0,
    maxFine: 0,
  },
  {
    id: "FH005",
    name: "Lab Fee",
    code: "LAB",
    frequency: "Annual",
    amount: 4000,
    isRecurring: false,
    isMandatory: true,
    taxable: false,
    status: "inactive",
    appliedTo: "Class 6-12",
    paymentMode: "offline",
    allowPartial: true,
    minPartialAmount: 1000,
    paymentOrder: 5,
    dueDate: "May 15",
    fineApplicable: true,
    finePerDay: 30,
    maxFine: 300,
  },
  {
    id: "FH006",
    name: "Library Fee",
    code: "LIB",
    frequency: "Annual",
    amount: 2000,
    isRecurring: false,
    isMandatory: true,
    taxable: false,
    status: "active",
    appliedTo: "All Classes",
    paymentMode: "both",
    allowPartial: false,
    minPartialAmount: 0,
    paymentOrder: 6,
    dueDate: "April 15",
    fineApplicable: false,
    finePerDay: 0,
    maxFine: 0,
  },
]

const receiptTypes = [
  { id: "RT001", name: "Standard Receipt", code: "STD", isDefault: true, fields: ["student", "fees", "amount", "date"] },
  { id: "RT002", name: "Detailed Receipt", code: "DTL", isDefault: false, fields: ["student", "fees", "breakdown", "amount", "date", "balance"] },
  { id: "RT003", name: "Transport Receipt", code: "TRN", isDefault: false, fields: ["student", "route", "amount", "date"] },
  { id: "RT004", name: "Hostel Receipt", code: "HST", isDefault: false, fields: ["student", "room", "meals", "amount", "date"] },
]

export function FeeHeadsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isConfigDialogOpen, setIsConfigDialogOpen] = useState(false)
  const [selectedFeeHead, setSelectedFeeHead] = useState<typeof feeHeads[0] | null>(null)

  const filteredFeeHeads = feeHeads.filter(
    (fh) =>
      fh.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fh.code.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getPaymentModeBadge = (mode: string) => {
    switch (mode) {
      case "online":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">Online Only</Badge>
      case "offline":
        return <Badge variant="outline" className="bg-orange-50 text-orange-700 dark:bg-orange-950 dark:text-orange-300">Offline Only</Badge>
      case "both":
        return <Badge variant="outline" className="bg-green-50 text-green-700 dark:bg-green-950 dark:text-green-300">Online &amp; Offline</Badge>
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Fee Heads</h1>
          <p className="text-muted-foreground">
            Configure fee components, payment rules, and collection settings
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <FileDown className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Fee Head
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Fee Head</DialogTitle>
                <DialogDescription>
                  Add a new fee component with payment configuration
                </DialogDescription>
              </DialogHeader>
              <Tabs defaultValue="basic" className="mt-4">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basic">Basic Info</TabsTrigger>
                  <TabsTrigger value="payment">Payment Config</TabsTrigger>
                  <TabsTrigger value="fine">Fine Settings</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basic" className="space-y-4 pt-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Fee Head Name</FieldLabel>
                        <Input placeholder="e.g., Tuition Fee" />
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Fee Code</FieldLabel>
                        <Input placeholder="e.g., TUI" />
                      </Field>
                    </FieldGroup>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Amount (₹)</FieldLabel>
                        <Input type="number" placeholder="0" />
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Frequency</FieldLabel>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="one-time">One-time</SelectItem>
                            <SelectItem value="monthly">Monthly</SelectItem>
                            <SelectItem value="quarterly">Quarterly</SelectItem>
                            <SelectItem value="half-yearly">Half-yearly</SelectItem>
                            <SelectItem value="annual">Annual</SelectItem>
                            <SelectItem value="per-exam">Per Exam</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </FieldGroup>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Applied To</FieldLabel>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select scope" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Classes</SelectItem>
                            <SelectItem value="new-admissions">New Admissions Only</SelectItem>
                            <SelectItem value="transport">Transport Students</SelectItem>
                            <SelectItem value="hostel">Hostel Students</SelectItem>
                            <SelectItem value="custom">Custom Groups</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Due Date</FieldLabel>
                        <Input placeholder="e.g., 10th of month" />
                      </Field>
                    </FieldGroup>
                  </div>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Description (shown to parents)</FieldLabel>
                      <Textarea placeholder="Brief description of this fee head..." />
                    </Field>
                  </FieldGroup>
                  <div className="flex flex-wrap gap-6">
                    <div className="flex items-center gap-2">
                      <Switch id="mandatory" />
                      <label htmlFor="mandatory" className="text-sm">Mandatory</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch id="recurring" />
                      <label htmlFor="recurring" className="text-sm">Recurring</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch id="taxable" />
                      <label htmlFor="taxable" className="text-sm">GST Applicable</label>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="payment" className="space-y-4 pt-4">
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Payment Mode</FieldLabel>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select payment mode" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="both">Online &amp; Offline</SelectItem>
                          <SelectItem value="online">Online Only</SelectItem>
                          <SelectItem value="offline">Offline Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </Field>
                  </FieldGroup>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Payment Order Priority</FieldLabel>
                      <Input type="number" placeholder="1" min="1" />
                      <p className="text-xs text-muted-foreground mt-1">
                        Lower number = higher priority. This fee will be collected first.
                      </p>
                    </Field>
                  </FieldGroup>
                  <div className="space-y-4 rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Allow Partial Payment</p>
                        <p className="text-sm text-muted-foreground">
                          Let parents pay this fee head in multiple installments
                        </p>
                      </div>
                      <Switch id="allowPartial" />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <FieldGroup>
                        <Field>
                          <FieldLabel>Minimum Partial Amount (₹)</FieldLabel>
                          <Input type="number" placeholder="0" />
                        </Field>
                      </FieldGroup>
                      <FieldGroup>
                        <Field>
                          <FieldLabel>Min Amount Per Transaction (₹)</FieldLabel>
                          <Input type="number" placeholder="500" />
                        </Field>
                      </FieldGroup>
                    </div>
                  </div>
                  <div className="space-y-4 rounded-lg border p-4">
                    <p className="font-medium">Class-wise Override</p>
                    <p className="text-sm text-muted-foreground">
                      Configure different payment rules for specific classes
                    </p>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-3 w-3" />
                      Add Class Override
                    </Button>
                  </div>
                  <div className="space-y-4 rounded-lg border p-4">
                    <p className="font-medium">Group-wise Override</p>
                    <p className="text-sm text-muted-foreground">
                      Configure different payment rules for student groups
                    </p>
                    <Button variant="outline" size="sm">
                      <Plus className="mr-2 h-3 w-3" />
                      Add Group Override
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="fine" className="space-y-4 pt-4">
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div>
                      <p className="font-medium">Enable Late Fee / Fine</p>
                      <p className="text-sm text-muted-foreground">
                        Automatically apply fine after due date
                      </p>
                    </div>
                    <Switch id="enableFine" />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Fine Per Day (₹)</FieldLabel>
                        <Input type="number" placeholder="0" />
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Maximum Fine (₹)</FieldLabel>
                        <Input type="number" placeholder="0" />
                      </Field>
                    </FieldGroup>
                  </div>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Grace Period (Days)</FieldLabel>
                      <Input type="number" placeholder="0" />
                      <p className="text-xs text-muted-foreground mt-1">
                        Number of days after due date before fine starts
                      </p>
                    </Field>
                  </FieldGroup>
                  <div className="space-y-4 rounded-lg border p-4">
                    <p className="font-medium">Fine Exemption</p>
                    <div className="flex items-center gap-2">
                      <Checkbox id="exemptScholarship" />
                      <label htmlFor="exemptScholarship" className="text-sm">Exempt scholarship students</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox id="exemptStaff" />
                      <label htmlFor="exemptStaff" className="text-sm">Exempt staff wards</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox id="allowManualExempt" />
                      <label htmlFor="allowManualExempt" className="text-sm">Allow manual full/partial exemption</label>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              <DialogFooter className="mt-6">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsCreateDialogOpen(false)}>
                  Create Fee Head
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{feeHeads.length}</div>
            <p className="text-sm text-muted-foreground">Total Fee Heads</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{feeHeads.filter(f => f.status === "active").length}</div>
            <p className="text-sm text-muted-foreground">Active Fee Heads</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{feeHeads.filter(f => f.allowPartial).length}</div>
            <p className="text-sm text-muted-foreground">Partial Payment Enabled</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{feeHeads.filter(f => f.fineApplicable).length}</div>
            <p className="text-sm text-muted-foreground">Fine Applicable</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="fee-heads" className="space-y-4">
        <TabsList>
          <TabsTrigger value="fee-heads">Fee Heads</TabsTrigger>
          <TabsTrigger value="receipt-types">Receipt Types</TabsTrigger>
          <TabsTrigger value="payment-order">Payment Order</TabsTrigger>
        </TabsList>

        <TabsContent value="fee-heads" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search fee heads..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-8">
                      <Checkbox />
                    </TableHead>
                    <TableHead>Fee Head</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Frequency</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Payment Mode</TableHead>
                    <TableHead>Partial Pay</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredFeeHeads.map((feeHead) => (
                    <TableRow key={feeHead.id}>
                      <TableCell>
                        <Checkbox />
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{feeHead.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {feeHead.code} &bull; {feeHead.appliedTo}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <IndianRupee className="h-3 w-3" />
                          {feeHead.amount.toLocaleString()}
                        </div>
                      </TableCell>
                      <TableCell>{feeHead.frequency}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm">
                          <Calendar className="h-3 w-3 text-muted-foreground" />
                          {feeHead.dueDate}
                        </div>
                      </TableCell>
                      <TableCell>{getPaymentModeBadge(feeHead.paymentMode)}</TableCell>
                      <TableCell>
                        {feeHead.allowPartial ? (
                          <div className="text-sm">
                            <Badge variant="secondary" className="text-xs">Yes</Badge>
                            <p className="text-xs text-muted-foreground mt-0.5">
                              Min: ₹{feeHead.minPartialAmount}
                            </p>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">No</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={feeHead.status === "active" ? "default" : "secondary"}>
                          {feeHead.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => {
                              setSelectedFeeHead(feeHead)
                              setIsConfigDialogOpen(true)
                            }}>
                              <Settings2 className="mr-2 h-4 w-4" />
                              Payment Config
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Copy className="mr-2 h-4 w-4" />
                              Duplicate
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              {feeHead.status === "active" ? (
                                <>
                                  <EyeOff className="mr-2 h-4 w-4" />
                                  Deactivate
                                </>
                              ) : (
                                <>
                                  <Eye className="mr-2 h-4 w-4" />
                                  Activate
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="receipt-types" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Receipt Types</CardTitle>
                  <CardDescription>Configure different receipt formats for various fee types</CardDescription>
                </div>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Receipt Type
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Receipt Type</TableHead>
                    <TableHead>Code</TableHead>
                    <TableHead>Fields Included</TableHead>
                    <TableHead>Default</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {receiptTypes.map((receipt) => (
                    <TableRow key={receipt.id}>
                      <TableCell className="font-medium">{receipt.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{receipt.code}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {receipt.fields.map((field) => (
                            <Badge key={field} variant="secondary" className="text-xs">
                              {field}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        {receipt.isDefault && <Badge>Default</Badge>}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Edit className="mr-2 h-4 w-4" />
                          Customize
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment-order" className="space-y-4">
          <Card>
            <CardHeader>
              <div>
                <CardTitle>Payment Order Priority</CardTitle>
                <CardDescription>
                  Drag to reorder. Fees with lower numbers are collected first when parents make partial payments.
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {[...feeHeads]
                  .sort((a, b) => a.paymentOrder - b.paymentOrder)
                  .map((feeHead, index) => (
                    <div
                      key={feeHead.id}
                      className="flex items-center gap-4 rounded-lg border p-3 bg-card"
                    >
                      <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                        {index + 1}
                      </span>
                      <div className="flex-1">
                        <p className="font-medium">{feeHead.name}</p>
                        <p className="text-sm text-muted-foreground">{feeHead.code}</p>
                      </div>
                      <Badge variant={feeHead.isMandatory ? "default" : "secondary"}>
                        {feeHead.isMandatory ? "Mandatory" : "Optional"}
                      </Badge>
                      <div className="text-right">
                        <p className="font-medium">₹{feeHead.amount.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">{feeHead.frequency}</p>
                      </div>
                    </div>
                  ))}
              </div>
              <div className="mt-4 flex justify-end">
                <Button>Save Order</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Payment Config Dialog */}
      <Dialog open={isConfigDialogOpen} onOpenChange={setIsConfigDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Payment Configuration</DialogTitle>
            <DialogDescription>
              Configure payment rules for {selectedFeeHead?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <FieldGroup>
              <Field>
                <FieldLabel>Payment Mode</FieldLabel>
                <Select defaultValue={selectedFeeHead?.paymentMode}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="both">Online &amp; Offline</SelectItem>
                    <SelectItem value="online">Online Only</SelectItem>
                    <SelectItem value="offline">Offline Only</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
            </FieldGroup>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="font-medium text-sm">Allow Partial Payment</p>
                <p className="text-xs text-muted-foreground">
                  Parents can pay in installments
                </p>
              </div>
              <Switch defaultChecked={selectedFeeHead?.allowPartial} />
            </div>
            <FieldGroup>
              <Field>
                <FieldLabel>Minimum Partial Amount (₹)</FieldLabel>
                <Input type="number" defaultValue={selectedFeeHead?.minPartialAmount} />
              </Field>
            </FieldGroup>
            <FieldGroup>
              <Field>
                <FieldLabel>Payment Order</FieldLabel>
                <Input type="number" defaultValue={selectedFeeHead?.paymentOrder} min="1" />
              </Field>
            </FieldGroup>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfigDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsConfigDialogOpen(false)}>
              Save Configuration
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
