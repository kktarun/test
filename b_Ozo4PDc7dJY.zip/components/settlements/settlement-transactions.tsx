"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import Link from "next/link"
import { 
  ExternalLink, 
  CreditCard, 
  Smartphone, 
  Building, 
  Wallet as WalletIcon,
  Receipt,
  Percent,
  TrendingUp
} from "lucide-react"

interface SettlementTransactionsProps {
  settlementId: string
}

interface SettlementTransaction {
  id: string
  orderId: string
  edvironOrderId: string
  gatewayTxnId: string
  institute: string
  studentName: string
  studentId: string
  amount: number
  orderAmount: number
  paymentMode: string
  channel: string
  date: string
  // MDR Details
  mdrAmount: number
  mdrPercentage: number
  mdrBearing: "surcharge" | "merchant_bearing"
  // ERP Commission
  erpCommission: number
  erpCommissionPercentage: number
  // Net Settlement
  vendorAmount: number
  // Card/UPI details
  cardNetwork?: string
  cardIssuer?: string
  upiPsp?: string
  // Financing details
  isFinancing?: boolean
  financingType?: string
  financingCharges?: {
    parentCharge: number
    instituteCharge: number
    bankCharge: number
  }
}

const transactionsBySettlement: Record<string, SettlementTransaction[]> = {
  STL001234: [
    {
      id: "TXN001234567",
      orderId: "ORD-DPS-2024-001",
      edvironOrderId: "EDV-2024-001234567",
      gatewayTxnId: "GTXN-RZP-001234567",
      institute: "Delhi Public School",
      studentName: "Aarav Sharma",
      studentId: "STU-DPS-001",
      amount: 45000,
      orderAmount: 45000,
      paymentMode: "Credit Card",
      channel: "Payment Form",
      date: "2024-01-15",
      mdrAmount: 900,
      mdrPercentage: 2.0,
      mdrBearing: "surcharge",
      erpCommission: 450,
      erpCommissionPercentage: 1.0,
      vendorAmount: 43650,
      cardNetwork: "Visa",
      cardIssuer: "HDFC Bank",
    },
    {
      id: "TXN001234568",
      orderId: "ORD-SMS-2024-002",
      edvironOrderId: "EDV-2024-001234568",
      gatewayTxnId: "GTXN-RZP-001234568",
      institute: "Delhi Public School",
      studentName: "Priya Singh",
      studentId: "STU-SMS-002",
      amount: 32500,
      orderAmount: 32500,
      paymentMode: "UPI",
      channel: "Payment Link",
      date: "2024-01-15",
      mdrAmount: 162,
      mdrPercentage: 0.5,
      mdrBearing: "merchant_bearing",
      erpCommission: 325,
      erpCommissionPercentage: 1.0,
      vendorAmount: 32013,
      upiPsp: "PhonePe",
    },
    {
      id: "TXN001234570",
      orderId: "ORD-RYN-2024-003",
      edvironOrderId: "EDV-2024-001234570",
      gatewayTxnId: "GTXN-RZP-001234570",
      institute: "Delhi Public School",
      studentName: "Kabir Mehta",
      studentId: "STU-RYN-003",
      amount: 52000,
      orderAmount: 52000,
      paymentMode: "Net Banking",
      channel: "Online",
      date: "2024-01-15",
      mdrAmount: 780,
      mdrPercentage: 1.5,
      mdrBearing: "merchant_bearing",
      erpCommission: 520,
      erpCommissionPercentage: 1.0,
      vendorAmount: 50700,
    },
    {
      id: "TXN001234572",
      orderId: "ORD-DPS-2024-004",
      edvironOrderId: "EDV-2024-001234572",
      gatewayTxnId: "GTXN-RZP-001234572",
      institute: "Delhi Public School",
      studentName: "Ananya Verma",
      studentId: "STU-DPS-004",
      amount: 38000,
      orderAmount: 38000,
      paymentMode: "UPI",
      channel: "Online",
      date: "2024-01-15",
      mdrAmount: 190,
      mdrPercentage: 0.5,
      mdrBearing: "merchant_bearing",
      erpCommission: 380,
      erpCommissionPercentage: 1.0,
      vendorAmount: 37430,
      upiPsp: "Google Pay",
    },
  ],
  STL001235: [
    {
      id: "TXN001234580",
      orderId: "ORD-AMT-2024-005",
      edvironOrderId: "EDV-2024-001234580",
      gatewayTxnId: "GTXN-CSF-001234580",
      institute: "Delhi Public School",
      studentName: "Rahul Kumar",
      studentId: "STU-AMT-005",
      amount: 125000,
      orderAmount: 125000,
      paymentMode: "Card EMI",
      channel: "Payment Form",
      date: "2024-01-15",
      mdrAmount: 2500,
      mdrPercentage: 2.0,
      mdrBearing: "merchant_bearing",
      erpCommission: 1250,
      erpCommissionPercentage: 1.0,
      vendorAmount: 121250,
      cardNetwork: "Mastercard",
      cardIssuer: "ICICI Bank",
      isFinancing: true,
      financingType: "No Cost EMI",
      financingCharges: {
        parentCharge: 0,
        instituteCharge: 6250,
        bankCharge: 0,
      },
    },
    {
      id: "TXN001234581",
      orderId: "ORD-MOD-2024-006",
      edvironOrderId: "EDV-2024-001234581",
      gatewayTxnId: "GTXN-CSF-001234581",
      institute: "Delhi Public School",
      studentName: "Ishita Gupta",
      studentId: "STU-MOD-006",
      amount: 28000,
      orderAmount: 28000,
      paymentMode: "Debit Card",
      channel: "Online",
      date: "2024-01-15",
      mdrAmount: 0,
      mdrPercentage: 0,
      mdrBearing: "merchant_bearing",
      erpCommission: 280,
      erpCommissionPercentage: 1.0,
      vendorAmount: 27720,
      cardNetwork: "RuPay",
      cardIssuer: "SBI",
    },
  ],
  STL001236: [
    {
      id: "TXN001234590",
      orderId: "ORD-SMS-2024-007",
      edvironOrderId: "EDV-2024-001234590",
      gatewayTxnId: "GTXN-EZB-001234590",
      institute: "Delhi Public School",
      studentName: "Diya Patel",
      studentId: "STU-SMS-007",
      amount: 42000,
      orderAmount: 42000,
      paymentMode: "Credit Card",
      channel: "Payment Link",
      date: "2024-01-15",
      mdrAmount: 840,
      mdrPercentage: 2.0,
      mdrBearing: "surcharge",
      erpCommission: 420,
      erpCommissionPercentage: 1.0,
      vendorAmount: 40740,
      cardNetwork: "Visa",
      cardIssuer: "Axis Bank",
    },
  ],
  STL001237: [
    {
      id: "TXN001234600",
      orderId: "ORD-RYN-2024-008",
      edvironOrderId: "EDV-2024-001234600",
      gatewayTxnId: "GTXN-PAYTM-001234600",
      institute: "Delhi Public School",
      studentName: "Arjun Reddy",
      studentId: "STU-RYN-008",
      amount: 65000,
      orderAmount: 65000,
      paymentMode: "Wallet",
      channel: "Online",
      date: "2024-01-15",
      mdrAmount: 975,
      mdrPercentage: 1.5,
      mdrBearing: "surcharge",
      erpCommission: 650,
      erpCommissionPercentage: 1.0,
      vendorAmount: 63375,
    },
  ],
  STL001238: [
    {
      id: "TXN001234610",
      orderId: "ORD-DPS-2024-009",
      edvironOrderId: "EDV-2024-001234610",
      gatewayTxnId: "GTXN-RZP-001234610",
      institute: "Delhi Public School",
      studentName: "Rohan Sharma",
      studentId: "STU-DPS-009",
      amount: 35000,
      orderAmount: 35000,
      paymentMode: "UPI",
      channel: "Autopay",
      date: "2024-01-14",
      mdrAmount: 175,
      mdrPercentage: 0.5,
      mdrBearing: "merchant_bearing",
      erpCommission: 350,
      erpCommissionPercentage: 1.0,
      vendorAmount: 34475,
      upiPsp: "Google Pay",
    },
  ],
}

const paymentModeIcons: Record<string, React.ReactNode> = {
  "Credit Card": <CreditCard className="h-3.5 w-3.5" />,
  "Debit Card": <CreditCard className="h-3.5 w-3.5" />,
  "Card EMI": <CreditCard className="h-3.5 w-3.5" />,
  "UPI": <Smartphone className="h-3.5 w-3.5" />,
  "Net Banking": <Building className="h-3.5 w-3.5" />,
  "Wallet": <WalletIcon className="h-3.5 w-3.5" />,
}

export function SettlementTransactions({ settlementId }: SettlementTransactionsProps) {
  const transactions = transactionsBySettlement[settlementId] || []

  // Calculate totals
  const totals = transactions.reduce(
    (acc, txn) => ({
      amount: acc.amount + txn.amount,
      mdrAmount: acc.mdrAmount + txn.mdrAmount,
      erpCommission: acc.erpCommission + txn.erpCommission,
      vendorAmount: acc.vendorAmount + txn.vendorAmount,
    }),
    { amount: 0, mdrAmount: 0, erpCommission: 0, vendorAmount: 0 }
  )

  return (
    <div className="bg-secondary/20 p-4 border-t border-border">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
          <Receipt className="h-4 w-4" />
          Included Transactions ({transactions.length})
        </h4>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">Total MDR:</span>
            <span className="font-medium text-warning">₹{totals.mdrAmount.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">ERP Commission:</span>
            <span className="font-medium text-emerald-500">₹{totals.erpCommission.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">Net:</span>
            <span className="font-medium text-primary">₹{totals.vendorAmount.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Table Header */}
      <div className="hidden lg:grid lg:grid-cols-12 gap-2 px-3 py-2 bg-secondary/50 rounded-t-lg text-xs font-medium text-muted-foreground uppercase">
        <div className="col-span-2">Transaction</div>
        <div className="col-span-2">Student</div>
        <div className="col-span-2">Payment Mode</div>
        <div className="col-span-1 text-right">Amount</div>
        <div className="col-span-1 text-right">MDR</div>
        <div className="col-span-1 text-right">ERP Comm</div>
        <div className="col-span-1 text-right">Net</div>
        <div className="col-span-2 text-right">Actions</div>
      </div>

      <div className="space-y-2 mt-2">
        {transactions.map((txn) => (
          <div 
            key={txn.id} 
            className="rounded-lg bg-card border border-border p-3 hover:border-primary/30 transition-colors"
          >
            {/* Desktop View */}
            <div className="hidden lg:grid lg:grid-cols-12 gap-2 items-center">
              {/* Transaction IDs */}
              <div className="col-span-2">
                <Link 
                  href={`/transactions/${txn.id}`}
                  className="font-mono text-xs text-primary hover:underline"
                >
                  {txn.id}
                </Link>
                <p className="text-[10px] text-muted-foreground font-mono truncate" title={txn.gatewayTxnId}>
                  GW: {txn.gatewayTxnId.slice(-12)}
                </p>
              </div>

              {/* Student */}
              <div className="col-span-2">
                <p className="text-sm font-medium truncate">{txn.studentName}</p>
                <p className="text-[10px] text-muted-foreground truncate font-mono">{txn.id}</p>
              </div>

              {/* Payment Mode */}
              <div className="col-span-2">
                <div className="flex items-center gap-1.5">
                  {paymentModeIcons[txn.paymentMode] || <CreditCard className="h-3.5 w-3.5" />}
                  <span className="text-sm">{txn.paymentMode}</span>
                </div>
                <div className="flex items-center gap-1 mt-0.5">
                  {txn.cardNetwork && (
                    <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">
                      {txn.cardNetwork}
                    </Badge>
                  )}
                  {txn.upiPsp && (
                    <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">
                      {txn.upiPsp}
                    </Badge>
                  )}
                  {txn.isFinancing && (
                    <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
                      {txn.financingType}
                    </Badge>
                  )}
                </div>
              </div>

              {/* Amount */}
              <div className="col-span-1 text-right">
                <span className="font-semibold">₹{txn.amount.toLocaleString()}</span>
              </div>

              {/* MDR */}
              <div className="col-span-1 text-right">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="space-y-0.5">
                        <span className="text-warning font-medium">₹{txn.mdrAmount.toLocaleString()}</span>
                        <Badge 
                          variant="outline" 
                          className={`text-[8px] px-1 py-0 h-4 block w-fit ml-auto ${
                            txn.mdrBearing === "surcharge" 
                              ? "bg-red-500/10 text-red-400 border-red-500/20" 
                              : "bg-green-500/10 text-green-400 border-green-500/20"
                          }`}
                        >
                          {txn.mdrBearing === "surcharge" ? "Sur" : "Mer"}
                        </Badge>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">MDR: {txn.mdrPercentage}%</p>
                      <p className="text-xs">{txn.mdrBearing === "surcharge" ? "Charged to Parent" : "Merchant Bearing"}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              {/* ERP Commission */}
              <div className="col-span-1 text-right">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="space-y-0.5">
                        <span className="text-emerald-500 font-medium">₹{txn.erpCommission.toLocaleString()}</span>
                        <p className="text-[10px] text-muted-foreground">{txn.erpCommissionPercentage}%</p>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">ERP Commission: {txn.erpCommissionPercentage}% of txn amount</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              {/* Net */}
              <div className="col-span-1 text-right">
                <span className="text-primary font-semibold">₹{txn.vendorAmount.toLocaleString()}</span>
              </div>

              {/* Actions */}
              <div className="col-span-2 text-right">
                <Button variant="ghost" size="sm" asChild className="h-7 text-xs">
                  <Link href={`/transactions/${txn.id}`}>
                    View Details
                    <ExternalLink className="h-3 w-3 ml-1" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* Mobile View */}
            <div className="lg:hidden space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {paymentModeIcons[txn.paymentMode] || <CreditCard className="h-4 w-4" />}
                  <Link 
                    href={`/transactions/${txn.id}`}
                    className="font-mono text-sm text-primary hover:underline"
                  >
                    {txn.id}
                  </Link>
                </div>
                <span className="font-semibold">₹{txn.amount.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{txn.studentName}</span>
                <span className="text-muted-foreground">{txn.paymentMode}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-warning">MDR: ₹{txn.mdrAmount}</span>
                  <span className="text-emerald-500">ERP: ₹{txn.erpCommission}</span>
                </div>
                <span className="text-primary font-medium">Net: ₹{txn.vendorAmount.toLocaleString()}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Summary Footer */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="grid grid-cols-4 gap-4 text-sm">
          <div className="text-center">
            <p className="text-muted-foreground text-xs">Total Amount</p>
            <p className="font-bold">₹{totals.amount.toLocaleString()}</p>
          </div>
          <div className="text-center">
            <p className="text-muted-foreground text-xs">Total MDR</p>
            <p className="font-bold text-warning">-₹{totals.mdrAmount.toLocaleString()}</p>
          </div>
          <div className="text-center">
            <p className="text-muted-foreground text-xs">ERP Commission</p>
            <p className="font-bold text-emerald-500">₹{totals.erpCommission.toLocaleString()}</p>
          </div>
          <div className="text-center">
            <p className="text-muted-foreground text-xs">Net Settlement</p>
            <p className="font-bold text-primary">₹{totals.vendorAmount.toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
