"use client"

import { useState } from "react"
import { Search, X, Calendar as CalendarIcon, Columns3, Settings2 } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import { format, addDays } from "date-fns"

interface SettlementFiltersProps {
  selectedGateway: string
  setSelectedGateway: (value: string) => void
  selectedStatus: string
  setSelectedStatus: (value: string) => void
  dateRange: string
  setDateRange: (value: string) => void
  searchQuery?: string
  setSearchQuery?: (value: string) => void
  visibleColumns?: string[]
  setVisibleColumns?: (value: string[]) => void
  onOpenCustomColumns?: () => void
}

const allColumns = [
  { id: "settlementId", label: "Settlement ID", default: true },
  { id: "settlementDate", label: "Settlement Date", default: true },
  { id: "settlementTime", label: "Settlement Time", default: true },
  { id: "collectionDate", label: "Collection Date", default: false },
  { id: "students", label: "Students", default: true },
  { id: "transactions", label: "Transactions", default: false },
  { id: "gateways", label: "Gateways", default: true },
  { id: "orderAmount", label: "Order Amount", default: true },
  { id: "mdrCharges", label: "MDR/PG Fees", default: true },
  { id: "erpCommission", label: "ERP Commission", default: true },
  { id: "refundAdj", label: "Refund Adjustments", default: true },
  { id: "chargebackAdj", label: "Chargeback Adjustments", default: false },
  { id: "recoveries", label: "Recoveries", default: false },
  { id: "netSettlement", label: "Net Settlement", default: true },
  { id: "utr", label: "UTR", default: false },
  { id: "status", label: "Status", default: true },
]

// Next settlement date calculation (T+1, skipping holidays and weekends)
const bankHolidays2024 = [
  "2024-01-26", // Republic Day
  "2024-03-08", // Maha Shivaratri
  "2024-03-25", // Holi
  "2024-03-29", // Good Friday
  "2024-04-11", // Idul Fitr
  "2024-04-14", // Dr. Ambedkar Jayanti
  "2024-04-17", // Ram Navami
  "2024-04-21", // Mahavir Jayanti
  "2024-05-23", // Buddha Purnima
  "2024-06-17", // Eid ul-Adha
  "2024-07-17", // Muharram
  "2024-08-15", // Independence Day
  "2024-08-26", // Janmashtami
  "2024-09-16", // Milad un-Nabi
  "2024-10-02", // Gandhi Jayanti
  "2024-10-12", // Dussehra
  "2024-10-31", // Diwali (Lakshmi Puja)
  "2024-11-01", // Diwali (Govardhan Puja)
  "2024-11-15", // Guru Nanak Jayanti
  "2024-12-25", // Christmas
]

const getNextSettlementDate = () => {
  let date = addDays(new Date(), 1) // T+1
  
  // Skip weekends and holidays
  while (true) {
    const dayOfWeek = date.getDay()
    const dateStr = format(date, "yyyy-MM-dd")
    
    if (dayOfWeek === 0 || dayOfWeek === 6 || bankHolidays2024.includes(dateStr)) {
      date = addDays(date, 1)
    } else {
      break
    }
  }
  
  return date
}

export function SettlementFilters({
  selectedGateway,
  setSelectedGateway,
  selectedStatus,
  setSelectedStatus,
  dateRange,
  setDateRange,
  searchQuery = "",
  setSearchQuery,
  visibleColumns = allColumns.filter(c => c.default).map(c => c.id),
  setVisibleColumns,
  onOpenCustomColumns,
}: SettlementFiltersProps) {
  const [date, setDate] = useState<Date | undefined>()
  const [columnsOpen, setColumnsOpen] = useState(false)
  const [localVisibleColumns, setLocalVisibleColumns] = useState<string[]>(visibleColumns)

  const nextSettlementDate = getNextSettlementDate()
  const activeFiltersCount = [
    selectedGateway !== "all",
    selectedStatus !== "all",
    searchQuery !== "",
  ].filter(Boolean).length

  const handleColumnToggle = (columnId: string) => {
    const newColumns = localVisibleColumns.includes(columnId)
      ? localVisibleColumns.filter(c => c !== columnId)
      : [...localVisibleColumns, columnId]
    setLocalVisibleColumns(newColumns)
    setVisibleColumns?.(newColumns)
  }

  const resetFilters = () => {
    setSelectedGateway("all")
    setSelectedStatus("all")
    setDateRange("30d")
    setSearchQuery?.("")
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4 space-y-4">
        {/* Next Settlement Info Bar */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-primary/5 border border-primary/20">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <CalendarIcon className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Next Settlement Date (T+1)</p>
              <p className="font-semibold text-primary">{format(nextSettlementDate, "EEEE, MMMM d, yyyy")}</p>
            </div>
          </div>
          <Badge variant="outline" className="bg-success/10 text-success border-success/20">
            {Math.ceil((nextSettlementDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} day(s) away
          </Badge>
        </div>

        {/* Filters Row */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-[250px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder="Search by Settlement ID, UTR, Institute, Student..." 
              className="bg-secondary pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery?.(e.target.value)}
            />
          </div>

          {/* Gateway Filter */}
          <Select value={selectedGateway} onValueChange={setSelectedGateway}>
            <SelectTrigger className="w-40 bg-secondary">
              <SelectValue placeholder="All Gateways" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Gateways</SelectItem>
              <SelectItem value="razorpay">Razorpay</SelectItem>
              <SelectItem value="cashfree">Cashfree</SelectItem>
              <SelectItem value="easebuzz">Easebuzz</SelectItem>
              <SelectItem value="paytm">Paytm</SelectItem>
              <SelectItem value="hdfc">HDFC</SelectItem>
              <SelectItem value="payu">PayU</SelectItem>
            </SelectContent>
          </Select>

          {/* Status Filter */}
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-36 bg-secondary">
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="settled">Settled</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="processing">Processing</SelectItem>
              <SelectItem value="delayed">Delayed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>

          {/* Date Range Filter */}
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-36 bg-secondary">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="yesterday">Yesterday</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="fy">Financial Year</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>

          {/* Custom Date Picker */}
          {dateRange === "custom" && (
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-[200px] justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          )}

          {/* Custom Columns Manager */}
          {onOpenCustomColumns && (
            <Button variant="outline" size="sm" className="gap-2" onClick={onOpenCustomColumns}>
              <Settings2 className="h-4 w-4" />
              Custom Fields
            </Button>
          )}

          {/* Column Customization */}
          <Popover open={columnsOpen} onOpenChange={setColumnsOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <Columns3 className="h-4 w-4" />
                Columns
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64" align="end">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-sm">Visible Columns</h4>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-7 text-xs"
                    onClick={() => {
                      const defaultCols = allColumns.filter(c => c.default).map(c => c.id)
                      setLocalVisibleColumns(defaultCols)
                      setVisibleColumns?.(defaultCols)
                    }}
                  >
                    Reset
                  </Button>
                </div>
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {allColumns.map((column) => (
                    <div key={column.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={column.id}
                        checked={localVisibleColumns.includes(column.id)}
                        onCheckedChange={() => handleColumnToggle(column.id)}
                      />
                      <Label htmlFor={column.id} className="text-sm font-normal cursor-pointer">
                        {column.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Reset Filters */}
          {activeFiltersCount > 0 && (
            <Button variant="ghost" size="sm" onClick={resetFilters} className="gap-1 text-muted-foreground">
              <X className="h-4 w-4" />
              Clear ({activeFiltersCount})
            </Button>
          )}
        </div>

        {/* Active Filters Display */}
        {activeFiltersCount > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-muted-foreground">Active filters:</span>
            {selectedGateway !== "all" && (
              <Badge variant="secondary" className="gap-1">
                Gateway: {selectedGateway}
                <X className="h-3 w-3 cursor-pointer" onClick={() => setSelectedGateway("all")} />
              </Badge>
            )}
            {selectedStatus !== "all" && (
              <Badge variant="secondary" className="gap-1">
                Status: {selectedStatus}
                <X className="h-3 w-3 cursor-pointer" onClick={() => setSelectedStatus("all")} />
              </Badge>
            )}
            {searchQuery && (
              <Badge variant="secondary" className="gap-1">
                Search: "{searchQuery}"
                <X className="h-3 w-3 cursor-pointer" onClick={() => setSearchQuery?.("")} />
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
