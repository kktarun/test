"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Search, 
  Download,
  Calendar,
  CheckCircle2,
  Clock,
  AlertCircle,
  ArrowUpRight,
  Building2,
  TrendingUp,
  Wallet,
  IndianRupee,
  FileText,
  ExternalLink,
} from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

const settlements = [
  {
    id: "STL001",
    date: "2024-01-15",
    amount: 245000,
    transactions: 42,
    status: "completed",
    utr: "HDFC24011567890",
    bankAccount: "HDFC Bank ****4521",
    processingFee: 2450,
    netAmount: 242550,
  },
  {
    id: "STL002",
    date: "2024-01-14",
    amount: 189500,
    transactions: 35,
    status: "completed",
    utr: "HDFC24011467891",
    bankAccount: "HDFC Bank ****4521",
    processingFee: 1895,
    netAmount: 187605,
  },
  {
    id: "STL003",
    date: "2024-01-13",
    amount: 312000,
    transactions: 58,
    status: "completed",
    utr: "HDFC24011367892",
    bankAccount: "HDFC Bank ****4521",
    processingFee: 3120,
    netAmount: 308880,
  },
  {
    id: "STL004",
    date: "2024-01-12",
    amount: 156000,
    transactions: 28,
    status: "completed",
    utr: "HDFC24011267893",
    bankAccount: "HDFC Bank ****4521",
    processingFee: 1560,
    netAmount: 154440,
  },
  {
    id: "STL005",
    date: "2024-01-16",
    amount: 278500,
    transactions: 48,
    status: "processing",
    utr: "-",
    bankAccount: "HDFC Bank ****4521",
    processingFee: 2785,
    netAmount: 275715,
  },
  {
    id: "STL006",
    date: "2024-01-17",
    amount: 198000,
    transactions: 36,
    status: "pending",
    utr: "-",
    bankAccount: "HDFC Bank ****4521",
    processingFee: 1980,
    netAmount: 196020,
  },
]

const bankAccounts = [
  {
    id: "BA001",
    bankName: "HDFC Bank",
    accountNumber: "****4521",
    ifsc: "HDFC0001234",
    accountType: "Current",
    isDefault: true,
    totalSettled: 4250000,
  },
  {
    id: "BA002",
    bankName: "ICICI Bank",
    accountNumber: "****7890",
    ifsc: "ICIC0005678",
    accountType: "Current",
    isDefault: false,
    totalSettled: 1850000,
  },
]

export function SettlementsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({
    from: undefined,
    to: undefined,
  })

  const filteredSettlements = settlements.filter((settlement) => {
    const matchesSearch = settlement.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      settlement.utr.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || settlement.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalSettled = settlements.filter(s => s.status === "completed").reduce((sum, s) => sum + s.netAmount, 0)
  const pendingSettlement = settlements.filter(s => s.status === "pending" || s.status === "processing").reduce((sum, s) => sum + s.netAmount, 0)
  const totalTransactions = settlements.reduce((sum, s) => sum + s.transactions, 0)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400">
            <CheckCircle2 className="mr-1 h-3 w-3" />
            Settled
          </Badge>
        )
      case "processing":
        return (
          <Badge variant="secondary" className="bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-400">
            <Clock className="mr-1 h-3 w-3" />
            Processing
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary" className="bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-400">
            <AlertCircle className="mr-1 h-3 w-3" />
            Pending
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Settlements</h1>
          <p className="text-sm text-muted-foreground">Track payment gateway settlements to your bank account</p>
        </div>
        <Button variant="outline" size="sm">
          <Download className="mr-2 h-4 w-4" />
          Export
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Settled</p>
                <p className="text-2xl font-semibold tracking-tight text-foreground">
                  <span className="text-lg">₹</span>{(totalSettled / 100000).toFixed(1)}L
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-50 dark:bg-emerald-950">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Settlement</p>
                <p className="text-2xl font-semibold tracking-tight text-foreground">
                  <span className="text-lg">₹</span>{(pendingSettlement / 100000).toFixed(1)}L
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-50 dark:bg-amber-950">
                <Clock className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">In progress</p>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Transactions</p>
                <p className="text-2xl font-semibold tracking-tight text-foreground">{totalTransactions}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-50 dark:bg-blue-950">
                <TrendingUp className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Across all settlements</p>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Settlement Time</p>
                <p className="text-2xl font-semibold tracking-tight text-foreground">T+1</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Next business day</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="settlements" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="settlements">Settlement History</TabsTrigger>
          <TabsTrigger value="accounts">Bank Accounts</TabsTrigger>
        </TabsList>

        <TabsContent value="settlements" className="space-y-4">
          {/* Filters */}
          <Card className="border-border/50">
            <CardContent className="pt-6">
              <div className="flex flex-col gap-4 md:flex-row md:items-center">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by Settlement ID or UTR..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full md:w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="completed">Settled</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full md:w-auto">
                      <Calendar className="mr-2 h-4 w-4" />
                      {dateRange.from ? (
                        dateRange.to ? (
                          <>
                            {format(dateRange.from, "MMM d")} - {format(dateRange.to, "MMM d")}
                          </>
                        ) : (
                          format(dateRange.from, "MMM d, yyyy")
                        )
                      ) : (
                        "Date Range"
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="end">
                    <CalendarComponent
                      mode="range"
                      selected={{ from: dateRange.from, to: dateRange.to }}
                      onSelect={(range) => setDateRange({ from: range?.from, to: range?.to })}
                      numberOfMonths={2}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </CardContent>
          </Card>

          {/* Settlements Table */}
          <Card className="border-border/50">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="font-medium">Settlement ID</TableHead>
                    <TableHead className="font-medium">Date</TableHead>
                    <TableHead className="font-medium">Transactions</TableHead>
                    <TableHead className="font-medium text-right">Gross Amount</TableHead>
                    <TableHead className="font-medium text-right">Fees</TableHead>
                    <TableHead className="font-medium text-right">Net Amount</TableHead>
                    <TableHead className="font-medium">Status</TableHead>
                    <TableHead className="font-medium">UTR</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSettlements.map((settlement) => (
                    <TableRow key={settlement.id} className="group">
                      <TableCell>
                        <span className="font-medium text-foreground">{settlement.id}</span>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {format(new Date(settlement.date), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell>
                        <span className="text-muted-foreground">{settlement.transactions}</span>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        ₹{settlement.amount.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        -₹{settlement.processingFee.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-foreground">
                        ₹{settlement.netAmount.toLocaleString()}
                      </TableCell>
                      <TableCell>{getStatusBadge(settlement.status)}</TableCell>
                      <TableCell>
                        {settlement.utr !== "-" ? (
                          <span className="font-mono text-xs text-muted-foreground">{settlement.utr}</span>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100">
                              <ArrowUpRight className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-lg">
                            <DialogHeader>
                              <DialogTitle>Settlement Details</DialogTitle>
                              <DialogDescription>
                                Settlement {settlement.id} on {format(new Date(settlement.date), "MMMM d, yyyy")}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-6 py-4">
                              <div className="flex items-center justify-between rounded-lg bg-muted/50 p-4">
                                <div>
                                  <p className="text-sm text-muted-foreground">Net Settlement</p>
                                  <p className="text-2xl font-semibold">₹{settlement.netAmount.toLocaleString()}</p>
                                </div>
                                {getStatusBadge(settlement.status)}
                              </div>

                              <div className="space-y-3">
                                <div className="flex justify-between text-sm">
                                  <span className="text-muted-foreground">Gross Amount</span>
                                  <span className="font-medium">₹{settlement.amount.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between text-sm">
                                  <span className="text-muted-foreground">Processing Fee (1%)</span>
                                  <span className="text-destructive">-₹{settlement.processingFee.toLocaleString()}</span>
                                </div>
                                <div className="border-t pt-3">
                                  <div className="flex justify-between text-sm">
                                    <span className="font-medium">Net Amount</span>
                                    <span className="font-semibold">₹{settlement.netAmount.toLocaleString()}</span>
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-3 rounded-lg border p-4">
                                <h4 className="text-sm font-medium">Bank Details</h4>
                                <div className="space-y-2 text-sm">
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Bank Account</span>
                                    <span>{settlement.bankAccount}</span>
                                  </div>
                                  {settlement.utr !== "-" && (
                                    <div className="flex justify-between">
                                      <span className="text-muted-foreground">UTR Number</span>
                                      <span className="font-mono">{settlement.utr}</span>
                                    </div>
                                  )}
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Transactions</span>
                                    <span>{settlement.transactions} payments</span>
                                  </div>
                                </div>
                              </div>

                              <Button variant="outline" className="w-full">
                                <FileText className="mr-2 h-4 w-4" />
                                Download Settlement Report
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium">Linked Bank Accounts</h3>
              <p className="text-sm text-muted-foreground">Manage accounts where settlements are credited</p>
            </div>
            <Button>
              <Building2 className="mr-2 h-4 w-4" />
              Add Bank Account
            </Button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {bankAccounts.map((account) => (
              <Card key={account.id} className={`border-border/50 ${account.isDefault ? "ring-2 ring-primary/20" : ""}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                        <Building2 className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{account.bankName}</CardTitle>
                        <CardDescription>{account.accountType} Account</CardDescription>
                      </div>
                    </div>
                    {account.isDefault && (
                      <Badge className="bg-primary/10 text-primary">Default</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Account Number</p>
                      <p className="font-medium font-mono">{account.accountNumber}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">IFSC Code</p>
                      <p className="font-medium font-mono">{account.ifsc}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
                    <div className="text-sm">
                      <p className="text-muted-foreground">Total Settled</p>
                      <p className="font-semibold">₹{(account.totalSettled / 100000).toFixed(1)}L</p>
                    </div>
                    <Button variant="ghost" size="sm">
                      <ExternalLink className="mr-2 h-4 w-4" />
                      View Settlements
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
