"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import React from "react"
import {
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Building2,
  Users,
  Wallet,
  AlertTriangle,
  Minus,
  ArrowRight,
  Split,
  Info,
  ExternalLink,
  TrendingUp,
} from "lucide-react"
import { InstituteStudentList } from "./institute-student-list"
import Link from "next/link"

interface GatewaySettlement {
  gateway: string
  grossAmount: number
  transactionFees: number
  adjustments: Array<{
    refundId: string
    originalTxnId: string
    studentName: string
    amount: number
    reason: string
    refundDate: string
  }>
  netAmount: number
  transactionCount: number
  utr?: string
  status: "settled" | "pending" | "delayed"
  settledAt?: string
  splitDetails?: Array<{
    beneficiary: string
    accountNumber: string
    ifsc: string
    amount: number
    percentage: number
  }>
}

interface InstituteSettlement {
  id: string
  settlementDate: string
  instituteId: string
  instituteName: string
  instituteCode: string
  grossOrderAmount: number
  totalTransactionFees: number
  totalErpCommission: number
  totalAdjustments: number
  netSettlementAmount: number
  transactionCount: number
  studentCount: number
  status: "settled" | "pending" | "delayed" | "partial"
  expectedDate: string
  bankAccount: string
  ifscCode: string
  gatewaySettlements: GatewaySettlement[]
}

const instituteSettlements: InstituteSettlement[] = [
  {
    id: "IST001",
    settlementDate: "2024-01-16",
    instituteId: "DPS001",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-RKP",
    grossOrderAmount: 10100000, // ₹1,01,00,000 (101 Lakhs from 10 students example)
    totalTransactionFees: 222200, // 2.2% avg
    totalErpCommission: 101000, // 1% ERP commission
    totalAdjustments: 85000, // Refund adjustment
    netSettlementAmount: 9691800, // Updated: Gross - Fees - ERP - Adjustments
    transactionCount: 156,
    studentCount: 142,
    status: "settled",
    expectedDate: "2024-01-16",
    bankAccount: "HDFC ****4521",
    ifscCode: "HDFC0001234",
    gatewaySettlements: [
      {
        gateway: "Razorpay",
        grossAmount: 5000000,
        transactionFees: 110000,
        adjustments: [
          {
            refundId: "REF001234",
            originalTxnId: "TXN001234500",
            studentName: "Amit Kumar",
            amount: 45000,
            reason: "Course cancellation - Full refund",
            refundDate: "2024-01-14",
          },
        ],
        netAmount: 4845000,
        transactionCount: 78,
        utr: "RAZP24011600001234",
        status: "settled",
        settledAt: "2024-01-16 09:30 AM",
        splitDetails: [
          {
            beneficiary: "DPS Main Account",
            accountNumber: "****4521",
            ifsc: "HDFC0001234",
            amount: 4360500,
            percentage: 90,
          },
          {
            beneficiary: "DPS Transport Fund",
            accountNumber: "****4522",
            ifsc: "HDFC0001234",
            amount: 484500,
            percentage: 10,
          },
        ],
      },
      {
        gateway: "Cashfree",
        grossAmount: 3200000,
        transactionFees: 70400,
        adjustments: [
          {
            refundId: "REF001235",
            originalTxnId: "TXN001234520",
            studentName: "Priya Sharma",
            amount: 25000,
            reason: "Duplicate payment - Refund processed",
            refundDate: "2024-01-15",
          },
        ],
        netAmount: 3104600,
        transactionCount: 52,
        utr: "CSHF24011600005678",
        status: "settled",
        settledAt: "2024-01-16 10:15 AM",
      },
      {
        gateway: "Paytm",
        grossAmount: 1900000,
        transactionFees: 41800,
        adjustments: [
          {
            refundId: "REF001236",
            originalTxnId: "TXN001234540",
            studentName: "Rahul Verma",
            amount: 15000,
            reason: "Partial fee waiver approved",
            refundDate: "2024-01-13",
          },
        ],
        netAmount: 1843200,
        transactionCount: 26,
        utr: "PYTM24011600009012",
        status: "settled",
        settledAt: "2024-01-16 11:00 AM",
      },
    ],
  },
  {
    id: "IST002",
    settlementDate: "2024-01-16",
    instituteId: "DPS001",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-RKP",
    grossOrderAmount: 3250000,
    totalTransactionFees: 71500,
    totalErpCommission: 32500,
    totalAdjustments: 0,
    netSettlementAmount: 3146000,
    transactionCount: 98,
    studentCount: 89,
    status: "settled",
    expectedDate: "2024-01-16",
    bankAccount: "ICICI ****8976",
    ifscCode: "ICIC0001234",
    gatewaySettlements: [
      {
        gateway: "Razorpay",
        grossAmount: 1850000,
        transactionFees: 40700,
        adjustments: [],
        netAmount: 1809300,
        transactionCount: 56,
        utr: "RAZP24011600002345",
        status: "settled",
        settledAt: "2024-01-16 09:45 AM",
      },
      {
        gateway: "Cashfree",
        grossAmount: 1400000,
        transactionFees: 30800,
        adjustments: [],
        netAmount: 1369200,
        transactionCount: 42,
        utr: "CSHF24011600006789",
        status: "settled",
        settledAt: "2024-01-16 10:30 AM",
      },
    ],
  },
  {
    id: "IST003",
    settlementDate: "2024-01-17",
    instituteId: "DPS001",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-RKP",
    grossOrderAmount: 2500000,
    totalTransactionFees: 55000,
    totalErpCommission: 25000,
    totalAdjustments: 120000, // Pending refund adjustment
    netSettlementAmount: 2300000,
    transactionCount: 75,
    studentCount: 68,
    status: "pending",
    expectedDate: "2024-01-17",
    bankAccount: "HDFC ****7654",
    ifscCode: "HDFC0005678",
    gatewaySettlements: [
      {
        gateway: "Easebuzz",
        grossAmount: 1600000,
        transactionFees: 35200,
        adjustments: [
          {
            refundId: "REF001240",
            originalTxnId: "TXN001234600",
            studentName: "Sneha Gupta",
            amount: 75000,
            reason: "Transfer to another school",
            refundDate: "2024-01-15",
          },
          {
            refundId: "REF001241",
            originalTxnId: "TXN001234610",
            studentName: "Vikram Singh",
            amount: 45000,
            reason: "Medical emergency - Fee waiver",
            refundDate: "2024-01-16",
          },
        ],
        netAmount: 1444800,
        transactionCount: 48,
        status: "pending",
      },
      {
        gateway: "Razorpay",
        grossAmount: 900000,
        transactionFees: 19800,
        adjustments: [],
        netAmount: 880200,
        transactionCount: 27,
        status: "pending",
      },
    ],
  },
  {
    id: "IST004",
    settlementDate: "2024-01-15",
    instituteId: "DPS001",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-RKP",
    grossOrderAmount: 8750000,
    totalTransactionFees: 192500,
    totalErpCommission: 87500,
    totalAdjustments: 250000,
    netSettlementAmount: 8220000,
    transactionCount: 245,
    studentCount: 198,
    status: "partial",
    expectedDate: "2024-01-15",
    bankAccount: "HDFC ****9821",
    ifscCode: "HDFC0009821",
    gatewaySettlements: [
      {
        gateway: "Razorpay",
        grossAmount: 5200000,
        transactionFees: 114400,
        adjustments: [
          {
            refundId: "REF001250",
            originalTxnId: "TXN001234700",
            studentName: "Aditya Kapoor",
            amount: 150000,
            reason: "Course change - Differential refund",
            refundDate: "2024-01-14",
          },
        ],
        netAmount: 4935600,
        transactionCount: 145,
        status: "delayed",
      },
      {
        gateway: "Cashfree",
        grossAmount: 2550000,
        transactionFees: 56100,
        adjustments: [],
        netAmount: 2493900,
        transactionCount: 72,
        utr: "CSHF24011500004567",
        status: "settled",
        settledAt: "2024-01-15 11:30 AM",
        splitDetails: [
          {
            beneficiary: "Amity Main",
            accountNumber: "****9821",
            ifsc: "HDFC0009821",
            amount: 2244510,
            percentage: 90,
          },
          {
            beneficiary: "Amity Hostel",
            accountNumber: "****9822",
            ifsc: "HDFC0009821",
            amount: 249390,
            percentage: 10,
          },
        ],
      },
      {
        gateway: "Easebuzz",
        grossAmount: 1000000,
        transactionFees: 22000,
        adjustments: [
          {
            refundId: "REF001251",
            originalTxnId: "TXN001234750",
            studentName: "Neha Reddy",
            amount: 100000,
            reason: "Admission cancelled",
            refundDate: "2024-01-13",
          },
        ],
        netAmount: 878000,
        transactionCount: 28,
        status: "delayed",
      },
    ],
  },
]

const statusColors = {
  settled: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  delayed: "bg-destructive/10 text-destructive border-destructive/20",
  partial: "bg-info/10 text-info border-info/20",
}

const statusLabels = {
  settled: "Fully Settled",
  pending: "Pending",
  delayed: "Delayed",
  partial: "Partially Settled",
}

interface InstituteSettlementsTableProps {
  gateway: string
  status: string
}

export function InstituteSettlementsTable({ gateway, status }: InstituteSettlementsTableProps) {
  const [expandedInstitute, setExpandedInstitute] = useState<string | null>(null)
  const [expandedGateway, setExpandedGateway] = useState<string | null>(null)
  const [showStudentList, setShowStudentList] = useState<{
    instituteId: string
    instituteName: string
    settlementId: string
  } | null>(null)
  
  const [currentPage, setCurrentPage] = useState(1)

  const filteredSettlements = instituteSettlements.filter((s) => {
    if (gateway !== "all" && !s.gatewaySettlements.some((stl) => stl.gateway.toLowerCase().includes(gateway)))
      return false
    if (status !== "all" && s.status !== status) return false
    return true
  })

  const toggleExpand = (id: string) => {
    setExpandedInstitute(expandedInstitute === id ? null : id)
    setExpandedGateway(null)
  }

  const toggleGatewayExpand = (key: string) => {
    setExpandedGateway(expandedGateway === key ? null : key)
  }

  return (
    <TooltipProvider>
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              {filteredSettlements.length} Institute Settlements
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-secondary">
                T+1 Settlement (Excluding Bank Holidays)
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="p-4 text-left w-10"></th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institute</th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">
                    <Tooltip>
                      <TooltipTrigger className="flex items-center gap-1 justify-end">
                        Gross Amount
                        <Info className="h-3 w-3" />
                      </TooltipTrigger>
                      <TooltipContent>Total order amount collected from students</TooltipContent>
                    </Tooltip>
                  </th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">
                    <Tooltip>
                      <TooltipTrigger className="flex items-center gap-1 justify-end text-warning">
                        Txn Fees
                        <Info className="h-3 w-3" />
                      </TooltipTrigger>
                      <TooltipContent>Payment gateway transaction fees</TooltipContent>
                    </Tooltip>
                  </th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">
                    <Tooltip>
                      <TooltipTrigger className="flex items-center gap-1 justify-end text-emerald-500">
                        ERP Comm
                        <Info className="h-3 w-3" />
                      </TooltipTrigger>
                      <TooltipContent>ERP platform commission</TooltipContent>
                    </Tooltip>
                  </th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">
                    <Tooltip>
                      <TooltipTrigger className="flex items-center gap-1 justify-end text-destructive">
                        Adjustments
                        <Info className="h-3 w-3" />
                      </TooltipTrigger>
                      <TooltipContent>Refund amounts deducted from this settlement</TooltipContent>
                    </Tooltip>
                  </th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">
                    <Tooltip>
                      <TooltipTrigger className="flex items-center gap-1 justify-end text-success">
                        Net Settlement
                        <Info className="h-3 w-3" />
                      </TooltipTrigger>
                      <TooltipContent>Final amount settled to institute (Gross - Fees - ERP - Adjustments)</TooltipContent>
                    </Tooltip>
                  </th>
                  <th className="p-4 text-center text-xs font-medium uppercase text-muted-foreground">
                    Txns / Students
                  </th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredSettlements.map((institute) => (
                  <React.Fragment key={institute.id}>
                    <tr
                      className="border-b border-border hover:bg-secondary/30 transition-colors cursor-pointer"
                      onClick={() => toggleExpand(institute.id)}
                    >
                      <td className="p-4">
                        <Button variant="ghost" size="icon" className="h-6 w-6">
                          {expandedInstitute === institute.id ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </Button>
                      </td>
                      <td className="p-4">
                        <div>
                          <span className="font-medium">{institute.instituteName}</span>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-xs text-muted-foreground font-mono">{institute.instituteCode}</span>
                            <span className="text-xs text-muted-foreground">•</span>
                            <span className="text-xs text-muted-foreground">{institute.bankAccount}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-right">
                        <span className="font-semibold">₹{(institute.grossOrderAmount / 100000).toFixed(2)} L</span>
                      </td>
                      <td className="p-4 text-right">
                        <span className="text-warning">-₹{(institute.totalTransactionFees / 1000).toFixed(1)}K</span>
                      </td>
                      <td className="p-4 text-right">
                        <span className="text-emerald-500">₹{(institute.totalErpCommission / 1000).toFixed(1)}K</span>
                      </td>
                      <td className="p-4 text-right">
                        {institute.totalAdjustments > 0 ? (
                          <Tooltip>
                            <TooltipTrigger>
                              <span className="text-destructive font-medium">
                                -₹{(institute.totalAdjustments / 1000).toFixed(1)}K
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>Refund adjustments deducted from settlement</TooltipContent>
                          </Tooltip>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </td>
                      <td className="p-4 text-right">
                        <span className="font-bold text-success">
                          ₹{(institute.netSettlementAmount / 100000).toFixed(2)} L
                        </span>
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <span className="text-sm">{institute.transactionCount}</span>
                          <span className="text-muted-foreground">/</span>
                          <span className="text-sm flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {institute.studentCount}
                          </span>
                        </div>
                      </td>
                      <td className="p-4">
                        <Badge variant="outline" className={statusColors[institute.status]}>
                          {statusLabels[institute.status]}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs bg-transparent h-7"
                            onClick={(e) => {
                              e.stopPropagation()
                              setShowStudentList({
                                instituteId: institute.instituteId,
                                instituteName: institute.instituteName,
                                settlementId: institute.id,
                              })
                            }}
                          >
                            <Users className="h-3 w-3 mr-1" />
                            Students
                          </Button>
                          <Link href={`/settlements/institute/${institute.id}`} onClick={(e) => e.stopPropagation()}>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-xs bg-transparent h-7"
                            >
                              <ExternalLink className="h-3 w-3 mr-1" />
                              View Details
                            </Button>
                          </Link>
                        </div>
                      </td>
                    </tr>

                    {/* Expanded Gateway Breakdown */}
                    {expandedInstitute === institute.id && (
                      <tr>
                        <td colSpan={10} className="p-0">
                          <div className="bg-secondary/20 p-4 border-t border-border">
                            {/* Settlement Calculation Summary */}
                            <div className="mb-4 p-3 rounded-lg bg-card border border-border">
                              <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                                <Wallet className="h-4 w-4 text-primary" />
                                Settlement Calculation
                              </h4>
                              <div className="flex items-center gap-4 text-sm flex-wrap">
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">Gross:</span>
                                  <span className="font-semibold">
                                    ₹{(institute.grossOrderAmount / 100000).toFixed(2)} L
                                  </span>
                                </div>
                                <Minus className="h-4 w-4 text-muted-foreground" />
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">Fees:</span>
                                  <span className="text-warning">
                                    ₹{(institute.totalTransactionFees / 1000).toFixed(1)}K
                                  </span>
                                </div>
                                <Minus className="h-4 w-4 text-muted-foreground" />
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">ERP Comm:</span>
                                  <span className="text-emerald-500">
                                    ₹{(institute.totalErpCommission / 1000).toFixed(1)}K
                                  </span>
                                </div>
                                <Minus className="h-4 w-4 text-muted-foreground" />
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">Adjustments:</span>
                                  <span className="text-destructive">
                                    ₹{(institute.totalAdjustments / 1000).toFixed(1)}K
                                  </span>
                                </div>
                                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                                <div className="flex items-center gap-2">
                                  <span className="text-muted-foreground">Net:</span>
                                  <span className="font-bold text-success">
                                    ₹{(institute.netSettlementAmount / 100000).toFixed(2)} L
                                  </span>
                                </div>
                              </div>
                            </div>

                            {/* Gateway-wise Breakdown */}
                            <h4 className="text-sm font-semibold mb-3 text-muted-foreground flex items-center gap-2">
                              <Building2 className="h-4 w-4" />
                              Gateway-wise Settlement Breakdown ({institute.gatewaySettlements.length} Gateways)
                            </h4>
                            <div className="space-y-3">
                              {institute.gatewaySettlements.map((gw, idx) => {
                                const gwKey = `${institute.id}-${gw.gateway}`
                                const hasAdjustments = gw.adjustments.length > 0
                                const hasSplits = gw.splitDetails && gw.splitDetails.length > 0

                                return (
                                  <div key={idx} className="rounded-lg bg-card border border-border overflow-hidden">
                                    {/* Gateway Header */}
                                    <div
                                      className="p-4 cursor-pointer hover:bg-secondary/30 transition-colors"
                                      onClick={() => toggleGatewayExpand(gwKey)}
                                    >
                                      <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-3">
                                          <Button variant="ghost" size="icon" className="h-6 w-6">
                                            {expandedGateway === gwKey ? (
                                              <ChevronDown className="h-4 w-4" />
                                            ) : (
                                              <ChevronRight className="h-4 w-4" />
                                            )}
                                          </Button>
                                          <div>
                                            <div className="flex items-center gap-2">
                                              <span className="font-semibold">{gw.gateway}</span>
                                              <Badge variant="outline" className={statusColors[gw.status]}>
                                                {gw.status}
                                              </Badge>
                                              {hasAdjustments && (
                                                <Badge
                                                  variant="outline"
                                                  className="bg-destructive/10 text-destructive border-destructive/20 text-xs"
                                                >
                                                  <AlertTriangle className="h-3 w-3 mr-1" />
                                                  {gw.adjustments.length} Adjustment
                                                  {gw.adjustments.length > 1 ? "s" : ""}
                                                </Badge>
                                              )}
                                              {hasSplits && (
                                                <Badge
                                                  variant="outline"
                                                  className="bg-info/10 text-info border-info/20 text-xs"
                                                >
                                                  <Split className="h-3 w-3 mr-1" />
                                                  Split Payment
                                                </Badge>
                                              )}
                                            </div>
                                            <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                                              <span>{gw.transactionCount} transactions</span>
                                              {gw.utr && (
                                                <>
                                                  <span>•</span>
                                                  <span className="font-mono">UTR: {gw.utr}</span>
                                                </>
                                              )}
                                              {gw.settledAt && (
                                                <>
                                                  <span>•</span>
                                                  <span>Settled: {gw.settledAt}</span>
                                                </>
                                              )}
                                            </div>
                                          </div>
                                        </div>
                                        <div className="flex items-center gap-6">
                                          <div className="text-right">
                                            <p className="text-xs text-muted-foreground">Gross</p>
                                            <p className="font-medium">₹{(gw.grossAmount / 100000).toFixed(2)} L</p>
                                          </div>
                                          <div className="text-right">
                                            <p className="text-xs text-muted-foreground">Fees</p>
                                            <p className="text-warning">-₹{(gw.transactionFees / 1000).toFixed(1)}K</p>
                                          </div>
                                          <div className="text-right">
                                            <p className="text-xs text-muted-foreground">Adjustments</p>
                                            <p
                                              className={hasAdjustments ? "text-destructive" : "text-muted-foreground"}
                                            >
                                              {hasAdjustments
                                                ? `-₹${(gw.adjustments.reduce((s, a) => s + a.amount, 0) / 1000).toFixed(1)}K`
                                                : "-"}
                                            </p>
                                          </div>
                                          <div className="text-right min-w-[100px]">
                                            <p className="text-xs text-muted-foreground">Net Amount</p>
                                            <p className="font-bold text-success text-lg">
                                              ₹{(gw.netAmount / 100000).toFixed(2)} L
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Expanded Gateway Details */}
                                    {expandedGateway === gwKey && (
                                      <div className="border-t border-border p-4 bg-secondary/30 space-y-4">
                                        {/* Adjustments Section */}
                                        {hasAdjustments && (
                                          <div>
                                            <h5 className="text-sm font-semibold mb-2 flex items-center gap-2 text-destructive">
                                              <AlertTriangle className="h-4 w-4" />
                                              Refund Adjustments (Deducted from this Settlement)
                                            </h5>
                                            <div className="space-y-2">
                                              {gw.adjustments.map((adj, adjIdx) => (
                                                <div
                                                  key={adjIdx}
                                                  className="rounded-lg bg-destructive/5 border border-destructive/20 p-3"
                                                >
                                                  <div className="flex items-center justify-between">
                                                    <div>
                                                      <div className="flex items-center gap-2">
                                                        <span className="font-mono text-xs text-destructive">
                                                          {adj.refundId}
                                                        </span>
                                                        <ArrowRight className="h-3 w-3 text-muted-foreground" />
                                                        <span className="font-mono text-xs text-muted-foreground">
                                                          {adj.originalTxnId}
                                                        </span>
                                                      </div>
                                                      <p className="font-medium mt-1">{adj.studentName}</p>
                                                      <p className="text-xs text-muted-foreground">{adj.reason}</p>
                                                    </div>
                                                    <div className="text-right">
                                                      <p className="font-bold text-destructive">
                                                        -₹{adj.amount.toLocaleString()}
                                                      </p>
                                                      <p className="text-xs text-muted-foreground">
                                                        Refund Date: {adj.refundDate}
                                                      </p>
                                                    </div>
                                                  </div>
                                                </div>
                                              ))}
                                            </div>
                                          </div>
                                        )}

                                        {/* Split Payment Details */}
                                        {hasSplits && (
                                          <div>
                                            <h5 className="text-sm font-semibold mb-2 flex items-center gap-2 text-info">
                                              <Split className="h-4 w-4" />
                                              Split Payment Beneficiaries
                                            </h5>
                                            <div className="grid gap-2 md:grid-cols-2">
                                              {gw.splitDetails!.map((split, splitIdx) => (
                                                <div
                                                  key={splitIdx}
                                                  className="rounded-lg bg-info/5 border border-info/20 p-3"
                                                >
                                                  <div className="flex items-center justify-between">
                                                    <div>
                                                      <p className="font-medium">{split.beneficiary}</p>
                                                      <p className="text-xs text-muted-foreground font-mono">
                                                        A/C: {split.accountNumber} | IFSC: {split.ifsc}
                                                      </p>
                                                    </div>
                                                    <div className="text-right">
                                                      <p className="font-semibold text-info">
                                                        ₹{(split.amount / 100000).toFixed(2)} L
                                                      </p>
                                                      <Badge variant="outline" className="text-xs">
                                                        {split.percentage}%
                                                      </Badge>
                                                    </div>
                                                  </div>
                                                </div>
                                              ))}
                                            </div>
                                          </div>
                                        )}

                                        {/* No extra details message */}
                                        {!hasAdjustments && !hasSplits && (
                                          <div className="text-center py-4 text-muted-foreground">
                                            No adjustments or split payments for this gateway settlement.
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                )
                              })}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-border p-4">
            <p className="text-sm text-muted-foreground">
              Showing 1 to {filteredSettlements.length} of {filteredSettlements.length} institutes
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm">Page 1 of 1</span>
              <Button variant="outline" size="sm" disabled>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <InstituteStudentList
        open={!!showStudentList}
        onOpenChange={(open) => !open && setShowStudentList(null)}
        instituteId={showStudentList?.instituteId || ""}
        instituteName={showStudentList?.instituteName || ""}
        settlementId={showStudentList?.settlementId || ""}
      />
    </TooltipProvider>
  )
}
