"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileSpreadsheet, FileText, File, Download } from "lucide-react"

interface SettlementExportModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const exportFields = [
  { id: "settlementId", label: "Settlement ID", default: true },
  { id: "settlementDate", label: "Settlement Date", default: true },
  { id: "students", label: "Number of Students", default: true },
  { id: "orderAmount", label: "Order Amount", default: true },
  { id: "fees", label: "Transaction Fees", default: true },
  { id: "adjustments", label: "Adjustments", default: true },
  { id: "netAmount", label: "Net Settlement", default: true },
  { id: "gateway", label: "Gateway Details", default: true },
  { id: "utr", label: "UTR Number", default: true },
  { id: "status", label: "Status", default: true },
  { id: "splitDetails", label: "Split Payment Details", default: false },
  { id: "studentList", label: "Student List", default: false },
  { id: "refundDetails", label: "Refund/Adjustment Details", default: false },
]

export function SettlementExportModal({ open, onOpenChange }: SettlementExportModalProps) {
  const [format, setFormat] = useState("excel")
  const [selectedFields, setSelectedFields] = useState<string[]>(exportFields.filter((f) => f.default).map((f) => f.id))
  const [exportScope, setExportScope] = useState("filtered")

  const toggleField = (fieldId: string) => {
    setSelectedFields((prev) => (prev.includes(fieldId) ? prev.filter((f) => f !== fieldId) : [...prev, fieldId]))
  }

  const handleExport = () => {
    // Trigger export based on format
    console.log("Exporting with:", { format, selectedFields, exportScope })
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="h-5 w-5 text-primary" />
            Export Settlement Report
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Export Format */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Export Format</Label>
            <RadioGroup value={format} onValueChange={setFormat} className="grid grid-cols-3 gap-3">
              <Label
                htmlFor="excel"
                className={`flex flex-col items-center gap-2 rounded-lg border p-4 cursor-pointer transition-colors ${
                  format === "excel" ? "border-primary bg-primary/5" : "border-border"
                }`}
              >
                <RadioGroupItem value="excel" id="excel" className="sr-only" />
                <FileSpreadsheet
                  className={`h-8 w-8 ${format === "excel" ? "text-primary" : "text-muted-foreground"}`}
                />
                <span className="text-sm font-medium">Excel</span>
                <span className="text-xs text-muted-foreground">.xlsx</span>
              </Label>
              <Label
                htmlFor="csv"
                className={`flex flex-col items-center gap-2 rounded-lg border p-4 cursor-pointer transition-colors ${
                  format === "csv" ? "border-primary bg-primary/5" : "border-border"
                }`}
              >
                <RadioGroupItem value="csv" id="csv" className="sr-only" />
                <File className={`h-8 w-8 ${format === "csv" ? "text-primary" : "text-muted-foreground"}`} />
                <span className="text-sm font-medium">CSV</span>
                <span className="text-xs text-muted-foreground">.csv</span>
              </Label>
              <Label
                htmlFor="pdf"
                className={`flex flex-col items-center gap-2 rounded-lg border p-4 cursor-pointer transition-colors ${
                  format === "pdf" ? "border-primary bg-primary/5" : "border-border"
                }`}
              >
                <RadioGroupItem value="pdf" id="pdf" className="sr-only" />
                <FileText className={`h-8 w-8 ${format === "pdf" ? "text-primary" : "text-muted-foreground"}`} />
                <span className="text-sm font-medium">PDF</span>
                <span className="text-xs text-muted-foreground">.pdf</span>
              </Label>
            </RadioGroup>
          </div>

          {/* Export Scope */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Export Scope</Label>
            <Select value={exportScope} onValueChange={setExportScope}>
              <SelectTrigger className="bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="filtered">Current Filtered Results</SelectItem>
                <SelectItem value="today">Today's Settlements</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="all">All Settlements</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Fields Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Include Fields</Label>
              <Button variant="ghost" size="sm" onClick={() => setSelectedFields(exportFields.map((f) => f.id))}>
                Select All
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1">
              {exportFields.map((field) => (
                <div key={field.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={field.id}
                    checked={selectedFields.includes(field.id)}
                    onCheckedChange={() => toggleField(field.id)}
                  />
                  <Label htmlFor={field.id} className="text-sm cursor-pointer">
                    {field.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleExport} className="gap-2">
            <Download className="h-4 w-4" />
            Export {format.toUpperCase()}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
