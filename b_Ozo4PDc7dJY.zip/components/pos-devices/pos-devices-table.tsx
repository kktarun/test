"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  MoreHorizontal,
  Eye,
  Settings,
  History,
  Wrench,
  Power,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Wifi,
  WifiOff,
} from "lucide-react"
import { PosDeviceDetailModal } from "./pos-device-detail-modal"
import { PosTransactionHistoryModal } from "./pos-transaction-history-modal"

interface PosDevice {
  id: string
  serialNumber: string
  model: string
  manufacturer: string
  institute: {
    id: string
    name: string
  }
  location: string
  status: "active" | "inactive" | "maintenance" | "faulty"
  lastOnline: string
  todayTxnCount: number
  todayCollection: number
  assignedDate: string
  firmwareVersion: string
  connectivity: "online" | "offline"
}

const posDevices: PosDevice[] = [
  {
    id: "POS001",
    serialNumber: "SN-2024-001234",
    model: "Paytm Soundbox 2.0",
    manufacturer: "Paytm",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Main Reception",
    status: "active",
    lastOnline: "2024-01-15T10:30:00",
    todayTxnCount: 45,
    todayCollection: 125000,
    assignedDate: "2023-06-15",
    firmwareVersion: "v2.4.1",
    connectivity: "online",
  },
  {
    id: "POS002",
    serialNumber: "SN-2024-001235",
    model: "Pine Labs P1000",
    manufacturer: "Pine Labs",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Accounts Office",
    status: "active",
    lastOnline: "2024-01-15T10:28:00",
    todayTxnCount: 32,
    todayCollection: 98000,
    assignedDate: "2023-07-20",
    firmwareVersion: "v3.1.0",
    connectivity: "online",
  },
  {
    id: "POS003",
    serialNumber: "SN-2024-001236",
    model: "Razorpay POS",
    manufacturer: "Razorpay",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Admission Counter 1",
    status: "active",
    lastOnline: "2024-01-15T10:25:00",
    todayTxnCount: 28,
    todayCollection: 156000,
    assignedDate: "2023-08-10",
    firmwareVersion: "v1.8.2",
    connectivity: "online",
  },
  {
    id: "POS004",
    serialNumber: "SN-2024-001237",
    model: "Mswipe WisePOS",
    manufacturer: "Mswipe",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Library",
    status: "maintenance",
    lastOnline: "2024-01-14T16:45:00",
    todayTxnCount: 0,
    todayCollection: 0,
    assignedDate: "2023-09-05",
    firmwareVersion: "v2.0.5",
    connectivity: "offline",
  },
  {
    id: "POS005",
    serialNumber: "SN-2024-001238",
    model: "BharatPe Swipe",
    manufacturer: "BharatPe",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Canteen",
    status: "active",
    lastOnline: "2024-01-15T10:32:00",
    todayTxnCount: 67,
    todayCollection: 34500,
    assignedDate: "2023-10-12",
    firmwareVersion: "v1.5.0",
    connectivity: "online",
  },
  {
    id: "POS006",
    serialNumber: "SN-2024-001239",
    model: "Paytm Soundbox 2.0",
    manufacturer: "Paytm",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Sports Complex",
    status: "faulty",
    lastOnline: "2024-01-10T09:15:00",
    todayTxnCount: 0,
    todayCollection: 0,
    assignedDate: "2023-11-01",
    firmwareVersion: "v2.4.0",
    connectivity: "offline",
  },
  {
    id: "POS007",
    serialNumber: "SN-2024-001240",
    model: "Pine Labs P1000",
    manufacturer: "Pine Labs",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Main Gate",
    status: "inactive",
    lastOnline: "2024-01-12T14:00:00",
    todayTxnCount: 0,
    todayCollection: 0,
    assignedDate: "2023-12-05",
    firmwareVersion: "v3.0.8",
    connectivity: "offline",
  },
  {
    id: "POS008",
    serialNumber: "SN-2024-001241",
    model: "Razorpay POS",
    manufacturer: "Razorpay",
    institute: { id: "INST001", name: "Delhi Public School" },
    location: "Admin Block",
    status: "active",
    lastOnline: "2024-01-15T10:29:00",
    todayTxnCount: 19,
    todayCollection: 87000,
    assignedDate: "2024-01-02",
    firmwareVersion: "v1.8.2",
    connectivity: "online",
  },
]

const statusColors = {
  active: "bg-success/10 text-success border-success/20",
  inactive: "bg-muted text-muted-foreground border-border",
  maintenance: "bg-warning/10 text-warning border-warning/20",
  faulty: "bg-destructive/10 text-destructive border-destructive/20",
}

interface PosDevicesTableProps {
  searchQuery: string
  statusFilter: string
  instituteFilter: string
}

export function PosDevicesTable({ searchQuery, statusFilter, instituteFilter }: PosDevicesTableProps) {
  const [selectedDevice, setSelectedDevice] = useState<PosDevice | null>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [showHistoryModal, setShowHistoryModal] = useState(false)

  const filteredDevices = posDevices.filter((device) => {
    if (statusFilter !== "all" && device.status !== statusFilter) return false
    if (instituteFilter !== "all" && device.institute.id !== instituteFilter) return false
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        device.id.toLowerCase().includes(query) ||
        device.serialNumber.toLowerCase().includes(query) ||
        device.institute.name.toLowerCase().includes(query) ||
        device.location.toLowerCase().includes(query) ||
        device.model.toLowerCase().includes(query)
      )
    }
    return true
  })

  const handleViewDetails = (device: PosDevice) => {
    setSelectedDevice(device)
    setShowDetailModal(true)
  }

  const handleViewHistory = (device: PosDevice) => {
    setSelectedDevice(device)
    setShowHistoryModal(true)
  }

  return (
    <>
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold">{filteredDevices.length} POS Devices</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Device</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Location</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Connectivity</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Today's Txns</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">
                    Today's Collection
                  </th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredDevices.map((device) => (
                  <tr key={device.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{device.model}</p>
                        <p className="text-xs text-muted-foreground">
                          {device.id} | {device.serialNumber}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{device.location}</span>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline" className={statusColors[device.status]}>
                        {device.status}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        {device.connectivity === "online" ? (
                          <>
                            <Wifi className="h-4 w-4 text-success" />
                            <span className="text-xs text-success">Online</span>
                          </>
                        ) : (
                          <>
                            <WifiOff className="h-4 w-4 text-muted-foreground" />
                            <span className="text-xs text-muted-foreground">Offline</span>
                          </>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="font-semibold">{device.todayTxnCount}</span>
                    </td>
                    <td className="p-4">
                      <span className="font-semibold">₹{(device.todayCollection / 1000).toFixed(1)}K</span>
                    </td>
                    <td className="p-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleViewDetails(device)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleViewHistory(device)}>
                            <History className="mr-2 h-4 w-4" />
                            Transaction History
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Settings className="mr-2 h-4 w-4" />
                            Configure
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Wrench className="mr-2 h-4 w-4" />
                            Mark for Maintenance
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Power className="mr-2 h-4 w-4" />
                            {device.status === "active" ? "Deactivate" : "Activate"}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Remove Device
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-border p-4">
            <p className="text-sm text-muted-foreground">
              Showing 1 to {filteredDevices.length} of {filteredDevices.length} devices
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm">Page 1 of 1</span>
              <Button variant="outline" size="sm" disabled>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedDevice && (
        <>
          <PosDeviceDetailModal open={showDetailModal} onOpenChange={setShowDetailModal} device={selectedDevice} />
          <PosTransactionHistoryModal
            open={showHistoryModal}
            onOpenChange={setShowHistoryModal}
            device={selectedDevice}
          />
        </>
      )}
    </>
  )
}
