"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { 
  Plus,
  MoreHorizontal,
  CreditCard,
  Smartphone,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Settings,
  Trash2,
  Edit,
  MapPin,
  User,
  RefreshCw,
  Download,
  Activity,
  IndianRupee,
  Wifi,
  WifiOff,
  Battery,
  Signal,
} from "lucide-react"
import { Textarea } from "@/components/ui/textarea"

const posProviders = [
  { id: "pine_labs", name: "Pine Labs", logo: "PL" },
  { id: "mswipe", name: "Mswipe", logo: "MS" },
  { id: "paytm_pos", name: "Paytm POS", logo: "PT" },
  { id: "razorpay_pos", name: "Razorpay POS", logo: "RP" },
  { id: "hdfc_pos", name: "HDFC POS", logo: "HD" },
  { id: "icici_pos", name: "ICICI POS", logo: "IC" },
  { id: "axis_pos", name: "Axis POS", logo: "AX" },
  { id: "phonepe_pos", name: "PhonePe POS", logo: "PP" },
]

const posMachines = [
  {
    id: "POS001",
    deviceId: "PL-2024-001234",
    serialNumber: "SN789456123",
    provider: "pine_labs",
    providerName: "Pine Labs",
    model: "Plutus Smart P20",
    location: "Main Office - Counter 1",
    assignedTo: "Ramesh Kumar",
    status: "online",
    lastTransaction: "2024-01-15 10:30 AM",
    todayTransactions: 12,
    todayAmount: 145000,
    batteryLevel: 85,
    signalStrength: "good",
    enabled: true,
  },
  {
    id: "POS002",
    deviceId: "PL-2024-001235",
    serialNumber: "SN789456124",
    provider: "pine_labs",
    providerName: "Pine Labs",
    model: "Plutus Smart P20",
    location: "Main Office - Counter 2",
    assignedTo: "Suresh Patel",
    status: "online",
    lastTransaction: "2024-01-15 10:25 AM",
    todayTransactions: 8,
    todayAmount: 92000,
    batteryLevel: 62,
    signalStrength: "good",
    enabled: true,
  },
  {
    id: "POS003",
    deviceId: "MS-2024-005678",
    serialNumber: "SN456789012",
    provider: "mswipe",
    providerName: "Mswipe",
    model: "WisePOS E",
    location: "Branch Office - Reception",
    assignedTo: "Priya Sharma",
    status: "offline",
    lastTransaction: "2024-01-14 04:15 PM",
    todayTransactions: 0,
    todayAmount: 0,
    batteryLevel: 15,
    signalStrength: "poor",
    enabled: true,
  },
  {
    id: "POS004",
    deviceId: "PT-2024-009876",
    serialNumber: "SN123789456",
    provider: "paytm_pos",
    providerName: "Paytm POS",
    model: "Paytm Soundbox Pro",
    location: "Canteen",
    assignedTo: "Amit Singh",
    status: "online",
    lastTransaction: "2024-01-15 09:45 AM",
    todayTransactions: 25,
    todayAmount: 15600,
    batteryLevel: 100,
    signalStrength: "excellent",
    enabled: true,
  },
]

const providerConfigs = [
  {
    id: "pine_labs",
    name: "Pine Labs",
    logo: "PL",
    status: "active",
    merchantId: "MID123456789",
    terminalPrefix: "PL-2024",
    totalDevices: 2,
    activeDevices: 2,
    supportedMethods: ["card", "upi", "wallet"],
    settlementAccount: "HDFC ****1234",
  },
  {
    id: "mswipe",
    name: "Mswipe",
    logo: "MS",
    status: "active",
    merchantId: "MSW987654321",
    terminalPrefix: "MS-2024",
    totalDevices: 1,
    activeDevices: 0,
    supportedMethods: ["card", "upi"],
    settlementAccount: "ICICI ****5678",
  },
  {
    id: "paytm_pos",
    name: "Paytm POS",
    logo: "PT",
    status: "active",
    merchantId: "PTM456123789",
    terminalPrefix: "PT-2024",
    totalDevices: 1,
    activeDevices: 1,
    supportedMethods: ["card", "upi", "wallet", "qr"],
    settlementAccount: "HDFC ****1234",
  },
]

const transactionLogs = [
  {
    id: "TXN001",
    deviceId: "POS001",
    amount: 25000,
    method: "Card",
    cardLast4: "4521",
    status: "success",
    timestamp: "2024-01-15 10:30:45 AM",
    rrn: "401234567890",
  },
  {
    id: "TXN002",
    deviceId: "POS001",
    amount: 15000,
    method: "UPI",
    cardLast4: null,
    status: "success",
    timestamp: "2024-01-15 10:15:22 AM",
    rrn: "401234567891",
  },
  {
    id: "TXN003",
    deviceId: "POS002",
    amount: 8500,
    method: "Card",
    cardLast4: "8976",
    status: "failed",
    timestamp: "2024-01-15 10:05:11 AM",
    rrn: null,
  },
  {
    id: "TXN004",
    deviceId: "POS004",
    amount: 350,
    method: "UPI",
    cardLast4: null,
    status: "success",
    timestamp: "2024-01-15 09:45:33 AM",
    rrn: "401234567892",
  },
]

export function PosDevicesContent() {
  const [showAddDevice, setShowAddDevice] = useState(false)
  const [showAddProvider, setShowAddProvider] = useState(false)
  const [selectedProvider, setSelectedProvider] = useState("")

  const totalDevices = posMachines.length
  const onlineDevices = posMachines.filter(p => p.status === "online").length
  const todayTotal = posMachines.reduce((sum, p) => sum + p.todayAmount, 0)
  const todayTxnCount = posMachines.reduce((sum, p) => sum + p.todayTransactions, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">POS Machines</h1>
          <p className="text-sm text-muted-foreground">
            Manage POS devices, providers, and offline collection terminals
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
          <Dialog open={showAddDevice} onOpenChange={setShowAddDevice}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Device
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Add POS Device</DialogTitle>
                <DialogDescription>
                  Register a new POS terminal to the system
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>POS Provider</Label>
                  <Select value={selectedProvider} onValueChange={setSelectedProvider}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select provider" />
                    </SelectTrigger>
                    <SelectContent>
                      {providerConfigs.map((provider) => (
                        <SelectItem key={provider.id} value={provider.id}>
                          <div className="flex items-center gap-2">
                            <div className="flex h-6 w-6 items-center justify-center rounded bg-primary/10 text-xs font-bold text-primary">
                              {provider.logo}
                            </div>
                            {provider.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Device ID / Terminal ID</Label>
                    <Input placeholder="e.g., PL-2024-001236" />
                  </div>
                  <div className="space-y-2">
                    <Label>Serial Number</Label>
                    <Input placeholder="e.g., SN789456125" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Device Model</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select model" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="plutus_p20">Plutus Smart P20</SelectItem>
                      <SelectItem value="plutus_p30">Plutus Smart P30</SelectItem>
                      <SelectItem value="wisepos_e">WisePOS E</SelectItem>
                      <SelectItem value="soundbox_pro">Soundbox Pro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Location / Counter Name</Label>
                  <Input placeholder="e.g., Main Office - Counter 3" />
                </div>
                <div className="space-y-2">
                  <Label>Assigned Operator</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select staff member" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ramesh">Ramesh Kumar</SelectItem>
                      <SelectItem value="suresh">Suresh Patel</SelectItem>
                      <SelectItem value="priya">Priya Sharma</SelectItem>
                      <SelectItem value="amit">Amit Singh</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Notes (Optional)</Label>
                  <Textarea placeholder="Any additional notes about this device..." />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowAddDevice(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setShowAddDevice(false)}>
                  Add Device
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Devices</p>
                <p className="text-2xl font-bold">{totalDevices}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <CreditCard className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Online Now</p>
                <p className="text-2xl font-bold text-success">{onlineDevices}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-success/10">
                <Wifi className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Today&apos;s Collection</p>
                <p className="text-2xl font-bold">₹{(todayTotal / 1000).toFixed(1)}K</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-chart-1/10">
                <IndianRupee className="h-5 w-5 text-chart-1" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Today&apos;s Transactions</p>
                <p className="text-2xl font-bold">{todayTxnCount}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-chart-2/10">
                <Activity className="h-5 w-5 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="devices" className="space-y-4">
        <TabsList>
          <TabsTrigger value="devices">Devices</TabsTrigger>
          <TabsTrigger value="providers">Providers</TabsTrigger>
          <TabsTrigger value="transactions">Transaction Log</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="devices" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Registered Devices</CardTitle>
                <div className="flex items-center gap-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[150px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Providers</SelectItem>
                      <SelectItem value="pine_labs">Pine Labs</SelectItem>
                      <SelectItem value="mswipe">Mswipe</SelectItem>
                      <SelectItem value="paytm_pos">Paytm POS</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[120px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="online">Online</SelectItem>
                      <SelectItem value="offline">Offline</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Device</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Today</TableHead>
                    <TableHead>Battery</TableHead>
                    <TableHead>Enabled</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {posMachines.map((device) => (
                    <TableRow key={device.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted text-xs font-bold">
                            {device.providerName.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-medium">{device.deviceId}</p>
                            <p className="text-xs text-muted-foreground">{device.model}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          <span className="text-sm">{device.location}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <User className="h-3 w-3 text-muted-foreground" />
                          <span className="text-sm">{device.assignedTo}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {device.status === "online" ? (
                          <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                            <Wifi className="mr-1 h-3 w-3" />
                            Online
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                            <WifiOff className="mr-1 h-3 w-3" />
                            Offline
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm font-medium">₹{device.todayAmount.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">{device.todayTransactions} txns</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Battery className={`h-4 w-4 ${
                            device.batteryLevel > 50 ? "text-success" : 
                            device.batteryLevel > 20 ? "text-warning" : "text-destructive"
                          }`} />
                          <span className="text-sm">{device.batteryLevel}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Switch checked={device.enabled} />
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Activity className="mr-2 h-4 w-4" />
                              View Transactions
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit Device
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <RefreshCw className="mr-2 h-4 w-4" />
                              Refresh Status
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Remove Device
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="providers" className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Configure POS service providers and their credentials
            </p>
            <Dialog open={showAddProvider} onOpenChange={setShowAddProvider}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Provider
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>Add POS Provider</DialogTitle>
                  <DialogDescription>
                    Configure a new POS service provider
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Select Provider</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a provider" />
                      </SelectTrigger>
                      <SelectContent>
                        {posProviders.map((provider) => (
                          <SelectItem key={provider.id} value={provider.id}>
                            <div className="flex items-center gap-2">
                              <div className="flex h-6 w-6 items-center justify-center rounded bg-primary/10 text-xs font-bold text-primary">
                                {provider.logo}
                              </div>
                              {provider.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Merchant ID</Label>
                    <Input placeholder="Enter merchant ID from provider" />
                  </div>
                  <div className="space-y-2">
                    <Label>Terminal ID Prefix</Label>
                    <Input placeholder="e.g., PL-2024" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>API Key</Label>
                      <Input type="password" placeholder="••••••••" />
                    </div>
                    <div className="space-y-2">
                      <Label>Secret Key</Label>
                      <Input type="password" placeholder="••••••••" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Settlement Bank Account</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select bank account" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hdfc">HDFC Bank ****1234</SelectItem>
                        <SelectItem value="icici">ICICI Bank ****5678</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-3">
                    <Label>Supported Payment Methods</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <span className="text-sm">Card Payments</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <span className="text-sm">UPI</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <span className="text-sm">Wallets</span>
                        <Switch />
                      </div>
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <span className="text-sm">QR Code</span>
                        <Switch />
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowAddProvider(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setShowAddProvider(false)}>
                    Add Provider
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {providerConfigs.map((provider) => (
              <Card key={provider.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 font-bold text-primary">
                        {provider.logo}
                      </div>
                      <div>
                        <CardTitle className="text-base">{provider.name}</CardTitle>
                        <CardDescription className="text-xs">
                          MID: {provider.merchantId}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                      Active
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Total Devices</p>
                      <p className="font-medium">{provider.totalDevices}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Active</p>
                      <p className="font-medium text-success">{provider.activeDevices}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Payment Methods</p>
                    <div className="flex flex-wrap gap-1">
                      {provider.supportedMethods.map((method) => (
                        <Badge key={method} variant="secondary" className="text-xs">
                          {method.toUpperCase()}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Settlement: {provider.settlementAccount}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Settings className="mr-2 h-3 w-3" />
                      Configure
                    </Button>
                    <Button variant="outline" size="sm">
                      <Activity className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Recent POS Transactions</CardTitle>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Transaction ID</TableHead>
                    <TableHead>Device</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>RRN</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactionLogs.map((txn) => (
                    <TableRow key={txn.id}>
                      <TableCell className="font-mono text-sm">{txn.id}</TableCell>
                      <TableCell className="font-mono text-sm">{txn.deviceId}</TableCell>
                      <TableCell className="font-medium">₹{txn.amount.toLocaleString()}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {txn.method === "Card" ? (
                            <CreditCard className="h-3 w-3 text-muted-foreground" />
                          ) : (
                            <Smartphone className="h-3 w-3 text-muted-foreground" />
                          )}
                          <span className="text-sm">{txn.method}</span>
                          {txn.cardLast4 && (
                            <span className="text-xs text-muted-foreground">****{txn.cardLast4}</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{txn.rrn || "-"}</TableCell>
                      <TableCell>
                        {txn.status === "success" ? (
                          <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                            Success
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                            <XCircle className="mr-1 h-3 w-3" />
                            Failed
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{txn.timestamp}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Transaction Settings</CardTitle>
                <CardDescription>Configure POS transaction behavior</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Auto-sync Transactions</p>
                    <p className="text-xs text-muted-foreground">Automatically fetch transactions every 5 minutes</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Real-time Notifications</p>
                    <p className="text-xs text-muted-foreground">Get notified for every POS transaction</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Auto-print Receipt</p>
                    <p className="text-xs text-muted-foreground">Print receipt automatically after successful payment</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Send SMS on Payment</p>
                    <p className="text-xs text-muted-foreground">SMS confirmation to parent after POS payment</p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Limits & Restrictions</CardTitle>
                <CardDescription>Set transaction limits for POS devices</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Min Transaction</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                      <Input className="pl-7" defaultValue="100" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Max Transaction</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                      <Input className="pl-7" defaultValue="500000" />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Daily Limit per Device</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                    <Input className="pl-7" defaultValue="2000000" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Offline Transaction Limit</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                    <Input className="pl-7" defaultValue="50000" />
                  </div>
                  <p className="text-xs text-muted-foreground">Max amount allowed when device is offline</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
