"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

const transactions = [
  {
    id: "TXN001234567",
    student: "Rahul Sharma",
    feeType: "Tuition Fee - Q4",
    amount: "₹45,000",
    gateway: "Razorpay",
    channel: "Online",
    status: "success",
    time: "2 min ago",
  },
  {
    id: "TXN001234568",
    student: "Priya Patel",
    feeType: "Annual Fee",
    amount: "₹32,500",
    gateway: "Cashfree",
    channel: "UPI",
    status: "success",
    time: "5 min ago",
  },
  {
    id: "TXN001234569",
    student: "Amit Kumar",
    feeType: "Transport Fee",
    amount: "₹28,000",
    gateway: "Easebuzz",
    channel: "POS",
    status: "pending",
    time: "8 min ago",
  },
  {
    id: "TXN001234570",
    student: "Sneha Gupta",
    feeType: "Admission Fee",
    amount: "₹52,000",
    gateway: "Paytm",
    channel: "Online",
    status: "success",
    time: "12 min ago",
  },
  {
    id: "TXN001234571",
    student: "Vikram Singh",
    feeType: "Semester Fee",
    amount: "₹1,25,000",
    gateway: "Razorpay",
    channel: "Online",
    status: "failed",
    time: "15 min ago",
  },
]

const statusColors = {
  success: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
}

export function RecentTransactions() {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/transactions" className="gap-1">
            View all <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.map((txn) => (
            <div
              key={txn.id}
              className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-4"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <p className="font-mono text-sm font-medium">{txn.id}</p>
                  <Badge variant="outline" className={statusColors[txn.status as keyof typeof statusColors]}>
                    {txn.status}
                  </Badge>
                </div>
                <p className="text-sm font-medium text-foreground">{txn.student}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span>{txn.feeType}</span>
                  <span>•</span>
                  <span>{txn.gateway}</span>
                  <span>•</span>
                  <span>{txn.channel}</span>
                  <span>•</span>
                  <span>{txn.time}</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-semibold">{txn.amount}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
