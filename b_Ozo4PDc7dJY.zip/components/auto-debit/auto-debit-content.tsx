"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  RefreshCcw,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  CreditCard,
  Building2,
  Download,
  Eye,
  Pause,
  Play,
  MoreHorizontal,
  Plus,
  Calendar,
  IndianRupee,
  Edit,
  Trash2,
  AlertTriangle,
  RotateCcw,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Checkbox } from "@/components/ui/checkbox"

const autoDebitStats = [
  { label: "Active Mandates", value: "245", trend: "+12 this month", icon: CheckCircle2, color: "text-green-600 dark:text-green-400" },
  { label: "Pending Approval", value: "18", trend: "Awaiting bank", icon: Clock, color: "text-yellow-600 dark:text-yellow-400" },
  { label: "Bounced This Month", value: "5", trend: "Requires attention", icon: XCircle, color: "text-red-600 dark:text-red-400" },
  { label: "Total Collection", value: "28.5L", trend: "This month", icon: RefreshCcw, color: "text-primary" },
]

const mandates = [
  {
    id: "MND001",
    studentId: "STU001",
    studentName: "Arjun Sharma",
    class: "10-A",
    parentName: "Rajesh Sharma",
    bank: "HDFC Bank",
    accountNo: "****4521",
    umrn: "HDFC00000012345678",
    maxAmount: 50000,
    frequency: "Monthly",
    status: "active",
    nextDebit: "2024-04-01",
    nextAmount: 12500,
    registeredOn: "2024-01-15",
    totalInstallments: 12,
    paidInstallments: 3,
  },
  {
    id: "MND002",
    studentId: "STU002",
    studentName: "Priya Patel",
    class: "9-B",
    parentName: "Amit Patel",
    bank: "ICICI Bank",
    accountNo: "****8932",
    umrn: "ICIC00000098765432",
    maxAmount: 45000,
    frequency: "Quarterly",
    status: "active",
    nextDebit: "2024-04-15",
    nextAmount: 15000,
    registeredOn: "2024-01-20",
    totalInstallments: 4,
    paidInstallments: 1,
  },
  {
    id: "MND003",
    studentId: "STU003",
    studentName: "Rahul Verma",
    class: "8-C",
    parentName: "Suresh Verma",
    bank: "SBI",
    accountNo: "****6745",
    umrn: null,
    maxAmount: 40000,
    frequency: "Monthly",
    status: "pending",
    nextDebit: null,
    nextAmount: 10000,
    registeredOn: "2024-03-05",
    totalInstallments: 12,
    paidInstallments: 0,
  },
  {
    id: "MND004",
    studentId: "STU004",
    studentName: "Ananya Gupta",
    class: "10-A",
    parentName: "Vivek Gupta",
    bank: "Axis Bank",
    accountNo: "****2198",
    umrn: "UTIB00000045678901",
    maxAmount: 55000,
    frequency: "Monthly",
    status: "bounced",
    nextDebit: "2024-03-25",
    nextAmount: 13000,
    registeredOn: "2024-02-10",
    totalInstallments: 12,
    paidInstallments: 2,
    bounceReason: "Insufficient funds",
    bounceDate: "2024-03-15",
  },
  {
    id: "MND005",
    studentId: "STU005",
    studentName: "Vikram Singh",
    class: "7-A",
    parentName: "Prakash Singh",
    bank: "Kotak Bank",
    accountNo: "****7834",
    umrn: "KKBK00000067890123",
    maxAmount: 35000,
    frequency: "Monthly",
    status: "paused",
    nextDebit: null,
    nextAmount: 8500,
    registeredOn: "2024-01-25",
    totalInstallments: 12,
    paidInstallments: 2,
    pauseReason: "Paid via other mode",
  },
]

const installmentSchedule = [
  { id: 1, mandateId: "MND001", installment: 1, dueDate: "2024-04-01", amount: 12500, status: "scheduled" },
  { id: 2, mandateId: "MND001", installment: 2, dueDate: "2024-05-01", amount: 12500, status: "scheduled" },
  { id: 3, mandateId: "MND001", installment: 3, dueDate: "2024-06-01", amount: 15000, status: "scheduled" },
  { id: 4, mandateId: "MND001", installment: 4, dueDate: "2024-07-01", amount: 12500, status: "scheduled" },
  { id: 5, mandateId: "MND001", installment: 5, dueDate: "2024-08-01", amount: 10000, status: "scheduled" },
]

const recentDebits = [
  { id: 1, mandateId: "MND001", studentName: "Arjun Sharma", amount: 12500, date: "2024-03-01", status: "success", utr: "HDFC12345678" },
  { id: 2, mandateId: "MND002", studentName: "Priya Patel", amount: 15000, date: "2024-03-01", status: "success", utr: "ICIC98765432" },
  { id: 3, mandateId: "MND001", studentName: "Arjun Sharma", amount: 12500, date: "2024-02-01", status: "success", utr: "HDFC12345679" },
  { id: 4, mandateId: "MND004", studentName: "Ananya Gupta", amount: 13000, date: "2024-03-15", status: "bounced", reason: "Insufficient funds" },
  { id: 5, mandateId: "MND005", studentName: "Vikram Singh", amount: 8500, date: "2024-02-01", status: "success", utr: "KKBK67890123" },
]

export function AutoDebitContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false)
  const [selectedMandate, setSelectedMandate] = useState<typeof mandates[0] | null>(null)

  const filteredMandates = mandates.filter((mandate) => {
    const matchesSearch =
      mandate.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mandate.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || mandate.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300">Active</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-300">Pending</Badge>
      case "bounced":
        return <Badge className="bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300">Bounced</Badge>
      case "paused":
        return <Badge className="bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300">Paused</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Auto-Debit / e-Mandate</h1>
          <p className="text-muted-foreground">
            Manage bank mandates, installment schedules, and automatic fee collection
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Mandate
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create e-Mandate</DialogTitle>
                <DialogDescription>
                  Set up automatic fee collection with variable installment schedule
                </DialogDescription>
              </DialogHeader>
              <Tabs defaultValue="student" className="mt-4">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="student">Student</TabsTrigger>
                  <TabsTrigger value="schedule">Schedule</TabsTrigger>
                  <TabsTrigger value="bank">Bank Details</TabsTrigger>
                </TabsList>
                
                <TabsContent value="student" className="space-y-4 pt-4">
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Search Student</FieldLabel>
                      <Input placeholder="Enter student name or ID..." />
                    </Field>
                  </FieldGroup>
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Avatar>
                        <AvatarFallback>AS</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">Arjun Sharma</p>
                        <p className="text-sm text-muted-foreground">STU001 &bull; Class 10-A</p>
                      </div>
                    </div>
                    <div className="grid gap-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Total Fee</span>
                        <span className="font-medium">₹65,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Paid</span>
                        <span className="font-medium text-green-600">₹52,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Pending</span>
                        <span className="font-medium text-red-600">₹13,000</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <p className="font-medium text-sm">Include Previous Dues</p>
                      <p className="text-xs text-muted-foreground">Add ₹8,500 from previous year</p>
                    </div>
                    <Switch />
                  </div>
                </TabsContent>

                <TabsContent value="schedule" className="space-y-4 pt-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Total Amount to Collect</FieldLabel>
                        <Input type="number" defaultValue="65000" />
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Number of Installments</FieldLabel>
                        <Select defaultValue="12">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="4">4 (Quarterly)</SelectItem>
                            <SelectItem value="6">6 (Bi-monthly)</SelectItem>
                            <SelectItem value="10">10 (Monthly - 10 months)</SelectItem>
                            <SelectItem value="12">12 (Monthly - Full year)</SelectItem>
                            <SelectItem value="custom">Custom</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </FieldGroup>
                  </div>
                  
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-4">
                      <p className="font-medium">Installment Schedule</p>
                      <div className="flex items-center gap-2">
                        <Switch id="variableAmount" />
                        <label htmlFor="variableAmount" className="text-sm">Variable amounts</label>
                      </div>
                    </div>
                    <div className="space-y-3">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <div key={num} className="flex items-center gap-3">
                          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-secondary text-xs">
                            {num}
                          </span>
                          <div className="flex-1 grid gap-2 sm:grid-cols-2">
                            <Input type="date" defaultValue={`2024-0${num + 3}-01`} />
                            <Input type="number" placeholder="Amount" defaultValue={num === 3 ? "15000" : "12500"} />
                          </div>
                        </div>
                      ))}
                      <Button variant="ghost" size="sm" className="w-full">
                        Show all 12 installments
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <p className="font-medium text-sm">Auto-adjust on manual payment</p>
                      <p className="text-xs text-muted-foreground">
                        If parent pays via another mode, reduce next mandate amount
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </TabsContent>

                <TabsContent value="bank" className="space-y-4 pt-4">
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Account Holder Name</FieldLabel>
                      <Input placeholder="As per bank records" />
                    </Field>
                  </FieldGroup>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Bank Name</FieldLabel>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select bank" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="hdfc">HDFC Bank</SelectItem>
                            <SelectItem value="icici">ICICI Bank</SelectItem>
                            <SelectItem value="sbi">State Bank of India</SelectItem>
                            <SelectItem value="axis">Axis Bank</SelectItem>
                            <SelectItem value="kotak">Kotak Mahindra Bank</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Account Type</FieldLabel>
                        <Select defaultValue="savings">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="savings">Savings</SelectItem>
                            <SelectItem value="current">Current</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </FieldGroup>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <FieldGroup>
                      <Field>
                        <FieldLabel>Account Number</FieldLabel>
                        <Input placeholder="Enter account number" />
                      </Field>
                    </FieldGroup>
                    <FieldGroup>
                      <Field>
                        <FieldLabel>IFSC Code</FieldLabel>
                        <Input placeholder="e.g., HDFC0001234" />
                      </Field>
                    </FieldGroup>
                  </div>
                  <FieldGroup>
                    <Field>
                      <FieldLabel>Maximum Debit Amount per Transaction</FieldLabel>
                      <Input type="number" placeholder="50000" />
                      <p className="text-xs text-muted-foreground mt-1">
                        Maximum amount that can be debited in a single transaction
                      </p>
                    </Field>
                  </FieldGroup>
                  <div className="rounded-lg bg-muted/50 p-4">
                    <p className="text-sm text-muted-foreground">
                      An e-mandate registration link will be sent to the parent&apos;s registered mobile number 
                      and email for authentication.
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
              <DialogFooter className="mt-6">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setIsCreateDialogOpen(false)}>
                  Send Registration Link
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        {autoDebitStats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg bg-secondary ${stat.color}`}>
                  <stat.icon className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="mandates" className="space-y-4">
        <TabsList>
          <TabsTrigger value="mandates">All Mandates</TabsTrigger>
          <TabsTrigger value="bounced" className="relative">
            Bounced
            <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-xs text-destructive-foreground">
              {mandates.filter(m => m.status === "bounced").length}
            </span>
          </TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="schedules">Upcoming Debits</TabsTrigger>
        </TabsList>

        <TabsContent value="mandates" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="relative w-full sm:w-72">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search mandates..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="bounced">Bounced</SelectItem>
                      <SelectItem value="paused">Paused</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Bank Details</TableHead>
                    <TableHead>Schedule</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Next Debit</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMandates.map((mandate) => (
                    <TableRow key={mandate.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="text-xs">
                              {mandate.studentName.split(" ").map((n) => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{mandate.studentName}</p>
                            <p className="text-xs text-muted-foreground">
                              {mandate.studentId} &bull; Class {mandate.class}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm">{mandate.bank}</p>
                            <p className="text-xs text-muted-foreground">{mandate.accountNo}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm">{mandate.frequency}</p>
                          <p className="text-xs text-muted-foreground">
                            Max: {formatCurrency(mandate.maxAmount)}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm font-medium">
                            {mandate.paidInstallments}/{mandate.totalInstallments}
                          </p>
                          <p className="text-xs text-muted-foreground">Installments</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {mandate.nextDebit ? (
                          <div>
                            <p className="text-sm">{mandate.nextDebit}</p>
                            <p className="text-xs text-muted-foreground">
                              {formatCurrency(mandate.nextAmount)}
                            </p>
                          </div>
                        ) : (
                          <span className="text-sm text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div>
                          {getStatusBadge(mandate.status)}
                          {mandate.status === "bounced" && (
                            <p className="text-xs text-red-600 mt-1">{mandate.bounceReason}</p>
                          )}
                          {mandate.status === "paused" && (
                            <p className="text-xs text-muted-foreground mt-1">{mandate.pauseReason}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => {
                              setSelectedMandate(mandate)
                              setIsScheduleDialogOpen(true)
                            }}>
                              <Calendar className="mr-2 h-4 w-4" />
                              View/Edit Schedule
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            {mandate.status === "active" && (
                              <DropdownMenuItem>
                                <Pause className="mr-2 h-4 w-4" />
                                Pause Mandate
                              </DropdownMenuItem>
                            )}
                            {mandate.status === "paused" && (
                              <DropdownMenuItem>
                                <Play className="mr-2 h-4 w-4" />
                                Resume Mandate
                              </DropdownMenuItem>
                            )}
                            {mandate.status === "bounced" && (
                              <>
                                <DropdownMenuItem>
                                  <RotateCcw className="mr-2 h-4 w-4" />
                                  Retry Debit
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Calendar className="mr-2 h-4 w-4" />
                                  Reschedule
                                </DropdownMenuItem>
                              </>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Cancel Mandate
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bounced" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Bounced Mandates</CardTitle>
              <CardDescription>
                Mandates that failed and require attention. Set next presentation date or retry.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mandates
                  .filter((m) => m.status === "bounced")
                  .map((mandate) => (
                    <div key={mandate.id} className="rounded-lg border border-red-200 bg-red-50/50 dark:border-red-900 dark:bg-red-950/20 p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>
                              {mandate.studentName.split(" ").map((n) => n[0]).join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{mandate.studentName}</p>
                            <p className="text-sm text-muted-foreground">
                              {mandate.studentId} &bull; Class {mandate.class}
                            </p>
                          </div>
                        </div>
                        <Badge variant="destructive">
                          <AlertTriangle className="mr-1 h-3 w-3" />
                          Bounced
                        </Badge>
                      </div>
                      <div className="grid gap-4 sm:grid-cols-4 mb-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Bank</p>
                          <p className="text-sm font-medium">{mandate.bank}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Amount</p>
                          <p className="text-sm font-medium">{formatCurrency(mandate.nextAmount)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Bounce Date</p>
                          <p className="text-sm font-medium">{mandate.bounceDate}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Reason</p>
                          <p className="text-sm font-medium text-red-600">{mandate.bounceReason}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <FieldGroup className="flex-1">
                          <Field>
                            <FieldLabel className="text-xs">Next Presentation Date</FieldLabel>
                            <Input type="date" className="h-9" />
                          </Field>
                        </FieldGroup>
                        <FieldGroup className="flex-1">
                          <Field>
                            <FieldLabel className="text-xs">Adjusted Amount</FieldLabel>
                            <Input type="number" defaultValue={mandate.nextAmount} className="h-9" />
                          </Field>
                        </FieldGroup>
                        <div className="flex items-end gap-2">
                          <Button size="sm">
                            <RotateCcw className="mr-2 h-4 w-4" />
                            Reschedule
                          </Button>
                          <Button variant="outline" size="sm">
                            Contact Parent
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Auto-debit transaction history</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Mandate ID</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>UTR / Reference</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentDebits.map((debit) => (
                    <TableRow key={debit.id}>
                      <TableCell className="font-medium">{debit.studentName}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{debit.mandateId}</Badge>
                      </TableCell>
                      <TableCell>{formatCurrency(debit.amount)}</TableCell>
                      <TableCell>{debit.date}</TableCell>
                      <TableCell>
                        {debit.utr ? (
                          <span className="font-mono text-sm">{debit.utr}</span>
                        ) : (
                          <span className="text-sm text-red-600">{debit.reason}</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {debit.status === "success" ? (
                          <Badge className="bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300">
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                            Success
                          </Badge>
                        ) : (
                          <Badge variant="destructive">
                            <XCircle className="mr-1 h-3 w-3" />
                            Bounced
                          </Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedules" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Debits</CardTitle>
              <CardDescription>Scheduled auto-debit transactions for the next 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>
                      <Checkbox />
                    </TableHead>
                    <TableHead>Student</TableHead>
                    <TableHead>Installment</TableHead>
                    <TableHead>Scheduled Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mandates
                    .filter((m) => m.status === "active" && m.nextDebit)
                    .map((mandate) => (
                      <TableRow key={mandate.id}>
                        <TableCell>
                          <Checkbox />
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{mandate.studentName}</p>
                            <p className="text-xs text-muted-foreground">Class {mandate.class}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          #{mandate.paidInstallments + 1} of {mandate.totalInstallments}
                        </TableCell>
                        <TableCell>{mandate.nextDebit}</TableCell>
                        <TableCell className="font-medium">{formatCurrency(mandate.nextAmount)}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">
                            <Clock className="mr-1 h-3 w-3" />
                            Scheduled
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Schedule Edit Dialog */}
      <Dialog open={isScheduleDialogOpen} onOpenChange={setIsScheduleDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Installment Schedule</DialogTitle>
            <DialogDescription>
              Modify dates and amounts for {selectedMandate?.studentName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="rounded-lg border p-3 bg-muted/50">
              <div className="flex justify-between text-sm">
                <span>Total Fee</span>
                <span className="font-medium">₹65,000</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Collected via Mandate</span>
                <span className="font-medium text-green-600">₹37,500</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Remaining</span>
                <span className="font-medium">₹27,500</span>
              </div>
            </div>
            <div className="space-y-3">
              {installmentSchedule.map((inst) => (
                <div key={inst.id} className="flex items-center gap-3">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-secondary text-xs">
                    {inst.installment}
                  </span>
                  <Input type="date" defaultValue={inst.dueDate} className="flex-1" />
                  <div className="relative w-32">
                    <IndianRupee className="absolute left-3 top-1/2 h-3 w-3 -translate-y-1/2 text-muted-foreground" />
                    <Input type="number" defaultValue={inst.amount} className="pl-8" />
                  </div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <p className="font-medium text-sm">Skip next installment</p>
                <p className="text-xs text-muted-foreground">
                  Parent paid via another mode
                </p>
              </div>
              <Switch />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsScheduleDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setIsScheduleDialogOpen(false)}>
              Save Schedule
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
