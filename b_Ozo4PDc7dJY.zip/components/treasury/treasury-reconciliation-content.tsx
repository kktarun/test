"use client"

import { useState } from "react"
import {
  CheckCircle2,
  AlertTriangle,
  Clock,
  Search,
  Upload,
  Download,
  RefreshCw,
  FileText,
  ArrowLeftRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"

type ReconStatus = "matched" | "pending" | "exception" | "unmatched"

interface ReconEntry {
  id: string
  settlementId: string
  utr: string
  bank: string
  amount: number
  bankAmount: number
  date: string
  status: ReconStatus
  reason?: string
}

const entries: ReconEntry[] = [
  {
    id: "RC001",
    settlementId: "STL-2026-0981",
    utr: "HDFC026042145821",
    bank: "HDFC Bank",
    amount: 485000,
    bankAmount: 485000,
    date: "2026-04-18",
    status: "matched",
  },
  {
    id: "RC002",
    settlementId: "STL-2026-0980",
    utr: "ICICI026042112398",
    bank: "ICICI Bank",
    amount: 320000,
    bankAmount: 319500,
    date: "2026-04-18",
    status: "exception",
    reason: "Amount mismatch (₹500 short credit)",
  },
  {
    id: "RC003",
    settlementId: "STL-2026-0979",
    utr: "-",
    bank: "ICICI Bank",
    amount: 680000,
    bankAmount: 0,
    date: "2026-04-18",
    status: "pending",
    reason: "UTR not yet received from PG",
  },
  {
    id: "RC004",
    settlementId: "STL-2026-0978",
    utr: "AXIS026041789445",
    bank: "Axis Bank",
    amount: 142000,
    bankAmount: 142000,
    date: "2026-04-17",
    status: "matched",
  },
  {
    id: "RC005",
    settlementId: "VAN-2026-1452",
    utr: "YES026041890012",
    bank: "Yes Bank",
    amount: 85000,
    bankAmount: 85000,
    date: "2026-04-17",
    status: "matched",
  },
  {
    id: "RC006",
    settlementId: "-",
    utr: "HDFC026041745822",
    bank: "HDFC Bank",
    amount: 0,
    bankAmount: 45000,
    date: "2026-04-17",
    status: "unmatched",
    reason: "Credit in bank without matching settlement",
  },
  {
    id: "RC007",
    settlementId: "STL-2026-0975",
    utr: "ICICI026041612398",
    bank: "ICICI Bank",
    amount: 218000,
    bankAmount: 218000,
    date: "2026-04-16",
    status: "matched",
  },
]

const statusConfig: Record<ReconStatus, { label: string; badge: "default" | "secondary" | "destructive" | "outline"; color: string }> = {
  matched: { label: "Matched", badge: "default", color: "text-primary" },
  pending: { label: "Pending", badge: "outline", color: "text-warning" },
  exception: { label: "Exception", badge: "destructive", color: "text-destructive" },
  unmatched: { label: "Unmatched", badge: "secondary", color: "text-muted-foreground" },
}

function formatINR(n: number) {
  return `₹${n.toLocaleString("en-IN")}`
}

export function TreasuryReconciliationContent() {
  const [search, setSearch] = useState("")
  const [activeTab, setActiveTab] = useState<ReconStatus | "all">("all")

  const filtered = entries.filter((e) => {
    if (activeTab !== "all" && e.status !== activeTab) return false
    return (
      e.settlementId.toLowerCase().includes(search.toLowerCase()) ||
      e.utr.toLowerCase().includes(search.toLowerCase()) ||
      e.bank.toLowerCase().includes(search.toLowerCase())
    )
  })

  const counts = {
    total: entries.length,
    matched: entries.filter((e) => e.status === "matched").length,
    pending: entries.filter((e) => e.status === "pending").length,
    exception: entries.filter((e) => e.status === "exception").length,
    unmatched: entries.filter((e) => e.status === "unmatched").length,
  }
  const matchRate = ((counts.matched / counts.total) * 100).toFixed(1)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Settlement Reconciliation</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Auto-match settlements and VAN credits with bank statement UTRs.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Upload className="mr-2 h-4 w-4" />
            Upload statement
          </Button>
          <Button variant="outline" size="sm">
            <RefreshCw className="mr-2 h-4 w-4" />
            Run auto-match
          </Button>
          <Button size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export report
          </Button>
        </div>
      </div>

      {/* Hero match-rate card */}
      <Card className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent" />
        <CardContent className="relative pt-6">
          <div className="grid gap-6 md:grid-cols-[1fr_2fr]">
            <div>
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Auto Match Success Rate
              </p>
              <p className="mt-2 text-5xl font-semibold tracking-tight">{matchRate}%</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {counts.matched} matched out of {counts.total} entries
              </p>
              <Progress value={Number(matchRate)} className="mt-4 h-2" />
            </div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <div className="rounded-lg border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <p className="text-xs text-muted-foreground">Matched</p>
                </div>
                <p className="mt-2 text-xl font-semibold">{counts.matched}</p>
              </div>
              <div className="rounded-lg border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-warning" />
                  <p className="text-xs text-muted-foreground">Pending</p>
                </div>
                <p className="mt-2 text-xl font-semibold">{counts.pending}</p>
              </div>
              <div className="rounded-lg border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  <p className="text-xs text-muted-foreground">Exceptions</p>
                </div>
                <p className="mt-2 text-xl font-semibold">{counts.exception}</p>
              </div>
              <div className="rounded-lg border border-border bg-card p-4">
                <div className="flex items-center gap-2">
                  <ArrowLeftRight className="h-4 w-4 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Unmatched</p>
                </div>
                <p className="mt-2 text-xl font-semibold">{counts.unmatched}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs filter */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <TabsList>
            <TabsTrigger value="all">All ({counts.total})</TabsTrigger>
            <TabsTrigger value="matched">Matched ({counts.matched})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({counts.pending})</TabsTrigger>
            <TabsTrigger value="exception">Exceptions ({counts.exception})</TabsTrigger>
            <TabsTrigger value="unmatched">Unmatched ({counts.unmatched})</TabsTrigger>
          </TabsList>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9 md:w-72"
              placeholder="Search by settlement ID or UTR"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <TabsContent value={activeTab} className="mt-4">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Settlement ID</TableHead>
                  <TableHead>UTR</TableHead>
                  <TableHead>Bank</TableHead>
                  <TableHead className="text-right">PG amount</TableHead>
                  <TableHead className="text-right">Bank amount</TableHead>
                  <TableHead className="text-right">Diff</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((entry) => {
                  const diff = entry.bankAmount - entry.amount
                  const status = statusConfig[entry.status]
                  return (
                    <TableRow key={entry.id}>
                      <TableCell className="font-mono text-xs">{entry.settlementId}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{entry.utr}</TableCell>
                      <TableCell>
                        <span className="text-sm">{entry.bank}</span>
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        {entry.amount > 0 ? formatINR(entry.amount) : "-"}
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        {entry.bankAmount > 0 ? formatINR(entry.bankAmount) : "-"}
                      </TableCell>
                      <TableCell
                        className={`text-right font-mono ${
                          diff === 0 ? "" : diff < 0 ? "text-destructive" : "text-primary"
                        }`}
                      >
                        {diff !== 0 ? (diff > 0 ? "+" : "") + formatINR(diff) : "-"}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{entry.date}</TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <Badge variant={status.badge}>{status.label}</Badge>
                          {entry.reason && (
                            <p className="text-xs text-muted-foreground">{entry.reason}</p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          {entry.status === "exception" || entry.status === "unmatched" ? "Resolve" : "View"}
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
                {filtered.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={9} className="py-12 text-center text-sm text-muted-foreground">
                      No entries found for this filter.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Exception handling panel */}
      {counts.exception > 0 && (
        <Card className="border-destructive/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              <CardTitle>Exception Handling</CardTitle>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              Entries flagged because of amount, UTR or date mismatches. Resolve them to keep your books clean.
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-3">
              <div className="rounded-lg border border-border p-4">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <p className="mt-2 text-sm font-medium">Review bank statement</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Upload the corrected statement and re-run the matcher.
                </p>
              </div>
              <div className="rounded-lg border border-border p-4">
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                <p className="mt-2 text-sm font-medium">Raise PG ticket</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  If mismatch is genuine, auto-escalate to payment gateway.
                </p>
              </div>
              <div className="rounded-lg border border-border p-4">
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
                <p className="mt-2 text-sm font-medium">Manual match</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Link settlement and bank credit manually with justification notes.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
