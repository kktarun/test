"use client"

import { useState } from "react"
import {
  Banknote,
  Building2,
  Plus,
  Search,
  MoreVertical,
  Shield,
  CreditCard,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  Landmark,
  Zap,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type AccountType = "current" | "escrow" | "van" | "fixed" | "payroll"
type Account = {
  id: string
  name: string
  bank: string
  accountNumber: string
  ifsc: string
  type: AccountType
  balance: number
  inflow7d: number
  outflow7d: number
  status: "active" | "frozen"
  isPrimary?: boolean
  linkedGateways?: string[]
}

const accounts: Account[] = [
  {
    id: "ACC001",
    name: "Primary Operating Account",
    bank: "HDFC Bank",
    accountNumber: "XXXX-XXXX-4521",
    ifsc: "HDFC0001234",
    type: "current",
    balance: 8450000,
    inflow7d: 12450000,
    outflow7d: 6820000,
    status: "active",
    isPrimary: true,
    linkedGateways: ["Cashfree", "Razorpay"],
  },
  {
    id: "ACC002",
    name: "Escrow Settlement Account",
    bank: "ICICI Bank",
    accountNumber: "XXXX-XXXX-8901",
    ifsc: "ICIC0004567",
    type: "escrow",
    balance: 3280000,
    inflow7d: 8920000,
    outflow7d: 7650000,
    status: "active",
    linkedGateways: ["Easebuzz"],
  },
  {
    id: "ACC003",
    name: "Virtual Account Pool (VAN)",
    bank: "Yes Bank",
    accountNumber: "VAN-MASTER-0012",
    ifsc: "YESB0000345",
    type: "van",
    balance: 1560000,
    inflow7d: 4180000,
    outflow7d: 4120000,
    status: "active",
    linkedGateways: ["Direct Bank"],
  },
  {
    id: "ACC004",
    name: "Payroll Disbursement Account",
    bank: "Axis Bank",
    accountNumber: "XXXX-XXXX-2341",
    ifsc: "UTIB0000987",
    type: "payroll",
    balance: 2100000,
    inflow7d: 2200000,
    outflow7d: 1850000,
    status: "active",
  },
  {
    id: "ACC005",
    name: "Tax Reserve Fixed Deposit",
    bank: "SBI",
    accountNumber: "FD-2026-0045",
    ifsc: "SBIN0001122",
    type: "fixed",
    balance: 780000,
    inflow7d: 0,
    outflow7d: 0,
    status: "active",
  },
]

const typeConfig: Record<AccountType, { label: string; icon: typeof Banknote; color: string }> = {
  current: { label: "Current", icon: Banknote, color: "text-primary" },
  escrow: { label: "Escrow", icon: Shield, color: "text-info" },
  van: { label: "Virtual Account", icon: Zap, color: "text-warning" },
  fixed: { label: "Fixed Deposit", icon: Landmark, color: "text-muted-foreground" },
  payroll: { label: "Payroll", icon: CreditCard, color: "text-primary" },
}

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)}Cr`
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)}L`
  return `₹${n.toLocaleString("en-IN")}`
}

export function TreasuryAccountsContent() {
  const [search, setSearch] = useState("")
  const [filterType, setFilterType] = useState<string>("all")
  const [addOpen, setAddOpen] = useState(false)

  const filtered = accounts.filter(
    (a) =>
      (filterType === "all" || a.type === filterType) &&
      (a.name.toLowerCase().includes(search.toLowerCase()) ||
        a.bank.toLowerCase().includes(search.toLowerCase()) ||
        a.accountNumber.toLowerCase().includes(search.toLowerCase())),
  )

  const totalBalance = accounts.reduce((a, b) => a + b.balance, 0)
  const activeCount = accounts.filter((a) => a.status === "active").length

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Bank Accounts</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Manage every current, escrow, virtual and reserve account from one place.
          </p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Bank Account
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Bank Account</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-2">
              <div className="grid gap-2">
                <Label>Account nickname</Label>
                <Input placeholder="e.g. Primary Operating Account" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Bank</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hdfc">HDFC Bank</SelectItem>
                      <SelectItem value="icici">ICICI Bank</SelectItem>
                      <SelectItem value="axis">Axis Bank</SelectItem>
                      <SelectItem value="sbi">SBI</SelectItem>
                      <SelectItem value="yes">Yes Bank</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Account type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="current">Current</SelectItem>
                      <SelectItem value="escrow">Escrow</SelectItem>
                      <SelectItem value="van">Virtual Account</SelectItem>
                      <SelectItem value="payroll">Payroll</SelectItem>
                      <SelectItem value="fixed">Fixed Deposit</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label>Account number</Label>
                <Input placeholder="0123 4567 8901" />
              </div>
              <div className="grid gap-2">
                <Label>IFSC code</Label>
                <Input placeholder="HDFC0001234" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setAddOpen(false)}>Link account</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">Total Balance</p>
            <p className="mt-2 text-2xl font-semibold">{formatINR(totalBalance)}</p>
            <p className="mt-1 text-xs text-muted-foreground">Across {accounts.length} accounts</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">Active Accounts</p>
            <p className="mt-2 text-2xl font-semibold">{activeCount}</p>
            <p className="mt-1 text-xs text-muted-foreground">All settlements enabled</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">Escrow + VAN</p>
            <p className="mt-2 text-2xl font-semibold">
              {formatINR(accounts.filter((a) => a.type === "escrow" || a.type === "van").reduce((a, b) => a + b.balance, 0))}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">Reserved for settlement</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">Linked Gateways</p>
            <p className="mt-2 text-2xl font-semibold">3</p>
            <p className="mt-1 text-xs text-muted-foreground">Cashfree, Razorpay, Easebuzz</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="grid">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <TabsList>
            <TabsTrigger value="grid">Grid view</TabsTrigger>
            <TabsTrigger value="table">Table view</TabsTrigger>
          </TabsList>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                className="pl-9 md:w-64"
                placeholder="Search account or bank"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                <SelectItem value="current">Current</SelectItem>
                <SelectItem value="escrow">Escrow</SelectItem>
                <SelectItem value="van">Virtual Account</SelectItem>
                <SelectItem value="payroll">Payroll</SelectItem>
                <SelectItem value="fixed">Fixed Deposit</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <TabsContent value="grid" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((acc) => {
              const cfg = typeConfig[acc.type]
              const Icon = cfg.icon
              const netFlow = acc.inflow7d - acc.outflow7d
              return (
                <Card key={acc.id} className="overflow-hidden">
                  <div
                    className={`h-1 ${acc.isPrimary ? "bg-primary" : "bg-border"}`}
                  />
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                          <Icon className={`h-5 w-5 ${cfg.color}`} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-base">{acc.name}</CardTitle>
                            {acc.isPrimary && <Badge className="text-[10px]">Primary</Badge>}
                          </div>
                          <p className="mt-0.5 text-xs text-muted-foreground">
                            {acc.bank} &middot; <span className="font-mono">{acc.accountNumber}</span>
                          </p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View statements</DropdownMenuItem>
                          <DropdownMenuItem>Edit details</DropdownMenuItem>
                          <DropdownMenuItem>Link gateway</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">Unlink account</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground">Current balance</p>
                    <p className="mt-1 text-2xl font-semibold tracking-tight">{formatINR(acc.balance)}</p>
                    <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
                      <div className="rounded-md border border-border p-2">
                        <p className="text-muted-foreground">7d Inflow</p>
                        <div className="mt-1 flex items-center gap-1">
                          <TrendingUp className="h-3 w-3 text-primary" />
                          <span className="font-mono font-medium">{formatINR(acc.inflow7d)}</span>
                        </div>
                      </div>
                      <div className="rounded-md border border-border p-2">
                        <p className="text-muted-foreground">7d Outflow</p>
                        <div className="mt-1 flex items-center gap-1">
                          <TrendingDown className="h-3 w-3 text-destructive" />
                          <span className="font-mono font-medium">{formatINR(acc.outflow7d)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center justify-between rounded-md bg-muted/50 px-3 py-2">
                      <span className="text-xs text-muted-foreground">Net movement</span>
                      <span className={`text-xs font-semibold ${netFlow >= 0 ? "text-primary" : "text-destructive"}`}>
                        {netFlow >= 0 ? "+" : ""}
                        {formatINR(netFlow)}
                      </span>
                    </div>
                    {acc.linkedGateways && acc.linkedGateways.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1">
                        {acc.linkedGateways.map((g) => (
                          <Badge key={g} variant="outline" className="text-[10px]">
                            {g}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="table" className="mt-4">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Bank / IFSC</TableHead>
                  <TableHead className="text-right">Balance</TableHead>
                  <TableHead className="text-right">7d Inflow</TableHead>
                  <TableHead className="text-right">7d Outflow</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((acc) => {
                  const cfg = typeConfig[acc.type]
                  return (
                    <TableRow key={acc.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{acc.name}</p>
                            <p className="font-mono text-xs text-muted-foreground">{acc.accountNumber}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{cfg.label}</Badge>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm">{acc.bank}</p>
                        <p className="font-mono text-xs text-muted-foreground">{acc.ifsc}</p>
                      </TableCell>
                      <TableCell className="text-right font-mono font-medium">{formatINR(acc.balance)}</TableCell>
                      <TableCell className="text-right font-mono text-primary">{formatINR(acc.inflow7d)}</TableCell>
                      <TableCell className="text-right font-mono text-destructive">
                        {formatINR(acc.outflow7d)}
                      </TableCell>
                      <TableCell>
                        <Badge variant={acc.status === "active" ? "default" : "secondary"}>{acc.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon">
                          <ArrowUpRight className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
