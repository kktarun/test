"use client"

import { useState } from "react"
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  Download,
  Droplets,
  Users,
  Receipt,
  Building2,
  CreditCard,
  GraduationCap,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts"

const monthlyData = [
  { month: "Jan", inflow: 48000000, outflow: 32000000, projected: 0 },
  { month: "Feb", inflow: 52000000, outflow: 34000000, projected: 0 },
  { month: "Mar", inflow: 61000000, outflow: 42000000, projected: 0 },
  { month: "Apr", inflow: 68000000, outflow: 45000000, projected: 0 },
  { month: "May", inflow: 54000000, outflow: 38000000, projected: 0 },
  { month: "Jun", inflow: 49000000, outflow: 36000000, projected: 0 },
  { month: "Jul", inflow: 0, outflow: 0, projected: 58000000 },
  { month: "Aug", inflow: 0, outflow: 0, projected: 62000000 },
  { month: "Sep", inflow: 0, outflow: 0, projected: 71000000 },
]

const inflowSources = [
  { label: "Fee Collections", amount: 42000000, pct: 78, icon: GraduationCap, color: "bg-primary" },
  { label: "Payment Gateway", amount: 6800000, pct: 13, icon: CreditCard, color: "bg-info" },
  { label: "Virtual Account", amount: 3200000, pct: 6, icon: Building2, color: "bg-warning" },
  { label: "Manual Deposits", amount: 1800000, pct: 3, icon: Receipt, color: "bg-muted-foreground" },
]

const outflowCategories = [
  { label: "Vendor Payouts", amount: 8400000, pct: 35, icon: Building2 },
  { label: "Payroll", amount: 7200000, pct: 30, icon: Users },
  { label: "Tax & Compliance", amount: 3800000, pct: 16, icon: Receipt },
  { label: "Lender EMIs", amount: 2900000, pct: 12, icon: CreditCard },
  { label: "Operational", amount: 1700000, pct: 7, icon: Droplets },
]

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)}Cr`
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)}L`
  return `₹${n.toLocaleString("en-IN")}`
}

export function CashFlowContent() {
  const [period, setPeriod] = useState("6months")

  const totalInflow = inflowSources.reduce((a, b) => a + b.amount, 0)
  const totalOutflow = outflowCategories.reduce((a, b) => a + b.amount, 0)
  const netFlow = totalInflow - totalOutflow
  const nextMonthProjected = monthlyData.find((m) => m.projected > 0)?.projected || 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Cash Flow Monitoring</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Live inflow, outflow and liquidity planning with forward projections.
          </p>
        </div>
        <div className="flex gap-2">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-[160px]">
              <Calendar className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 days</SelectItem>
              <SelectItem value="30days">Last 30 days</SelectItem>
              <SelectItem value="6months">Last 6 months</SelectItem>
              <SelectItem value="12months">Last 12 months</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent" />
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-xs font-medium uppercase text-muted-foreground">
              <TrendingUp className="h-4 w-4 text-primary" />
              Period Inflow
            </div>
            <p className="mt-2 text-2xl font-semibold">{formatINR(totalInflow)}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              <span className="font-medium text-primary">+14.2%</span> vs previous period
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-xs font-medium uppercase text-muted-foreground">
              <TrendingDown className="h-4 w-4 text-destructive" />
              Period Outflow
            </div>
            <p className="mt-2 text-2xl font-semibold">{formatINR(totalOutflow)}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              <span className="font-medium text-destructive">+8.1%</span> vs previous period
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">Net Cash Position</p>
            <p className="mt-2 text-2xl font-semibold text-primary">{formatINR(netFlow)}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Runway: <span className="font-medium text-foreground">94 days</span>
            </p>
          </CardContent>
        </Card>
        <Card className="relative overflow-hidden">
          <div className="absolute right-0 top-0 h-full w-24 bg-gradient-to-l from-primary/5 to-transparent" />
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">Next Month Forecast</p>
            <p className="mt-2 text-2xl font-semibold">{formatINR(nextMonthProjected)}</p>
            <Badge variant="outline" className="mt-2">
              Projected
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* Trend Chart */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle>Cash Flow Trend</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                Actual movement with 3-month forward projection based on collection patterns
              </p>
            </div>
            <div className="flex gap-2">
              <Badge variant="outline" className="gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" />
                Inflow
              </Badge>
              <Badge variant="outline" className="gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-3" />
                Outflow
              </Badge>
              <Badge variant="outline" className="gap-1.5">
                <span className="h-2 w-2 rounded-full bg-chart-2" />
                Projected
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[380px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={monthlyData}>
                <defs>
                  <linearGradient id="inflowGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.02} />
                  </linearGradient>
                  <linearGradient id="projGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--chart-2)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--chart-2)" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} />
                <YAxis
                  stroke="var(--muted-foreground)"
                  fontSize={12}
                  tickLine={false}
                  tickFormatter={(v) => `₹${v / 10000000}Cr`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: "var(--radius)",
                    fontSize: "12px",
                  }}
                  formatter={(value: number) => (value > 0 ? formatINR(value) : "-")}
                />
                <Area
                  type="monotone"
                  dataKey="inflow"
                  name="Inflow"
                  fill="url(#inflowGrad)"
                  stroke="var(--chart-1)"
                  strokeWidth={2}
                />
                <Bar dataKey="outflow" name="Outflow" fill="var(--chart-3)" radius={[4, 4, 0, 0]} />
                <Area
                  type="monotone"
                  dataKey="projected"
                  name="Projected"
                  fill="url(#projGrad)"
                  stroke="var(--chart-2)"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="inflow">
        <TabsList>
          <TabsTrigger value="inflow">Inflow breakdown</TabsTrigger>
          <TabsTrigger value="outflow">Outflow breakdown</TabsTrigger>
          <TabsTrigger value="forecast">Liquidity forecast</TabsTrigger>
        </TabsList>

        <TabsContent value="inflow" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Inflow Sources</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                Where your money is coming from across every channel
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {inflowSources.map((src) => {
                const Icon = src.icon
                return (
                  <div key={src.label} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${src.color}/10`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="font-medium">{src.label}</p>
                          <p className="text-xs text-muted-foreground">{src.pct}% of total inflow</p>
                        </div>
                      </div>
                      <span className="font-mono font-semibold">{formatINR(src.amount)}</span>
                    </div>
                    <Progress value={src.pct} className="h-1.5" />
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="outflow" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Outflow Categories</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">Every rupee going out, organized by purpose</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {outflowCategories.map((cat) => {
                const Icon = cat.icon
                return (
                  <div key={cat.label} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-destructive/10">
                          <Icon className="h-4 w-4 text-destructive" />
                        </div>
                        <div>
                          <p className="font-medium">{cat.label}</p>
                          <p className="text-xs text-muted-foreground">{cat.pct}% of total outflow</p>
                        </div>
                      </div>
                      <span className="font-mono font-semibold">{formatINR(cat.amount)}</span>
                    </div>
                    <Progress value={cat.pct} className="h-1.5" />
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="forecast" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Liquidity Forecast</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                90-day view combining recurring payouts and expected receivables
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 md:grid-cols-3">
                {[
                  { label: "30-day projection", amount: 58000000, trend: "up", pct: "+8.4%" },
                  { label: "60-day projection", amount: 62000000, trend: "up", pct: "+14.7%" },
                  { label: "90-day projection", amount: 71000000, trend: "up", pct: "+23.2%" },
                ].map((f) => (
                  <Card key={f.label} className="border-dashed">
                    <CardContent className="pt-6">
                      <p className="text-xs font-medium uppercase text-muted-foreground">{f.label}</p>
                      <p className="mt-2 text-2xl font-semibold">{formatINR(f.amount)}</p>
                      <div className="mt-1 flex items-center gap-1 text-xs">
                        <TrendingUp className="h-3 w-3 text-primary" />
                        <span className="font-medium text-primary">{f.pct}</span>
                        <span className="text-muted-foreground">expected inflow</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="mt-6 rounded-lg border border-primary/20 bg-primary/5 p-4">
                <p className="text-sm font-medium">Liquidity advice</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Based on seasonal patterns, you will receive a 23% inflow spike in September (start of the academic
                  term). Consider parking escrow balances into short-term liquid funds between July and August.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
