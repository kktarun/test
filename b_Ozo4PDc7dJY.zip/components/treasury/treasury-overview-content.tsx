"use client"

import { useState } from "react"
import Link from "next/link"
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  AlertTriangle,
  Banknote,
  PiggyBank,
  Activity,
  GitBranch,
  Clock,
  CheckCircle2,
  Download,
  RefreshCw,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Cell,
  Pie,
  PieChart,
} from "recharts"

const cashFlowData = [
  { day: "Mon", inflow: 2840000, outflow: 1240000 },
  { day: "Tue", inflow: 3120000, outflow: 1560000 },
  { day: "Wed", inflow: 2680000, outflow: 2100000 },
  { day: "Thu", inflow: 3850000, outflow: 1820000 },
  { day: "Fri", inflow: 4200000, outflow: 1450000 },
  { day: "Sat", inflow: 1850000, outflow: 980000 },
  { day: "Sun", inflow: 890000, outflow: 520000 },
]

const accountBalances = [
  { name: "Primary Current", balance: 8450000, type: "Current", color: "var(--chart-1)" },
  { name: "Escrow Account", balance: 3280000, type: "Escrow", color: "var(--chart-2)" },
  { name: "Virtual Account", balance: 1560000, type: "VAN", color: "var(--chart-3)" },
  { name: "Payroll Account", balance: 2100000, type: "Current", color: "var(--chart-4)" },
  { name: "Tax Reserve", balance: 780000, type: "Fixed", color: "var(--chart-5)" },
]

const upcomingObligations = [
  { label: "Vendor Payouts", due: "Tomorrow", amount: 485000, status: "scheduled" },
  { label: "Payroll Disbursement", due: "In 3 days", amount: 1850000, status: "scheduled" },
  { label: "TDS Deposit", due: "In 5 days", amount: 142000, status: "warning" },
  { label: "GST Payment", due: "In 8 days", amount: 98500, status: "scheduled" },
  { label: "Lender EMI", due: "In 12 days", amount: 320000, status: "scheduled" },
]

const recentAlerts = [
  {
    type: "critical",
    title: "3 settlements pending reconciliation",
    description: "UTR mismatch detected on CF-2026-0892",
    time: "12 min ago",
  },
  {
    type: "warning",
    title: "Low balance alert - Payroll Account",
    description: "Balance below ₹25L threshold before salary run",
    time: "45 min ago",
  },
  {
    type: "info",
    title: "Bulk VAN reconciliation completed",
    description: "128 virtual account entries auto-matched",
    time: "2 hrs ago",
  },
]

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)}Cr`
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)}L`
  return `₹${n.toLocaleString("en-IN")}`
}

export function TreasuryOverviewContent() {
  const [activeTab, setActiveTab] = useState("overview")

  const totalBalance = accountBalances.reduce((a, b) => a + b.balance, 0)
  const weekInflow = cashFlowData.reduce((a, b) => a + b.inflow, 0)
  const weekOutflow = cashFlowData.reduce((a, b) => a + b.outflow, 0)
  const netCashFlow = weekInflow - weekOutflow

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              Live Treasury View
            </Badge>
            <span className="text-xs text-muted-foreground">Updated just now</span>
          </div>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight text-balance">Banking & Treasury</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            CFO-level command center for cash, liquidity and reconciliation across every bank relationship.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <GitBranch className="mr-2 h-4 w-4" />
            New Allocation Rule
          </Button>
        </div>
      </div>

      {/* Hero stat grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent" />
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <Wallet className="h-4 w-4" />
              Total Liquid Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-semibold tracking-tight">{formatINR(totalBalance)}</p>
            <div className="mt-2 flex items-center gap-1 text-xs">
              <TrendingUp className="h-3 w-3 text-primary" />
              <span className="font-medium text-primary">+12.4%</span>
              <span className="text-muted-foreground">vs last week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <ArrowDownRight className="h-4 w-4 text-primary" />
              7-Day Inflow
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-semibold tracking-tight">{formatINR(weekInflow)}</p>
            <p className="mt-2 text-xs text-muted-foreground">
              Across <span className="font-medium text-foreground">1,284</span> payment instruments
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <ArrowUpRight className="h-4 w-4 text-destructive" />
              7-Day Outflow
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-semibold tracking-tight">{formatINR(weekOutflow)}</p>
            <p className="mt-2 text-xs text-muted-foreground">
              <span className="font-medium text-foreground">42</span> vendor payouts &middot;{" "}
              <span className="font-medium text-foreground">1</span> payroll run
            </p>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent" />
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <Activity className="h-4 w-4" />
              Net Cash Flow
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-semibold tracking-tight text-primary">{formatINR(netCashFlow)}</p>
            <p className="mt-2 text-xs text-muted-foreground">Runway: 94 days at current burn</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="accounts">Accounts</TabsTrigger>
          <TabsTrigger value="obligations">Obligations</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Weekly Cash Movement</CardTitle>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Daily inflow vs outflow across all treasury accounts
                    </p>
                  </div>
                  <Button variant="ghost" size="sm" asChild>
                    <Link href="/treasury/cash-flow">View detail</Link>
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-[320px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={cashFlowData}>
                      <defs>
                        <linearGradient id="inflow" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.4} />
                          <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0.02} />
                        </linearGradient>
                        <linearGradient id="outflow" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.4} />
                          <stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                      <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} />
                      <YAxis
                        stroke="var(--muted-foreground)"
                        fontSize={12}
                        tickLine={false}
                        tickFormatter={(v) => `₹${v / 100000}L`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--popover)",
                          border: "1px solid var(--border)",
                          borderRadius: "var(--radius)",
                          fontSize: "12px",
                        }}
                        formatter={(value: number) => formatINR(value)}
                      />
                      <Legend wrapperStyle={{ fontSize: "12px" }} />
                      <Area
                        type="monotone"
                        dataKey="inflow"
                        name="Inflow"
                        stroke="var(--chart-1)"
                        strokeWidth={2}
                        fill="url(#inflow)"
                      />
                      <Area
                        type="monotone"
                        dataKey="outflow"
                        name="Outflow"
                        stroke="var(--chart-3)"
                        strokeWidth={2}
                        fill="url(#outflow)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Balance Mix</CardTitle>
                <p className="mt-1 text-sm text-muted-foreground">Distribution across account types</p>
              </CardHeader>
              <CardContent>
                <div className="h-[240px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={accountBalances}
                        dataKey="balance"
                        nameKey="name"
                        innerRadius={60}
                        outerRadius={95}
                        paddingAngle={2}
                      >
                        {accountBalances.map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "var(--popover)",
                          border: "1px solid var(--border)",
                          borderRadius: "var(--radius)",
                          fontSize: "12px",
                        }}
                        formatter={(value: number) => formatINR(value)}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 space-y-2">
                  {accountBalances.map((acc) => (
                    <div key={acc.name} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: acc.color }} />
                        <span className="text-muted-foreground">{acc.name}</span>
                      </div>
                      <span className="font-mono font-medium">{formatINR(acc.balance)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardContent className="flex items-center gap-4 pt-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Auto-reconciled</p>
                  <p className="text-2xl font-semibold">94.2%</p>
                  <p className="text-xs text-muted-foreground">1,821 of 1,932 entries</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-4 pt-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-amber-500/10">
                  <Clock className="h-6 w-6 text-amber-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Pending Recon</p>
                  <p className="text-2xl font-semibold">111</p>
                  <p className="text-xs text-muted-foreground">Total value {formatINR(8420000)}</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="flex items-center gap-4 pt-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-destructive/10">
                  <AlertTriangle className="h-6 w-6 text-destructive" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Exceptions</p>
                  <p className="text-2xl font-semibold">7</p>
                  <p className="text-xs text-muted-foreground">Require manual intervention</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="accounts" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {accountBalances.map((acc) => {
              const pct = (acc.balance / totalBalance) * 100
              return (
                <Card key={acc.name}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                        <Banknote className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {acc.type}
                      </Badge>
                    </div>
                    <CardTitle className="mt-2 text-base">{acc.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-semibold tracking-tight">{formatINR(acc.balance)}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{pct.toFixed(1)}% of total treasury</p>
                    <Progress value={pct} className="mt-3 h-1.5" />
                  </CardContent>
                </Card>
              )
            })}
            <Card className="border-dashed">
              <CardContent className="flex h-full flex-col items-center justify-center gap-2 py-8 text-center">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <PiggyBank className="h-5 w-5 text-primary" />
                </div>
                <p className="text-sm font-medium">Link another bank</p>
                <p className="text-xs text-muted-foreground">Add a current, escrow or fixed deposit account</p>
                <Button size="sm" variant="outline" asChild>
                  <Link href="/treasury/accounts">Manage Accounts</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="obligations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Payout Obligations</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                Scheduled outflows in the next 14 days &middot; plan liquidity accordingly
              </p>
            </CardHeader>
            <CardContent className="space-y-3">
              {upcomingObligations.map((obl) => (
                <div
                  key={obl.label}
                  className="flex items-center justify-between rounded-lg border border-border bg-card p-4"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                        obl.status === "warning" ? "bg-amber-500/10" : "bg-primary/10"
                      }`}
                    >
                      <Clock
                        className={`h-5 w-5 ${obl.status === "warning" ? "text-amber-600" : "text-primary"}`}
                      />
                    </div>
                    <div>
                      <p className="font-medium">{obl.label}</p>
                      <p className="text-xs text-muted-foreground">Due {obl.due}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-mono font-semibold">{formatINR(obl.amount)}</p>
                    <Badge variant={obl.status === "warning" ? "destructive" : "outline"} className="mt-1 text-xs">
                      {obl.status === "warning" ? "Needs funding" : "Ready"}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Treasury Alerts</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">Operational signals requiring attention</p>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentAlerts.map((alert, idx) => (
                <div key={idx} className="flex gap-3 rounded-lg border border-border p-4">
                  <div
                    className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                      alert.type === "critical"
                        ? "bg-destructive/10 text-destructive"
                        : alert.type === "warning"
                          ? "bg-amber-500/10 text-amber-600"
                          : "bg-primary/10 text-primary"
                    }`}
                  >
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-4">
                      <p className="font-medium">{alert.title}</p>
                      <span className="text-xs text-muted-foreground">{alert.time}</span>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{alert.description}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
