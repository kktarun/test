"use client"

import { useState } from "react"
import {
  GitBranch,
  Plus,
  MoreVertical,
  Shield,
  Building2,
  Users,
  Receipt,
  Landmark,
  ArrowRight,
  Power,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AllocationRule {
  id: string
  name: string
  source: string
  description: string
  splits: { target: string; percentage: number; icon: typeof Building2; color: string }[]
  active: boolean
  priority: number
  volume: string
}

const rules: AllocationRule[] = [
  {
    id: "RULE001",
    name: "Standard Fee Inflow",
    source: "Parent Fee Payment",
    description: "Applied when parents pay academic + transport fees via any PG",
    splits: [
      { target: "Institute Operating (HDFC)", percentage: 85, icon: Building2, color: "text-primary" },
      { target: "Transport Vendor Escrow", percentage: 10, icon: Users, color: "text-info" },
      { target: "Tax Reserve", percentage: 5, icon: Receipt, color: "text-warning" },
    ],
    active: true,
    priority: 1,
    volume: "₹42.8L / month",
  },
  {
    id: "RULE002",
    name: "Financed Fee Inflow",
    source: "NBFC Disbursement",
    description: "When a parent uses embedded loan, split between lender escrow and institute",
    splits: [
      { target: "Institute Operating (HDFC)", percentage: 92, icon: Building2, color: "text-primary" },
      { target: "Lender Escrow (ICICI)", percentage: 8, icon: Shield, color: "text-info" },
    ],
    active: true,
    priority: 2,
    volume: "₹18.4L / month",
  },
  {
    id: "RULE003",
    name: "VAN Auto-Allocation",
    source: "Virtual Account credit",
    description: "Splits hostel and mess fees automatically based on fee head",
    splits: [
      { target: "Institute Operating (HDFC)", percentage: 60, icon: Building2, color: "text-primary" },
      { target: "Hostel Vendor Payout", percentage: 25, icon: Users, color: "text-info" },
      { target: "Mess Vendor Payout", percentage: 15, icon: Users, color: "text-warning" },
    ],
    active: true,
    priority: 3,
    volume: "₹6.2L / month",
  },
  {
    id: "RULE004",
    name: "Donation / Trust Inflow",
    source: "Manual / Bulk deposit",
    description: "Trustee-supervised allocation across scholarship and infrastructure funds",
    splits: [
      { target: "Scholarship Fund", percentage: 50, icon: Landmark, color: "text-primary" },
      { target: "Infrastructure Reserve", percentage: 40, icon: Building2, color: "text-info" },
      { target: "Trustee Visibility", percentage: 10, icon: Shield, color: "text-warning" },
    ],
    active: false,
    priority: 4,
    volume: "₹3.8L / quarter",
  },
]

export function AllocationRulesContent() {
  const [addOpen, setAddOpen] = useState(false)
  const [ruleState, setRuleState] = useState(rules)

  const toggle = (id: string) => {
    setRuleState((prev) => prev.map((r) => (r.id === id ? { ...r, active: !r.active } : r)))
  }

  const activeCount = ruleState.filter((r) => r.active).length

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Fund Allocation Rules</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Route every incoming rupee automatically to escrow, vendors, tax reserves and lenders.
          </p>
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create rule
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>New allocation rule</DialogTitle>
              <DialogDescription>
                Auto-split incoming funds as soon as they hit your account.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-2">
              <div className="grid gap-2">
                <Label>Rule name</Label>
                <Input placeholder="e.g. Transport fee allocation" />
              </div>
              <div className="grid gap-2">
                <Label>Triggers on</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fee">Parent fee payment</SelectItem>
                    <SelectItem value="van">VAN credit</SelectItem>
                    <SelectItem value="nbfc">NBFC disbursement</SelectItem>
                    <SelectItem value="manual">Manual deposit</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label>Description</Label>
                <Input placeholder="What happens when this rule fires" />
              </div>
              <div className="rounded-lg border border-dashed border-border p-3 text-xs text-muted-foreground">
                You can add splits on the next step. Percentages must add up to 100%.
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setAddOpen(false)}>Continue</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <GitBranch className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Active rules</p>
                <p className="text-2xl font-semibold">{activeCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Funds auto-routed (last 30d)</p>
            <p className="mt-1 text-2xl font-semibold">₹71.2L</p>
            <p className="mt-1 text-xs text-muted-foreground">
              <span className="font-medium text-primary">+22%</span> vs previous month
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Average routing time</p>
            <p className="mt-1 text-2xl font-semibold">1.2 s</p>
            <p className="mt-1 text-xs text-muted-foreground">From inflow to escrow split</p>
          </CardContent>
        </Card>
      </div>

      {/* Rule cards */}
      <div className="space-y-4">
        {ruleState.map((rule) => (
          <Card key={rule.id} className={rule.active ? "" : "opacity-60"}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                    <GitBranch className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-base">{rule.name}</CardTitle>
                      <Badge variant="outline" className="text-[10px]">
                        Priority {rule.priority}
                      </Badge>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">{rule.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">Volume</p>
                    <p className="text-sm font-mono font-medium">{rule.volume}</p>
                  </div>
                  <Switch checked={rule.active} onCheckedChange={() => toggle(rule.id)} />
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Edit rule</DropdownMenuItem>
                      <DropdownMenuItem>View routing log</DropdownMenuItem>
                      <DropdownMenuItem>Duplicate</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 rounded-lg border border-dashed border-border bg-muted/20 p-3">
                <Badge variant="secondary">{rule.source}</Badge>
                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                <div className="flex flex-1 flex-wrap gap-2">
                  {rule.splits.map((split) => {
                    const Icon = split.icon
                    return (
                      <div
                        key={split.target}
                        className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5"
                      >
                        <Icon className={`h-3.5 w-3.5 ${split.color}`} />
                        <span className="text-xs font-medium">{split.target}</span>
                        <Badge variant="outline" className="h-5 text-[10px] font-mono">
                          {split.percentage}%
                        </Badge>
                      </div>
                    )
                  })}
                </div>
              </div>
              {/* Visual split bar */}
              <div className="mt-3 flex h-2 overflow-hidden rounded-full bg-muted">
                {rule.splits.map((split, idx) => (
                  <div
                    key={idx}
                    style={{ width: `${split.percentage}%` }}
                    className={`${
                      idx === 0 ? "bg-primary" : idx === 1 ? "bg-chart-2" : idx === 2 ? "bg-chart-3" : "bg-chart-4"
                    }`}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Info banner */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="flex items-start gap-3 pt-6">
          <Power className="mt-0.5 h-5 w-5 text-primary" />
          <div>
            <p className="font-medium">Trustee visibility is enabled</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Every rule execution is logged with timestamp, source UTR and split destinations. Trustees can download
              the allocation ledger from the Audit section for any reporting period.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
