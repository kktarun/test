"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronRight, ChevronLeft, Eye, Upload, Landmark, ArrowRight, ArrowUpRight } from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ChargebackDetailModal } from "./chargeback-detail-modal"

interface Chargeback {
  id: string
  transactionId: string
  arn: string
  institute: string
  studentName: string
  amount: number
  gateway: string
  reason: string
  reasonCode: string
  status: "open" | "under_review" | "response_submitted" | "won" | "lost" | "expired"
  raisedBy: string
  raisedDate: string
  dueDate: string
  cardType: string
  cardLast4: string
  originalSettlement?: {
    id: string
    date: string
  }
  deductedFromSettlement?: {
    id: string
    date: string
    deductionDate: string
  }
  recoveryInfo?: {
    creditedToSettlement: string
    creditedDate: string
    wonDate: string
  }
}

const chargebacks: Chargeback[] = [
  {
    id: "CHB001234",
    transactionId: "TXN789456123",
    arn: "74567891234567890123",
    institute: "Delhi Public School",
    studentName: "Rahul Sharma",
    amount: 45000,
    gateway: "Razorpay",
    reason: "Fraudulent Transaction",
    reasonCode: "10.4",
    status: "open",
    raisedBy: "HDFC Bank",
    raisedDate: "2024-01-14",
    dueDate: "2024-01-21",
    cardType: "Visa",
    cardLast4: "4521",
    originalSettlement: {
      id: "SETTLE-082",
      date: "2024-01-08",
    },
    deductedFromSettlement: {
      id: "SETTLE-089",
      date: "2024-01-15",
      deductionDate: "2024-01-14",
    },
  },
  {
    id: "CHB001235",
    transactionId: "TXN789456124",
    arn: "74567891234567890124",
    institute: "Delhi Public School",
    studentName: "Priya Patel",
    amount: 78000,
    gateway: "Cashfree",
    reason: "Product Not Received",
    reasonCode: "13.1",
    status: "under_review",
    raisedBy: "ICICI Bank",
    raisedDate: "2024-01-12",
    dueDate: "2024-01-19",
    cardType: "Mastercard",
    cardLast4: "8976",
    originalSettlement: {
      id: "SETTLE-078",
      date: "2024-01-04",
    },
    deductedFromSettlement: {
      id: "SETTLE-085",
      date: "2024-01-13",
      deductionDate: "2024-01-12",
    },
  },
  {
    id: "CHB001236",
    transactionId: "TXN789456125",
    arn: "74567891234567890125",
    institute: "Delhi Public School",
    studentName: "Amit Kumar",
    amount: 125000,
    gateway: "Paytm",
    reason: "Duplicate Transaction",
    reasonCode: "12.6",
    status: "response_submitted",
    raisedBy: "SBI Card",
    raisedDate: "2024-01-10",
    dueDate: "2024-01-17",
    cardType: "Rupay",
    cardLast4: "3214",
    originalSettlement: {
      id: "SETTLE-075",
      date: "2024-01-02",
    },
    deductedFromSettlement: {
      id: "SETTLE-083",
      date: "2024-01-11",
      deductionDate: "2024-01-10",
    },
  },
  {
    id: "CHB001237",
    transactionId: "TXN789456126",
    arn: "74567891234567890126",
    institute: "Delhi Public School",
    studentName: "Sneha Reddy",
    amount: 32000,
    gateway: "Easebuzz",
    reason: "Unauthorized Transaction",
    reasonCode: "10.1",
    status: "won",
    raisedBy: "Axis Bank",
    raisedDate: "2024-01-05",
    dueDate: "2024-01-12",
    cardType: "Visa",
    cardLast4: "6543",
    originalSettlement: {
      id: "SETTLE-070",
      date: "2023-12-28",
    },
    deductedFromSettlement: {
      id: "SETTLE-076",
      date: "2024-01-06",
      deductionDate: "2024-01-05",
    },
    recoveryInfo: {
      creditedToSettlement: "SETTLE-090",
      creditedDate: "2024-01-16",
      wonDate: "2024-01-14",
    },
  },
  {
    id: "CHB001238",
    transactionId: "TXN789456127",
    arn: "74567891234567890127",
    institute: "Delhi Public School",
    studentName: "Vikram Singh",
    amount: 56000,
    gateway: "Razorpay",
    reason: "Refund Not Processed",
    reasonCode: "13.6",
    status: "lost",
    raisedBy: "Kotak Bank",
    raisedDate: "2024-01-03",
    dueDate: "2024-01-10",
    cardType: "Mastercard",
    cardLast4: "9876",
    originalSettlement: {
      id: "SETTLE-068",
      date: "2023-12-26",
    },
    deductedFromSettlement: {
      id: "SETTLE-074",
      date: "2024-01-04",
      deductionDate: "2024-01-03",
    },
  },
]

const statusColors = {
  open: "bg-warning/10 text-warning border-warning/20",
  under_review: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  response_submitted: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  won: "bg-success/10 text-success border-success/20",
  lost: "bg-destructive/10 text-destructive border-destructive/20",
  expired: "bg-muted text-muted-foreground border-muted",
}

const statusLabels = {
  open: "Open",
  under_review: "Under Review",
  response_submitted: "Response Submitted",
  won: "Won",
  lost: "Lost",
  expired: "Expired",
}

interface ChargebacksTableProps {
  filters: {
    institute: string
    gateway: string
    status: string
    reason: string
  }
  onSelectChargeback: (id: string | null) => void
  selectedChargeback: string | null
}

export function ChargebacksTable({ filters, onSelectChargeback, selectedChargeback }: ChargebacksTableProps) {
  const [detailChargeback, setDetailChargeback] = useState<Chargeback | null>(null)

  const filteredChargebacks = chargebacks.filter((c) => {
    if (filters.gateway !== "all" && !c.gateway.toLowerCase().includes(filters.gateway)) return false
    if (filters.status !== "all" && c.status !== filters.status) return false
    return true
  })

  const getDaysRemaining = (dueDate: string) => {
    const due = new Date(dueDate)
    const now = new Date()
    const diff = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    return diff
  }

  return (
    <TooltipProvider>
      <>
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-semibold">{filteredChargebacks.length} Chargebacks</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-secondary/50">
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Chargeback ID</th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Student</th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Amount</th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Reason</th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Raised By</th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">
                      Settlement Impact
                    </th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Due Date</th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredChargebacks.map((chargeback) => {
                    const daysRemaining = getDaysRemaining(chargeback.dueDate)
                    const isUrgent = daysRemaining <= 3 && chargeback.status === "open"

                    return (
                      <tr
                        key={chargeback.id}
                        className={`border-b border-border hover:bg-secondary/30 transition-colors cursor-pointer ${
                          selectedChargeback === chargeback.id ? "bg-secondary/50" : ""
                        }`}
                        onClick={() => onSelectChargeback(chargeback.id)}
                      >
                        <td className="p-4">
                          <div>
                            <span className="font-mono text-sm font-medium text-primary">{chargeback.id}</span>
                            <p className="text-xs text-muted-foreground mt-1">{chargeback.transactionId}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <div>
                            <span className="text-sm font-medium">{chargeback.studentName}</span>
                            <p className="text-xs text-muted-foreground font-mono">{chargeback.transactionId}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="font-semibold">₹{chargeback.amount.toLocaleString()}</span>
                        </td>
                        <td className="p-4">
                          <div>
                            <span className="text-sm">{chargeback.reason}</span>
                            <p className="text-xs text-muted-foreground">Code: {chargeback.reasonCode}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <div>
                            <span className="text-sm">{chargeback.raisedBy}</span>
                            <p className="text-xs text-muted-foreground">
                              {chargeback.cardType} ****{chargeback.cardLast4}
                            </p>
                          </div>
                        </td>
                        <td className="p-4">
                          {chargeback.deductedFromSettlement && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="space-y-1 cursor-help">
                                  <div className="flex items-center gap-1 text-xs">
                                    <Landmark className="h-3.5 w-3.5 text-red-500" />
                                    <span className="font-mono text-red-600">
                                      {chargeback.deductedFromSettlement.id}
                                    </span>
                                  </div>
                                  {chargeback.status === "won" && chargeback.recoveryInfo && (
                                    <div className="flex items-center gap-1 text-xs">
                                      <ArrowUpRight className="h-3.5 w-3.5 text-emerald-500" />
                                      <span className="font-mono text-emerald-600">
                                        {chargeback.recoveryInfo.creditedToSettlement}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-sm">
                                <div className="space-y-3 text-xs">
                                  <p className="font-semibold">Settlement Impact</p>

                                  {/* Deduction Flow */}
                                  <div className="bg-red-500/10 rounded p-2">
                                    <p className="text-red-600 font-medium mb-1">Deduction</p>
                                    <div className="flex items-center gap-2">
                                      <div>
                                        <p className="text-muted-foreground">Original</p>
                                        <p className="font-mono">{chargeback.originalSettlement?.id}</p>
                                      </div>
                                      <ArrowRight className="h-3 w-3" />
                                      <div>
                                        <p className="text-muted-foreground">Deducted From</p>
                                        <p className="font-mono text-red-600">{chargeback.deductedFromSettlement.id}</p>
                                      </div>
                                    </div>
                                    <p className="text-muted-foreground mt-1">
                                      ₹{chargeback.amount.toLocaleString()} on{" "}
                                      {chargeback.deductedFromSettlement.deductionDate}
                                    </p>
                                  </div>

                                  {/* Recovery Flow (if won) */}
                                  {chargeback.status === "won" && chargeback.recoveryInfo && (
                                    <div className="bg-emerald-500/10 rounded p-2">
                                      <p className="text-emerald-600 font-medium mb-1">Recovery (Won)</p>
                                      <div>
                                        <p className="text-muted-foreground">Credited To</p>
                                        <p className="font-mono text-emerald-600">
                                          {chargeback.recoveryInfo.creditedToSettlement}
                                        </p>
                                      </div>
                                      <p className="text-muted-foreground mt-1">
                                        Won: {chargeback.recoveryInfo.wonDate} | Credited:{" "}
                                        {chargeback.recoveryInfo.creditedDate}
                                      </p>
                                    </div>
                                  )}

                                  {chargeback.status === "lost" && (
                                    <div className="bg-red-500/10 rounded p-2">
                                      <p className="text-red-600 font-medium">Permanent Loss</p>
                                      <p className="text-muted-foreground">
                                        ₹{chargeback.amount.toLocaleString()} permanently deducted
                                      </p>
                                    </div>
                                  )}
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </td>
                        <td className="p-4">
                          <div>
                            <span className={`text-sm ${isUrgent ? "text-destructive font-medium" : ""}`}>
                              {chargeback.dueDate}
                            </span>
                            {chargeback.status === "open" && (
                              <p className={`text-xs ${isUrgent ? "text-destructive" : "text-muted-foreground"}`}>
                                {daysRemaining > 0 ? `${daysRemaining} days left` : "Overdue"}
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge variant="outline" className={statusColors[chargeback.status]}>
                            {statusLabels[chargeback.status]}
                          </Badge>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={(e) => {
                                e.stopPropagation()
                                setDetailChargeback(chargeback)
                              }}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            {(chargeback.status === "open" || chargeback.status === "under_review") && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={(e) => e.stopPropagation()}
                              >
                                <Upload className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between border-t border-border p-4">
              <p className="text-sm text-muted-foreground">
                Showing 1 to {filteredChargebacks.length} of {filteredChargebacks.length} chargebacks
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm">Page 1 of 1</span>
                <Button variant="outline" size="sm" disabled>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <ChargebackDetailModal chargeback={detailChargeback} onClose={() => setDetailChargeback(null)} />
      </>
    </TooltipProvider>
  )
}
