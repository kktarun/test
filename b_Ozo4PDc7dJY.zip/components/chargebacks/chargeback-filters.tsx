"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, Download } from "lucide-react"
import { DateRangePicker } from "@/components/date-range-picker"

interface ChargebackFiltersProps {
  filters: {
    gateway: string
    status: string
    reason: string
  }
  onFilterChange: (filters: any) => void
}

export function ChargebackFilters({ filters, onFilterChange }: ChargebackFiltersProps) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by Transaction ID, ARN..." className="pl-9 bg-secondary/50 border-border" />
          </div>

          <Select value={filters.gateway} onValueChange={(value) => onFilterChange({ ...filters, gateway: value })}>
            <SelectTrigger className="w-[150px] bg-secondary/50 border-border">
              <SelectValue placeholder="All Gateways" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Gateways</SelectItem>
              <SelectItem value="razorpay">Razorpay</SelectItem>
              <SelectItem value="cashfree">Cashfree</SelectItem>
              <SelectItem value="paytm">Paytm</SelectItem>
              <SelectItem value="easebuzz">Easebuzz</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.status} onValueChange={(value) => onFilterChange({ ...filters, status: value })}>
            <SelectTrigger className="w-[160px] bg-secondary/50 border-border">
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="under_review">Under Review</SelectItem>
              <SelectItem value="response_submitted">Response Submitted</SelectItem>
              <SelectItem value="won">Won</SelectItem>
              <SelectItem value="lost">Lost</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.reason} onValueChange={(value) => onFilterChange({ ...filters, reason: value })}>
            <SelectTrigger className="w-[180px] bg-secondary/50 border-border">
              <SelectValue placeholder="All Reasons" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Reasons</SelectItem>
              <SelectItem value="fraud">Fraud</SelectItem>
              <SelectItem value="not_received">Product Not Received</SelectItem>
              <SelectItem value="not_as_described">Not as Described</SelectItem>
              <SelectItem value="duplicate">Duplicate Transaction</SelectItem>
              <SelectItem value="unauthorized">Unauthorized</SelectItem>
              <SelectItem value="refund_not_processed">Refund Not Processed</SelectItem>
            </SelectContent>
          </Select>

          <DateRangePicker />

          <Button variant="outline" className="gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
