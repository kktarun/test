"use client"

import { useState } from "react"
import { ChargebackStats } from "./chargeback-stats"
import { ChargebackFilters } from "./chargeback-filters"
import { ChargebacksTable } from "./chargebacks-table"
import { ChargebackTimeline } from "./chargeback-timeline"

export function ChargebacksContent() {
  const [filters, setFilters] = useState({
    gateway: "all",
    status: "all",
    reason: "all",
  })
  const [selectedChargeback, setSelectedChargeback] = useState<string | null>(null)

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-bold">Chargebacks</h1>
        <p className="text-muted-foreground">
          Monitor and manage all chargeback disputes across your payment gateways
        </p>
      </div>

      <ChargebackStats />

      <ChargebackFilters filters={filters} onFilterChange={setFilters} />

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2">
          <ChargebacksTable
            filters={filters}
            onSelectChargeback={setSelectedChargeback}
            selectedChargeback={selectedChargeback}
          />
        </div>
        <div className="xl:col-span-1">
          <ChargebackTimeline chargebackId={selectedChargeback} />
        </div>
      </div>
    </div>
  )
}
