"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, ArrowUpRight, ArrowDownRight, Download } from "lucide-react"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const instituteData = [
  {
    name: "Delhi Public School",
    collections: 12000000,
    transactions: 12450,
    erpRevenue: 60000,
    growth: 15.2,
    status: "active",
  },
  {
    name: "Amity University",
    collections: 9800000,
    transactions: 8920,
    erpRevenue: 49000,
    growth: 8.5,
    status: "active",
  },
  {
    name: "St. Mary's College",
    collections: 7600000,
    transactions: 7650,
    erpRevenue: 38000,
    growth: 22.1,
    status: "active",
  },
  {
    name: "Ryan International",
    collections: 6500000,
    transactions: 6540,
    erpRevenue: 32500,
    growth: -2.3,
    status: "active",
  },
  {
    name: "Modern School",
    collections: 5400000,
    transactions: 5430,
    erpRevenue: 27000,
    growth: 12.8,
    status: "active",
  },
  {
    name: "Kendriya Vidyalaya",
    collections: 4200000,
    transactions: 4250,
    erpRevenue: 21000,
    growth: 5.6,
    status: "active",
  },
]

const chartData = instituteData.slice(0, 6).map((inst) => ({
  name: inst.name.split(" ")[0],
  collections: inst.collections / 100000,
  revenue: inst.erpRevenue / 1000,
}))

export function RevenueByInstitute() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="space-y-6">
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Top Institutes by Collection</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            {mounted ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
                <XAxis dataKey="name" stroke="#6b7280" fontSize={12} />
                <YAxis stroke="#6b7280" fontSize={12} yAxisId="left" tickFormatter={(v) => `₹${v}L`} />
                <YAxis
                  stroke="#6b7280"
                  fontSize={12}
                  yAxisId="right"
                  orientation="right"
                  tickFormatter={(v) => `₹${v}K`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e1e2e",
                    border: "1px solid #2a2a3e",
                    borderRadius: "8px",
                  }}
                />
                <Bar yAxisId="left" dataKey="collections" name="Collections (L)" fill="#22c55e" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="right" dataKey="revenue" name="ERP Revenue (K)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center">
                <div className="animate-pulse bg-secondary rounded h-full w-full" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Institute-wise Revenue Details</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Search institutes..." className="w-64 bg-secondary pl-10" />
              </div>
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institute</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Collections</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Transactions</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">ERP Revenue</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Growth</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {instituteData.map((institute) => (
                  <tr key={institute.name} className="border-b border-border hover:bg-secondary/30 transition-colors">
                    <td className="p-4">
                      <span className="font-medium">{institute.name}</span>
                    </td>
                    <td className="p-4">
                      <span className="font-semibold">₹{(institute.collections / 100000).toFixed(2)} L</span>
                    </td>
                    <td className="p-4">
                      <span className="text-muted-foreground">{institute.transactions.toLocaleString()}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-primary font-medium">₹{(institute.erpRevenue / 1000).toFixed(1)}K</span>
                    </td>
                    <td className="p-4">
                      <div
                        className={`flex items-center gap-1 ${institute.growth >= 0 ? "text-success" : "text-destructive"}`}
                      >
                        {institute.growth >= 0 ? (
                          <ArrowUpRight className="h-4 w-4" />
                        ) : (
                          <ArrowDownRight className="h-4 w-4" />
                        )}
                        {Math.abs(institute.growth)}%
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                        {institute.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
