"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

const feeData = [
  { gateway: "Razorpay", gatewayFee: 2.0, platformFee: 0.5, total: 2.5 },
  { gateway: "Cashfree", gatewayFee: 1.9, platformFee: 0.5, total: 2.4 },
  { gateway: "Easebuzz", gatewayFee: 1.8, platformFee: 0.5, total: 2.3 },
  { gateway: "Paytm", gatewayFee: 2.1, platformFee: 0.5, total: 2.6 },
  { gateway: "NTT Atom", gatewayFee: 1.85, platformFee: 0.5, total: 2.35 },
  { gateway: "Worldline", gatewayFee: 1.95, platformFee: 0.5, total: 2.45 },
]

interface FeeAnalyticsProps {
  fullWidth?: boolean
}

export function FeeAnalytics({ fullWidth }: FeeAnalyticsProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <Card className={`bg-card border-border ${fullWidth ? "" : ""}`}>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Fee Structure by Gateway</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          {mounted ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={feeData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
              <XAxis type="number" stroke="#6b7280" fontSize={12} tickFormatter={(v) => `${v}%`} />
              <YAxis type="category" dataKey="gateway" stroke="#6b7280" fontSize={12} width={80} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1e1e2e",
                  border: "1px solid #2a2a3e",
                  borderRadius: "8px",
                }}
                formatter={(value: number) => [`${value}%`, ""]}
              />
              <Legend />
              <Bar dataKey="gatewayFee" name="Gateway Fee" fill="#3b82f6" stackId="a" radius={[0, 0, 0, 0]} />
              <Bar dataKey="platformFee" name="Platform Fee" fill="#22c55e" stackId="a" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center">
              <div className="animate-pulse bg-secondary rounded h-full w-full" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
