"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Bar,
  BarChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Line,
  LineChart,
  Legend,
} from "recharts"

const gatewayData = [
  {
    name: "Razorpay",
    volume: 42000000,
    transactions: 42156,
    successRate: 98.7,
    avgTime: "2.1s",
    color: "#22c55e",
  },
  {
    name: "Cashfree",
    volume: 31000000,
    transactions: 31245,
    successRate: 97.9,
    avgTime: "2.3s",
    color: "#3b82f6",
  },
  {
    name: "Easebuzz",
    volume: 24000000,
    transactions: 24891,
    successRate: 97.2,
    avgTime: "2.5s",
    color: "#eab308",
  },
  {
    name: "Paytm",
    volume: 15000000,
    transactions: 15234,
    successRate: 96.5,
    avgTime: "2.8s",
    color: "#a855f7",
  },
  {
    name: "NTT Atom",
    volume: 8500000,
    transactions: 8520,
    successRate: 97.8,
    avgTime: "2.4s",
    color: "#f97316",
  },
  {
    name: "Worldline",
    volume: 3500000,
    transactions: 2521,
    successRate: 98.1,
    avgTime: "2.2s",
    color: "#06b6d4",
  },
]

const hourlyVolume = [
  { time: "00:00", razorpay: 120, cashfree: 80, easebuzz: 60, paytm: 40 },
  { time: "04:00", razorpay: 80, cashfree: 50, easebuzz: 40, paytm: 25 },
  { time: "08:00", razorpay: 450, cashfree: 320, easebuzz: 280, paytm: 180 },
  { time: "12:00", razorpay: 680, cashfree: 520, easebuzz: 420, paytm: 320 },
  { time: "16:00", razorpay: 720, cashfree: 580, easebuzz: 480, paytm: 380 },
  { time: "20:00", razorpay: 380, cashfree: 280, easebuzz: 220, paytm: 160 },
]

export function GatewayComparison() {
  const [mounted, setMounted] = useState(false)
  const totalVolume = gatewayData.reduce((sum, g) => sum + g.volume, 0)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Volume Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              {mounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={gatewayData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
                  <XAxis dataKey="name" stroke="#6b7280" fontSize={12} />
                  <YAxis stroke="#6b7280" fontSize={12} tickFormatter={(v) => `₹${(v / 10000000).toFixed(0)}Cr`} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e1e2e",
                      border: "1px solid #2a2a3e",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => [`₹${(value / 100000).toFixed(2)}L`, "Volume"]}
                  />
                  <Bar dataKey="volume" fill="#22c55e" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <div className="animate-pulse bg-secondary rounded h-full w-full" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Hourly Transaction Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              {mounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={hourlyVolume}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
                  <XAxis dataKey="time" stroke="#6b7280" fontSize={12} />
                  <YAxis stroke="#6b7280" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1e1e2e",
                      border: "1px solid #2a2a3e",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="razorpay" stroke="#22c55e" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="cashfree" stroke="#3b82f6" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="easebuzz" stroke="#eab308" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="paytm" stroke="#a855f7" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <div className="animate-pulse bg-secondary rounded h-full w-full" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Gateway Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {gatewayData.map((gateway) => (
              <div key={gateway.name} className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: gateway.color }} />
                    <span className="font-medium">{gateway.name}</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-muted-foreground">
                      ₹{(gateway.volume / 10000000).toFixed(1)} Cr ({((gateway.volume / totalVolume) * 100).toFixed(1)}
                      %)
                    </span>
                    <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                      {gateway.successRate}% success
                    </Badge>
                    <span className="text-muted-foreground">{gateway.avgTime} avg</span>
                  </div>
                </div>
                <Progress value={(gateway.volume / totalVolume) * 100} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
