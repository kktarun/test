"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SplitPaymentStats } from "./split-payment-stats"
import { SplitPaymentFilters } from "./split-payment-filters"
import { SplitPaymentsTable } from "./split-payments-table"
import { SplitSettlementsTab } from "../settlements/split-settlements-tab"
import { CreditCard, Landmark } from "lucide-react"

export function SplitPaymentsContent() {
  const [activeTab, setActiveTab] = useState("transactions")
  const [filters, setFilters] = useState({
    gateway: "all",
    status: "all",
    vendor: "all",
  })

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-bold">Split Payments</h1>
        <p className="text-muted-foreground">View transaction splits across multiple vendors and accounts</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-secondary/50">
          <TabsTrigger value="transactions" className="gap-2">
            <CreditCard className="h-4 w-4" />
            Transactions
          </TabsTrigger>
          <TabsTrigger value="settlements" className="gap-2">
            <Landmark className="h-4 w-4" />
            Settlements
          </TabsTrigger>
        </TabsList>

        <TabsContent value="transactions" className="space-y-6">
          <SplitPaymentStats />
          <SplitPaymentFilters filters={filters} onFilterChange={setFilters} />
          <SplitPaymentsTable filters={filters} />
        </TabsContent>

        <TabsContent value="settlements" className="space-y-6">
          <SplitSettlementsTab />
        </TabsContent>
      </Tabs>
    </div>
  )
}
