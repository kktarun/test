"use client"

import { useState } from "react"
import {
  Search,
  MessageSquare,
  Mail,
  Phone,
  Send,
  Paperclip,
  MoreVertical,
  Star,
  Archive,
  CheckCheck,
  Filter,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

interface Conversation {
  id: string
  sender: string
  avatar: string
  channel: string
  lastMessage: string
  time: string
  unread: boolean
  starred: boolean
  studentName: string
  class: string
}

const conversations: Conversation[] = [
  {
    id: "C001",
    sender: "Anita Patel",
    avatar: "AP",
    channel: "WhatsApp",
    lastMessage: "Thanks for the reminder. Will pay by tomorrow.",
    time: "2 min ago",
    unread: true,
    starred: false,
    studentName: "Riya Patel",
    class: "Class 10-A",
  },
  {
    id: "C002",
    sender: "Rajesh Kumar",
    avatar: "RK",
    channel: "WhatsApp",
    lastMessage: "Is there any discount for early payment?",
    time: "15 min ago",
    unread: true,
    starred: true,
    studentName: "Arjun Kumar",
    class: "Class 8-B",
  },
  {
    id: "C003",
    sender: "Priya Sharma",
    avatar: "PS",
    channel: "SMS",
    lastMessage: "Payment done. Receipt no. REC-2026-4521",
    time: "1h ago",
    unread: false,
    starred: false,
    studentName: "Ishaan Sharma",
    class: "Class 12-Sci",
  },
  {
    id: "C004",
    sender: "Sneha Reddy",
    avatar: "SR",
    channel: "Email",
    lastMessage: "Can you share the fee breakdown for 2026-27?",
    time: "2h ago",
    unread: true,
    starred: false,
    studentName: "Tanvi Reddy",
    class: "Class 5-A",
  },
  {
    id: "C005",
    sender: "Vikram Singh",
    avatar: "VS",
    channel: "WhatsApp",
    lastMessage: "Please update the transport route for next month",
    time: "4h ago",
    unread: false,
    starred: true,
    studentName: "Aarav Singh",
    class: "Class 6-C",
  },
  {
    id: "C006",
    sender: "Meera Iyer",
    avatar: "MI",
    channel: "WhatsApp",
    lastMessage: "Got the receipt. Thanks!",
    time: "Yesterday",
    unread: false,
    starred: false,
    studentName: "Kavya Iyer",
    class: "Class 9-A",
  },
  {
    id: "C007",
    sender: "Amit Mehta",
    avatar: "AM",
    channel: "SMS",
    lastMessage: "When is the next installment due?",
    time: "Yesterday",
    unread: false,
    starred: false,
    studentName: "Neha Mehta",
    class: "Class 11-Com",
  },
]

const messagesForC001 = [
  {
    id: "M1",
    text: "Dear Anita, this is a gentle reminder that the fee of ₹45,000 for Riya Patel (Class 10-A) is due on 25-Jan-2026.",
    time: "Yesterday, 10:00 AM",
    sender: "us",
  },
  {
    id: "M2",
    text: "Hello, I wanted to know if I can pay in two installments?",
    time: "Yesterday, 11:30 AM",
    sender: "them",
  },
  {
    id: "M3",
    text: "Yes, we offer installment options. You can pay 50% now and the balance by 15-Feb. Would you like us to set that up?",
    time: "Yesterday, 2:45 PM",
    sender: "us",
  },
  {
    id: "M4",
    text: "Thanks for the reminder. Will pay by tomorrow.",
    time: "2 min ago",
    sender: "them",
  },
]

export function InboxContent() {
  const [search, setSearch] = useState("")
  const [selectedId, setSelectedId] = useState<string>("C001")
  const [tab, setTab] = useState("all")
  const [reply, setReply] = useState("")

  const filtered = conversations.filter((c) => {
    const matchesSearch =
      c.sender.toLowerCase().includes(search.toLowerCase()) ||
      c.studentName.toLowerCase().includes(search.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(search.toLowerCase())
    const matchesTab =
      tab === "all" ||
      (tab === "unread" && c.unread) ||
      (tab === "starred" && c.starred) ||
      (tab === "whatsapp" && c.channel === "WhatsApp") ||
      (tab === "sms" && c.channel === "SMS") ||
      (tab === "email" && c.channel === "Email")
    return matchesSearch && matchesTab
  })

  const selected = conversations.find((c) => c.id === selectedId)

  const getChannelIcon = (channel: string) => {
    if (channel === "WhatsApp") return MessageSquare
    if (channel === "SMS") return Phone
    return Mail
  }

  return (
    <div className="flex-1 overflow-hidden">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="border-b border-border p-6 pb-0">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-semibold">Inbox</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Incoming replies and conversations across all channels.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline">
                <CheckCheck className="h-4 w-4 mr-2" />
                Mark All Read
              </Button>
            </div>
          </div>
        </div>

        {/* Split View */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-[340px_1fr] overflow-hidden">
          {/* Conversation List */}
          <div className="border-r border-border overflow-hidden flex flex-col">
            <div className="p-4 space-y-3 border-b border-border">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search conversations..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 h-9"
                />
              </div>
              <Tabs value={tab} onValueChange={setTab}>
                <TabsList className="h-8 w-full grid grid-cols-3">
                  <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                  <TabsTrigger value="unread" className="text-xs">
                    Unread ({conversations.filter((c) => c.unread).length})
                  </TabsTrigger>
                  <TabsTrigger value="starred" className="text-xs">Starred</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            <div className="flex-1 overflow-y-auto">
              {filtered.map((conv) => {
                const ChannelIcon = getChannelIcon(conv.channel)
                return (
                  <button
                    key={conv.id}
                    onClick={() => setSelectedId(conv.id)}
                    className={`w-full text-left p-3 border-b border-border hover:bg-secondary/50 transition-colors ${
                      selectedId === conv.id ? "bg-secondary" : ""
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="relative flex-shrink-0">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="text-xs">{conv.avatar}</AvatarFallback>
                        </Avatar>
                        <div className="absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full bg-background border border-border flex items-center justify-center">
                          <ChannelIcon className="h-2.5 w-2.5" />
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-0.5">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <p className={`text-sm truncate ${conv.unread ? "font-semibold" : "font-medium"}`}>
                              {conv.sender}
                            </p>
                            {conv.starred && <Star className="h-3 w-3 fill-chart-4 text-chart-4 flex-shrink-0" />}
                          </div>
                          <span className="text-[10px] text-muted-foreground flex-shrink-0 ml-2">
                            {conv.time}
                          </span>
                        </div>
                        <p className="text-[11px] text-muted-foreground mb-1">
                          {conv.studentName} • {conv.class}
                        </p>
                        <p
                          className={`text-xs truncate ${
                            conv.unread ? "text-foreground font-medium" : "text-muted-foreground"
                          }`}
                        >
                          {conv.lastMessage}
                        </p>
                      </div>
                      {conv.unread && (
                        <div className="h-2 w-2 rounded-full bg-primary flex-shrink-0 mt-2"></div>
                      )}
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Conversation View */}
          {selected ? (
            <div className="flex flex-col overflow-hidden">
              {/* Conv Header */}
              <div className="border-b border-border p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="text-xs">{selected.avatar}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-semibold">{selected.sender}</p>
                      <Badge variant="outline" className="text-[10px]">
                        {selected.channel}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {selected.studentName} • {selected.class}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="sm">
                    <Star className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Archive className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-secondary/20">
                {messagesForC001.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender === "us" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[70%] rounded-2xl p-3 ${
                        msg.sender === "us"
                          ? "bg-primary text-primary-foreground rounded-br-sm"
                          : "bg-card border border-border rounded-bl-sm"
                      }`}
                    >
                      <p className="text-sm leading-relaxed">{msg.text}</p>
                      <p
                        className={`text-[10px] mt-1 ${
                          msg.sender === "us"
                            ? "text-primary-foreground/70"
                            : "text-muted-foreground"
                        }`}
                      >
                        {msg.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Reply */}
              <div className="border-t border-border p-4">
                <div className="flex items-end gap-2">
                  <Button variant="ghost" size="sm">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Textarea
                    placeholder={`Reply via ${selected.channel}...`}
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    rows={1}
                    className="min-h-[40px] max-h-32 resize-none"
                  />
                  <Button disabled={!reply.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-2">
                  Replies are sent via {selected.channel} • Templates available in message box
                </p>
              </div>
            </div>
          ) : (
            <Card className="m-6 flex items-center justify-center">
              <CardContent className="text-center py-12">
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                <p className="text-sm text-muted-foreground">Select a conversation to start replying</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
