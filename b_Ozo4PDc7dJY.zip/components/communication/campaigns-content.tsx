"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  Plus,
  MessageSquare,
  Mail,
  Phone,
  Calendar,
  Users,
  CheckCircle2,
  Clock,
  XCircle,
  Play,
  MoreVertical,
  TrendingUp,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"

const campaigns = [
  {
    id: "CMP-2026-015",
    name: "Q4 Fee Reminder - Class 10",
    channel: "WhatsApp",
    audience: "Class 10 - Overdue",
    audienceCount: 420,
    sent: 420,
    delivered: 418,
    opened: 385,
    clicked: 142,
    status: "Completed",
    scheduledAt: "2026-01-22T10:00:00",
    createdBy: "Rajesh Kumar",
  },
  {
    id: "CMP-2026-014",
    name: "Scholarship Application Open",
    channel: "Email",
    audience: "All Students",
    audienceCount: 2450,
    sent: 2450,
    delivered: 2423,
    opened: 1852,
    clicked: 624,
    status: "Completed",
    scheduledAt: "2026-01-20T09:00:00",
    createdBy: "Priya Sharma",
  },
  {
    id: "CMP-2026-013",
    name: "PTM Invitation - Feb 15",
    channel: "SMS",
    audience: "Parents - Class 9 to 12",
    audienceCount: 1820,
    sent: 0,
    delivered: 0,
    opened: 0,
    clicked: 0,
    status: "Scheduled",
    scheduledAt: "2026-02-10T14:00:00",
    createdBy: "Admin",
  },
  {
    id: "CMP-2026-012",
    name: "Transport Fee Deadline Reminder",
    channel: "WhatsApp",
    audience: "Bus Route Users - Unpaid",
    audienceCount: 320,
    sent: 320,
    delivered: 318,
    opened: 298,
    clicked: 215,
    status: "Completed",
    scheduledAt: "2026-01-18T16:30:00",
    createdBy: "Anjali Mehta",
  },
  {
    id: "CMP-2026-011",
    name: "Exam Fee Collection Notice",
    channel: "SMS",
    audience: "Class 9-12",
    audienceCount: 1250,
    sent: 1250,
    delivered: 1242,
    opened: 1180,
    clicked: 420,
    status: "Completed",
    scheduledAt: "2026-01-15T08:00:00",
    createdBy: "Rajesh Kumar",
  },
  {
    id: "CMP-2026-010",
    name: "Welcome to New Academic Year",
    channel: "Email",
    audience: "All Parents",
    audienceCount: 3200,
    sent: 1600,
    delivered: 1582,
    opened: 0,
    clicked: 0,
    status: "Sending",
    scheduledAt: "2026-01-22T14:00:00",
    createdBy: "Admin",
  },
  {
    id: "CMP-2026-009",
    name: "Late Fee Notice - Jan",
    channel: "WhatsApp",
    audience: "Overdue Students",
    audienceCount: 180,
    sent: 0,
    delivered: 0,
    opened: 0,
    clicked: 0,
    status: "Draft",
    scheduledAt: "",
    createdBy: "Priya Sharma",
  },
]

const stats = [
  { label: "Total Campaigns", value: "48", icon: MessageSquare },
  { label: "Scheduled", value: "6", icon: Calendar },
  { label: "Sent This Month", value: "42,850", icon: TrendingUp },
  { label: "Avg. Open Rate", value: "76.8%", icon: CheckCircle2 },
]

export function CampaignsContent() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [channelFilter, setChannelFilter] = useState("all")
  const [tab, setTab] = useState("all")
  const [createOpen, setCreateOpen] = useState(false)

  const filtered = campaigns.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.id.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = statusFilter === "all" || c.status === statusFilter
    const matchesChannel = channelFilter === "all" || c.channel === channelFilter
    const matchesTab =
      tab === "all" ||
      (tab === "sent" && c.status === "Completed") ||
      (tab === "scheduled" && c.status === "Scheduled") ||
      (tab === "draft" && c.status === "Draft") ||
      (tab === "sending" && c.status === "Sending")
    return matchesSearch && matchesStatus && matchesChannel && matchesTab
  })

  const getChannelIcon = (channel: string) => {
    if (channel === "WhatsApp") return MessageSquare
    if (channel === "SMS") return Phone
    return Mail
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      Completed: "bg-chart-2/10 text-chart-2 border-chart-2/20",
      Scheduled: "bg-chart-1/10 text-chart-1 border-chart-1/20",
      Sending: "bg-chart-3/10 text-chart-3 border-chart-3/20",
      Draft: "bg-muted text-muted-foreground border-border",
      Failed: "bg-destructive/10 text-destructive border-destructive/20",
    }
    return styles[status] || styles.Draft
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Campaigns</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Create and manage bulk messaging campaigns across SMS, WhatsApp, and Email.
            </p>
          </div>
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Campaign
          </Button>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-5 flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <stat.icon className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="text-xl font-semibold">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4 space-y-4">
            <Tabs value={tab} onValueChange={setTab}>
              <TabsList>
                <TabsTrigger value="all">All ({campaigns.length})</TabsTrigger>
                <TabsTrigger value="sent">
                  Sent ({campaigns.filter((c) => c.status === "Completed").length})
                </TabsTrigger>
                <TabsTrigger value="scheduled">
                  Scheduled ({campaigns.filter((c) => c.status === "Scheduled").length})
                </TabsTrigger>
                <TabsTrigger value="sending">
                  Sending ({campaigns.filter((c) => c.status === "Sending").length})
                </TabsTrigger>
                <TabsTrigger value="draft">
                  Drafts ({campaigns.filter((c) => c.status === "Draft").length})
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search campaigns..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={channelFilter} onValueChange={setChannelFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Channels</SelectItem>
                  <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                  <SelectItem value="SMS">SMS</SelectItem>
                  <SelectItem value="Email">Email</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Completed">Completed</SelectItem>
                  <SelectItem value="Scheduled">Scheduled</SelectItem>
                  <SelectItem value="Sending">Sending</SelectItem>
                  <SelectItem value="Draft">Draft</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                More Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Campaigns List */}
        <div className="space-y-3">
          {filtered.map((campaign) => {
            const ChannelIcon = getChannelIcon(campaign.channel)
            const deliveryRate =
              campaign.sent > 0 ? ((campaign.delivered / campaign.sent) * 100).toFixed(1) : "0"
            const openRate =
              campaign.delivered > 0 ? ((campaign.opened / campaign.delivered) * 100).toFixed(1) : "0"
            const progress =
              campaign.audienceCount > 0 ? (campaign.sent / campaign.audienceCount) * 100 : 0

            return (
              <Card key={campaign.id} className="hover:shadow-sm transition-shadow">
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <div className="h-11 w-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <ChannelIcon className="h-5 w-5 text-primary" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold truncate">{campaign.name}</h3>
                        <Badge variant="outline" className={`${getStatusBadge(campaign.status)} text-[10px]`}>
                          {campaign.status}
                        </Badge>
                        <Badge variant="outline" className="text-[10px]">
                          {campaign.channel}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="font-mono">{campaign.id}</span>
                        <div className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          <span>{campaign.audience}</span>
                        </div>
                        <span>•</span>
                        <span>by {campaign.createdBy}</span>
                      </div>

                      {campaign.status === "Sending" && (
                        <div className="mt-3">
                          <div className="flex items-center justify-between text-[11px] mb-1">
                            <span className="text-muted-foreground">
                              {campaign.sent.toLocaleString()} / {campaign.audienceCount.toLocaleString()} sent
                            </span>
                            <span className="font-medium">{progress.toFixed(0)}%</span>
                          </div>
                          <Progress value={progress} className="h-1.5" />
                        </div>
                      )}

                      {campaign.status === "Completed" && (
                        <div className="mt-3 grid grid-cols-4 gap-4">
                          <div>
                            <p className="text-[10px] text-muted-foreground uppercase">Sent</p>
                            <p className="text-sm font-semibold">{campaign.sent.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-muted-foreground uppercase">Delivered</p>
                            <p className="text-sm font-semibold text-chart-2">{deliveryRate}%</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-muted-foreground uppercase">Opened</p>
                            <p className="text-sm font-semibold text-chart-1">{openRate}%</p>
                          </div>
                          <div>
                            <p className="text-[10px] text-muted-foreground uppercase">Clicked</p>
                            <p className="text-sm font-semibold text-chart-3">
                              {campaign.clicked.toLocaleString()}
                            </p>
                          </div>
                        </div>
                      )}

                      {campaign.status === "Scheduled" && (
                        <div className="mt-2 flex items-center gap-2 text-xs">
                          <Clock className="h-3.5 w-3.5 text-chart-1" />
                          <span className="text-chart-1 font-medium">
                            Scheduled for {new Date(campaign.scheduledAt).toLocaleString("en-IN", {
                              day: "2-digit",
                              month: "short",
                              year: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </span>
                          <span className="text-muted-foreground">
                            • {campaign.audienceCount.toLocaleString()} recipients
                          </span>
                        </div>
                      )}

                      {campaign.status === "Draft" && (
                        <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                          <XCircle className="h-3.5 w-3.5" />
                          <span>Not yet scheduled • {campaign.audienceCount} recipients</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0">
                      {campaign.status === "Draft" && (
                        <Button size="sm" variant="outline">
                          <Play className="h-3.5 w-3.5 mr-1.5" />
                          Launch
                        </Button>
                      )}
                      {campaign.status === "Completed" && (
                        <Button size="sm" variant="outline">
                          View Report
                        </Button>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>Duplicate</DropdownMenuItem>
                          <DropdownMenuItem>Edit</DropdownMenuItem>
                          <DropdownMenuItem>Export Report</DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>New Campaign</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Campaign Name</Label>
              <Input placeholder="e.g., February Fee Reminder" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Channel</Label>
                <Select defaultValue="whatsapp">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                    <SelectItem value="sms">SMS</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Audience</Label>
                <Select defaultValue="all">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Parents</SelectItem>
                    <SelectItem value="overdue">Overdue Students</SelectItem>
                    <SelectItem value="class-10">Class 10</SelectItem>
                    <SelectItem value="transport">Transport Users</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Message</Label>
              <Textarea
                placeholder="Enter your message. Use {{name}}, {{amount}}, {{due_date}} for personalization."
                rows={5}
              />
              <p className="text-xs text-muted-foreground">
                Available variables: {"{{name}}, {{amount}}, {{due_date}}, {{class}}, {{roll_no}}"}
              </p>
            </div>
            <div className="space-y-2">
              <Label>Schedule</Label>
              <Select defaultValue="now">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="now">Send Immediately</SelectItem>
                  <SelectItem value="schedule">Schedule for Later</SelectItem>
                  <SelectItem value="draft">Save as Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setCreateOpen(false)}>Create Campaign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
