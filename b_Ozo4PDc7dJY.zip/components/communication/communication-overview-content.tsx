"use client"

import { useState } from "react"
import Link from "next/link"
import {
  MessageSquare,
  Mail,
  Phone,
  Send,
  TrendingUp,
  Users,
  Eye,
  MousePointerClick,
  ArrowUpRight,
  Plus,
  FileText,
  Inbox,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

const deliveryData = [
  { day: "Mon", sms: 2450, email: 1823, whatsapp: 3201 },
  { day: "Tue", sms: 2180, email: 1950, whatsapp: 3450 },
  { day: "Wed", sms: 2780, email: 2100, whatsapp: 3820 },
  { day: "Thu", sms: 2340, email: 2250, whatsapp: 3680 },
  { day: "Fri", sms: 3120, email: 2400, whatsapp: 4200 },
  { day: "Sat", sms: 1850, email: 1450, whatsapp: 2900 },
  { day: "Sun", sms: 1420, email: 980, whatsapp: 2150 },
]

const engagementData = [
  { week: "W1", openRate: 68, clickRate: 24, replyRate: 8 },
  { week: "W2", openRate: 72, clickRate: 28, replyRate: 12 },
  { week: "W3", openRate: 75, clickRate: 31, replyRate: 14 },
  { week: "W4", openRate: 78, clickRate: 34, replyRate: 16 },
]

const recentCampaigns = [
  {
    id: "CMP-2026-012",
    name: "Q4 Fee Reminder - Class 10",
    channel: "WhatsApp",
    sent: 420,
    delivered: 418,
    opened: 385,
    status: "Completed",
    sentAt: "2h ago",
  },
  {
    id: "CMP-2026-011",
    name: "Exam Fee Due Notification",
    channel: "SMS",
    sent: 1250,
    delivered: 1242,
    opened: 1180,
    status: "Completed",
    sentAt: "5h ago",
  },
  {
    id: "CMP-2026-010",
    name: "Transport Fee Late Payment",
    channel: "Email",
    sent: 342,
    delivered: 339,
    opened: 268,
    status: "Completed",
    sentAt: "Yesterday",
  },
  {
    id: "CMP-2026-009",
    name: "Scholarship Application Reminder",
    channel: "WhatsApp",
    sent: 180,
    delivered: 180,
    opened: 156,
    status: "Completed",
    sentAt: "Yesterday",
  },
]

export function CommunicationOverviewContent() {
  const [period, setPeriod] = useState("7d")

  const stats = [
    {
      label: "Messages Sent",
      value: "42,850",
      change: "+18.2%",
      positive: true,
      icon: Send,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Delivery Rate",
      value: "99.2%",
      change: "+0.4%",
      positive: true,
      icon: TrendingUp,
      color: "text-chart-2",
      bg: "bg-chart-2/10",
    },
    {
      label: "Open Rate",
      value: "76.8%",
      change: "+5.1%",
      positive: true,
      icon: Eye,
      color: "text-chart-1",
      bg: "bg-chart-1/10",
    },
    {
      label: "Click-Through Rate",
      value: "32.4%",
      change: "+2.3%",
      positive: true,
      icon: MousePointerClick,
      color: "text-chart-3",
      bg: "bg-chart-3/10",
    },
  ]

  const channels = [
    {
      name: "WhatsApp",
      icon: MessageSquare,
      count: "23,401",
      percentage: 55,
      color: "bg-chart-2",
      textColor: "text-chart-2",
      cost: "₹0.15 / msg",
    },
    {
      name: "SMS",
      icon: Phone,
      count: "14,140",
      percentage: 33,
      color: "bg-chart-1",
      textColor: "text-chart-1",
      cost: "₹0.25 / msg",
    },
    {
      name: "Email",
      icon: Mail,
      count: "12,953",
      percentage: 12,
      color: "bg-chart-3",
      textColor: "text-chart-3",
      cost: "₹0.05 / msg",
    },
  ]

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Communication Center</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Send fee reminders, announcements, and payment updates to parents and students.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/communication/templates">
              <Button variant="outline">
                <FileText className="h-4 w-4 mr-2" />
                Templates
              </Button>
            </Link>
            <Link href="/communication/campaigns">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Campaign
              </Button>
            </Link>
          </div>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${stat.bg}`}>
                    <stat.icon className={`h-4 w-4 ${stat.color}`} />
                  </div>
                  <span
                    className={`text-xs font-medium ${
                      stat.positive ? "text-chart-2" : "text-destructive"
                    }`}
                  >
                    {stat.change}
                  </span>
                </div>
                <p className="text-2xl font-semibold">{stat.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Delivery Trend */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">Messages Delivered (7 days)</CardTitle>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Daily breakdown by channel
                  </p>
                </div>
                <div className="flex items-center gap-1 border border-border rounded-md p-0.5">
                  {["7d", "30d", "90d"].map((p) => (
                    <button
                      key={p}
                      onClick={() => setPeriod(p)}
                      className={`px-2 py-1 text-xs rounded ${
                        period === p ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={deliveryData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                  <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="whatsapp" stackId="a" fill="hsl(var(--chart-2))" name="WhatsApp" />
                  <Bar dataKey="sms" stackId="a" fill="hsl(var(--chart-1))" name="SMS" />
                  <Bar dataKey="email" stackId="a" fill="hsl(var(--chart-3))" name="Email" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Channel Split */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Channel Distribution</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {channels.map((ch) => (
                <div key={ch.name}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${ch.color}/10`}>
                        <ch.icon className={`h-4 w-4 ${ch.textColor}`} />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{ch.name}</p>
                        <p className="text-[10px] text-muted-foreground">{ch.cost}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{ch.count}</p>
                      <p className="text-[10px] text-muted-foreground">{ch.percentage}%</p>
                    </div>
                  </div>
                  <Progress value={ch.percentage} className="h-1.5" />
                </div>
              ))}

              <div className="pt-3 border-t border-border">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Total cost this month</span>
                  <span className="font-semibold">₹8,425</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Engagement Metrics */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Engagement Trends (4 weeks)</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              Track open rate, click rate, and reply rate over time
            </p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" unit="%" />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="openRate"
                  stroke="hsl(var(--chart-1))"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  name="Open Rate"
                />
                <Line
                  type="monotone"
                  dataKey="clickRate"
                  stroke="hsl(var(--chart-2))"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  name="Click Rate"
                />
                <Line
                  type="monotone"
                  dataKey="replyRate"
                  stroke="hsl(var(--chart-3))"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  name="Reply Rate"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Quick Actions & Recent Campaigns */}
        <div className="grid gap-6 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/communication/campaigns" className="block">
                <div className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Send className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Send Fee Reminder</p>
                    <p className="text-[11px] text-muted-foreground">Bulk SMS/WhatsApp to parents</p>
                  </div>
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
              <Link href="/communication/templates" className="block">
                <div className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors">
                  <div className="h-10 w-10 rounded-lg bg-chart-2/10 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-chart-2" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Create Template</p>
                    <p className="text-[11px] text-muted-foreground">Reusable message templates</p>
                  </div>
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
              <Link href="/communication/inbox" className="block">
                <div className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors">
                  <div className="h-10 w-10 rounded-lg bg-chart-3/10 flex items-center justify-center">
                    <Inbox className="h-5 w-5 text-chart-3" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">View Replies</p>
                    <p className="text-[11px] text-muted-foreground">Inbox with 12 unread</p>
                  </div>
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </Link>
              <div className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors cursor-pointer">
                <div className="h-10 w-10 rounded-lg bg-chart-4/10 flex items-center justify-center">
                  <Users className="h-5 w-5 text-chart-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Create Audience</p>
                  <p className="text-[11px] text-muted-foreground">Segment by class, overdue, etc.</p>
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Recent Campaigns</CardTitle>
                <Link href="/communication/campaigns">
                  <Button variant="ghost" size="sm">
                    View All
                    <ArrowUpRight className="h-3.5 w-3.5 ml-1" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentCampaigns.map((campaign) => {
                  const openRate = ((campaign.opened / campaign.delivered) * 100).toFixed(1)
                  const ChannelIcon =
                    campaign.channel === "WhatsApp"
                      ? MessageSquare
                      : campaign.channel === "SMS"
                      ? Phone
                      : Mail
                  return (
                    <div
                      key={campaign.id}
                      className="flex items-center gap-4 p-3 rounded-lg border border-border hover:bg-secondary/30 transition-colors"
                    >
                      <div className="h-9 w-9 rounded-lg bg-secondary flex items-center justify-center">
                        <ChannelIcon className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium truncate">{campaign.name}</p>
                          <Badge variant="outline" className="text-[10px]">
                            {campaign.channel}
                          </Badge>
                        </div>
                        <p className="text-[11px] text-muted-foreground font-mono">
                          {campaign.id} • {campaign.sentAt}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold">{campaign.sent.toLocaleString()}</p>
                        <p className="text-[10px] text-muted-foreground">sent</p>
                      </div>
                      <div className="text-right w-20">
                        <p className="text-sm font-semibold text-chart-2">{openRate}%</p>
                        <p className="text-[10px] text-muted-foreground">opened</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
