"use client"

import { useState } from "react"
import {
  Plus,
  Search,
  Copy,
  Edit,
  Trash2,
  MessageSquare,
  Mail,
  Phone,
  CheckCircle2,
  Clock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const templates = [
  {
    id: "TPL-001",
    name: "Fee Reminder - First Notice",
    channel: "WhatsApp",
    category: "Fee Reminder",
    content:
      "Dear {{parent_name}}, this is a gentle reminder that the fee of ₹{{amount}} for {{student_name}} (Class {{class}}) is due on {{due_date}}. Please pay at: {{payment_link}}",
    approved: true,
    usage: 42,
    lastUsed: "2 days ago",
  },
  {
    id: "TPL-002",
    name: "Fee Reminder - Overdue",
    channel: "SMS",
    category: "Fee Reminder",
    content:
      "URGENT: Fee of Rs.{{amount}} for {{student_name}} is overdue by {{days_overdue}} days. Pay now to avoid late fee: {{payment_link}} -Delhi Public School",
    approved: true,
    usage: 28,
    lastUsed: "1 day ago",
  },
  {
    id: "TPL-003",
    name: "Payment Confirmation",
    channel: "WhatsApp",
    category: "Transactional",
    content:
      "Payment received! ✓ Receipt: ₹{{amount}} paid for {{student_name}} on {{date}}. Receipt No: {{receipt_no}}. Thank you!",
    approved: true,
    usage: 1250,
    lastUsed: "Just now",
  },
  {
    id: "TPL-004",
    name: "PTM Invitation",
    channel: "Email",
    category: "Announcement",
    content:
      "Dear {{parent_name}}, we cordially invite you for the Parent-Teacher Meeting scheduled on {{date}} at {{time}}. Your presence is appreciated.",
    approved: true,
    usage: 8,
    lastUsed: "15 days ago",
  },
  {
    id: "TPL-005",
    name: "Exam Fee Collection",
    channel: "SMS",
    category: "Fee Reminder",
    content:
      "Dear Parent, exam fee of Rs.{{amount}} for {{student_name}} (Class {{class}}) is due on {{due_date}}. -DPS",
    approved: true,
    usage: 15,
    lastUsed: "10 days ago",
  },
  {
    id: "TPL-006",
    name: "Transport Fee Notice",
    channel: "WhatsApp",
    category: "Fee Reminder",
    content:
      "Dear {{parent_name}}, transport fee of ₹{{amount}} for {{student_name}} is due. Route: {{route}}. Pay before {{due_date}} to avoid service interruption.",
    approved: true,
    usage: 22,
    lastUsed: "5 days ago",
  },
  {
    id: "TPL-007",
    name: "Admission Confirmation",
    channel: "Email",
    category: "Transactional",
    content:
      "Congratulations {{parent_name}}! Admission confirmed for {{student_name}} in Class {{class}}. Admission No: {{adm_no}}. Welcome to Delhi Public School.",
    approved: true,
    usage: 145,
    lastUsed: "1 hour ago",
  },
  {
    id: "TPL-008",
    name: "Holiday Announcement",
    channel: "SMS",
    category: "Announcement",
    content:
      "Dear Parents, school will remain closed on {{date}} for {{reason}}. Classes will resume on {{next_day}}. -DPS",
    approved: false,
    usage: 0,
    lastUsed: "Never",
  },
]

export function TemplatesContent() {
  const [search, setSearch] = useState("")
  const [channelTab, setChannelTab] = useState("all")
  const [createOpen, setCreateOpen] = useState(false)

  const filtered = templates.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.category.toLowerCase().includes(search.toLowerCase())
    const matchesChannel = channelTab === "all" || t.channel.toLowerCase() === channelTab
    return matchesSearch && matchesChannel
  })

  const getChannelIcon = (channel: string) => {
    if (channel === "WhatsApp") return MessageSquare
    if (channel === "SMS") return Phone
    return Mail
  }

  const categoryColors: Record<string, string> = {
    "Fee Reminder": "bg-chart-1/10 text-chart-1 border-chart-1/20",
    Transactional: "bg-chart-2/10 text-chart-2 border-chart-2/20",
    Announcement: "bg-chart-3/10 text-chart-3 border-chart-3/20",
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Message Templates</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Create reusable message templates with dynamic variables for faster campaigns.
            </p>
          </div>
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Template
          </Button>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-5">
              <p className="text-xs text-muted-foreground">Total Templates</p>
              <p className="text-2xl font-semibold">{templates.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <p className="text-xs text-muted-foreground">WhatsApp</p>
              <p className="text-2xl font-semibold">
                {templates.filter((t) => t.channel === "WhatsApp").length}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <p className="text-xs text-muted-foreground">Pending Approval</p>
              <p className="text-2xl font-semibold text-chart-5">
                {templates.filter((t) => !t.approved).length}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <p className="text-xs text-muted-foreground">Most Used</p>
              <p className="text-2xl font-semibold">1,250</p>
              <p className="text-[11px] text-muted-foreground">Payment Confirmation</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4 space-y-4">
            <Tabs value={channelTab} onValueChange={setChannelTab}>
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
                <TabsTrigger value="sms">SMS</TabsTrigger>
                <TabsTrigger value="email">Email</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search templates..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
          </CardContent>
        </Card>

        {/* Templates Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((template) => {
            const ChannelIcon = getChannelIcon(template.channel)
            return (
              <Card key={template.id} className="flex flex-col">
                <CardContent className="p-5 flex-1 flex flex-col">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
                        <ChannelIcon className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{template.name}</p>
                        <p className="text-[10px] text-muted-foreground font-mono">{template.id}</p>
                      </div>
                    </div>
                    {template.approved ? (
                      <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2/20 text-[10px]">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Approved
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="bg-chart-5/10 text-chart-5 border-chart-5/20 text-[10px]">
                        <Clock className="h-3 w-3 mr-1" />
                        Pending
                      </Badge>
                    )}
                  </div>

                  <Badge
                    variant="outline"
                    className={`${categoryColors[template.category]} text-[10px] mb-3 self-start`}
                  >
                    {template.category}
                  </Badge>

                  <div className="bg-secondary/50 rounded-lg p-3 mb-3 flex-1 border border-border">
                    <p className="text-xs leading-relaxed whitespace-pre-wrap">{template.content}</p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-3">
                    <span>Used {template.usage} times</span>
                    <span>Last: {template.lastUsed}</span>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Edit className="h-3.5 w-3.5 mr-1" />
                      Edit
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <Copy className="h-3.5 w-3.5 mr-1" />
                      Clone
                    </Button>
                    <Button size="sm" variant="outline">
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>New Template</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Template Name</Label>
                <Input placeholder="e.g., Fee Reminder First Notice" />
              </div>
              <div className="space-y-2">
                <Label>Channel</Label>
                <Select defaultValue="whatsapp">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                    <SelectItem value="sms">SMS</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select defaultValue="fee-reminder">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fee-reminder">Fee Reminder</SelectItem>
                  <SelectItem value="transactional">Transactional</SelectItem>
                  <SelectItem value="announcement">Announcement</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Message Content</Label>
              <Textarea
                placeholder="Dear {{parent_name}}, ..."
                rows={6}
              />
              <p className="text-xs text-muted-foreground">
                Variables: {"{{parent_name}}, {{student_name}}, {{amount}}, {{due_date}}, {{class}}, {{payment_link}}"}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => setCreateOpen(false)}>Submit for Approval</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
