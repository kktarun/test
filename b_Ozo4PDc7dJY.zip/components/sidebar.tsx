"use client"

import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  ArrowLeftRight,
  Wallet,
  RotateCcw,
  AlertTriangle,
  SplitSquareHorizontal,
  FileText,
  CreditCard,
  Settings,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  Repeat,
  Receipt,
  Users,
  BookOpen,
  Link2,
  Bell,
  Users2,
  Layers,
  Clock,
  Percent,
  Truck,
  TrendingUp,
  RotateCw,
  Landmark,
  Smartphone,
  QrCode,
  Plug,
  Building2,
  UserCog,
  Mail,
  Upload,
  Database,
  CheckCircle2,
  Banknote,
  GitBranch,
  LineChart,
  CircleDollarSign,
  Briefcase,
  ShieldCheck,
  ClipboardList,
  FileSpreadsheet,
  LifeBuoy,
  MessageSquare,
  Megaphone,
  Send,
  Activity,
  PiggyBank,
  Sparkles,
  HandCoins,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { merchantInstitute } from "@/lib/shared-data"

const administrationNav = [
  { name: "Fee Dashboard", href: "/fees", icon: Receipt },
  { name: "Collect Now", href: "/fees/collect", icon: CreditCard },
  { name: "Students", href: "/fees/students", icon: Users },
  { name: "Student Groups", href: "/fees/student-groups", icon: Users2 },
  { name: "Fee Structure", href: "/fees/structure", icon: BookOpen },
  { name: "Fee Heads", href: "/fees/fee-heads", icon: Layers },
  { name: "Previous Dues", href: "/fees/previous-dues", icon: Clock },
  { name: "Scholarships", href: "/fees/scholarships", icon: Percent },
  { name: "Transport Slabs", href: "/fees/transport-slabs", icon: Truck },
]

const paymentOrchestrationNav = [
  { name: "Transactions", href: "/transactions", icon: ArrowLeftRight },
  { name: "Settlements", href: "/settlements", icon: Wallet },
  { name: "Refunds", href: "/refunds", icon: RotateCcw },
  { name: "Chargebacks", href: "/chargebacks", icon: AlertTriangle },
  { name: "Split Payments", href: "/split-payments", icon: SplitSquareHorizontal },
]

const collectionNav = [
  { name: "Payment Links", href: "/fees/payment-links", icon: Link2 },
  { name: "Reminders", href: "/fees/reminders", icon: Bell },
  { name: "Auto-Debit", href: "/auto-debit", icon: Repeat },
]

const treasuryNav = [
  { name: "Treasury Overview", href: "/treasury", icon: PiggyBank },
  { name: "Bank Accounts", href: "/treasury/accounts", icon: Banknote },
  { name: "Cash Flow", href: "/treasury/cash-flow", icon: LineChart },
  { name: "Reconciliation", href: "/treasury/reconciliation", icon: Activity },
  { name: "Allocation Rules", href: "/treasury/allocation", icon: GitBranch },
]

const payrollNav = [
  { name: "Payroll Dashboard", href: "/payroll", icon: CircleDollarSign },
  { name: "Employees", href: "/payroll/employees", icon: Briefcase },
  { name: "Payroll Runs", href: "/payroll/runs", icon: ClipboardList },
  { name: "Compliance", href: "/payroll/compliance", icon: ShieldCheck },
  { name: "GST", href: "/payroll/gst", icon: FileSpreadsheet },
]

const financingNav = [
  { name: "Financing Overview", href: "/financing", icon: TrendingUp },
  { name: "Applications", href: "/financing/applications", icon: CheckCircle2 },
  { name: "Finance Partners", href: "/financing/partners", icon: HandCoins },
  { name: "Eligibility Engine", href: "/financing/eligibility", icon: Sparkles },
]

const communicationsNav = [
  { name: "Communication Hub", href: "/communications", icon: Megaphone },
  { name: "Templates", href: "/communications/templates", icon: FileText },
  { name: "Campaigns", href: "/communications/campaigns", icon: Send },
  { name: "Delivery Logs", href: "/communications/logs", icon: ClipboardList },
]

const supportNav = [
  { name: "Support Tickets", href: "/support", icon: LifeBuoy },
  { name: "New Ticket", href: "/support/new", icon: MessageSquare },
]

const reconcialiationNav = [{ name: "Reconciliation", href: "/reconciliation", icon: RotateCw }]

const reportsNav = [{ name: "Reports", href: "/reports", icon: FileText }]

const systemNav = [
  { name: "Classes & Divisions", href: "/system/classes", icon: Database },
  { name: "Bank Accounts", href: "/system/bank-accounts", icon: Landmark },
  { name: "Payment Gateways", href: "/system/gateways", icon: BarChart3 },
  { name: "POS Machines", href: "/pos-devices", icon: Smartphone },
  { name: "Dynamic QR", href: "/system/dynamic-qr", icon: QrCode },
  { name: "Integrations", href: "/system/integrations", icon: Plug },
]

const instituteNav = [
  { name: "Institute Info", href: "/institute", icon: Building2 },
  { name: "Users", href: "/users", icon: UserCog },
  { name: "Notifications", href: "/notifications", icon: Mail },
  { name: "Bulk Upload", href: "/bulk-upload", icon: Upload },
  { name: "Settings", href: "/settings", icon: Settings },
]

interface SidebarProps {
  collapsed: boolean
  onToggle: () => void
}

interface NavItem {
  name: string
  href: string
  icon: typeof LayoutDashboard
}

function NavSection({
  title,
  items,
  collapsed,
  pathname,
}: {
  title: string
  items: NavItem[]
  collapsed: boolean
  pathname: string
}) {
  return (
    <>
      {!collapsed && (
        <div className="mb-2 mt-4 px-3 pt-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50">{title}</span>
        </div>
      )}
      {collapsed && <div className="my-2 border-t border-sidebar-border" />}
      <div className="space-y-1">
        {items.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/")
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
              )}
            >
              <item.icon className="h-5 w-5 shrink-0" />
              {!collapsed && <span>{item.name}</span>}
            </Link>
          )
        })}
      </div>
    </>
  )
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const pathname = usePathname()

  return (
    <aside
      className={cn(
        "flex flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-4">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <span className="text-sm font-bold text-primary-foreground">CN</span>
            </div>
            <span className="font-semibold text-sidebar-foreground">ClearN</span>
          </div>
        )}
        <button
          onClick={onToggle}
          className="flex h-8 w-8 items-center justify-center rounded-md text-sidebar-foreground hover:bg-sidebar-accent"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto p-2">
        {/* Dashboard */}
        {!collapsed && (
          <div className="mb-2 px-3 pt-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/50">
              Dashboard
            </span>
          </div>
        )}
        <div className="space-y-1">
          <Link
            href="/"
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
              pathname === "/"
                ? "bg-sidebar-accent text-sidebar-primary"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
            )}
          >
            <LayoutDashboard className="h-5 w-5 shrink-0" />
            {!collapsed && <span>Dashboard</span>}
          </Link>
        </div>

        <NavSection title="Fee Management" items={administrationNav} collapsed={collapsed} pathname={pathname} />
        <NavSection
          title="Payment Orchestration"
          items={paymentOrchestrationNav}
          collapsed={collapsed}
          pathname={pathname}
        />
        <NavSection title="Collection" items={collectionNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Treasury" items={treasuryNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Payroll & Compliance" items={payrollNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Financing" items={financingNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Communications" items={communicationsNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Support" items={supportNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Reconciliation" items={reconcialiationNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Reports" items={reportsNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="System" items={systemNav} collapsed={collapsed} pathname={pathname} />
        <NavSection title="Institute" items={instituteNav} collapsed={collapsed} pathname={pathname} />
      </nav>

      {!collapsed && (
        <div className="border-t border-sidebar-border p-4">
          <div className="rounded-lg bg-sidebar-accent p-3">
            <p className="text-xs font-medium text-sidebar-foreground">Financial Infrastructure</p>
            <p className="text-sm font-semibold text-sidebar-primary">{merchantInstitute.name}</p>
            <p className="mt-1 text-xs text-sidebar-foreground/60">Institute ID: {merchantInstitute.code}</p>
          </div>
        </div>
      )}
    </aside>
  )
}
