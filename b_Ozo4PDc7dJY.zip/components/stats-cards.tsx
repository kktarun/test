"use client"

import { Card, CardContent } from "@/components/ui/card"
import { ArrowUpRight, ArrowDownRight, IndianRupee, ArrowLeftRight, Users, Percent } from "lucide-react"
import { getDashboardStats } from "@/lib/shared-data"

const formatCurrency = (amount: number) => {
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(2)} Cr`
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(1)} L`
  if (amount >= 1000) return `₹${(amount / 1000).toFixed(1)} K`
  return `₹${amount}`
}

export function StatsCards() {
  const dashboardStats = getDashboardStats()
  
  const stats = [
    {
      name: "Total Collections",
      value: formatCurrency(dashboardStats.totalCollections),
      change: "+12.5%",
      trend: "up" as const,
      icon: IndianRupee,
      subtitle: "This month",
    },
    {
      name: "Transactions",
      value: dashboardStats.totalTransactions.toLocaleString(),
      change: "+8.2%",
      trend: "up" as const,
      icon: ArrowLeftRight,
      subtitle: "This month",
    },
    {
      name: "Active Students",
      value: dashboardStats.activeStudents.toLocaleString(),
      change: `+${Math.floor(dashboardStats.activeStudents * 0.1)}`,
      trend: "up" as const,
      icon: Users,
      subtitle: "Paying this month",
    },
    {
      name: "Success Rate",
      value: `${dashboardStats.successRate}%`,
      change: dashboardStats.successRate >= 95 ? "+0.5%" : "-0.2%",
      trend: dashboardStats.successRate >= 95 ? "up" as const : "down" as const,
      icon: Percent,
      subtitle: "Across all gateways",
    },
  ]
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.name} className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <stat.icon className="h-5 w-5 text-primary" />
              </div>
              <div
                className={`flex items-center gap-1 text-sm font-medium ${
                  stat.trend === "up" ? "text-success" : "text-destructive"
                }`}
              >
                {stat.change}
                {stat.trend === "up" ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
              </div>
            </div>
            <div className="mt-4">
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm font-medium text-foreground/90">{stat.name}</p>
              <p className="text-xs text-muted-foreground">{stat.subtitle}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
