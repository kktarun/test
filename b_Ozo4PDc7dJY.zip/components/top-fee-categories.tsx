"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, BookOpen, Bus, Home, Beaker, Trophy, GraduationCap, Library } from "lucide-react"
import { getFeeTypeStats } from "@/lib/shared-data"

const iconMap: Record<string, React.ElementType> = {
  "Tuition Fee": BookOpen,
  "Transport Fee": Bus,
  "Hostel Fee": Home,
  "Annual Fee": GraduationCap,
  "Lab Fee": Beaker,
  "Sports Fee": Trophy,
  "Library Fee": Library,
  "Exam Fee": GraduationCap,
  "Admission Fee": GraduationCap,
  "Term Fee": BookOpen,
}

const formatCurrency = (amount: number) => {
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(1)} Cr`
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(1)} L`
  if (amount >= 1000) return `₹${(amount / 1000).toFixed(1)} K`
  return `₹${amount}`
}

const feeStats = getFeeTypeStats()

export function TopFeeCategories() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Fee Category Breakdown</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {feeStats.slice(0, 5).map((category) => {
          const Icon = iconMap[category.feeType] || BookOpen
          return (
            <div
              key={category.feeType}
              className="flex items-center gap-3 rounded-lg border border-border bg-secondary/30 p-3"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                <Icon className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{category.feeType}</p>
                <p className="text-xs text-muted-foreground">{category.count} txns</p>
              </div>
              <div className="text-right">
                <p className="font-semibold">{formatCurrency(category.amount)}</p>
                <div className="flex items-center justify-end gap-1 text-xs text-success">
                  <TrendingUp className="h-3 w-3" />
                  +{Math.floor(Math.random() * 15 + 5)}%
                </div>
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
