"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import {
  Building2,
  MapPin,
  Phone,
  Mail,
  Globe,
  Upload,
  CreditCard,
  Banknote,
  Shield,
  FileText,
  CheckCircle2,
  Clock,
  AlertCircle,
  IndianRupee,
  Smartphone,
  QrCode,
  Landmark,
  Save,
  Image as ImageIcon,
} from "lucide-react"

const paymentGateways = [
  { id: "razorpay", name: "Razorpay", status: "active", logo: "R" },
  { id: "paytm", name: "Paytm", status: "pending", logo: "P" },
  { id: "phonepe", name: "PhonePe", status: "inactive", logo: "Ph" },
  { id: "billdesk", name: "BillDesk", status: "inactive", logo: "B" },
]

const paymentMethods = [
  { id: "upi", name: "UPI", icon: Smartphone, enabled: true },
  { id: "cards", name: "Credit/Debit Cards", icon: CreditCard, enabled: true },
  { id: "netbanking", name: "Net Banking", icon: Landmark, enabled: true },
  { id: "wallet", name: "Wallets", icon: Banknote, enabled: false },
  { id: "qr", name: "Dynamic QR", icon: QrCode, enabled: true },
]

export function InstituteInfoContent() {
  const [instituteData, setInstituteData] = useState({
    name: "Delhi Public School",
    shortName: "DPS",
    code: "DPS-DEL-001",
    type: "school",
    board: "CBSE",
    email: "admin@dpsdelhi.edu.in",
    phone: "+91 11 2634 5678",
    website: "https://dpsdelhi.edu.in",
    address: "Mathura Road, New Delhi",
    city: "New Delhi",
    state: "Delhi",
    pincode: "110003",
    gstNumber: "07AABCD1234E1Z5",
    panNumber: "AABCD1234E",
  })

  const [bankDetails, setBankDetails] = useState({
    accountName: "Delhi Public School Society",
    accountNumber: "1234567890123456",
    ifscCode: "HDFC0001234",
    bankName: "HDFC Bank",
    branch: "Connaught Place, New Delhi",
  })

  const [enabledMethods, setEnabledMethods] = useState<Record<string, boolean>>({
    upi: true,
    cards: true,
    netbanking: true,
    wallet: false,
    qr: true,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Institute Settings</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your institute profile, payment settings, and integrations
          </p>
        </div>
        <Button>
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </Button>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="bank">Bank Account</TabsTrigger>
          <TabsTrigger value="payment">Payment Gateways</TabsTrigger>
          <TabsTrigger value="branding">Branding</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                Institute Information
              </CardTitle>
              <CardDescription>
                Basic information about your educational institute
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Institute Name</Label>
                  <Input
                    id="name"
                    value={instituteData.name}
                    onChange={(e) => setInstituteData({ ...instituteData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="shortName">Short Name</Label>
                  <Input
                    id="shortName"
                    value={instituteData.shortName}
                    onChange={(e) => setInstituteData({ ...instituteData, shortName: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="code">Institute Code</Label>
                  <Input
                    id="code"
                    value={instituteData.code}
                    onChange={(e) => setInstituteData({ ...instituteData, code: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="type">Institute Type</Label>
                  <Select value={instituteData.type} onValueChange={(value) => setInstituteData({ ...instituteData, type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="school">School</SelectItem>
                      <SelectItem value="college">College</SelectItem>
                      <SelectItem value="university">University</SelectItem>
                      <SelectItem value="coaching">Coaching Institute</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="board">Board/Affiliation</Label>
                  <Select value={instituteData.board} onValueChange={(value) => setInstituteData({ ...instituteData, board: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="CBSE">CBSE</SelectItem>
                      <SelectItem value="ICSE">ICSE</SelectItem>
                      <SelectItem value="State">State Board</SelectItem>
                      <SelectItem value="IB">IB</SelectItem>
                      <SelectItem value="Cambridge">Cambridge</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      className="pl-10"
                      value={instituteData.email}
                      onChange={(e) => setInstituteData({ ...instituteData, email: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="phone"
                      className="pl-10"
                      value={instituteData.phone}
                      onChange={(e) => setInstituteData({ ...instituteData, phone: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="website">Website</Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="website"
                      className="pl-10"
                      value={instituteData.website}
                      onChange={(e) => setInstituteData({ ...instituteData, website: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Textarea
                      id="address"
                      className="pl-10 min-h-[80px]"
                      value={instituteData.address}
                      onChange={(e) => setInstituteData({ ...instituteData, address: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={instituteData.city}
                    onChange={(e) => setInstituteData({ ...instituteData, city: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Input
                    id="state"
                    value={instituteData.state}
                    onChange={(e) => setInstituteData({ ...instituteData, state: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pincode">PIN Code</Label>
                  <Input
                    id="pincode"
                    value={instituteData.pincode}
                    onChange={(e) => setInstituteData({ ...instituteData, pincode: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bank" className="space-y-6">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Landmark className="h-5 w-5 text-primary" />
                Bank Account Details
              </CardTitle>
              <CardDescription>
                Configure the bank account for receiving fee settlements
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-3 p-4 bg-success/10 border border-success/20 rounded-lg">
                <CheckCircle2 className="h-5 w-5 text-success" />
                <div>
                  <p className="text-sm font-medium text-foreground">Bank Account Verified</p>
                  <p className="text-xs text-muted-foreground">Last verified on March 1, 2026</p>
                </div>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="accountName">Account Holder Name</Label>
                  <Input
                    id="accountName"
                    value={bankDetails.accountName}
                    onChange={(e) => setBankDetails({ ...bankDetails, accountName: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="accountNumber">Account Number</Label>
                  <Input
                    id="accountNumber"
                    value={bankDetails.accountNumber}
                    onChange={(e) => setBankDetails({ ...bankDetails, accountNumber: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ifscCode">IFSC Code</Label>
                  <Input
                    id="ifscCode"
                    value={bankDetails.ifscCode}
                    onChange={(e) => setBankDetails({ ...bankDetails, ifscCode: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bankName">Bank Name</Label>
                  <Input
                    id="bankName"
                    value={bankDetails.bankName}
                    onChange={(e) => setBankDetails({ ...bankDetails, bankName: e.target.value })}
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="branch">Branch</Label>
                  <Input
                    id="branch"
                    value={bankDetails.branch}
                    onChange={(e) => setBankDetails({ ...bankDetails, branch: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                <AlertCircle className="h-5 w-5 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Changing bank account details requires re-verification and may take 2-3 business days.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Settlement Schedule</CardTitle>
              <CardDescription>
                Configure when collected fees are settled to your bank account
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="p-4 border rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">T+1 Settlement</span>
                    <Badge variant="default">Active</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Funds settle next business day
                  </p>
                </div>
                <div className="p-4 border rounded-lg space-y-2 opacity-50">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">T+2 Settlement</span>
                    <Badge variant="secondary">Available</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Lower transaction fees
                  </p>
                </div>
                <div className="p-4 border rounded-lg space-y-2 opacity-50">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Instant Settlement</span>
                    <Badge variant="outline">Premium</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Real-time fund transfer
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment" className="space-y-6">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-primary" />
                Payment Gateways
              </CardTitle>
              <CardDescription>
                Manage your payment gateway integrations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {paymentGateways.map((gateway) => (
                  <div
                    key={gateway.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-semibold">
                        {gateway.logo}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{gateway.name}</p>
                        <p className="text-xs text-muted-foreground capitalize">{gateway.status}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {gateway.status === "active" ? (
                        <Badge className="bg-success/10 text-success hover:bg-success/20 border-0">
                          <CheckCircle2 className="mr-1 h-3 w-3" />
                          Active
                        </Badge>
                      ) : gateway.status === "pending" ? (
                        <Badge variant="secondary" className="bg-warning/10 text-warning-foreground">
                          <Clock className="mr-1 h-3 w-3" />
                          Pending
                        </Badge>
                      ) : (
                        <Button variant="outline" size="sm">
                          Connect
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Payment Methods</CardTitle>
              <CardDescription>
                Enable or disable payment methods for fee collection
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                        <method.icon className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{method.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {enabledMethods[method.id] ? "Enabled for all transactions" : "Currently disabled"}
                        </p>
                      </div>
                    </div>
                    <Switch
                      checked={enabledMethods[method.id]}
                      onCheckedChange={(checked) =>
                        setEnabledMethods({ ...enabledMethods, [method.id]: checked })
                      }
                    />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Transaction Limits</CardTitle>
              <CardDescription>
                Set minimum and maximum transaction amounts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Minimum Transaction Amount</Label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input className="pl-10" defaultValue="100" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Maximum Transaction Amount</Label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input className="pl-10" defaultValue="500000" />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="branding" className="space-y-6">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <ImageIcon className="h-5 w-5 text-primary" />
                Logo & Branding
              </CardTitle>
              <CardDescription>
                Customize the appearance of payment pages and receipts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  <Label>Institute Logo</Label>
                  <div className="border-2 border-dashed rounded-lg p-8 text-center">
                    <div className="mx-auto h-16 w-16 rounded-lg bg-muted flex items-center justify-center mb-4">
                      <Building2 className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <Button variant="outline" size="sm">
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Logo
                    </Button>
                    <p className="text-xs text-muted-foreground mt-2">
                      PNG, JPG up to 2MB. Recommended: 200x200px
                    </p>
                  </div>
                </div>
                <div className="space-y-4">
                  <Label>Favicon</Label>
                  <div className="border-2 border-dashed rounded-lg p-8 text-center">
                    <div className="mx-auto h-16 w-16 rounded-lg bg-muted flex items-center justify-center mb-4">
                      <Globe className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <Button variant="outline" size="sm">
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Favicon
                    </Button>
                    <p className="text-xs text-muted-foreground mt-2">
                      ICO or PNG, 32x32px recommended
                    </p>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <Label>Brand Colors</Label>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Primary Color</Label>
                    <div className="flex gap-2">
                      <div className="h-10 w-10 rounded-lg bg-primary border" />
                      <Input defaultValue="#6366f1" className="font-mono" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs text-muted-foreground">Accent Color</Label>
                    <div className="flex gap-2">
                      <div className="h-10 w-10 rounded-lg bg-success border" />
                      <Input defaultValue="#22c55e" className="font-mono" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Receipt Customization</CardTitle>
              <CardDescription>
                Configure the appearance of payment receipts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Receipt Header Text</Label>
                <Textarea
                  placeholder="Add custom header text for receipts..."
                  defaultValue="Thank you for your payment. This is an official receipt from Delhi Public School."
                />
              </div>
              <div className="space-y-2">
                <Label>Receipt Footer Text</Label>
                <Textarea
                  placeholder="Add custom footer text for receipts..."
                  defaultValue="For any queries, please contact the accounts department."
                />
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium text-sm">Include QR Code on Receipts</p>
                  <p className="text-xs text-muted-foreground">
                    Add a QR code for receipt verification
                  </p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-6">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Tax & Compliance
              </CardTitle>
              <CardDescription>
                Manage tax registration and compliance documents
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="gst">GST Number</Label>
                  <Input
                    id="gst"
                    value={instituteData.gstNumber}
                    onChange={(e) => setInstituteData({ ...instituteData, gstNumber: e.target.value })}
                  />
                  <p className="text-xs text-muted-foreground">Required for GST invoicing</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pan">PAN Number</Label>
                  <Input
                    id="pan"
                    value={instituteData.panNumber}
                    onChange={(e) => setInstituteData({ ...instituteData, panNumber: e.target.value })}
                  />
                  <p className="text-xs text-muted-foreground">Required for TDS compliance</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <Label>Uploaded Documents</Label>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">GST Certificate</p>
                        <p className="text-xs text-muted-foreground">Uploaded on Jan 15, 2026</p>
                      </div>
                    </div>
                    <Badge className="bg-success/10 text-success hover:bg-success/20 border-0">
                      Verified
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">PAN Card</p>
                        <p className="text-xs text-muted-foreground">Uploaded on Jan 15, 2026</p>
                      </div>
                    </div>
                    <Badge className="bg-success/10 text-success hover:bg-success/20 border-0">
                      Verified
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Trust Deed / Registration</p>
                        <p className="text-xs text-muted-foreground">Uploaded on Jan 15, 2026</p>
                      </div>
                    </div>
                    <Badge className="bg-success/10 text-success hover:bg-success/20 border-0">
                      Verified
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 border-2 border-dashed rounded-lg">
                    <div className="flex items-center gap-3">
                      <Upload className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm font-medium">Add Document</p>
                        <p className="text-xs text-muted-foreground">Upload additional documents</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Upload</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">80G / 12A Exemption</CardTitle>
              <CardDescription>
                Tax exemption certificate details for donors
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium text-sm">80G Exemption Status</p>
                  <p className="text-xs text-muted-foreground">
                    Donations to your institute are tax-exempt under Section 80G
                  </p>
                </div>
                <Badge className="bg-success/10 text-success hover:bg-success/20 border-0">
                  Active
                </Badge>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>80G Registration Number</Label>
                  <Input defaultValue="CIT(E)/80G/2024-25/A/12345" />
                </div>
                <div className="space-y-2">
                  <Label>Valid Until</Label>
                  <Input defaultValue="March 31, 2029" disabled />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
