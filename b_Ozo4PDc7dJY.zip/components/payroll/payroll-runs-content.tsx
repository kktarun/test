"use client"

import { useState } from "react"
import {
  Play,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Download,
  Search,
  Calendar,
  Users,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

type RunStatus = "draft" | "pending_approval" | "approved" | "disbursed" | "failed"

interface PayrollRun {
  id: string
  period: string
  employees: number
  gross: number
  net: number
  deductions: number
  status: RunStatus
  processedOn?: string
  disbursedOn?: string
  approvedBy?: string
  failures?: number
}

const runs: PayrollRun[] = [
  {
    id: "PR-2026-04",
    period: "April 2026",
    employees: 142,
    gross: 5380000,
    net: 4540000,
    deductions: 840000,
    status: "pending_approval",
    processedOn: "2026-04-22",
    approvedBy: "Priya Sharma (Finance)",
  },
  {
    id: "PR-2026-03",
    period: "March 2026",
    employees: 140,
    gross: 5240000,
    net: 4430000,
    deductions: 810000,
    status: "disbursed",
    processedOn: "2026-03-24",
    disbursedOn: "2026-03-28",
    approvedBy: "Director",
  },
  {
    id: "PR-2026-02",
    period: "February 2026",
    employees: 138,
    gross: 5080000,
    net: 4300000,
    deductions: 780000,
    status: "disbursed",
    processedOn: "2026-02-25",
    disbursedOn: "2026-02-28",
    approvedBy: "Director",
    failures: 2,
  },
  {
    id: "PR-2026-01",
    period: "January 2026",
    employees: 138,
    gross: 5020000,
    net: 4260000,
    deductions: 760000,
    status: "disbursed",
    processedOn: "2026-01-26",
    disbursedOn: "2026-01-30",
    approvedBy: "Director",
  },
  {
    id: "PR-2025-12",
    period: "December 2025",
    employees: 136,
    gross: 4920000,
    net: 4180000,
    deductions: 740000,
    status: "disbursed",
    processedOn: "2025-12-24",
    disbursedOn: "2025-12-30",
    approvedBy: "Director",
  },
]

const statusConfig: Record<RunStatus, { label: string; color: string; icon: typeof Clock }> = {
  draft: { label: "Draft", color: "secondary", icon: FileText },
  pending_approval: { label: "Pending approval", color: "default", icon: Clock },
  approved: { label: "Approved", color: "default", icon: CheckCircle2 },
  disbursed: { label: "Disbursed", color: "default", icon: CheckCircle2 },
  failed: { label: "Failed", color: "destructive", icon: AlertTriangle },
}

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)}Cr`
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)}L`
  return `₹${n.toLocaleString("en-IN")}`
}

export function PayrollRunsContent() {
  const [search, setSearch] = useState("")

  const filtered = runs.filter(
    (r) => r.period.toLowerCase().includes(search.toLowerCase()) || r.id.toLowerCase().includes(search.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Payroll Runs</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Every historical and active payroll cycle with full approval trail.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Download register
          </Button>
          <Button size="sm">
            <Play className="mr-2 h-4 w-4" />
            Start new run
          </Button>
        </div>
      </div>

      {/* Active run highlight */}
      <Card className="relative overflow-hidden border-primary/20">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent" />
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <Badge variant="default">Active cycle</Badge>
              <CardTitle className="mt-2 text-xl">April 2026 Payroll</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                142 employees processed &middot; Awaiting final approval before bank disbursement on Apr 28
              </p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline">
                <FileText className="mr-2 h-4 w-4" />
                Review payslips
              </Button>
              <Button size="sm">Approve &amp; disburse</Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-4">
            <div className="rounded-lg border border-border bg-card p-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Users className="h-3.5 w-3.5" />
                Employees
              </div>
              <p className="mt-1 text-xl font-semibold">142</p>
            </div>
            <div className="rounded-lg border border-border bg-card p-3">
              <p className="text-xs text-muted-foreground">Gross</p>
              <p className="mt-1 text-xl font-semibold">{formatINR(5380000)}</p>
            </div>
            <div className="rounded-lg border border-border bg-card p-3">
              <p className="text-xs text-muted-foreground">Deductions</p>
              <p className="mt-1 text-xl font-semibold">{formatINR(840000)}</p>
            </div>
            <div className="rounded-lg border border-border bg-card p-3">
              <p className="text-xs text-muted-foreground">Net disbursement</p>
              <p className="mt-1 text-xl font-semibold text-primary">{formatINR(4540000)}</p>
            </div>
          </div>
          <div className="mt-4">
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Processing progress</span>
              <span className="font-medium">3 of 4 steps</span>
            </div>
            <Progress value={75} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Run history */}
      <Card>
        <div className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search by period or run ID"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            Showing {filtered.length} run{filtered.length !== 1 && "s"}
          </div>
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Run ID / Period</TableHead>
              <TableHead className="text-center">Employees</TableHead>
              <TableHead className="text-right">Gross</TableHead>
              <TableHead className="text-right">Net</TableHead>
              <TableHead>Approved by</TableHead>
              <TableHead>Disbursed on</TableHead>
              <TableHead>Status</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((run) => {
              const cfg = statusConfig[run.status]
              const Icon = cfg.icon
              return (
                <TableRow key={run.id}>
                  <TableCell>
                    <p className="font-medium">{run.period}</p>
                    <p className="font-mono text-xs text-muted-foreground">{run.id}</p>
                  </TableCell>
                  <TableCell className="text-center">
                    <span className="font-medium">{run.employees}</span>
                    {run.failures && (
                      <p className="text-xs text-destructive">{run.failures} failed</p>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-mono">{formatINR(run.gross)}</TableCell>
                  <TableCell className="text-right font-mono font-medium">{formatINR(run.net)}</TableCell>
                  <TableCell className="text-sm">{run.approvedBy || "-"}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{run.disbursedOn || "-"}</TableCell>
                  <TableCell>
                    <Badge variant={cfg.color as any} className="gap-1">
                      <Icon className="h-3 w-3" />
                      {cfg.label}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button size="sm" variant="ghost">
                      <Download className="mr-1.5 h-3.5 w-3.5" />
                      Register
                    </Button>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </Card>
    </div>
  )
}
