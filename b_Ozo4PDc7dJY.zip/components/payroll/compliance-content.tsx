"use client"

import { useState } from "react"
import {
  ShieldCheck,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Calendar,
  Download,
  FileText,
  Bell,
  ArrowUpRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

type ComplianceStatus = "filed" | "pending" | "overdue" | "scheduled"
type Obligation = {
  id: string
  name: string
  category: "TDS" | "PF" | "ESIC" | "PT" | "GST"
  dueDate: string
  amount: number
  status: ComplianceStatus
  period: string
  filingId?: string
}

const obligations: Obligation[] = [
  {
    id: "C001",
    name: "TDS Deposit &mdash; Form 26Q",
    category: "TDS",
    dueDate: "2026-04-30",
    amount: 142000,
    status: "pending",
    period: "Mar 2026",
  },
  {
    id: "C002",
    name: "EPF Monthly Contribution",
    category: "PF",
    dueDate: "2026-04-25",
    amount: 248000,
    status: "pending",
    period: "Mar 2026",
  },
  {
    id: "C003",
    name: "ESIC Monthly Challan",
    category: "ESIC",
    dueDate: "2026-04-25",
    amount: 84000,
    status: "pending",
    period: "Mar 2026",
  },
  {
    id: "C004",
    name: "Professional Tax Return",
    category: "PT",
    dueDate: "2026-04-30",
    amount: 36000,
    status: "scheduled",
    period: "Mar 2026",
  },
  {
    id: "C005",
    name: "TDS Quarterly Return",
    category: "TDS",
    dueDate: "2026-04-15",
    amount: 0,
    status: "overdue",
    period: "Q4 FY26",
  },
  {
    id: "C006",
    name: "TDS Deposit &mdash; Feb 2026",
    category: "TDS",
    dueDate: "2026-03-30",
    amount: 138000,
    status: "filed",
    period: "Feb 2026",
    filingId: "CIN-HDFC26030054812",
  },
  {
    id: "C007",
    name: "EPF Monthly Contribution",
    category: "PF",
    dueDate: "2026-03-25",
    amount: 244000,
    status: "filed",
    period: "Feb 2026",
    filingId: "ECR-26030012198",
  },
  {
    id: "C008",
    name: "ESIC Monthly Challan",
    category: "ESIC",
    dueDate: "2026-03-25",
    amount: 82000,
    status: "filed",
    period: "Feb 2026",
    filingId: "CH-ESIC-26030028",
  },
]

const statusCfg: Record<
  ComplianceStatus,
  { label: string; badge: "default" | "destructive" | "outline" | "secondary"; icon: typeof Clock }
> = {
  filed: { label: "Filed", badge: "default", icon: CheckCircle2 },
  pending: { label: "Pending", badge: "outline", icon: Clock },
  overdue: { label: "Overdue", badge: "destructive", icon: AlertTriangle },
  scheduled: { label: "Scheduled", badge: "secondary", icon: Calendar },
}

const categoryCfg: Record<
  Obligation["category"],
  { color: string; description: string }
> = {
  TDS: { color: "bg-primary/10 text-primary", description: "Income Tax deductions" },
  PF: { color: "bg-info/10 text-info", description: "Provident Fund - EPFO" },
  ESIC: { color: "bg-warning/10 text-warning", description: "Employee State Insurance" },
  PT: { color: "bg-chart-4/10 text-chart-4", description: "Professional Tax (State)" },
  GST: { color: "bg-chart-2/10 text-chart-2", description: "Goods & Services Tax" },
}

function formatINR(n: number) {
  return `₹${n.toLocaleString("en-IN")}`
}

export function ComplianceContent() {
  const [active, setActive] = useState<"all" | "pending" | "filed">("all")

  const counts = {
    total: obligations.length,
    pending: obligations.filter((o) => o.status === "pending").length,
    overdue: obligations.filter((o) => o.status === "overdue").length,
    filed: obligations.filter((o) => o.status === "filed").length,
    scheduled: obligations.filter((o) => o.status === "scheduled").length,
  }
  const complianceScore = Math.round((counts.filed / counts.total) * 100)

  const filtered = obligations.filter((o) => {
    if (active === "pending") return o.status === "pending" || o.status === "overdue" || o.status === "scheduled"
    if (active === "filed") return o.status === "filed"
    return true
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Statutory Compliance</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            TDS, PF, ESIC, Professional Tax and GST filings &mdash; all in one tracker.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Bell className="mr-2 h-4 w-4" />
            Filing reminders
          </Button>
          <Button size="sm">
            <Download className="mr-2 h-4 w-4" />
            Download challans
          </Button>
        </div>
      </div>

      {/* Compliance Score Hero */}
      <Card className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent" />
        <CardContent className="relative pt-6">
          <div className="grid gap-6 md:grid-cols-[1fr_2fr]">
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" />
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Compliance Score</p>
              </div>
              <p className="mt-3 text-5xl font-semibold tracking-tight">{complianceScore}%</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {counts.filed} filings completed out of {counts.total} tracked
              </p>
              <Progress value={complianceScore} className="mt-4 h-2" />
              {counts.overdue > 0 && (
                <Badge variant="destructive" className="mt-3">
                  <AlertTriangle className="mr-1 h-3 w-3" />
                  {counts.overdue} overdue filing{counts.overdue > 1 && "s"}
                </Badge>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {(["TDS", "PF", "ESIC", "PT", "GST"] as const).map((cat) => {
                const items = obligations.filter((o) => o.category === cat)
                const pending = items.filter((o) => o.status !== "filed").length
                const total = items.length
                if (total === 0) return null
                const pct = total ? Math.round(((total - pending) / total) * 100) : 0
                const cfg = categoryCfg[cat]
                return (
                  <div key={cat} className="rounded-lg border border-border bg-card p-4">
                    <div className="flex items-center justify-between">
                      <div className={`rounded px-2 py-0.5 text-xs font-semibold ${cfg.color}`}>{cat}</div>
                      <span className="text-xs text-muted-foreground">{pct}%</span>
                    </div>
                    <p className="mt-3 text-xs text-muted-foreground">{cfg.description}</p>
                    <Progress value={pct} className="mt-2 h-1" />
                  </div>
                )
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={active} onValueChange={(v) => setActive(v as any)}>
        <TabsList>
          <TabsTrigger value="all">All ({counts.total})</TabsTrigger>
          <TabsTrigger value="pending">
            Action needed ({counts.pending + counts.overdue + counts.scheduled})
          </TabsTrigger>
          <TabsTrigger value="filed">Filed ({counts.filed})</TabsTrigger>
        </TabsList>

        <TabsContent value={active} className="mt-4">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Obligation</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead>Due date</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Challan / Ref</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((o) => {
                  const cfg = statusCfg[o.status]
                  const StatusIcon = cfg.icon
                  return (
                    <TableRow key={o.id}>
                      <TableCell>
                        <p
                          className="font-medium"
                          dangerouslySetInnerHTML={{ __html: o.name }}
                        />
                        <p className="font-mono text-xs text-muted-foreground">{o.id}</p>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{o.category}</Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">{o.period}</TableCell>
                      <TableCell>
                        <p className="text-sm">{o.dueDate}</p>
                        {o.status === "overdue" && (
                          <p className="text-xs text-destructive">Overdue by 5 days</p>
                        )}
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        {o.amount > 0 ? formatINR(o.amount) : "-"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={cfg.badge} className="gap-1">
                          <StatusIcon className="h-3 w-3" />
                          {cfg.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {o.filingId || "-"}
                      </TableCell>
                      <TableCell>
                        {o.status === "filed" ? (
                          <Button size="sm" variant="ghost">
                            <Download className="mr-1.5 h-3.5 w-3.5" />
                            Challan
                          </Button>
                        ) : (
                          <Button size="sm" variant={o.status === "overdue" ? "destructive" : "default"}>
                            File now <ArrowUpRight className="ml-1.5 h-3.5 w-3.5" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Upcoming calendar */}
      <Card>
        <CardHeader>
          <CardTitle>Filing Calendar</CardTitle>
          <p className="mt-1 text-sm text-muted-foreground">
            Monthly and quarterly recurring obligations so nothing slips through
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-2">
            {[
              { day: "7th of every month", label: "TDS deposit (challan 281)" },
              { day: "15th of every month", label: "EPF (ECR upload)" },
              { day: "15th of every month", label: "ESIC challan" },
              { day: "20th of every month", label: "GSTR-3B filing" },
              { day: "Last working day", label: "Professional tax (state specific)" },
              { day: "15 Jan / Jul / Oct / Apr", label: "Quarterly TDS return (24Q / 26Q)" },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center gap-3 rounded-lg border border-border p-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.day}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
