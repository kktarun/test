"use client"

import Link from "next/link"
import {
  Users,
  CircleDollarSign,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Calendar,
  TrendingUp,
  ArrowRight,
  Play,
  Download,
  ShieldCheck,
  Wallet,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

const payrollHistory = [
  { month: "Nov 25", gross: 4850000, net: 4120000, tax: 730000 },
  { month: "Dec 25", gross: 4920000, net: 4180000, tax: 740000 },
  { month: "Jan 26", gross: 5020000, net: 4260000, tax: 760000 },
  { month: "Feb 26", gross: 5080000, net: 4300000, tax: 780000 },
  { month: "Mar 26", gross: 5240000, net: 4430000, tax: 810000 },
  { month: "Apr 26", gross: 5380000, net: 4540000, tax: 840000 },
]

const upcomingCompliance = [
  { label: "TDS Deposit (Mar)", due: "2026-04-30", amount: "₹1,42,000", status: "pending", tag: "Statutory" },
  { label: "PF Contribution", due: "2026-04-25", amount: "₹2,48,000", status: "pending", tag: "EPFO" },
  { label: "Professional Tax", due: "2026-04-30", amount: "₹36,000", status: "scheduled", tag: "State" },
  { label: "GSTR-3B", due: "2026-05-20", amount: "₹98,500", status: "scheduled", tag: "GST" },
  { label: "ESIC Contribution", due: "2026-04-25", amount: "₹84,000", status: "pending", tag: "ESIC" },
]

const payrollRunStatus = {
  month: "April 2026",
  status: "ready",
  totalEmployees: 142,
  processed: 0,
  approvedBy: null as string | null,
  grossAmount: 5380000,
  netAmount: 4540000,
  scheduled: "2026-04-28",
}

function formatINR(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)}Cr`
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)}L`
  return `₹${n.toLocaleString("en-IN")}`
}

export function PayrollOverviewContent() {
  const kpis = [
    { label: "Active employees", value: 142, icon: Users, hint: "4 new joiners this month" },
    { label: "Monthly gross", value: formatINR(5380000), icon: CircleDollarSign, hint: "+3.1% MoM" },
    { label: "Next payroll run", value: "Apr 28", icon: Calendar, hint: "142 employees ready" },
    { label: "Compliance score", value: "98%", icon: ShieldCheck, hint: "All filings up to date" },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <Badge variant="outline" className="gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Payroll cycle open
          </Badge>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">Payroll & Compliance</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            End-to-end salary processing, statutory deductions and compliance filings in one place.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link href="/payroll/runs">
              <FileText className="mr-2 h-4 w-4" />
              Run history
            </Link>
          </Button>
          <Button size="sm">
            <Play className="mr-2 h-4 w-4" />
            Start payroll run
          </Button>
        </div>
      </div>

      {/* KPI grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {kpis.map((kpi) => {
          const Icon = kpi.icon
          return (
            <Card key={kpi.label}>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">{kpi.label}</p>
                    <p className="text-2xl font-semibold tracking-tight">{kpi.value}</p>
                  </div>
                </div>
                <p className="mt-3 text-xs text-muted-foreground">{kpi.hint}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Active run + trend */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="relative overflow-hidden lg:col-span-2">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle>Active Payroll Run &mdash; {payrollRunStatus.month}</CardTitle>
                <p className="mt-1 text-sm text-muted-foreground">
                  Scheduled disbursement on {payrollRunStatus.scheduled}. Review and approve to process.
                </p>
              </div>
              <Badge variant="default" className="capitalize">
                {payrollRunStatus.status}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3 md:grid-cols-4">
              <div className="rounded-lg border border-border p-3">
                <p className="text-xs text-muted-foreground">Employees</p>
                <p className="mt-1 text-xl font-semibold">{payrollRunStatus.totalEmployees}</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-xs text-muted-foreground">Gross amount</p>
                <p className="mt-1 text-xl font-semibold">{formatINR(payrollRunStatus.grossAmount)}</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-xs text-muted-foreground">Net disbursement</p>
                <p className="mt-1 text-xl font-semibold text-primary">{formatINR(payrollRunStatus.netAmount)}</p>
              </div>
              <div className="rounded-lg border border-border p-3">
                <p className="text-xs text-muted-foreground">Statutory deduction</p>
                <p className="mt-1 text-xl font-semibold">
                  {formatINR(payrollRunStatus.grossAmount - payrollRunStatus.netAmount)}
                </p>
              </div>
            </div>

            <div className="space-y-3 rounded-lg border border-border p-4">
              <p className="text-sm font-medium">Approval workflow</p>
              <div className="space-y-2">
                {[
                  { step: "Payroll data prepared", done: true, by: "HR System" },
                  { step: "Finance review", done: true, by: "Priya Sharma, CFO" },
                  { step: "Approval from Director", done: false, by: "Pending" },
                  { step: "Bank disbursement", done: false, by: "Scheduled" },
                ].map((s, idx) => (
                  <div key={idx} className="flex items-center gap-3 text-sm">
                    <div
                      className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs ${
                        s.done ? "bg-primary text-primary-foreground" : "border border-border text-muted-foreground"
                      }`}
                    >
                      {s.done ? <CheckCircle2 className="h-3.5 w-3.5" /> : idx + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{s.step}</p>
                      <p className="text-xs text-muted-foreground">{s.by}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button size="sm">Approve run</Button>
              <Button size="sm" variant="outline">
                <FileText className="mr-2 h-4 w-4" />
                View payslips
              </Button>
              <Button size="sm" variant="ghost">
                <Download className="mr-2 h-4 w-4" />
                Export bank file
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payroll Trend</CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">Gross, net and tax over last 6 months</p>
          </CardHeader>
          <CardContent>
            <div className="h-[260px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={payrollHistory}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="month" fontSize={11} tickLine={false} stroke="var(--muted-foreground)" />
                  <YAxis
                    fontSize={11}
                    tickLine={false}
                    stroke="var(--muted-foreground)"
                    tickFormatter={(v) => `${v / 100000}L`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: "var(--radius)",
                      fontSize: "12px",
                    }}
                    formatter={(v: number) => formatINR(v)}
                  />
                  <Bar dataKey="net" name="Net" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="tax" name="Tax" fill="var(--chart-3)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming compliance */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle>Upcoming Compliance</CardTitle>
              <p className="mt-1 text-sm text-muted-foreground">
                Statutory obligations due in the next 30 days &mdash; pay early to avoid penalties
              </p>
            </div>
            <Button size="sm" variant="outline" asChild>
              <Link href="/payroll/compliance">
                View all <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {upcomingCompliance.map((c) => (
              <div key={c.label} className="flex items-center justify-between rounded-lg border border-border p-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                      c.status === "pending" ? "bg-amber-500/10" : "bg-primary/10"
                    }`}
                  >
                    {c.status === "pending" ? (
                      <Clock className="h-5 w-5 text-amber-600" />
                    ) : (
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-medium">{c.label}</p>
                      <Badge variant="outline" className="text-[10px]">
                        {c.tag}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Due {c.due}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <p className="font-mono font-semibold">{c.amount}</p>
                  <Button size="sm" variant={c.status === "pending" ? "default" : "outline"}>
                    {c.status === "pending" ? "Pay now" : "Scheduled"}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
