"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  Upload,
  Download,
  Users,
  Filter,
  MoreVertical,
  Mail,
  Phone,
  Building2,
  Briefcase,
} from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface Employee {
  id: string
  name: string
  role: string
  department: string
  email: string
  phone: string
  gross: number
  status: "active" | "notice" | "on_leave"
  joinDate: string
}

const employees: Employee[] = [
  {
    id: "EMP001",
    name: "Priya Sharma",
    role: "Chief Financial Officer",
    department: "Finance",
    email: "priya.sharma@dpsrkp.edu",
    phone: "+91 98765 43210",
    gross: 185000,
    status: "active",
    joinDate: "2021-06-15",
  },
  {
    id: "EMP002",
    name: "Rahul Verma",
    role: "Principal",
    department: "Academic",
    email: "principal@dpsrkp.edu",
    phone: "+91 98200 11223",
    gross: 220000,
    status: "active",
    joinDate: "2018-04-01",
  },
  {
    id: "EMP003",
    name: "Anjali Gupta",
    role: "Senior Math Teacher",
    department: "Academic",
    email: "anjali.g@dpsrkp.edu",
    phone: "+91 99886 21134",
    gross: 92000,
    status: "active",
    joinDate: "2020-07-10",
  },
  {
    id: "EMP004",
    name: "Vikram Singh",
    role: "Accounts Manager",
    department: "Finance",
    email: "vikram.s@dpsrkp.edu",
    phone: "+91 98111 44566",
    gross: 78000,
    status: "active",
    joinDate: "2022-01-20",
  },
  {
    id: "EMP005",
    name: "Neha Kapoor",
    role: "HR Executive",
    department: "HR",
    email: "neha.k@dpsrkp.edu",
    phone: "+91 98880 22134",
    gross: 62000,
    status: "on_leave",
    joinDate: "2023-03-12",
  },
  {
    id: "EMP006",
    name: "Arjun Mehta",
    role: "IT Infrastructure",
    department: "IT",
    email: "arjun.m@dpsrkp.edu",
    phone: "+91 98890 78542",
    gross: 85000,
    status: "active",
    joinDate: "2021-11-05",
  },
  {
    id: "EMP007",
    name: "Kavita Iyer",
    role: "English Teacher",
    department: "Academic",
    email: "kavita.i@dpsrkp.edu",
    phone: "+91 98890 33441",
    gross: 78000,
    status: "notice",
    joinDate: "2019-08-22",
  },
  {
    id: "EMP008",
    name: "Sanjay Reddy",
    role: "Physical Education",
    department: "Sports",
    email: "sanjay.r@dpsrkp.edu",
    phone: "+91 98880 99211",
    gross: 56000,
    status: "active",
    joinDate: "2020-02-18",
  },
]

function formatINR(n: number) {
  return `₹${n.toLocaleString("en-IN")}`
}

function initials(name: string) {
  return name
    .split(" ")
    .map((x) => x[0])
    .join("")
    .slice(0, 2)
    .toUpperCase()
}

export function EmployeesContent() {
  const [search, setSearch] = useState("")
  const [dept, setDept] = useState("all")
  const [status, setStatus] = useState("all")

  const filtered = employees.filter(
    (e) =>
      (dept === "all" || e.department === dept) &&
      (status === "all" || e.status === status) &&
      (e.name.toLowerCase().includes(search.toLowerCase()) ||
        e.role.toLowerCase().includes(search.toLowerCase()) ||
        e.id.toLowerCase().includes(search.toLowerCase())),
  )

  const totalGross = employees.reduce((a, b) => a + b.gross, 0)
  const deptCount = new Set(employees.map((e) => e.department)).size

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Employees</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Manage your employee master, salary structures and reporting lines.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Upload className="mr-2 h-4 w-4" />
            Bulk import
          </Button>
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Add employee
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Total employees</p>
                <p className="text-2xl font-semibold">{employees.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Building2 className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Departments</p>
                <p className="text-2xl font-semibold">{deptCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Briefcase className="h-5 w-5 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Monthly gross</p>
                <p className="text-2xl font-semibold">{formatINR(totalGross)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs text-muted-foreground">Active</p>
            <p className="mt-1 text-2xl font-semibold text-primary">
              {employees.filter((e) => e.status === "active").length}
            </p>
            <div className="mt-2 flex gap-2 text-xs text-muted-foreground">
              <span>{employees.filter((e) => e.status === "on_leave").length} on leave</span>
              <span>&middot;</span>
              <span>{employees.filter((e) => e.status === "notice").length} on notice</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters + Table */}
      <Card>
        <div className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search name, role or employee ID"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Select value={dept} onValueChange={setDept}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All departments</SelectItem>
                <SelectItem value="Academic">Academic</SelectItem>
                <SelectItem value="Finance">Finance</SelectItem>
                <SelectItem value="HR">HR</SelectItem>
                <SelectItem value="IT">IT</SelectItem>
                <SelectItem value="Sports">Sports</SelectItem>
              </SelectContent>
            </Select>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="on_leave">On leave</SelectItem>
                <SelectItem value="notice">Notice period</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Employee</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead className="text-right">Gross (monthly)</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead className="w-10" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((emp) => (
              <TableRow key={emp.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarFallback className="bg-primary/10 text-xs font-medium text-primary">
                        {initials(emp.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{emp.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {emp.role} &middot; <span className="font-mono">{emp.id}</span>
                      </p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{emp.department}</Badge>
                </TableCell>
                <TableCell>
                  <div className="text-xs">
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <Mail className="h-3 w-3" />
                      <span>{emp.email}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-1 text-muted-foreground">
                      <Phone className="h-3 w-3" />
                      <span>{emp.phone}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-right font-mono font-medium">{formatINR(emp.gross)}</TableCell>
                <TableCell>
                  <Badge
                    variant={
                      emp.status === "active"
                        ? "default"
                        : emp.status === "notice"
                          ? "destructive"
                          : "secondary"
                    }
                  >
                    {emp.status === "on_leave" ? "On leave" : emp.status === "notice" ? "Notice" : "Active"}
                  </Badge>
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">{emp.joinDate}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>View profile</DropdownMenuItem>
                      <DropdownMenuItem>Salary structure</DropdownMenuItem>
                      <DropdownMenuItem>Reimbursements</DropdownMenuItem>
                      <DropdownMenuItem>Download payslips</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">Offboard</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  )
}
