"use client"

import { useState } from "react"
import {
  FileSpreadsheet,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Download,
  Filter,
  Search,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

const gstHistory = [
  { month: "Nov", collected: 142000, paid: 138000, input: 28000 },
  { month: "Dec", collected: 148000, paid: 142000, input: 31000 },
  { month: "Jan", collected: 156000, paid: 148000, input: 34000 },
  { month: "Feb", collected: 162000, paid: 152000, input: 38000 },
  { month: "Mar", collected: 168000, paid: 156000, input: 42000 },
  { month: "Apr", collected: 174000, paid: 0, input: 45000 },
]

const filings = [
  {
    id: "GST001",
    period: "Mar 2026",
    form: "GSTR-3B",
    dueDate: "2026-04-20",
    collected: 168000,
    input: 42000,
    payable: 126000,
    status: "filed",
    arn: "AA072604218529M",
  },
  {
    id: "GST002",
    period: "Mar 2026",
    form: "GSTR-1",
    dueDate: "2026-04-11",
    collected: 168000,
    input: 0,
    payable: 0,
    status: "filed",
    arn: "AA072604115821L",
  },
  {
    id: "GST003",
    period: "Apr 2026",
    form: "GSTR-3B",
    dueDate: "2026-05-20",
    collected: 174000,
    input: 45000,
    payable: 129000,
    status: "pending",
    arn: "-",
  },
  {
    id: "GST004",
    period: "Apr 2026",
    form: "GSTR-1",
    dueDate: "2026-05-11",
    collected: 174000,
    input: 0,
    payable: 0,
    status: "pending",
    arn: "-",
  },
]

const vendors = [
  {
    id: "V001",
    name: "Apollo Stationers",
    gstin: "07AABCA1234F1Z2",
    invoices: 12,
    total: 84000,
    input: 12800,
    reconciled: true,
  },
  {
    id: "V002",
    name: "Sunrise Transport",
    gstin: "07ABCDS5678G2H9",
    invoices: 4,
    total: 280000,
    input: 24000,
    reconciled: true,
  },
  {
    id: "V003",
    name: "Global Labs Supplies",
    gstin: "07AABCA9921K3L7",
    invoices: 8,
    total: 180000,
    input: 16200,
    reconciled: false,
  },
  {
    id: "V004",
    name: "Tech Services Pvt Ltd",
    gstin: "07AABCT7865H2K9",
    invoices: 2,
    total: 45000,
    input: 6750,
    reconciled: true,
  },
]

function formatINR(n: number) {
  return `₹${n.toLocaleString("en-IN")}`
}

export function GstContent() {
  const [search, setSearch] = useState("")

  const filteredVendors = vendors.filter(
    (v) =>
      v.name.toLowerCase().includes(search.toLowerCase()) ||
      v.gstin.toLowerCase().includes(search.toLowerCase()),
  )

  const totalCollected = gstHistory.reduce((a, b) => a + b.collected, 0)
  const totalPaid = gstHistory.reduce((a, b) => a + b.paid, 0)
  const totalInput = gstHistory.reduce((a, b) => a + b.input, 0)
  const currentPayable = 174000 - 45000

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">GST Compliance</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Track GST collected, input credit and monthly filings with automated vendor reconciliation.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export reports
          </Button>
          <Button size="sm">
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            File GSTR-3B
          </Button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-xs font-medium uppercase text-muted-foreground">
              <TrendingUp className="h-4 w-4 text-primary" />
              GST Collected (6mo)
            </div>
            <p className="mt-2 text-2xl font-semibold">{formatINR(totalCollected)}</p>
            <p className="mt-1 text-xs text-muted-foreground">Output tax liability</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 text-xs font-medium uppercase text-muted-foreground">
              <TrendingDown className="h-4 w-4 text-info" />
              Input Credit (6mo)
            </div>
            <p className="mt-2 text-2xl font-semibold">{formatINR(totalInput)}</p>
            <p className="mt-1 text-xs text-muted-foreground">Offset against liability</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">GST Paid</p>
            <p className="mt-2 text-2xl font-semibold text-primary">{formatINR(totalPaid)}</p>
            <p className="mt-1 text-xs text-muted-foreground">Net cash outflow</p>
          </CardContent>
        </Card>
        <Card className="border-amber-500/30">
          <CardContent className="pt-6">
            <p className="text-xs font-medium uppercase text-muted-foreground">Current Payable</p>
            <p className="mt-2 text-2xl font-semibold text-amber-600">{formatINR(currentPayable)}</p>
            <p className="mt-1 text-xs text-muted-foreground">Due May 20, 2026</p>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      <Card>
        <CardHeader>
          <CardTitle>GST Trend</CardTitle>
          <p className="mt-1 text-sm text-muted-foreground">
            Monthly output liability, input credit and net paid over the last 6 months
          </p>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={gstHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                <XAxis dataKey="month" fontSize={12} tickLine={false} stroke="var(--muted-foreground)" />
                <YAxis
                  fontSize={12}
                  tickLine={false}
                  stroke="var(--muted-foreground)"
                  tickFormatter={(v) => `${v / 1000}K`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: "var(--radius)",
                    fontSize: "12px",
                  }}
                  formatter={(v: number) => formatINR(v)}
                />
                <Legend wrapperStyle={{ fontSize: "12px" }} />
                <Bar dataKey="collected" name="Collected" fill="var(--chart-1)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="input" name="Input credit" fill="var(--chart-2)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="paid" name="Paid" fill="var(--chart-3)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="filings">
        <TabsList>
          <TabsTrigger value="filings">Filing history</TabsTrigger>
          <TabsTrigger value="vendors">Vendor reconciliation</TabsTrigger>
        </TabsList>

        <TabsContent value="filings" className="mt-4">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Form</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead>Due date</TableHead>
                  <TableHead className="text-right">Output tax</TableHead>
                  <TableHead className="text-right">Input credit</TableHead>
                  <TableHead className="text-right">Payable</TableHead>
                  <TableHead>ARN</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filings.map((f) => (
                  <TableRow key={f.id}>
                    <TableCell className="font-medium">{f.form}</TableCell>
                    <TableCell className="text-sm">{f.period}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{f.dueDate}</TableCell>
                    <TableCell className="text-right font-mono">{formatINR(f.collected)}</TableCell>
                    <TableCell className="text-right font-mono">
                      {f.input > 0 ? formatINR(f.input) : "-"}
                    </TableCell>
                    <TableCell className="text-right font-mono font-medium">
                      {f.payable > 0 ? formatINR(f.payable) : "-"}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{f.arn}</TableCell>
                    <TableCell>
                      <Badge
                        variant={f.status === "filed" ? "default" : "outline"}
                        className="gap-1"
                      >
                        {f.status === "filed" ? (
                          <CheckCircle2 className="h-3 w-3" />
                        ) : (
                          <Clock className="h-3 w-3" />
                        )}
                        {f.status === "filed" ? "Filed" : "Pending"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost">
                        {f.status === "filed" ? "Download" : "File"}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="vendors" className="mt-4">
          <Card>
            <div className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between">
              <div className="relative flex-1 md:max-w-sm">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  className="pl-9"
                  placeholder="Search vendor or GSTIN"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <Button size="sm" variant="outline">
                <Filter className="mr-2 h-4 w-4" />
                Auto-match
              </Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vendor</TableHead>
                  <TableHead>GSTIN</TableHead>
                  <TableHead className="text-center">Invoices</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Input credit</TableHead>
                  <TableHead>Reconciled</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVendors.map((v) => (
                  <TableRow key={v.id}>
                    <TableCell className="font-medium">{v.name}</TableCell>
                    <TableCell className="font-mono text-xs">{v.gstin}</TableCell>
                    <TableCell className="text-center">{v.invoices}</TableCell>
                    <TableCell className="text-right font-mono">{formatINR(v.total)}</TableCell>
                    <TableCell className="text-right font-mono">{formatINR(v.input)}</TableCell>
                    <TableCell>
                      {v.reconciled ? (
                        <Badge variant="default" className="gap-1">
                          <CheckCircle2 className="h-3 w-3" />
                          Matched
                        </Badge>
                      ) : (
                        <Badge variant="destructive" className="gap-1">
                          <AlertTriangle className="h-3 w-3" />
                          Mismatch
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="ghost">
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
