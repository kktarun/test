"use client"

import React, { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  FileDown,
  Download,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ArrowRightLeft,
  Upload,
  Link2,
  Unlink2,
  Calendar,
  TrendingDown,
  TrendingUp,
  Receipt,
  Undo2,
  Ban,
  Building2,
  ArrowDownRight,
  Minus,
  FileText,
  Printer,
  Info,
} from "lucide-react"
import { Progress } from "@/components/ui/progress"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

// ---------- Daily report dataset (13/03/2026) ----------
const reportDate = "2026-03-13"

const gatewayCollection = [
  {
    gateway: "Razorpay",
    gross: 2650000,
    txnCount: 184,
    modes: [
      { mode: "UPI", amount: 1480000, count: 108, mdr: 0 },
      { mode: "Net Banking", amount: 620000, count: 28, mdr: 12 },
      { mode: "Credit Card", amount: 380000, count: 22, mdr: 7600 },
      { mode: "Debit Card", amount: 120000, count: 18, mdr: 360 },
      { mode: "Wallet", amount: 50000, count: 8, mdr: 100 },
    ],
    fees: 8072,
    gst: 1453,
    net: 2640475,
  },
  {
    gateway: "Cashfree",
    gross: 1450000,
    txnCount: 96,
    modes: [
      { mode: "UPI", amount: 780000, count: 58, mdr: 0 },
      { mode: "Net Banking", amount: 320000, count: 14, mdr: 8 },
      { mode: "Credit Card", amount: 210000, count: 12, mdr: 4200 },
      { mode: "Debit Card", amount: 90000, count: 8, mdr: 270 },
      { mode: "Wallet", amount: 50000, count: 4, mdr: 100 },
    ],
    fees: 4578,
    gst: 824,
    net: 1444598,
  },
  {
    gateway: "Easebuzz",
    gross: 900000,
    txnCount: 62,
    modes: [
      { mode: "UPI", amount: 520000, count: 42, mdr: 0 },
      { mode: "Net Banking", amount: 180000, count: 8, mdr: 10 },
      { mode: "Credit Card", amount: 120000, count: 6, mdr: 2400 },
      { mode: "Debit Card", amount: 60000, count: 4, mdr: 180 },
      { mode: "Wallet", amount: 20000, count: 2, mdr: 40 },
    ],
    fees: 2630,
    gst: 473,
    net: 896897,
  },
]

const grossTotal = gatewayCollection.reduce((s, g) => s + g.gross, 0)
const feesTotal = gatewayCollection.reduce((s, g) => s + g.fees, 0)
const gstTotal = gatewayCollection.reduce((s, g) => s + g.gst, 0)
const txnTotal = gatewayCollection.reduce((s, g) => s + g.txnCount, 0)

const bankSettlements = [
  {
    accountName: "Main Operating Account",
    bank: "HDFC Bank",
    accountNumber: "•••• 3456",
    expected: 3185000,
    credited: 3185000,
    utr: "HDFCN26031301745",
    gateway: "Razorpay",
    creditedAt: "2026-03-13 18:42",
    feeHeads: ["Tuition Fee", "Admission Fee (70%)", "Lab Fee", "Activity Fee (50%)"],
    status: "matched",
  },
  {
    accountName: "Transport Fee Account",
    bank: "ICICI Bank",
    accountNumber: "•••• 7654",
    expected: 815000,
    credited: 815000,
    utr: "ICICN26031301892",
    gateway: "Cashfree",
    creditedAt: "2026-03-13 19:08",
    feeHeads: ["Transport Fee"],
    status: "matched",
  },
  {
    accountName: "Development Fund Account",
    bank: "State Bank of India",
    accountNumber: "•••• 7890",
    expected: 981970,
    credited: 975000,
    utr: "SBIN26031301563",
    gateway: "Easebuzz",
    creditedAt: "2026-03-13 20:15",
    feeHeads: ["Development Fee", "Admission Fee (30%)", "Activity Fee (50%)"],
    status: "mismatch",
    discrepancy: -6970,
  },
]

const creditedTotal = bankSettlements.reduce((s, b) => s + b.credited, 0)
const expectedTotal = bankSettlements.reduce((s, b) => s + b.expected, 0)

const refunds = [
  { id: "RF-260313-001", txnId: "PAY_RZP_991234", student: "Arjun Sharma", amount: 15000, gateway: "Razorpay", reason: "Double payment", status: "processed" },
  { id: "RF-260313-002", txnId: "PAY_CF_882311", student: "Priya Patel", amount: 4500, gateway: "Cashfree", reason: "Transport fee adjustment", status: "processed" },
  { id: "RF-260313-003", txnId: "PAY_RZP_993102", student: "Rohan Kumar", amount: 7500, gateway: "Razorpay", reason: "Excess fee collected", status: "processed" },
  { id: "RF-260313-004", txnId: "PAY_EB_551243", student: "Sneha Reddy", amount: 3000, gateway: "Easebuzz", reason: "Activity cancelled", status: "processed" },
]
const refundsTotal = refunds.reduce((s, r) => s + r.amount, 0)

const chargebacks = [
  { id: "CB-260313-001", txnId: "PAY_RZP_990087", student: "Amit Verma", amount: 45000, gateway: "Razorpay", reason: "Unauthorized transaction (cardholder dispute)", status: "deducted", fee: 500 },
  { id: "CB-260313-002", txnId: "PAY_CF_881123", student: "Karan Singh", amount: 12000, gateway: "Cashfree", reason: "Service not rendered", status: "deducted", fee: 500 },
]
const chargebacksTotal = chargebacks.reduce((s, c) => s + c.amount + c.fee, 0)

const adjustments = [
  { id: "ADJ-260313-001", type: "Reserve Hold", gateway: "Razorpay", amount: -5000, note: "Rolling reserve (2% of Apr'26 projection)" },
  { id: "ADJ-260313-002", type: "Convenience Fee Payout", gateway: "Cashfree", amount: 1250, note: "Parent-borne charges credited to institute" },
  { id: "ADJ-260313-003", type: "Gateway Correction", gateway: "Easebuzz", amount: -1970, note: "TDR undercharge from 11-Mar settlement" },
]
const adjustmentsTotal = adjustments.reduce((s, a) => s + a.amount, 0)

// Expected net to bank = Gross - Fees - GST - Refunds - Chargebacks(incl fee) + Adjustments
const expectedNet = grossTotal - feesTotal - gstTotal - refundsTotal - chargebacksTotal + adjustmentsTotal
const discrepancy = creditedTotal - expectedNet

// ---------- Day transactions detail (13-Mar-2026) ----------
type TxnStatus = "captured" | "refunded" | "chargeback" | "failed" | "unmatched"
type DayTxn = {
  id: string
  time: string
  student: string
  class: string
  feeHead: string
  gateway: "Razorpay" | "Cashfree" | "Easebuzz"
  mode: "UPI" | "NetBanking" | "Card" | "Wallet"
  amount: number
  fee: number
  gst: number
  utr: string | null
  settledTo: "Main" | "Transport" | "Dev Fund" | null
  status: TxnStatus
}
const dayTransactions: DayTxn[] = [
  { id: "TXN-260313-0001", time: "09:12", student: "Aarav Sharma", class: "X-A", feeHead: "Term 4 Tuition", gateway: "Razorpay", mode: "UPI", amount: 45000, fee: 0, gst: 0, utr: "HDFC26031301111", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0002", time: "09:34", student: "Priya Patel", class: "VIII-B", feeHead: "Transport Q4", gateway: "Cashfree", mode: "UPI", amount: 12500, fee: 0, gst: 0, utr: "ICIC26031302222", settledTo: "Transport", status: "captured" },
  { id: "TXN-260313-0003", time: "10:05", student: "Rohan Verma", class: "XII-C", feeHead: "Annual Fee", gateway: "Razorpay", mode: "Card", amount: 85000, fee: 1700, gst: 306, utr: "HDFC26031303333", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0004", time: "10:21", student: "Sneha Reddy", class: "IX-A", feeHead: "Term 4 Tuition", gateway: "Easebuzz", mode: "NetBanking", amount: 42000, fee: 420, gst: 75.6, utr: "SBIN26031301563", settledTo: "Dev Fund", status: "captured" },
  { id: "TXN-260313-0005", time: "10:48", student: "Amit Kumar", class: "XI-A", feeHead: "Lab Fee", gateway: "Cashfree", mode: "UPI", amount: 18000, fee: 0, gst: 0, utr: "ICIC26031304444", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0006", time: "11:02", student: "Isha Nair", class: "VII-B", feeHead: "Transport Q4", gateway: "Razorpay", mode: "Wallet", amount: 12500, fee: 250, gst: 45, utr: "HDFC26031305555", settledTo: "Transport", status: "captured" },
  { id: "TXN-260313-0007", time: "11:25", student: "Kabir Singh", class: "X-B", feeHead: "Hostel Fee", gateway: "Easebuzz", mode: "NetBanking", amount: 65000, fee: 650, gst: 117, utr: "SBIN26031306666", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0008", time: "11:41", student: "Ananya Das", class: "VI-A", feeHead: "Term 4 Tuition", gateway: "Razorpay", mode: "UPI", amount: 38000, fee: 0, gst: 0, utr: "HDFC26031307777", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0009", time: "12:03", student: "Vikram Rao", class: "XI-B", feeHead: "Examination Fee", gateway: "Cashfree", mode: "Card", amount: 8500, fee: 170, gst: 30.6, utr: "ICIC26031308888", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0010", time: "12:18", student: "Meera Iyer", class: "XII-A", feeHead: "Annual Fee", gateway: "Easebuzz", mode: "NetBanking", amount: 92000, fee: 920, gst: 165.6, utr: "SBIN26031309999", settledTo: "Dev Fund", status: "captured" },
  { id: "TXN-260313-0011", time: "12:44", student: "Arjun Gupta", class: "IX-B", feeHead: "Transport Q4", gateway: "Razorpay", mode: "UPI", amount: 12500, fee: 0, gst: 0, utr: "HDFC26031310000", settledTo: "Transport", status: "captured" },
  { id: "TXN-260313-0012", time: "13:15", student: "Divya Menon", class: "VIII-A", feeHead: "Library Fee", gateway: "Cashfree", mode: "Wallet", amount: 2500, fee: 50, gst: 9, utr: "ICIC26031311111", settledTo: "Main", status: "refunded" },
  { id: "TXN-260313-0013", time: "13:32", student: "Rahul Sinha", class: "X-A", feeHead: "Term 4 Tuition", gateway: "Razorpay", mode: "Card", amount: 45000, fee: 900, gst: 162, utr: null, settledTo: null, status: "failed" },
  { id: "TXN-260313-0014", time: "14:07", student: "Neha Joshi", class: "VII-A", feeHead: "Sports Fee", gateway: "Easebuzz", mode: "UPI", amount: 3500, fee: 0, gst: 0, utr: "SBIN26031312222", settledTo: "Dev Fund", status: "captured" },
  { id: "TXN-260313-0015", time: "14:29", student: "Siddharth Roy", class: "XI-C", feeHead: "Annual Fee", gateway: "Cashfree", mode: "NetBanking", amount: 78000, fee: 780, gst: 140.4, utr: "ICIC26031313333", settledTo: "Main", status: "chargeback" },
  { id: "TXN-260313-0016", time: "14:52", student: "Pooja Shah", class: "VI-B", feeHead: "Transport Q4", gateway: "Razorpay", mode: "UPI", amount: 12500, fee: 0, gst: 0, utr: "HDFC26031314444", settledTo: "Transport", status: "captured" },
  { id: "TXN-260313-0017", time: "15:18", student: "Karan Malhotra", class: "XII-B", feeHead: "Examination Fee", gateway: "Easebuzz", mode: "Card", amount: 8500, fee: 170, gst: 30.6, utr: "SBIN26031315555", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0018", time: "15:41", student: "Tanya Kapoor", class: "IX-A", feeHead: "Lab Fee", gateway: "Razorpay", mode: "Wallet", amount: 18000, fee: 360, gst: 64.8, utr: "HDFC26031316666", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0019", time: "16:02", student: "Dev Anand", class: "X-C", feeHead: "Term 4 Tuition", gateway: "Cashfree", mode: "UPI", amount: 45000, fee: 0, gst: 0, utr: "ICIC26031317777", settledTo: "Main", status: "captured" },
  { id: "TXN-260313-0020", time: "16:28", student: "Ritu Agarwal", class: "VIII-C", feeHead: "Hostel Fee", gateway: "Easebuzz", mode: "NetBanking", amount: 65000, fee: 650, gst: 117, utr: "PAY_EB_551999", settledTo: null, status: "unmatched" },
]

// ---------- Legacy data (existing tabs) ----------
const reconciliationStats = [
  { title: "Total Transactions", value: "1,245", icon: ArrowRightLeft },
  { title: "Matched", value: "1,198", icon: CheckCircle2, color: "text-success" },
  { title: "Unmatched", value: "32", icon: AlertTriangle, color: "text-warning" },
  { title: "Failed", value: "15", icon: XCircle, color: "text-destructive" },
]

const gatewayTransactions = [
  { id: "GW001", gatewayTxnId: "PAY_RZP_991234", amount: 15000, date: "2026-03-13", gateway: "Razorpay", utr: "UTR123456789012", bankRef: "HDFC123456", status: "matched", matchedWith: "TXN20260313001" },
  { id: "GW002", gatewayTxnId: "PAY_CF_882311", amount: 12500, date: "2026-03-13", gateway: "Cashfree", utr: "UTR987654321098", bankRef: "ICIC987654", status: "matched", matchedWith: "TXN20260313002" },
  { id: "GW003", gatewayTxnId: "PAY_EB_551999", amount: 18000, date: "2026-03-13", gateway: "Easebuzz", utr: "UTR456789123456", bankRef: null, status: "unmatched", matchedWith: null },
  { id: "GW004", gatewayTxnId: "PAY_RZP_993102", amount: 8500, date: "2026-03-13", gateway: "Razorpay", utr: "UTR789123456789", bankRef: "HDFC789123", status: "matched", matchedWith: "TXN20260313006" },
  { id: "GW005", gatewayTxnId: "PAY_CF_881444", amount: 16500, date: "2026-03-13", gateway: "Cashfree", utr: null, bankRef: null, status: "failed", matchedWith: null },
]

export function ReconciliationContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDate, setSelectedDate] = useState(reportDate)
  const [expandedGateway, setExpandedGateway] = useState<string | null>("Razorpay")
  const [txnGatewayFilter, setTxnGatewayFilter] = useState("all")
  const [txnModeFilter, setTxnModeFilter] = useState("all")
  const [txnStatusFilter, setTxnStatusFilter] = useState("all")

  const filteredDayTransactions = dayTransactions.filter((t) => {
    if (txnGatewayFilter !== "all" && t.gateway !== txnGatewayFilter) return false
    if (txnModeFilter !== "all" && t.mode !== txnModeFilter) return false
    if (txnStatusFilter !== "all" && t.status !== txnStatusFilter) return false
    return true
  })

  const matchedPercentage = (1198 / 1245) * 100

  const fmt = (n: number) =>
    `${n < 0 ? "-" : ""}₹${Math.abs(n).toLocaleString("en-IN")}`

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Reconciliation</h1>
            <p className="text-muted-foreground">
              Match payment gateway transactions with bank settlements
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline">
              <Upload className="mr-2 h-4 w-4" />
              Import Bank Statement
            </Button>
            <Button variant="outline">
              <RefreshCw className="mr-2 h-4 w-4" />
              Sync Gateways
            </Button>
            <Button>
              <ArrowRightLeft className="mr-2 h-4 w-4" />
              Auto-Reconcile
            </Button>
          </div>
        </div>

        <Tabs defaultValue="daily" className="space-y-4">
          <TabsList>
            <TabsTrigger value="daily">Daily Report</TabsTrigger>
            <TabsTrigger value="transactions">Gateway Transactions</TabsTrigger>
            <TabsTrigger value="settlements">Settlements</TabsTrigger>
            <TabsTrigger value="utr">UTR Matching</TabsTrigger>
          </TabsList>

          {/* --------- DAILY REPORT TAB --------- */}
          <TabsContent value="daily" className="space-y-4">
            {/* Date selector + export bar */}
            <Card>
              <CardContent className="flex flex-col gap-3 p-4 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Calendar className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Report date</p>
                    <div className="flex items-center gap-2">
                      <Input
                        type="date"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                        className="h-8 w-44"
                      />
                      <Badge variant="outline" className="gap-1">
                        <CheckCircle2 className="h-3 w-3 text-success" />
                        EOD closed
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    <Printer className="mr-2 h-4 w-4" />
                    Print
                  </Button>
                  <Button variant="outline" size="sm">
                    <FileText className="mr-2 h-4 w-4" />
                    Export PDF
                  </Button>
                  <Button size="sm">
                    <FileDown className="mr-2 h-4 w-4" />
                    Export Excel
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Summary tiles */}
            <div className="grid gap-3 md:grid-cols-3 lg:grid-cols-6">
              <Card className="border-l-4 border-l-primary">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Gross Collection</p>
                  <p className="mt-1 text-xl font-bold">{fmt(grossTotal)}</p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {txnTotal} transactions · 3 gateways
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <TrendingDown className="h-3 w-3" />
                    Gateway Fees + GST
                  </p>
                  <p className="mt-1 text-xl font-bold text-destructive">
                    -{fmt(feesTotal + gstTotal)}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    MDR {fmt(feesTotal)} + GST {fmt(gstTotal)}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Undo2 className="h-3 w-3" />
                    Refunds
                  </p>
                  <p className="mt-1 text-xl font-bold text-destructive">
                    -{fmt(refundsTotal)}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {refunds.length} refunds issued
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Ban className="h-3 w-3" />
                    Chargebacks
                  </p>
                  <p className="mt-1 text-xl font-bold text-destructive">
                    -{fmt(chargebacksTotal)}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {chargebacks.length} disputes · incl. fees
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    <ArrowRightLeft className="h-3 w-3" />
                    Adjustments
                  </p>
                  <p
                    className={`mt-1 text-xl font-bold ${
                      adjustmentsTotal >= 0 ? "text-success" : "text-destructive"
                    }`}
                  >
                    {fmt(adjustmentsTotal)}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {adjustments.length} gateway adjustments
                  </p>
                </CardContent>
              </Card>
              <Card
                className={`border-l-4 ${
                  discrepancy === 0 ? "border-l-success" : "border-l-destructive"
                }`}
              >
                <CardContent className="p-4">
                  <p className="flex items-center gap-1 text-xs text-muted-foreground">
                    {discrepancy === 0 ? (
                      <CheckCircle2 className="h-3 w-3 text-success" />
                    ) : (
                      <AlertTriangle className="h-3 w-3 text-destructive" />
                    )}
                    Discrepancy
                  </p>
                  <p
                    className={`mt-1 text-xl font-bold ${
                      discrepancy === 0 ? "text-success" : "text-destructive"
                    }`}
                  >
                    {fmt(discrepancy)}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    Credited vs expected
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Gateway-wise collection with mode breakdown */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">Gateway-wise Collection</CardTitle>
                    <CardDescription>
                      Gross receipts by gateway and payment mode
                    </CardDescription>
                  </div>
                  <Badge variant="secondary">
                    {gatewayCollection.length} gateways
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-8"></TableHead>
                      <TableHead>Gateway</TableHead>
                      <TableHead className="text-right">Txns</TableHead>
                      <TableHead className="text-right">Gross</TableHead>
                      <TableHead className="text-right">Fees</TableHead>
                      <TableHead className="text-right">GST</TableHead>
                      <TableHead className="text-right">Net</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gatewayCollection.map((gw) => (
                      <React.Fragment key={gw.gateway}>
                        <TableRow
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() =>
                            setExpandedGateway(
                              expandedGateway === gw.gateway ? null : gw.gateway,
                            )
                          }
                        >
                          <TableCell>
                            <div className="flex h-6 w-6 items-center justify-center rounded-md bg-muted text-xs">
                              {expandedGateway === gw.gateway ? "−" : "+"}
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{gw.gateway}</TableCell>
                          <TableCell className="text-right">{gw.txnCount}</TableCell>
                          <TableCell className="text-right font-semibold">
                            {fmt(gw.gross)}
                          </TableCell>
                          <TableCell className="text-right text-destructive">
                            -{fmt(gw.fees)}
                          </TableCell>
                          <TableCell className="text-right text-destructive">
                            -{fmt(gw.gst)}
                          </TableCell>
                          <TableCell className="text-right font-semibold text-success">
                            {fmt(gw.net)}
                          </TableCell>
                        </TableRow>
                        {expandedGateway === gw.gateway &&
                          gw.modes.map((mode) => (
                            <TableRow
                              key={`${gw.gateway}-${mode.mode}`}
                              className="bg-muted/30"
                            >
                              <TableCell></TableCell>
                              <TableCell className="pl-8 text-sm text-muted-foreground">
                                <span className="inline-flex items-center gap-2">
                                  <ArrowDownRight className="h-3 w-3" />
                                  {mode.mode}
                                </span>
                              </TableCell>
                              <TableCell className="text-right text-sm">
                                {mode.count}
                              </TableCell>
                              <TableCell className="text-right text-sm">
                                {fmt(mode.amount)}
                              </TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">
                                -{fmt(mode.mdr)}
                              </TableCell>
                              <TableCell className="text-right text-sm text-muted-foreground">
                                <Minus className="ml-auto h-3 w-3" />
                              </TableCell>
                              <TableCell className="text-right text-sm">
                                {fmt(mode.amount - mode.mdr)}
                              </TableCell>
                            </TableRow>
                          ))}
                      </React.Fragment>
                    ))}
                  </TableBody>
                  <TableFooter>
                    <TableRow>
                      <TableCell></TableCell>
                      <TableCell className="font-semibold">Total</TableCell>
                      <TableCell className="text-right font-semibold">
                        {txnTotal}
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        {fmt(grossTotal)}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-destructive">
                        -{fmt(feesTotal)}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-destructive">
                        -{fmt(gstTotal)}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-success">
                        {fmt(grossTotal - feesTotal - gstTotal)}
                      </TableCell>
                    </TableRow>
                  </TableFooter>
                </Table>
              </CardContent>
            </Card>

            {/* Settlement to bank accounts (split) */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">
                      Settlement to School Bank Accounts
                    </CardTitle>
                    <CardDescription>
                      Credits to institute accounts per split rules
                    </CardDescription>
                  </div>
                  <Badge variant="secondary">{bankSettlements.length} accounts</Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account</TableHead>
                      <TableHead>Fee Heads</TableHead>
                      <TableHead>From Gateway</TableHead>
                      <TableHead>UTR / Credited At</TableHead>
                      <TableHead className="text-right">Expected</TableHead>
                      <TableHead className="text-right">Credited</TableHead>
                      <TableHead className="text-right">Delta</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bankSettlements.map((s) => {
                      const delta = s.credited - s.expected
                      return (
                        <TableRow key={s.accountNumber}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Building2 className="h-4 w-4 text-muted-foreground" />
                              <div>
                                <p className="text-sm font-medium">{s.accountName}</p>
                                <p className="text-xs text-muted-foreground">
                                  {s.bank} · {s.accountNumber}
                                </p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {s.feeHeads.map((fh) => (
                                <Badge
                                  key={fh}
                                  variant="outline"
                                  className="text-[10px]"
                                >
                                  {fh}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{s.gateway}</Badge>
                          </TableCell>
                          <TableCell className="text-xs">
                            <p className="font-mono">{s.utr}</p>
                            <p className="text-muted-foreground">{s.creditedAt}</p>
                          </TableCell>
                          <TableCell className="text-right">
                            {fmt(s.expected)}
                          </TableCell>
                          <TableCell className="text-right font-semibold">
                            {fmt(s.credited)}
                          </TableCell>
                          <TableCell
                            className={`text-right font-semibold ${
                              delta === 0
                                ? "text-muted-foreground"
                                : "text-destructive"
                            }`}
                          >
                            {delta === 0 ? "—" : fmt(delta)}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                s.status === "matched" ? "default" : "destructive"
                              }
                              className="capitalize"
                            >
                              {s.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                  <TableFooter>
                    <TableRow>
                      <TableCell colSpan={4} className="font-semibold">
                        Total Credited
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        {fmt(expectedTotal)}
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        {fmt(creditedTotal)}
                      </TableCell>
                      <TableCell
                        className={`text-right font-semibold ${
                          creditedTotal - expectedTotal === 0
                            ? ""
                            : "text-destructive"
                        }`}
                      >
                        {fmt(creditedTotal - expectedTotal)}
                      </TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  </TableFooter>
                </Table>
              </CardContent>
            </Card>

            {/* Refunds + Chargebacks + Adjustments in 3 columns */}
            <div className="grid gap-4 lg:grid-cols-3">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Undo2 className="h-4 w-4" />
                    Refunds
                  </CardTitle>
                  <CardDescription className="text-xs">
                    Processed on {selectedDate}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs">Student</TableHead>
                        <TableHead className="text-xs">Reason</TableHead>
                        <TableHead className="text-right text-xs">Amount</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {refunds.map((r) => (
                        <TableRow key={r.id}>
                          <TableCell className="text-xs">
                            <p className="font-medium">{r.student}</p>
                            <p className="font-mono text-muted-foreground">
                              {r.gateway}
                            </p>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {r.reason}
                          </TableCell>
                          <TableCell className="text-right text-xs font-semibold text-destructive">
                            -{fmt(r.amount)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <TableFooter>
                      <TableRow>
                        <TableCell colSpan={2} className="text-xs font-semibold">
                          Total
                        </TableCell>
                        <TableCell className="text-right text-xs font-semibold text-destructive">
                          -{fmt(refundsTotal)}
                        </TableCell>
                      </TableRow>
                    </TableFooter>
                  </Table>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Ban className="h-4 w-4" />
                    Chargeback Deductions
                  </CardTitle>
                  <CardDescription className="text-xs">
                    Disputes deducted by gateway
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs">Student</TableHead>
                        <TableHead className="text-xs">Reason</TableHead>
                        <TableHead className="text-right text-xs">
                          Amount + Fee
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {chargebacks.map((c) => (
                        <TableRow key={c.id}>
                          <TableCell className="text-xs">
                            <p className="font-medium">{c.student}</p>
                            <p className="font-mono text-muted-foreground">
                              {c.gateway}
                            </p>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {c.reason}
                          </TableCell>
                          <TableCell className="text-right text-xs font-semibold text-destructive">
                            -{fmt(c.amount)}
                            <span className="block text-[10px] font-normal text-muted-foreground">
                              +{fmt(c.fee)} fee
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <TableFooter>
                      <TableRow>
                        <TableCell colSpan={2} className="text-xs font-semibold">
                          Total
                        </TableCell>
                        <TableCell className="text-right text-xs font-semibold text-destructive">
                          -{fmt(chargebacksTotal)}
                        </TableCell>
                      </TableRow>
                    </TableFooter>
                  </Table>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <ArrowRightLeft className="h-4 w-4" />
                    Gateway Adjustments
                  </CardTitle>
                  <CardDescription className="text-xs">
                    Reserves, corrections and payouts
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-xs">Type</TableHead>
                        <TableHead className="text-xs">Note</TableHead>
                        <TableHead className="text-right text-xs">Impact</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {adjustments.map((a) => (
                        <TableRow key={a.id}>
                          <TableCell className="text-xs">
                            <p className="font-medium">{a.type}</p>
                            <p className="font-mono text-muted-foreground">
                              {a.gateway}
                            </p>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {a.note}
                          </TableCell>
                          <TableCell
                            className={`text-right text-xs font-semibold ${
                              a.amount >= 0 ? "text-success" : "text-destructive"
                            }`}
                          >
                            {fmt(a.amount)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <TableFooter>
                      <TableRow>
                        <TableCell colSpan={2} className="text-xs font-semibold">
                          Total
                        </TableCell>
                        <TableCell
                          className={`text-right text-xs font-semibold ${
                            adjustmentsTotal >= 0
                              ? "text-success"
                              : "text-destructive"
                          }`}
                        >
                          {fmt(adjustmentsTotal)}
                        </TableCell>
                      </TableRow>
                    </TableFooter>
                  </Table>
                </CardContent>
              </Card>
            </div>

            {/* Reconciliation waterfall + discrepancy */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">
                      End-of-Day Reconciliation
                    </CardTitle>
                    <CardDescription>
                      Waterfall from gross collection to bank credit
                    </CardDescription>
                  </div>
                  <Badge
                    variant={discrepancy === 0 ? "default" : "destructive"}
                    className="gap-1"
                  >
                    {discrepancy === 0 ? (
                      <>
                        <CheckCircle2 className="h-3 w-3" /> Reconciled
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="h-3 w-3" /> Mismatch {fmt(discrepancy)}
                      </>
                    )}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">
                        <span className="flex items-center gap-2">
                          <Receipt className="h-4 w-4 text-muted-foreground" />
                          Gross Collection
                        </span>
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        {fmt(grossTotal)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-muted-foreground">
                        − Gateway Fees (MDR)
                      </TableCell>
                      <TableCell className="text-right text-destructive">
                        -{fmt(feesTotal)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-muted-foreground">
                        − GST on Fees (18%)
                      </TableCell>
                      <TableCell className="text-right text-destructive">
                        -{fmt(gstTotal)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-muted-foreground">− Refunds</TableCell>
                      <TableCell className="text-right text-destructive">
                        -{fmt(refundsTotal)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-muted-foreground">
                        − Chargebacks (incl. fees)
                      </TableCell>
                      <TableCell className="text-right text-destructive">
                        -{fmt(chargebacksTotal)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-muted-foreground">
                        ± Gateway Adjustments
                      </TableCell>
                      <TableCell
                        className={`text-right ${
                          adjustmentsTotal >= 0 ? "text-success" : "text-destructive"
                        }`}
                      >
                        {fmt(adjustmentsTotal)}
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-t-2 bg-muted/40">
                      <TableCell className="font-semibold">
                        Expected Bank Credit
                      </TableCell>
                      <TableCell className="text-right text-base font-bold">
                        {fmt(expectedNet)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">
                        <span className="flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-muted-foreground" />
                          Actual Bank Credit
                          <Tooltip>
                            <TooltipTrigger>
                              <Info className="h-3 w-3 text-muted-foreground" />
                            </TooltipTrigger>
                            <TooltipContent>
                              Sum of UTR credits across 3 school bank accounts
                            </TooltipContent>
                          </Tooltip>
                        </span>
                      </TableCell>
                      <TableCell className="text-right text-base font-bold text-success">
                        {fmt(creditedTotal)}
                      </TableCell>
                    </TableRow>
                    <TableRow
                      className={`border-t-2 ${
                        discrepancy === 0 ? "bg-success/5" : "bg-destructive/5"
                      }`}
                    >
                      <TableCell className="font-semibold">
                        <span className="flex items-center gap-2">
                          {discrepancy === 0 ? (
                            <CheckCircle2 className="h-4 w-4 text-success" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-destructive" />
                          )}
                          Discrepancy
                        </span>
                      </TableCell>
                      <TableCell
                        className={`text-right text-base font-bold ${
                          discrepancy === 0 ? "text-success" : "text-destructive"
                        }`}
                      >
                        {fmt(discrepancy)}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Mismatched transactions */}
            {discrepancy !== 0 && (
              <Card className="border-destructive/30">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                    Mismatch Details
                  </CardTitle>
                  <CardDescription>
                    Review these items to resolve the {fmt(Math.abs(discrepancy))} discrepancy
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Issue</TableHead>
                        <TableHead>Account / Gateway</TableHead>
                        <TableHead>Reference</TableHead>
                        <TableHead className="text-right">Impact</TableHead>
                        <TableHead className="text-right">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell>
                          <p className="font-medium">Short credit from Easebuzz</p>
                          <p className="text-xs text-muted-foreground">
                            Development Fund Account received ₹975,000 against expected ₹981,970
                          </p>
                        </TableCell>
                        <TableCell>
                          <p className="text-sm">SBI · •••• 7890</p>
                          <Badge variant="outline" className="text-[10px]">
                            Easebuzz
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          SBIN26031301563
                        </TableCell>
                        <TableCell className="text-right font-semibold text-destructive">
                          -{fmt(6970)}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button size="sm" variant="outline">
                            Raise with gateway
                          </Button>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell>
                          <p className="font-medium">Unmatched gateway transaction</p>
                          <p className="text-xs text-muted-foreground">
                            Payment captured at gateway but UTR missing in bank feed
                          </p>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-[10px]">
                            Easebuzz
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          PAY_EB_551999
                        </TableCell>
                        <TableCell className="text-right font-semibold text-warning">
                          Pending
                        </TableCell>
                        <TableCell className="text-right">
                          <Button size="sm" variant="outline">
                            <Link2 className="mr-1 h-3 w-3" />
                            Link manually
                          </Button>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}

            {/* All transactions for the day */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Receipt className="h-4 w-4" />
                      All Transactions on {reportDate ? new Date(reportDate).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) : ""}
                    </CardTitle>
                    <CardDescription>
                      {dayTransactions.length} total · {dayTransactions.filter((t) => t.status === "captured").length} captured · {dayTransactions.filter((t) => t.status === "refunded").length} refunded · {dayTransactions.filter((t) => t.status === "chargeback").length} chargeback · {dayTransactions.filter((t) => t.status === "failed" || t.status === "unmatched").length} failed/unmatched
                    </CardDescription>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Select value={txnGatewayFilter} onValueChange={setTxnGatewayFilter}>
                      <SelectTrigger className="h-9 w-36">
                        <SelectValue placeholder="Gateway" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Gateways</SelectItem>
                        <SelectItem value="Razorpay">Razorpay</SelectItem>
                        <SelectItem value="Cashfree">Cashfree</SelectItem>
                        <SelectItem value="Easebuzz">Easebuzz</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={txnModeFilter} onValueChange={setTxnModeFilter}>
                      <SelectTrigger className="h-9 w-32">
                        <SelectValue placeholder="Mode" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Modes</SelectItem>
                        <SelectItem value="UPI">UPI</SelectItem>
                        <SelectItem value="NetBanking">NetBanking</SelectItem>
                        <SelectItem value="Card">Card</SelectItem>
                        <SelectItem value="Wallet">Wallet</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={txnStatusFilter} onValueChange={setTxnStatusFilter}>
                      <SelectTrigger className="h-9 w-36">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="captured">Captured</SelectItem>
                        <SelectItem value="refunded">Refunded</SelectItem>
                        <SelectItem value="chargeback">Chargeback</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                        <SelectItem value="unmatched">Unmatched</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-3 w-3" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Time</TableHead>
                      <TableHead className="text-xs">Txn ID</TableHead>
                      <TableHead className="text-xs">Student</TableHead>
                      <TableHead className="text-xs">Fee Head</TableHead>
                      <TableHead className="text-xs">Gateway / Mode</TableHead>
                      <TableHead className="text-right text-xs">Amount</TableHead>
                      <TableHead className="text-right text-xs">Fee + GST</TableHead>
                      <TableHead className="text-xs">UTR</TableHead>
                      <TableHead className="text-xs">Settled To</TableHead>
                      <TableHead className="text-xs">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDayTransactions.map((t) => (
                      <TableRow key={t.id}>
                        <TableCell className="text-xs text-muted-foreground">
                          {t.time}
                        </TableCell>
                        <TableCell className="font-mono text-xs">{t.id}</TableCell>
                        <TableCell className="text-xs">
                          <p className="font-medium">{t.student}</p>
                          <p className="text-muted-foreground">{t.class}</p>
                        </TableCell>
                        <TableCell className="text-xs">{t.feeHead}</TableCell>
                        <TableCell className="text-xs">
                          <p className="font-medium">{t.gateway}</p>
                          <p className="text-muted-foreground">{t.mode}</p>
                        </TableCell>
                        <TableCell className="text-right text-xs font-semibold">
                          {fmt(t.amount)}
                        </TableCell>
                        <TableCell className="text-right text-xs text-muted-foreground">
                          {t.fee + t.gst === 0 ? "—" : fmt(t.fee + t.gst)}
                        </TableCell>
                        <TableCell className="font-mono text-[10px] text-muted-foreground">
                          {t.utr ?? "—"}
                        </TableCell>
                        <TableCell className="text-xs">
                          {t.settledTo ? (
                            <Badge variant="outline" className="text-[10px]">
                              {t.settledTo}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {t.status === "captured" && (
                            <Badge className="bg-success/15 text-success hover:bg-success/20 text-[10px]">
                              Captured
                            </Badge>
                          )}
                          {t.status === "refunded" && (
                            <Badge className="bg-warning/15 text-warning hover:bg-warning/20 text-[10px]">
                              Refunded
                            </Badge>
                          )}
                          {t.status === "chargeback" && (
                            <Badge variant="destructive" className="text-[10px]">
                              Chargeback
                            </Badge>
                          )}
                          {t.status === "failed" && (
                            <Badge variant="destructive" className="text-[10px]">
                              Failed
                            </Badge>
                          )}
                          {t.status === "unmatched" && (
                            <Badge className="bg-warning/15 text-warning hover:bg-warning/20 text-[10px]">
                              Unmatched
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredDayTransactions.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={10} className="text-center text-xs text-muted-foreground py-6">
                          No transactions match the current filters
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                  <TableFooter>
                    <TableRow>
                      <TableCell colSpan={5} className="text-xs font-semibold">
                        Showing {filteredDayTransactions.length} of {dayTransactions.length} transactions
                      </TableCell>
                      <TableCell className="text-right text-xs font-semibold">
                        {fmt(filteredDayTransactions.reduce((s, t) => s + t.amount, 0))}
                      </TableCell>
                      <TableCell className="text-right text-xs font-semibold text-muted-foreground">
                        {fmt(filteredDayTransactions.reduce((s, t) => s + t.fee + t.gst, 0))}
                      </TableCell>
                      <TableCell colSpan={3} />
                    </TableRow>
                  </TableFooter>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* --------- LEGACY TABS --------- */}
          <TabsContent value="transactions" className="space-y-4">
            {/* Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              {reconciliationStats.map((stat) => (
                <Card key={stat.title}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.title}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`rounded-lg bg-muted p-3 ${stat.color || ""}`}>
                      <stat.icon className="h-5 w-5" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Reconciliation Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">March 2026</span>
                    <span className="font-medium">
                      {matchedPercentage.toFixed(1)}% matched
                    </span>
                  </div>
                  <Progress value={matchedPercentage} className="h-3" />
                  <div className="flex gap-4 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full bg-primary" />
                      Matched: 1,198
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full bg-warning" />
                      Unmatched: 32
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full bg-destructive" />
                      Failed: 15
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div className="relative w-full md:w-72">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by UTR or Txn ID..."
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Select defaultValue="all">
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Gateway" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Gateways</SelectItem>
                        <SelectItem value="razorpay">Razorpay</SelectItem>
                        <SelectItem value="cashfree">Cashfree</SelectItem>
                        <SelectItem value="easebuzz">Easebuzz</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select defaultValue="all">
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="matched">Matched</SelectItem>
                        <SelectItem value="unmatched">Unmatched</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline">
                      <FileDown className="mr-2 h-4 w-4" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Gateway Txn ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Gateway</TableHead>
                      <TableHead>UTR Number</TableHead>
                      <TableHead>Bank Ref</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Matched With</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gatewayTransactions.map((txn) => (
                      <TableRow key={txn.id}>
                        <TableCell className="font-mono text-xs">
                          {txn.gatewayTxnId}
                        </TableCell>
                        <TableCell>{txn.date}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{txn.gateway}</Badge>
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {txn.utr || <span className="text-muted-foreground">-</span>}
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {txn.bankRef || (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right font-semibold">
                          {fmt(txn.amount)}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              txn.status === "matched"
                                ? "default"
                                : txn.status === "unmatched"
                                ? "secondary"
                                : "destructive"
                            }
                            className="capitalize"
                          >
                            {txn.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono text-xs">
                          {txn.matchedWith ? (
                            <span className="text-success">{txn.matchedWith}</span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {txn.status === "unmatched" ? (
                            <Button variant="ghost" size="sm">
                              <Link2 className="h-4 w-4" />
                            </Button>
                          ) : txn.status === "matched" ? (
                            <Button variant="ghost" size="sm">
                              <Unlink2 className="h-4 w-4" />
                            </Button>
                          ) : null}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settlements" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Settlement Reports</CardTitle>
                <CardDescription>
                  Payment gateway settlement details and fees breakdown
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Settlement ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Gateway</TableHead>
                      <TableHead className="text-right">Gross Amount</TableHead>
                      <TableHead className="text-right">Fees</TableHead>
                      <TableHead className="text-right">GST</TableHead>
                      <TableHead className="text-right">Net Amount</TableHead>
                      <TableHead>Transactions</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {gatewayCollection.map((gw, idx) => (
                      <TableRow key={gw.gateway}>
                        <TableCell className="font-mono text-sm">
                          SET-260313-{String(idx + 1).padStart(3, "0")}
                        </TableCell>
                        <TableCell>{selectedDate}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{gw.gateway}</Badge>
                        </TableCell>
                        <TableCell className="text-right">{fmt(gw.gross)}</TableCell>
                        <TableCell className="text-right text-destructive">
                          -{fmt(gw.fees)}
                        </TableCell>
                        <TableCell className="text-right text-destructive">
                          -{fmt(gw.gst)}
                        </TableCell>
                        <TableCell className="text-right font-semibold text-success">
                          {fmt(gw.net)}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{gw.txnCount}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="default" className="capitalize">
                            completed
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="utr" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>UTR Verification</CardTitle>
                <CardDescription>
                  Match UTR numbers submitted by parents with bank records
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <Input placeholder="Enter UTR Number" className="max-w-sm" />
                  <Button>
                    <Search className="mr-2 h-4 w-4" />
                    Verify UTR
                  </Button>
                </div>
                <div className="rounded-lg border p-6 text-center text-muted-foreground">
                  Enter a UTR number to verify against bank settlements
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </TooltipProvider>
  )
}
