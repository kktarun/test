"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { 
  Upload, 
  Download, 
  FileSpreadsheet, 
  Users, 
  IndianRupee, 
  GraduationCap,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  Eye,
  Trash2,
  RefreshCw,
  FileText,
  MoreHorizontal
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu"

// Upload templates
const uploadTemplates = [
  {
    id: "TPL001",
    name: "Students",
    description: "Bulk upload student data with parent details",
    icon: Users,
    columns: ["admission_no", "first_name", "last_name", "class", "division", "dob", "gender", "father_name", "mother_name", "phone", "email", "address"],
    sampleRows: 5,
    lastUploaded: "2024-04-10",
  },
  {
    id: "TPL002",
    name: "Fee Assignments",
    description: "Assign fee structures to students",
    icon: IndianRupee,
    columns: ["admission_no", "fee_structure_id", "installment_plan", "discount_type", "discount_value"],
    sampleRows: 5,
    lastUploaded: "2024-04-05",
  },
  {
    id: "TPL003",
    name: "Scholarships",
    description: "Bulk assign scholarships to students",
    icon: GraduationCap,
    columns: ["admission_no", "scholarship_id", "discount_amount", "valid_from", "valid_to", "remarks"],
    sampleRows: 5,
    lastUploaded: "2024-03-20",
  },
  {
    id: "TPL004",
    name: "Previous Dues",
    description: "Import previous year dues for students",
    icon: Clock,
    columns: ["admission_no", "academic_year", "description", "amount", "due_date"],
    sampleRows: 5,
    lastUploaded: "2024-04-01",
  },
  {
    id: "TPL005",
    name: "Transport Assignments",
    description: "Assign transport routes and slabs",
    icon: FileSpreadsheet,
    columns: ["admission_no", "route_id", "stop_name", "distance_km", "start_date"],
    sampleRows: 5,
    lastUploaded: "2024-03-15",
  },
]

// Upload history
const uploadHistory = [
  {
    id: "UPL001",
    fileName: "students_batch_april_2024.xlsx",
    type: "Students",
    uploadedBy: "Admin",
    uploadedAt: "2024-04-10 09:30",
    totalRecords: 150,
    processed: 150,
    success: 145,
    failed: 5,
    status: "completed",
    errors: [
      { row: 23, error: "Invalid phone number format" },
      { row: 45, error: "Duplicate admission number" },
      { row: 67, error: "Missing required field: father_name" },
      { row: 89, error: "Invalid date format for DOB" },
      { row: 112, error: "Class not found: Class 13" },
    ],
  },
  {
    id: "UPL002",
    fileName: "fee_assignments_q2.xlsx",
    type: "Fee Assignments",
    uploadedBy: "Finance Manager",
    uploadedAt: "2024-04-05 14:15",
    totalRecords: 200,
    processed: 200,
    success: 200,
    failed: 0,
    status: "completed",
    errors: [],
  },
  {
    id: "UPL003",
    fileName: "scholarships_merit_2024.xlsx",
    type: "Scholarships",
    uploadedBy: "Admin",
    uploadedAt: "2024-03-20 11:00",
    totalRecords: 50,
    processed: 50,
    success: 48,
    failed: 2,
    status: "completed",
    errors: [
      { row: 12, error: "Student not found" },
      { row: 38, error: "Invalid scholarship ID" },
    ],
  },
  {
    id: "UPL004",
    fileName: "previous_dues_2023.xlsx",
    type: "Previous Dues",
    uploadedBy: "Accountant",
    uploadedAt: "2024-04-01 16:30",
    totalRecords: 75,
    processed: 75,
    success: 75,
    failed: 0,
    status: "completed",
    errors: [],
  },
  {
    id: "UPL005",
    fileName: "new_students_april.xlsx",
    type: "Students",
    uploadedBy: "Admin",
    uploadedAt: "2024-04-14 10:00",
    totalRecords: 100,
    processed: 65,
    success: 60,
    failed: 5,
    status: "processing",
    errors: [],
  },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "completed":
      return <Badge className="bg-green-500/10 text-green-600 border-green-200">Completed</Badge>
    case "processing":
      return <Badge className="bg-blue-500/10 text-blue-600 border-blue-200">Processing</Badge>
    case "failed":
      return <Badge className="bg-red-500/10 text-red-600 border-red-200">Failed</Badge>
    case "pending":
      return <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-200">Pending</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export function BulkUploadContent() {
  const [selectedTemplate, setSelectedTemplate] = useState<typeof uploadTemplates[0] | null>(null)
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [selectedUpload, setSelectedUpload] = useState<typeof uploadHistory[0] | null>(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)

  const stats = {
    totalUploads: uploadHistory.length,
    completed: uploadHistory.filter(u => u.status === "completed").length,
    processing: uploadHistory.filter(u => u.status === "processing").length,
    totalRecords: uploadHistory.reduce((sum, u) => sum + u.totalRecords, 0),
    successRecords: uploadHistory.reduce((sum, u) => sum + u.success, 0),
    failedRecords: uploadHistory.reduce((sum, u) => sum + u.failed, 0),
  }

  const handleUpload = () => {
    setIsUploading(true)
    setUploadProgress(0)
    
    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)
          return 100
        }
        return prev + 10
      })
    }, 500)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Bulk Upload</h1>
          <p className="text-muted-foreground">Import data in bulk using Excel/CSV files</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Uploads</CardTitle>
            <Upload className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalUploads}</div>
            <p className="text-xs text-muted-foreground">
              {stats.processing} in progress
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Records Processed</CardTitle>
            <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalRecords.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Total records uploaded
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {((stats.successRecords / stats.totalRecords) * 100).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              {stats.successRecords.toLocaleString()} successful
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed Records</CardTitle>
            <XCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.failedRecords}</div>
            <p className="text-xs text-muted-foreground">
              Requires attention
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="upload" className="space-y-4">
        <TabsList>
          <TabsTrigger value="upload">New Upload</TabsTrigger>
          <TabsTrigger value="history">Upload History</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {uploadTemplates.map((template) => (
              <Card 
                key={template.id} 
                className="cursor-pointer hover:shadow-md hover:border-primary/50 transition-all"
                onClick={() => {
                  setSelectedTemplate(template)
                  setShowUploadModal(true)
                }}
              >
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <template.icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{template.name}</CardTitle>
                      <CardDescription className="text-xs">{template.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Columns</span>
                    <span className="font-medium">{template.columns.length}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {template.columns.slice(0, 4).map(col => (
                      <Badge key={col} variant="secondary" className="text-xs">
                        {col}
                      </Badge>
                    ))}
                    {template.columns.length > 4 && (
                      <Badge variant="secondary" className="text-xs">
                        +{template.columns.length - 4}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <Button variant="outline" size="sm" className="gap-1" onClick={(e) => {
                      e.stopPropagation()
                    }}>
                      <Download className="h-3 w-3" />
                      Template
                    </Button>
                    <span className="text-xs text-muted-foreground">
                      Last: {template.lastUploaded}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upload History</CardTitle>
              <CardDescription>View and manage past uploads</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>File</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Uploaded By</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-center">Records</TableHead>
                    <TableHead className="text-center">Success</TableHead>
                    <TableHead className="text-center">Failed</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {uploadHistory.map((upload) => (
                    <TableRow key={upload.id} className="cursor-pointer hover:bg-muted/50" onClick={() => setSelectedUpload(upload)}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileSpreadsheet className="h-4 w-4 text-green-600" />
                          <span className="font-medium truncate max-w-[200px]">{upload.fileName}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{upload.type}</Badge>
                      </TableCell>
                      <TableCell>{upload.uploadedBy}</TableCell>
                      <TableCell className="text-muted-foreground">{upload.uploadedAt}</TableCell>
                      <TableCell className="text-center">{upload.totalRecords}</TableCell>
                      <TableCell className="text-center text-green-600 font-medium">{upload.success}</TableCell>
                      <TableCell className="text-center">
                        {upload.failed > 0 ? (
                          <span className="text-red-600 font-medium">{upload.failed}</span>
                        ) : (
                          <span className="text-muted-foreground">0</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {upload.status === "processing" ? (
                          <div className="flex items-center gap-2">
                            <Progress value={(upload.processed / upload.totalRecords) * 100} className="h-2 w-16" />
                            <span className="text-xs text-muted-foreground">{Math.round((upload.processed / upload.totalRecords) * 100)}%</span>
                          </div>
                        ) : (
                          getStatusBadge(upload.status)
                        )}
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setSelectedUpload(upload)}>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Download Report
                            </DropdownMenuItem>
                            {upload.failed > 0 && (
                              <DropdownMenuItem>
                                <AlertTriangle className="mr-2 h-4 w-4" />
                                View Errors
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Upload Modal */}
      <Dialog open={showUploadModal} onOpenChange={(open) => {
        if (!open) {
          setShowUploadModal(false)
          setSelectedTemplate(null)
          setUploadProgress(0)
          setIsUploading(false)
        }
      }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Upload {selectedTemplate?.name}</DialogTitle>
            <DialogDescription>{selectedTemplate?.description}</DialogDescription>
          </DialogHeader>
          {selectedTemplate && (
            <div className="space-y-4">
              {!isUploading && uploadProgress < 100 ? (
                <>
                  <div className="border-2 border-dashed rounded-lg p-8 text-center">
                    <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                    <p className="text-sm font-medium">Drag and drop your file here</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Supported formats: Excel (.xlsx, .xls) and CSV
                    </p>
                    <Input type="file" className="hidden" accept=".xlsx,.xls,.csv" />
                    <Button variant="outline" size="sm" className="mt-4">
                      Browse Files
                    </Button>
                  </div>

                  <div>
                    <p className="text-sm font-medium mb-2">Required Columns</p>
                    <div className="flex flex-wrap gap-1">
                      {selectedTemplate.columns.map(col => (
                        <Badge key={col} variant="outline" className="text-xs font-mono">
                          {col}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm">Download sample template</span>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Download className="h-4 w-4" />
                      Download
                    </Button>
                  </div>
                </>
              ) : (
                <div className="space-y-4 py-4">
                  <div className="text-center">
                    {uploadProgress < 100 ? (
                      <>
                        <RefreshCw className="h-10 w-10 mx-auto text-primary animate-spin mb-3" />
                        <p className="font-medium">Processing your file...</p>
                        <p className="text-sm text-muted-foreground">This may take a few minutes</p>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="h-10 w-10 mx-auto text-green-500 mb-3" />
                        <p className="font-medium">Upload Complete!</p>
                        <p className="text-sm text-muted-foreground">Your data has been processed</p>
                      </>
                    )}
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{uploadProgress}%</span>
                    </div>
                    <Progress value={uploadProgress} className="h-2" />
                  </div>
                  {uploadProgress >= 100 && (
                    <div className="grid grid-cols-3 gap-4 p-3 bg-muted/50 rounded-lg text-center">
                      <div>
                        <p className="text-2xl font-bold">150</p>
                        <p className="text-xs text-muted-foreground">Total</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-green-600">145</p>
                        <p className="text-xs text-muted-foreground">Success</p>
                      </div>
                      <div>
                        <p className="text-2xl font-bold text-red-600">5</p>
                        <p className="text-xs text-muted-foreground">Failed</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            {uploadProgress >= 100 ? (
              <>
                <Button variant="outline" onClick={() => {
                  setShowUploadModal(false)
                  setSelectedTemplate(null)
                  setUploadProgress(0)
                }}>Close</Button>
                <Button className="gap-2">
                  <Download className="h-4 w-4" />
                  Download Report
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => {
                  setShowUploadModal(false)
                  setSelectedTemplate(null)
                }} disabled={isUploading}>Cancel</Button>
                <Button onClick={handleUpload} disabled={isUploading}>
                  {isUploading ? "Uploading..." : "Upload & Process"}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Upload Detail Modal */}
      <Dialog open={!!selectedUpload} onOpenChange={() => setSelectedUpload(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Upload Details</DialogTitle>
            <DialogDescription>{selectedUpload?.fileName}</DialogDescription>
          </DialogHeader>
          {selectedUpload && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Records</p>
                        <p className="text-2xl font-bold">{selectedUpload.totalRecords}</p>
                      </div>
                      <FileSpreadsheet className="h-8 w-8 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Success Rate</p>
                        <p className="text-2xl font-bold text-green-600">
                          {((selectedUpload.success / selectedUpload.totalRecords) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <CheckCircle2 className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-4 gap-4 text-center">
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-lg font-bold">{selectedUpload.totalRecords}</p>
                  <p className="text-xs text-muted-foreground">Total</p>
                </div>
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-lg font-bold">{selectedUpload.processed}</p>
                  <p className="text-xs text-muted-foreground">Processed</p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <p className="text-lg font-bold text-green-600">{selectedUpload.success}</p>
                  <p className="text-xs text-muted-foreground">Success</p>
                </div>
                <div className="p-3 bg-red-50 rounded-lg">
                  <p className="text-lg font-bold text-red-600">{selectedUpload.failed}</p>
                  <p className="text-xs text-muted-foreground">Failed</p>
                </div>
              </div>

              {selectedUpload.errors.length > 0 && (
                <div>
                  <p className="font-medium mb-2">Errors ({selectedUpload.errors.length})</p>
                  <div className="border rounded-lg max-h-[200px] overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[80px]">Row</TableHead>
                          <TableHead>Error</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedUpload.errors.map((error, idx) => (
                          <TableRow key={idx}>
                            <TableCell className="font-mono">{error.row}</TableCell>
                            <TableCell className="text-red-600">{error.error}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              <div className="text-sm text-muted-foreground">
                <p>Uploaded by {selectedUpload.uploadedBy} on {selectedUpload.uploadedAt}</p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedUpload(null)}>Close</Button>
            {selectedUpload?.failed && selectedUpload.failed > 0 && (
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Download Error Report
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
