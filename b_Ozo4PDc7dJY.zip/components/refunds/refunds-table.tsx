"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Eye, MoreHorizontal, Ban, CheckCircle, ArrowRight, Landmark, XCircle, Layers } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export interface SplitTransaction {
  transactionId: string
  amount: number
  paymentMode: string
  gateway: string
  status: "processed" | "pending" | "initiated" | "failed"
  arn?: string
  // Source account where refund will be credited
  sourceAccount: {
    type: "credit_card" | "debit_card" | "net_banking" | "upi" | "wallet"
    cardType?: string // Visa, Mastercard, Rupay etc.
    cardNumber?: string // masked e.g. XXXX XXXX XXXX 4532
    cardHolder?: string
    bankName: string
    accountNumber?: string // for net banking
    upiId?: string // for UPI
    walletName?: string // for wallet
  }
}

export interface Refund {
  id: string
  transactionId: string
  orderId: string
  institute: string
  studentName: string
  studentId: string
  studentPhone: string
  orderAmount: number
  transactionAmount: number
  refundAmount: number
  gateway: string
  accountType: "merchant" | "vendor"
  // Split and Pay - multiple transactions for single order (full refund only)
  isSplitPayment?: boolean
  splitTransactions?: SplitTransaction[]
  merchantAccount?: {
    merchantName: string
    merchantId: string
    accountNumber: string
    ifscCode: string
    bankName: string
  }
  vendorAccount?: {
    vendorName: string
    vendorCode: string
    vendorAccountId: string
    accountNumber: string
    ifscCode: string
    bankName: string
  }
  status: "processed" | "pending" | "initiated" | "failed" | "rejected"
  reason: string
  requestedBy: string
  requestedAt: string
  createdDate: string
  updatedDate: string
  processedAt?: string
  arn?: string
  paymentMode: string
  studentEmail: string
  studentMobile: string
  originalSettlement?: {
    id: string
    date: string
    institute: string
  }
  adjustedFromSettlement?: {
    id: string
    date: string
    adjustmentDate: string
  }
}

const refunds: Refund[] = [
  {
    id: "RFD001234",
    transactionId: "TXN001234573",
    orderId: "ORD-SMC-2024-007",
    institute: "Delhi Public School",
    studentName: "Rohan Joshi",
    studentId: "STU-SMC-001",
    studentPhone: "+91 32109 87654",
    orderAmount: 42000,
    transactionAmount: 41370,
    refundAmount: 42000,
    gateway: "NTT Atom",
    accountType: "merchant",
    merchantAccount: {
      merchantName: "St. Mary's College",
      merchantId: "MID-SMC-NTT-001",
      accountNumber: "XXXX XXXX 4521",
      ifscCode: "HDFC0001234",
      bankName: "HDFC Bank",
    },
    status: "processed",
    reason: "Course cancellation",
    requestedBy: "Admin - Priya Sharma",
    requestedAt: "2024-01-15 11:30",
    createdDate: "2024-01-15",
    updatedDate: "2024-01-15",
    processedAt: "2024-01-15 14:45",
    arn: "ARN2024011500012345",
    paymentMode: "Credit Card",
    studentEmail: "rohan.joshi@gmail.com",
    studentMobile: "+91 32109 87654",
    originalSettlement: {
      id: "SETTLE-085",
      date: "2024-01-10",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: {
      id: "SETTLE-090",
      date: "2024-01-16",
      adjustmentDate: "2024-01-15",
    },
  },
  {
    id: "RFD001235",
    transactionId: "TXN001234580",
    orderId: "ORD-AMT-2024-011",
    institute: "Delhi Public School",
    studentName: "Pooja Reddy",
    studentId: "STU-AMT-002",
    studentPhone: "+91 98765 12345",
    orderAmount: 125000,
    transactionAmount: 123125,
    refundAmount: 100000,
    gateway: "Razorpay",
    accountType: "merchant",
    merchantAccount: {
      merchantName: "Amity University",
      merchantId: "MID-AMT-RZP-001",
      accountNumber: "XXXX XXXX 7823",
      ifscCode: "ICIC0002345",
      bankName: "ICICI Bank",
    },
    status: "pending",
    reason: "Partial refund - Hostel fee adjustment",
    requestedBy: "Finance - Rahul Mehta",
    requestedAt: "2024-01-16 09:15",
    createdDate: "2024-01-16",
    updatedDate: "2024-01-16",
    paymentMode: "Net Banking",
    studentEmail: "pooja.reddy@amity.edu",
    studentMobile: "+91 98765 12345",
    originalSettlement: {
      id: "SETTLE-082",
      date: "2024-01-08",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: undefined,
  },
  {
    id: "RFD001236",
    transactionId: "TXN001234567",
    orderId: "ORD-DPS-2024-001",
    institute: "Delhi Public School",
    studentName: "Rahul Sharma",
    studentId: "STU-DPS-003",
    studentPhone: "+91 98765 43210",
    orderAmount: 45000,
    transactionAmount: 44325,
    refundAmount: 45000,
    gateway: "Razorpay",
    accountType: "vendor",
    vendorAccount: {
      vendorName: "DPS Transport Services",
      vendorCode: "VND-DPS-TRANS",
      vendorAccountId: "VA-RZP-DPS-001",
      accountNumber: "XXXX XXXX 3456",
      ifscCode: "SBIN0003456",
      bankName: "State Bank of India",
    },
    status: "initiated",
    reason: "Duplicate payment",
    requestedBy: "Parent Request",
    requestedAt: "2024-01-16 10:30",
    createdDate: "2024-01-16",
    updatedDate: "2024-01-16",
    paymentMode: "Credit Card",
    studentEmail: "rahul.sharma@gmail.com",
    studentMobile: "+91 98765 43210",
    originalSettlement: {
      id: "SETTLE-088",
      date: "2024-01-12",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: undefined,
  },
  {
    id: "RFD001237",
    transactionId: "TXN001234590",
    orderId: "ORD-MOD-2024-012",
    institute: "Delhi Public School",
    studentName: "Arjun Kapoor",
    studentId: "STU-MOD-004",
    studentPhone: "+91 87654 32100",
    orderAmount: 28000,
    transactionAmount: 27580,
    refundAmount: 28000,
    gateway: "Cashfree",
    accountType: "merchant",
    merchantAccount: {
      merchantName: "Modern School Trust",
      merchantId: "MID-MOD-CF-001",
      accountNumber: "XXXX XXXX 9012",
      ifscCode: "AXIS0004567",
      bankName: "Axis Bank",
    },
    status: "failed",
    reason: "Bank account closed",
    requestedBy: "Admin - Neha Singh",
    requestedAt: "2024-01-14 15:20",
    createdDate: "2024-01-14",
    updatedDate: "2024-01-14",
    paymentMode: "UPI",
    studentEmail: "arjun.kapoor@yahoo.com",
    studentMobile: "+91 87654 32100",
    originalSettlement: {
      id: "SETTLE-080",
      date: "2024-01-06",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: {
      id: "SETTLE-086",
      date: "2024-01-14",
      adjustmentDate: "2024-01-14",
    },
  },
  {
    id: "RFD001238",
    transactionId: "TXN001234595",
    orderId: "ORD-RYN-2024-013",
    institute: "Delhi Public School",
    studentName: "Meera Patel",
    studentId: "STU-RYN-005",
    studentPhone: "+91 76543 21098",
    orderAmount: 67000,
    transactionAmount: 65995,
    refundAmount: 67000,
    gateway: "Easebuzz",
    accountType: "vendor",
    vendorAccount: {
      vendorName: "Ryan Hostel Services",
      vendorCode: "VND-RYN-HOST",
      vendorAccountId: "VA-EB-RYN-002",
      accountNumber: "XXXX XXXX 6789",
      ifscCode: "UTIB0005678",
      bankName: "Axis Bank",
    },
    status: "rejected",
    reason: "Exceeds refund window (90 days)",
    requestedBy: "Parent Request",
    requestedAt: "2024-01-13 11:45",
    createdDate: "2024-01-13",
    updatedDate: "2024-01-13",
    paymentMode: "Debit Card",
    studentEmail: "meera.patel@outlook.com",
    studentMobile: "+91 76543 21098",
    originalSettlement: {
      id: "SETTLE-045",
      date: "2023-10-15",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: undefined,
  },
  {
    id: "RFD001239",
    transactionId: "TXN001234600",
    orderId: "ORD-SMC-2024-014",
    institute: "Delhi Public School",
    studentName: "Vikrant Desai",
    studentId: "STU-SMC-006",
    studentPhone: "+91 65432 10987",
    orderAmount: 35000,
    transactionAmount: 34475,
    refundAmount: 17500,
    gateway: "Paytm",
    accountType: "merchant",
    merchantAccount: {
      merchantName: "St. Mary's College",
      merchantId: "MID-SMC-PTM-001",
      accountNumber: "XXXX XXXX 4521",
      ifscCode: "HDFC0001234",
      bankName: "HDFC Bank",
    },
    status: "processed",
    reason: "50% refund - Mid-term withdrawal",
    requestedBy: "Admin - Priya Sharma",
    requestedAt: "2024-01-12 09:00",
    createdDate: "2024-01-12",
    updatedDate: "2024-01-12",
    processedAt: "2024-01-12 16:30",
    arn: "ARN2024011200098765",
    paymentMode: "UPI",
    studentEmail: "vikrant.desai@gmail.com",
    studentMobile: "+91 65432 10987",
    originalSettlement: {
      id: "SETTLE-078",
      date: "2024-01-04",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: {
      id: "SETTLE-084",
      date: "2024-01-13",
      adjustmentDate: "2024-01-12",
    },
  },
  {
    id: "RFD001240",
    transactionId: "SPLIT-ORD-KV-2024-015",
    orderId: "ORD-KV-2024-015",
    institute: "Delhi Public School",
    studentName: "Aditya Verma",
    studentId: "STU-KV-007",
    studentPhone: "+91 99887 76655",
    orderAmount: 85000,
    transactionAmount: 83725,
    refundAmount: 85000,
    gateway: "Multiple",
    accountType: "merchant",
    isSplitPayment: true,
    splitTransactions: [
      {
        transactionId: "TXN001234610",
        amount: 35000,
        paymentMode: "Credit Card",
        gateway: "Razorpay",
        status: "processed",
        arn: "ARN2024011700011111",
        sourceAccount: {
          type: "credit_card",
          cardType: "Visa",
          cardNumber: "XXXX XXXX XXXX 4532",
          cardHolder: "Aditya Verma",
          bankName: "HDFC Bank",
        },
      },
      {
        transactionId: "TXN001234611",
        amount: 30000,
        paymentMode: "Net Banking",
        gateway: "Razorpay",
        status: "processed",
        arn: "ARN2024011700022222",
        sourceAccount: {
          type: "net_banking",
          bankName: "State Bank of India",
          accountNumber: "XXXX XXXX 7890",
          cardHolder: "Aditya Verma",
        },
      },
      {
        transactionId: "TXN001234612",
        amount: 20000,
        paymentMode: "UPI",
        gateway: "Paytm",
        status: "processed",
        arn: "ARN2024011700033333",
        sourceAccount: {
          type: "upi",
          upiId: "aditya.verma@okicici",
          bankName: "ICICI Bank",
        },
      },
    ],
    merchantAccount: {
      merchantName: "Kendriya Vidyalaya Sangathan",
      merchantId: "MID-KV-RZP-001",
      accountNumber: "XXXX XXXX 1234",
      ifscCode: "SBIN0001234",
      bankName: "State Bank of India",
    },
    status: "processed",
    reason: "Full refund - Admission cancelled (Split & Pay)",
    requestedBy: "Admin - Suresh Kumar",
    requestedAt: "2024-01-17 10:00",
    createdDate: "2024-01-17",
    updatedDate: "2024-01-17",
    processedAt: "2024-01-17 15:30",
    paymentMode: "Split & Pay",
    studentEmail: "aditya.verma@gmail.com",
    studentMobile: "+91 99887 76655",
    originalSettlement: {
      id: "SETTLE-092",
      date: "2024-01-14",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: {
      id: "SETTLE-095",
      date: "2024-01-18",
      adjustmentDate: "2024-01-17",
    },
  },
  {
    id: "RFD001241",
    transactionId: "SPLIT-ORD-DAV-2024-016",
    orderId: "ORD-DAV-2024-016",
    institute: "Delhi Public School",
    studentName: "Priya Singh",
    studentId: "STU-DAV-008",
    studentPhone: "+91 88776 65544",
    orderAmount: 120000,
    transactionAmount: 118200,
    refundAmount: 120000,
    gateway: "Multiple",
    accountType: "merchant",
    isSplitPayment: true,
    splitTransactions: [
      {
        transactionId: "TXN001234620",
        amount: 50000,
        paymentMode: "Credit Card",
        gateway: "Cashfree",
        status: "processed",
        arn: "ARN2024011800044444",
        sourceAccount: {
          type: "credit_card",
          cardType: "MasterCard",
          cardNumber: "XXXX XXXX XXXX 8765",
          cardHolder: "Rajesh Singh",
          bankName: "Axis Bank",
        },
      },
      {
        transactionId: "TXN001234621",
        amount: 70000,
        paymentMode: "Debit Card",
        gateway: "Cashfree",
        status: "pending",
        sourceAccount: {
          type: "debit_card",
          cardType: "Rupay",
          cardNumber: "XXXX XXXX XXXX 3456",
          cardHolder: "Priya Singh",
          bankName: "HDFC Bank",
        },
      },
    ],
    merchantAccount: {
      merchantName: "DAV Public School Trust",
      merchantId: "MID-DAV-CF-001",
      accountNumber: "XXXX XXXX 5678",
      ifscCode: "HDFC0005678",
      bankName: "HDFC Bank",
    },
    status: "pending",
    reason: "Full refund - Course not available (Split & Pay)",
    requestedBy: "Parent Request",
    requestedAt: "2024-01-18 09:30",
    createdDate: "2024-01-18",
    updatedDate: "2024-01-18",
    paymentMode: "Split & Pay",
    studentEmail: "priya.singh@yahoo.com",
    studentMobile: "+91 88776 65544",
    originalSettlement: {
      id: "SETTLE-094",
      date: "2024-01-16",
      institute: "Delhi Public School",
    },
    adjustedFromSettlement: undefined,
  },
]

const statusColors = {
  processed: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  initiated: "bg-info/10 text-info border-info/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
  rejected: "bg-muted text-muted-foreground border-muted",
}

interface RefundsTableProps {
  gateway: string
  status: string
  vendor: string
  searchQuery: string
  dateRange: string
}

export function RefundsTable({ gateway, status, vendor, searchQuery, dateRange }: RefundsTableProps) {
  const [currentPage, setCurrentPage] = useState(1)
  const [rowsPerPage, setRowsPerPage] = useState("10")

  const filteredRefunds = refunds.filter((r) => {
    if (gateway !== "all" && !r.gateway.toLowerCase().includes(gateway)) return false
    if (status !== "all" && r.status !== status) return false
    if (vendor !== "all" && r.accountType !== vendor) return false
    if (searchQuery) {
      const search = searchQuery.toLowerCase()
      const matchesSearch = 
        r.id.toLowerCase().includes(search) ||
        r.orderId.toLowerCase().includes(search) ||
        r.studentName.toLowerCase().includes(search) ||
        r.studentId.toLowerCase().includes(search) ||
        r.studentPhone.toLowerCase().includes(search) ||
        r.institute.toLowerCase().includes(search) ||
        r.reason.toLowerCase().includes(search)
      if (!matchesSearch) return false
    }
    return true
  })

  const totalPages = Math.ceil(filteredRefunds.length / parseInt(rowsPerPage))
  const paginatedRefunds = filteredRefunds.slice(
    (currentPage - 1) * parseInt(rowsPerPage),
    currentPage * parseInt(rowsPerPage)
  )

  const handleCancelRefund = (refund: Refund) => {
    alert(`Cancel refund ${refund.id} - This would call an API in production`)
  }

  return (
    <TooltipProvider>
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">{filteredRefunds.length} Refunds</CardTitle>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Rows per page:</span>
              <Select value={rowsPerPage} onValueChange={(v) => { setRowsPerPage(v); setCurrentPage(1) }}>
                <SelectTrigger className="w-20 h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Sr.No</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Refund ID</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Order ID</th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">Refund Amt</th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">Order Amt</th>
                  <th className="p-4 text-right text-xs font-medium uppercase text-muted-foreground">Transaction Amt</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Created Date</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Updated Date</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Reason</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Gateway</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Account</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Refunded From</th>
                  <th className="p-4 text-center text-xs font-medium uppercase text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {paginatedRefunds.length === 0 ? (
                  <tr>
                    <td colSpan={14} className="text-center py-8 text-muted-foreground">
                      No refunds found
                    </td>
                  </tr>
                ) : (
                  paginatedRefunds.map((refund, idx) => (
                    <tr key={refund.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                      <td className="p-4 text-sm">{(currentPage - 1) * parseInt(rowsPerPage) + idx + 1}</td>
                      <td className="p-4">
                        <Link
                          href={`/refunds/${refund.id}`}
                          className="font-mono text-sm font-medium text-primary hover:underline"
                        >
                          {refund.id}
                        </Link>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">{refund.orderId}</span>
                          {refund.isSplitPayment && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge variant="outline" className="bg-indigo-500/10 text-indigo-500 border-indigo-500/20 text-xs cursor-help">
                                  <Layers className="h-3 w-3 mr-1" />
                                  Split
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-md p-3">
                                <div className="space-y-2">
                                  <p className="font-semibold text-sm border-b pb-2">Split & Pay - {refund.splitTransactions?.length} Transactions</p>
                                  <div className="flex items-center gap-2 text-xs">
                                    <Badge className="bg-warning/20 text-warning border-transparent">Full Refund Only</Badge>
                                    <span className="text-muted-foreground">Refund to respective source accounts</span>
                                  </div>
                                  <div className="space-y-3 mt-2">
                                    {refund.splitTransactions?.map((txn, i) => (
                                      <div key={txn.transactionId} className="bg-secondary/50 rounded p-2 text-xs border border-border/50">
                                        <div className="flex justify-between items-center">
                                          <span className="font-mono text-primary">{txn.transactionId}</span>
                                          <Badge variant="outline" className={`text-[10px] ${txn.status === 'processed' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}`}>
                                            {txn.status.toUpperCase()}
                                          </Badge>
                                        </div>
                                        <div className="flex justify-between mt-1 text-muted-foreground">
                                          <span>{txn.paymentMode} via {txn.gateway}</span>
                                          <span className="font-semibold text-foreground">₹{txn.amount.toLocaleString()}</span>
                                        </div>
                                        {/* Refund Destination */}
                                        <div className="mt-2 pt-2 border-t border-border/50 bg-background/50 rounded p-1.5">
                                          <p className="text-[10px] text-muted-foreground mb-1">Refund To:</p>
                                          {txn.sourceAccount.type === 'credit_card' || txn.sourceAccount.type === 'debit_card' ? (
                                            <div className="text-xs">
                                              <p className="font-medium">{txn.sourceAccount.cardType} {txn.sourceAccount.type === 'credit_card' ? 'Credit Card' : 'Debit Card'}</p>
                                              <p className="font-mono text-muted-foreground">{txn.sourceAccount.cardNumber}</p>
                                              <p className="text-muted-foreground">{txn.sourceAccount.cardHolder} - {txn.sourceAccount.bankName}</p>
                                            </div>
                                          ) : txn.sourceAccount.type === 'net_banking' ? (
                                            <div className="text-xs">
                                              <p className="font-medium">Net Banking - {txn.sourceAccount.bankName}</p>
                                              <p className="font-mono text-muted-foreground">A/C: {txn.sourceAccount.accountNumber}</p>
                                            </div>
                                          ) : txn.sourceAccount.type === 'upi' ? (
                                            <div className="text-xs">
                                              <p className="font-medium">UPI - {txn.sourceAccount.bankName}</p>
                                              <p className="font-mono text-muted-foreground">{txn.sourceAccount.upiId}</p>
                                            </div>
                                          ) : txn.sourceAccount.type === 'wallet' ? (
                                            <div className="text-xs">
                                              <p className="font-medium">{txn.sourceAccount.walletName} Wallet</p>
                                            </div>
                                          ) : null}
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                  <div className="border-t pt-2 flex justify-between font-semibold">
                                    <span>Total Refund Amount</span>
                                    <span className="text-success">₹{refund.orderAmount.toLocaleString()}</span>
                                  </div>
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                      </td>
                      <td className="p-4 text-right">
                        <span className="font-bold text-warning">₹{refund.refundAmount.toLocaleString()}</span>
                      </td>
                      <td className="p-4 text-right">
                        <span className="font-semibold">₹{refund.orderAmount.toLocaleString()}</span>
                      </td>
                      <td className="p-4 text-right">
                        <span className="text-sm">₹{refund.transactionAmount.toLocaleString()}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant="outline" className={statusColors[refund.status]}>
                          {refund.status.toUpperCase()}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <span className="text-sm">{refund.createdDate}</span>
                      </td>
                      <td className="p-4">
                        <span className="text-sm">{refund.updatedDate}</span>
                      </td>
                      <td className="p-4">
                        <span className="text-sm max-w-32 truncate block" title={refund.reason}>{refund.reason}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant="outline" className="text-xs">
                          {refund.gateway}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <Badge variant="outline" className={`text-xs ${refund.accountType === 'vendor' ? 'bg-purple-500/10 text-purple-500' : 'bg-blue-500/10 text-blue-500'}`}>
                          {refund.accountType === 'vendor' ? 'Vendor' : 'Merchant'}
                        </Badge>
                      </td>
                      <td className="p-4">
                        {refund.accountType === 'vendor' && refund.vendorAccount ? (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="cursor-help">
                                <p className="text-sm font-medium text-purple-600">{refund.vendorAccount.vendorName}</p>
                                <p className="text-xs text-muted-foreground font-mono">{refund.vendorAccount.accountNumber}</p>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs p-3">
                              <div className="space-y-2 text-xs">
                                <p className="font-semibold text-sm border-b pb-2">Vendor Account Details</p>
                                <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                                  <p className="text-muted-foreground">Vendor Name:</p>
                                  <p className="font-medium">{refund.vendorAccount.vendorName}</p>
                                  <p className="text-muted-foreground">Vendor Code:</p>
                                  <p className="font-mono">{refund.vendorAccount.vendorCode}</p>
                                  <p className="text-muted-foreground">Account ID:</p>
                                  <p className="font-mono">{refund.vendorAccount.vendorAccountId}</p>
                                  <p className="text-muted-foreground">Account No:</p>
                                  <p className="font-mono">{refund.vendorAccount.accountNumber}</p>
                                  <p className="text-muted-foreground">IFSC Code:</p>
                                  <p className="font-mono">{refund.vendorAccount.ifscCode}</p>
                                  <p className="text-muted-foreground">Bank:</p>
                                  <p>{refund.vendorAccount.bankName}</p>
                                </div>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        ) : refund.merchantAccount ? (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="cursor-help">
                                <p className="text-sm font-medium text-blue-600">{refund.merchantAccount.merchantName}</p>
                                <p className="text-xs text-muted-foreground font-mono">{refund.merchantAccount.accountNumber}</p>
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs p-3">
                              <div className="space-y-2 text-xs">
                                <p className="font-semibold text-sm border-b pb-2">Merchant Account Details</p>
                                <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                                  <p className="text-muted-foreground">Merchant Name:</p>
                                  <p className="font-medium">{refund.merchantAccount.merchantName}</p>
                                  <p className="text-muted-foreground">Merchant ID:</p>
                                  <p className="font-mono">{refund.merchantAccount.merchantId}</p>
                                  <p className="text-muted-foreground">Account No:</p>
                                  <p className="font-mono">{refund.merchantAccount.accountNumber}</p>
                                  <p className="text-muted-foreground">IFSC Code:</p>
                                  <p className="font-mono">{refund.merchantAccount.ifscCode}</p>
                                  <p className="text-muted-foreground">Bank:</p>
                                  <p>{refund.merchantAccount.bankName}</p>
                                </div>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        ) : (
                          <div>
                            <p className="text-sm font-medium text-blue-600">Merchant Account</p>
                            <p className="text-xs text-muted-foreground">{refund.institute}</p>
                          </div>
                        )}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1">
                          <Link href={`/refunds/${refund.id}`}>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </Link>
                          {(refund.status === "pending" || refund.status === "initiated") && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              onClick={() => handleCancelRefund(refund)}
                            >
                              <XCircle className="h-4 w-4" />
                            </Button>
                          )}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem asChild>
                                <Link href={`/refunds/${refund.id}`}>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Details
                                </Link>
                              </DropdownMenuItem>
                              {(refund.status === "pending" || refund.status === "initiated") && (
                                <>
                                  <DropdownMenuItem>
                                    <CheckCircle className="mr-2 h-4 w-4" />
                                    Approve Refund
                                  </DropdownMenuItem>
                                  <DropdownMenuItem className="text-destructive">
                                    <Ban className="mr-2 h-4 w-4" />
                                    Reject Refund
                                  </DropdownMenuItem>
                                </>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-border p-4">
            <p className="text-sm text-muted-foreground">
              Showing {paginatedRefunds.length > 0 ? (currentPage - 1) * parseInt(rowsPerPage) + 1 : 0} to {Math.min(currentPage * parseInt(rowsPerPage), filteredRefunds.length)} of {filteredRefunds.length} refunds
            </p>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(p => p - 1)}
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              <span className="text-sm">Page {currentPage} of {totalPages || 1}</span>
              <Button 
                variant="outline" 
                size="sm" 
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage(p => p + 1)}
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  )
}
