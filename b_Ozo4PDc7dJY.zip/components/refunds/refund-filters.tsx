"use client"

import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"

interface RefundFiltersProps {
  selectedGateway: string
  setSelectedGateway: (value: string) => void
  selectedStatus: string
  setSelectedStatus: (value: string) => void
  dateRange: string
  setDateRange: (value: string) => void
  selectedVendor: string
  setSelectedVendor: (value: string) => void
  searchQuery: string
  setSearchQuery: (value: string) => void
}

export function RefundFilters({
  selectedGateway,
  setSelectedGateway,
  selectedStatus,
  setSelectedStatus,
  dateRange,
  setDateRange,
  selectedVendor,
  setSelectedVendor,
  searchQuery,
  setSearchQuery,
}: RefundFiltersProps) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="flex flex-wrap items-center gap-4 p-4">
        <div className="relative flex-1 min-w-[250px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input 
            placeholder="Search by Refund ID, Order ID, Student Name, Phone..." 
            className="bg-secondary pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Select value={dateRange} onValueChange={setDateRange}>
          <SelectTrigger className="w-36 bg-secondary">
            <SelectValue placeholder="Date Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Time</SelectItem>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedGateway} onValueChange={setSelectedGateway}>
          <SelectTrigger className="w-40 bg-secondary">
            <SelectValue placeholder="All Gateways" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Gateways</SelectItem>
            <SelectItem value="razorpay">Razorpay</SelectItem>
            <SelectItem value="cashfree">Cashfree</SelectItem>
            <SelectItem value="easebuzz">Easebuzz</SelectItem>
            <SelectItem value="paytm">Paytm</SelectItem>
            <SelectItem value="ntt">NTT Atom</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
          <SelectTrigger className="w-36 bg-secondary">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="processed">Processed</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="initiated">Initiated</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedVendor} onValueChange={setSelectedVendor}>
          <SelectTrigger className="w-36 bg-secondary">
            <SelectValue placeholder="Account Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Accounts</SelectItem>
            <SelectItem value="merchant">Merchant</SelectItem>
            <SelectItem value="vendor">Vendor</SelectItem>
          </SelectContent>
        </Select>
      </CardContent>
    </Card>
  )
}
