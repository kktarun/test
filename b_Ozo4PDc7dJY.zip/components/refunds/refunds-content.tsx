"use client"

import { useState } from "react"
import { RefundStats } from "./refund-stats"
import { RefundFilters } from "./refund-filters"
import { RefundsTable } from "./refunds-table"
import { Button } from "@/components/ui/button"
import { Download, RefreshCw, Plus } from "lucide-react"
import { InitiateRefundModal } from "./initiate-refund-modal"

export function RefundsContent() {
  const [selectedGateway, setSelectedGateway] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [dateRange, setDateRange] = useState("all")
  const [selectedVendor, setSelectedVendor] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [showInitiateModal, setShowInitiateModal] = useState(false)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Refund Portal</h1>
          <p className="text-muted-foreground">Manage and track all refund requests across payment gateways</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <RefreshCw className="h-4 w-4" />
            Sync
          </Button>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button size="sm" className="gap-2" onClick={() => setShowInitiateModal(true)}>
            <Plus className="h-4 w-4" />
            Initiate Refund
          </Button>
        </div>
      </div>

      <RefundStats />

      <RefundFilters
        selectedGateway={selectedGateway}
        setSelectedGateway={setSelectedGateway}
        selectedStatus={selectedStatus}
        setSelectedStatus={setSelectedStatus}
        dateRange={dateRange}
        setDateRange={setDateRange}
        selectedVendor={selectedVendor}
        setSelectedVendor={setSelectedVendor}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      <RefundsTable 
        gateway={selectedGateway} 
        status={selectedStatus} 
        vendor={selectedVendor}
        searchQuery={searchQuery}
        dateRange={dateRange}
      />

      <InitiateRefundModal open={showInitiateModal} onOpenChange={setShowInitiateModal} />
    </div>
  )
}
