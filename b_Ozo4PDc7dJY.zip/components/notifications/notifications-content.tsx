"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { 
  Bell,
  Mail,
  MessageSquare,
  Smartphone,
  Plus,
  Edit2,
  Trash2,
  Copy,
  Eye,
  Send,
  Clock,
  CheckCircle2,
  AlertCircle,
  Zap,
  CreditCard,
  Calendar,
  FileText,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  IndianRupee,
  History,
} from "lucide-react"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"
import { Checkbox } from "@/components/ui/checkbox"

const notificationEvents = [
  {
    id: "payment_received",
    name: "Payment Received",
    description: "When a payment is successfully processed",
    icon: CreditCard,
    sms: true,
    email: true,
    whatsapp: true,
    push: true,
  },
  {
    id: "payment_failed",
    name: "Payment Failed",
    description: "When a payment attempt fails",
    icon: AlertCircle,
    sms: true,
    email: true,
    whatsapp: false,
    push: true,
  },
  {
    id: "fee_due_reminder",
    name: "Fee Due Reminder",
    description: "Reminder before fee due date",
    icon: Calendar,
    sms: true,
    email: true,
    whatsapp: true,
    push: true,
  },
  {
    id: "fee_overdue",
    name: "Fee Overdue",
    description: "When fee payment is past due date",
    icon: Clock,
    sms: true,
    email: true,
    whatsapp: true,
    push: false,
  },
  {
    id: "receipt_generated",
    name: "Receipt Generated",
    description: "When payment receipt is ready",
    icon: FileText,
    sms: false,
    email: true,
    whatsapp: true,
    push: false,
  },
  {
    id: "new_fee_assigned",
    name: "New Fee Assigned",
    description: "When new fee is assigned to student",
    icon: Zap,
    sms: false,
    email: true,
    whatsapp: false,
    push: true,
  },
]

const templates = [
  {
    id: 1,
    name: "Payment Confirmation",
    event: "payment_received",
    channel: "SMS",
    content: "Dear Parent, payment of Rs.{amount} for {student_name} received. Receipt: {receipt_no}. Thank you - {institute_name}",
    status: "active",
    lastUsed: "2 hours ago",
    isRecurring: false,
    dltTemplateId: "1107165784532",
  },
  {
    id: 2,
    name: "Fee Reminder - 7 Days",
    event: "fee_due_reminder",
    channel: "WhatsApp",
    content: "Dear Parent, fee of Rs.{amount} for {student_name} is due on {due_date}. Pay now: {payment_link}",
    status: "active",
    lastUsed: "1 day ago",
    isRecurring: true,
    recurringDays: [7, 3, 1],
  },
  {
    id: 3,
    name: "Payment Failed Alert",
    event: "payment_failed",
    channel: "Email",
    content: "Your payment of Rs.{amount} for {student_name} could not be processed. Please try again.",
    status: "active",
    lastUsed: "3 days ago",
    isRecurring: false,
  },
  {
    id: 4,
    name: "Overdue Notice",
    event: "fee_overdue",
    channel: "SMS",
    content: "Dear Parent, fee of Rs.{amount} for {student_name} is overdue by {days} days. Please clear immediately.",
    status: "draft",
    lastUsed: "Never",
    isRecurring: true,
    recurringDays: [1, 7, 15, 30],
  },
]

const recentNotifications = [
  {
    id: 1,
    recipient: "Rahul Sharma",
    phone: "+91 98765 43210",
    template: "Payment Confirmation",
    channel: "SMS",
    status: "delivered",
    sentAt: "2024-01-15 10:30 AM",
    credits: 1,
  },
  {
    id: 2,
    recipient: "Priya Patel",
    phone: "+91 87654 32109",
    template: "Fee Reminder - 7 Days",
    channel: "WhatsApp",
    status: "delivered",
    sentAt: "2024-01-15 10:15 AM",
    credits: 1,
  },
  {
    id: 3,
    recipient: "Amit Kumar",
    phone: "+91 76543 21098",
    template: "Payment Confirmation",
    channel: "SMS",
    status: "failed",
    sentAt: "2024-01-15 09:45 AM",
    credits: 0,
  },
  {
    id: 4,
    recipient: "Sneha Reddy",
    email: "sneha@email.com",
    template: "Receipt Generated",
    channel: "Email",
    status: "delivered",
    sentAt: "2024-01-15 09:30 AM",
    credits: 0,
  },
]

const walletTransactions = [
  { id: 1, type: "credit", description: "Top-up via Razorpay", amount: 5000, balance: 10420, date: "2024-01-15 10:00 AM", reference: "PAY-20240115-001" },
  { id: 2, type: "debit", description: "SMS - Payment Confirmation (125 messages)", amount: 125, balance: 5420, date: "2024-01-14 06:00 PM", reference: "SMS-20240114-125" },
  { id: 3, type: "debit", description: "WhatsApp - Fee Reminder (89 messages)", amount: 178, balance: 5545, date: "2024-01-14 10:00 AM", reference: "WA-20240114-089" },
  { id: 4, type: "credit", description: "Top-up via PayU", amount: 2000, balance: 5723, date: "2024-01-12 02:30 PM", reference: "PAY-20240112-002" },
  { id: 5, type: "debit", description: "SMS - Overdue Notice (45 messages)", amount: 45, balance: 3723, date: "2024-01-11 09:00 AM", reference: "SMS-20240111-045" },
  { id: 6, type: "credit", description: "Initial Balance", amount: 3768, balance: 3768, date: "2024-01-01 12:00 AM", reference: "INIT-20240101" },
]

const topUpAmounts = [500, 1000, 2000, 5000, 10000]

export function NotificationsContent() {
  const [events, setEvents] = useState(notificationEvents)
  const [showTemplateDialog, setShowTemplateDialog] = useState(false)
  const [showPreviewDialog, setShowPreviewDialog] = useState(false)
  const [showTopUpDialog, setShowTopUpDialog] = useState(false)
  const [selectedTemplate, setSelectedTemplate] = useState<typeof templates[0] | null>(null)
  const [topUpAmount, setTopUpAmount] = useState("")
  const [customTopUpAmount, setCustomTopUpAmount] = useState("")
  const [isRecurring, setIsRecurring] = useState(false)
  const [recurringDays, setRecurringDays] = useState<number[]>([])

  const smsBalance = 5420
  const whatsappBalance = 3250

  const toggleChannel = (eventId: string, channel: 'sms' | 'email' | 'whatsapp' | 'push') => {
    setEvents(events.map(event => 
      event.id === eventId 
        ? { ...event, [channel]: !event[channel] }
        : event
    ))
  }

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case "SMS": return <Smartphone className="h-4 w-4" />
      case "Email": return <Mail className="h-4 w-4" />
      case "WhatsApp": return <MessageSquare className="h-4 w-4" />
      default: return <Bell className="h-4 w-4" />
    }
  }

  const toggleRecurringDay = (day: number) => {
    setRecurringDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day)
        : [...prev, day].sort((a, b) => b - a)
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold tracking-tight text-foreground">Notifications</h1>
        <p className="text-sm text-muted-foreground">
          Configure notification channels, templates, and manage communication wallet
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Send className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">1,234</p>
                <p className="text-sm text-muted-foreground">Sent Today</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                <CheckCircle2 className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">98.5%</p>
                <p className="text-sm text-muted-foreground">Delivery Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50 cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setShowTopUpDialog(true)}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-muted">
                  <Smartphone className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-semibold text-foreground">{smsBalance.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">SMS Credits</p>
                </div>
              </div>
              <Button size="sm" variant="ghost" className="h-8 text-primary">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50 cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setShowTopUpDialog(true)}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-green-500/10">
                  <MessageSquare className="h-6 w-6 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-semibold text-foreground">{whatsappBalance.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">WhatsApp Credits</p>
                </div>
              </div>
              <Button size="sm" variant="ghost" className="h-8 text-primary">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="events" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="events">Notification Events</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="wallet">Wallet & Top-up</TabsTrigger>
          <TabsTrigger value="history">Delivery History</TabsTrigger>
          <TabsTrigger value="channels">Channel Settings</TabsTrigger>
        </TabsList>

        {/* Events Tab */}
        <TabsContent value="events" className="space-y-4">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Notification Triggers</CardTitle>
              <CardDescription>
                Enable or disable notification channels for each event type
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {events.map((event) => (
                  <div
                    key={event.id}
                    className="flex items-center justify-between rounded-lg border border-border/50 p-4"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                        <event.icon className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{event.name}</p>
                        <p className="text-sm text-muted-foreground">{event.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={event.sms}
                          onCheckedChange={() => toggleChannel(event.id, 'sms')}
                        />
                        <span className="text-sm text-muted-foreground">SMS</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={event.email}
                          onCheckedChange={() => toggleChannel(event.id, 'email')}
                        />
                        <span className="text-sm text-muted-foreground">Email</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={event.whatsapp}
                          onCheckedChange={() => toggleChannel(event.id, 'whatsapp')}
                        />
                        <span className="text-sm text-muted-foreground">WhatsApp</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={event.push}
                          onCheckedChange={() => toggleChannel(event.id, 'push')}
                        />
                        <span className="text-sm text-muted-foreground">Push</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-foreground">Message Templates</h3>
              <p className="text-sm text-muted-foreground">
                Create and manage notification templates with recurring options
              </p>
            </div>
            <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Create Template
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create Notification Template</DialogTitle>
                  <DialogDescription>
                    Design a new message template with dynamic variables
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <Field>
                    <FieldLabel>Template Name</FieldLabel>
                    <Input placeholder="e.g., Payment Confirmation SMS" />
                  </Field>
                  <FieldGroup>
                    <div className="grid grid-cols-2 gap-4">
                      <Field>
                        <FieldLabel>Event Type</FieldLabel>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select event" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="payment_received">Payment Received</SelectItem>
                            <SelectItem value="payment_failed">Payment Failed</SelectItem>
                            <SelectItem value="fee_due_reminder">Fee Due Reminder</SelectItem>
                            <SelectItem value="fee_overdue">Fee Overdue</SelectItem>
                            <SelectItem value="receipt_generated">Receipt Generated</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                      <Field>
                        <FieldLabel>Channel</FieldLabel>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select channel" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sms">SMS</SelectItem>
                            <SelectItem value="email">Email</SelectItem>
                            <SelectItem value="whatsapp">WhatsApp</SelectItem>
                            <SelectItem value="push">Push Notification</SelectItem>
                          </SelectContent>
                        </Select>
                      </Field>
                    </div>
                  </FieldGroup>
                  <Field>
                    <FieldLabel>DLT Template ID (for SMS)</FieldLabel>
                    <Input placeholder="e.g., 1107165784532" />
                  </Field>
                  <Field>
                    <FieldLabel>Subject (for Email)</FieldLabel>
                    <Input placeholder="Payment Confirmation - {receipt_no}" />
                  </Field>
                  <Field>
                    <FieldLabel>Message Content</FieldLabel>
                    <Textarea
                      placeholder="Dear Parent, your payment of Rs.{amount} has been received..."
                      rows={4}
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Variables: {"{student_name}"}, {"{amount}"}, {"{due_date}"}, {"{receipt_no}"}, {"{payment_link}"}, {"{institute_name}"}, {"{days}"}
                    </p>
                  </Field>

                  {/* Recurring Options */}
                  <div className="rounded-lg border p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Enable Recurring</Label>
                        <p className="text-xs text-muted-foreground">Send this notification on a schedule</p>
                      </div>
                      <Switch checked={isRecurring} onCheckedChange={setIsRecurring} />
                    </div>
                    {isRecurring && (
                      <div className="space-y-3">
                        <Label className="text-sm">Send reminders before due date</Label>
                        <div className="flex flex-wrap gap-2">
                          {[30, 15, 7, 3, 1].map((day) => (
                            <Button
                              key={day}
                              type="button"
                              variant={recurringDays.includes(day) ? "default" : "outline"}
                              size="sm"
                              onClick={() => toggleRecurringDay(day)}
                            >
                              {day} day{day > 1 ? "s" : ""}
                            </Button>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Selected: {recurringDays.length > 0 ? recurringDays.join(", ") + " days before due" : "None"}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowTemplateDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setShowTemplateDialog(false)}>
                    Create Template
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <Card className="border-border/50">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead>Template Name</TableHead>
                    <TableHead>Event</TableHead>
                    <TableHead>Channel</TableHead>
                    <TableHead>Recurring</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Used</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {templates.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-foreground">{template.name}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1 max-w-xs">
                            {template.content}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="font-normal">
                          {template.event.replace(/_/g, ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getChannelIcon(template.channel)}
                          <span className="text-sm">{template.channel}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {template.isRecurring ? (
                          <div className="flex items-center gap-1">
                            <RefreshCw className="h-3 w-3 text-primary" />
                            <span className="text-xs text-muted-foreground">
                              {template.recurringDays?.join(", ")} days
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs text-muted-foreground">One-time</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={template.status === "active" ? "default" : "secondary"}
                          className={template.status === "active" ? "bg-success hover:bg-success/90" : ""}
                        >
                          {template.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {template.lastUsed}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => {
                              setSelectedTemplate(template)
                              setShowPreviewDialog(true)
                            }}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8" title="Resend">
                            <Send className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit2 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Wallet Tab */}
        <TabsContent value="wallet" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="border-border/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">SMS Wallet</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-3xl font-bold">{smsBalance.toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">Credits available</p>
                  </div>
                  <Button onClick={() => setShowTopUpDialog(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Top Up
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-4">Rate: ₹1 per SMS</p>
              </CardContent>
            </Card>
            <Card className="border-border/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">WhatsApp Wallet</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-3xl font-bold">{whatsappBalance.toLocaleString()}</p>
                    <p className="text-sm text-muted-foreground">Credits available</p>
                  </div>
                  <Button onClick={() => setShowTopUpDialog(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    Top Up
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-4">Rate: ₹2 per message</p>
              </CardContent>
            </Card>
            <Card className="border-border/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">This Month Usage</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">SMS Sent</span>
                    <span className="font-medium">2,450</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">WhatsApp Sent</span>
                    <span className="font-medium">1,823</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Emails Sent</span>
                    <span className="font-medium">3,156</span>
                  </div>
                  <div className="flex justify-between text-sm pt-2 border-t">
                    <span className="text-muted-foreground">Total Spend</span>
                    <span className="font-semibold">₹6,096</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Transaction History</CardTitle>
                  <CardDescription>
                    Wallet top-ups and deductions ledger
                  </CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <History className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Reference</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead className="text-right">Balance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {walletTransactions.map((txn) => (
                    <TableRow key={txn.id}>
                      <TableCell className="text-muted-foreground text-sm">
                        {txn.date}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {txn.type === "credit" ? (
                            <ArrowUpRight className="h-4 w-4 text-success" />
                          ) : (
                            <ArrowDownRight className="h-4 w-4 text-destructive" />
                          )}
                          <span className="text-sm">{txn.description}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {txn.reference}
                      </TableCell>
                      <TableCell className={`text-right font-medium ${
                        txn.type === "credit" ? "text-success" : "text-destructive"
                      }`}>
                        {txn.type === "credit" ? "+" : "-"}₹{txn.amount.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right font-semibold">
                        ₹{txn.balance.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-4">
          <Card className="border-border/50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Delivery History</CardTitle>
                  <CardDescription>
                    Recent notification delivery status
                  </CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Template</TableHead>
                    <TableHead>Channel</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Credits</TableHead>
                    <TableHead>Sent At</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentNotifications.map((notification) => (
                    <TableRow key={notification.id}>
                      <TableCell className="font-medium">{notification.recipient}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {notification.phone || notification.email}
                      </TableCell>
                      <TableCell className="text-sm">{notification.template}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getChannelIcon(notification.channel)}
                          <span className="text-sm">{notification.channel}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={notification.status === "delivered" ? "default" : "destructive"}
                          className={notification.status === "delivered" ? "bg-success hover:bg-success/90" : ""}
                        >
                          {notification.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {notification.credits > 0 ? notification.credits : "-"}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {notification.sentAt}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="h-8 w-8" title="Resend">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Channels Tab */}
        <TabsContent value="channels" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                    <Smartphone className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-base">SMS Gateway</CardTitle>
                    <CardDescription>Configure SMS provider</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Field>
                  <FieldLabel>Provider</FieldLabel>
                  <Select defaultValue="msg91">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="msg91">MSG91</SelectItem>
                      <SelectItem value="textlocal">Textlocal</SelectItem>
                      <SelectItem value="twilio">Twilio</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel>API Key</FieldLabel>
                  <Input type="password" value="••••••••••••••••" readOnly />
                </Field>
                <Field>
                  <FieldLabel>Sender ID</FieldLabel>
                  <Input value="FEEFLO" readOnly />
                </Field>
                <div className="flex items-center justify-between pt-2">
                  <Badge variant="default" className="bg-success">Connected</Badge>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-500/10">
                    <MessageSquare className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <CardTitle className="text-base">WhatsApp Business</CardTitle>
                    <CardDescription>Configure WhatsApp API</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Field>
                  <FieldLabel>Provider</FieldLabel>
                  <Select defaultValue="gupshup">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gupshup">Gupshup</SelectItem>
                      <SelectItem value="twilio">Twilio</SelectItem>
                      <SelectItem value="wati">WATI</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel>API Key</FieldLabel>
                  <Input type="password" value="••••••••••••••••" readOnly />
                </Field>
                <Field>
                  <FieldLabel>Business Phone</FieldLabel>
                  <Input value="+91 98765 43210" readOnly />
                </Field>
                <div className="flex items-center justify-between pt-2">
                  <Badge variant="default" className="bg-success">Connected</Badge>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-base">Email Service</CardTitle>
                    <CardDescription>Configure email provider</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Field>
                  <FieldLabel>Provider</FieldLabel>
                  <Select defaultValue="sendgrid">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sendgrid">SendGrid</SelectItem>
                      <SelectItem value="ses">Amazon SES</SelectItem>
                      <SelectItem value="mailgun">Mailgun</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel>From Email</FieldLabel>
                  <Input value="noreply@feeflo.in" readOnly />
                </Field>
                <div className="flex items-center justify-between pt-2">
                  <Badge variant="default" className="bg-success">Connected</Badge>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/50">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                    <Bell className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-base">Push Notifications</CardTitle>
                    <CardDescription>Configure push service</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <Field>
                  <FieldLabel>Provider</FieldLabel>
                  <Select defaultValue="firebase">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="firebase">Firebase FCM</SelectItem>
                      <SelectItem value="onesignal">OneSignal</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel>Project ID</FieldLabel>
                  <Input value="feeflo-app-12345" readOnly />
                </Field>
                <div className="flex items-center justify-between pt-2">
                  <Badge variant="default" className="bg-success">Connected</Badge>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Top Up Dialog */}
      <Dialog open={showTopUpDialog} onOpenChange={setShowTopUpDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Top Up Wallet</DialogTitle>
            <DialogDescription>
              Add credits to your SMS or WhatsApp wallet
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Field>
              <FieldLabel>Select Wallet</FieldLabel>
              <Select defaultValue="sms">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms">SMS Wallet (₹1/credit)</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp Wallet (₹2/credit)</SelectItem>
                </SelectContent>
              </Select>
            </Field>

            <div className="space-y-2">
              <Label className="text-sm font-medium">Select Amount</Label>
              <div className="grid grid-cols-3 gap-2">
                {topUpAmounts.map((amount) => (
                  <Button
                    key={amount}
                    variant={topUpAmount === String(amount) ? "default" : "outline"}
                    onClick={() => {
                      setTopUpAmount(String(amount))
                      setCustomTopUpAmount("")
                    }}
                  >
                    ₹{amount.toLocaleString()}
                  </Button>
                ))}
              </div>
            </div>

            <Field>
              <FieldLabel>Or Enter Custom Amount</FieldLabel>
              <div className="relative">
                <IndianRupee className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="number"
                  placeholder="Enter amount"
                  className="pl-9"
                  value={customTopUpAmount}
                  onChange={(e) => {
                    setCustomTopUpAmount(e.target.value)
                    setTopUpAmount("")
                  }}
                />
              </div>
            </Field>

            <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Amount</span>
                <span className="font-medium">
                  ₹{(topUpAmount || customTopUpAmount || 0).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Credits</span>
                <span className="font-medium">
                  {Number(topUpAmount || customTopUpAmount || 0).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">GST (18%)</span>
                <span className="font-medium">
                  ₹{(Number(topUpAmount || customTopUpAmount || 0) * 0.18).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-sm pt-2 border-t font-semibold">
                <span>Total</span>
                <span>
                  ₹{(Number(topUpAmount || customTopUpAmount || 0) * 1.18).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTopUpDialog(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowTopUpDialog(false)} className="gap-2">
              <Wallet className="h-4 w-4" />
              Pay & Top Up
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreviewDialog} onOpenChange={setShowPreviewDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Template Preview</DialogTitle>
            <DialogDescription>
              Preview how the message will appear to recipients
            </DialogDescription>
          </DialogHeader>
          {selectedTemplate && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-2">
                {getChannelIcon(selectedTemplate.channel)}
                <Badge variant="secondary">{selectedTemplate.channel}</Badge>
                {selectedTemplate.isRecurring && (
                  <Badge variant="outline" className="gap-1">
                    <RefreshCw className="h-3 w-3" />
                    Recurring
                  </Badge>
                )}
              </div>
              <div className="rounded-lg border border-border bg-muted/30 p-4">
                <p className="text-sm text-foreground whitespace-pre-wrap">
                  {selectedTemplate.content
                    .replace("{student_name}", "Rahul Sharma")
                    .replace("{amount}", "15,000")
                    .replace("{due_date}", "15th Jan 2024")
                    .replace("{receipt_no}", "RCP-2024-001")
                    .replace("{payment_link}", "https://pay.feeflo.in/xyz")
                    .replace("{institute_name}", "Delhi Public School")
                    .replace("{days}", "5")}
                </p>
              </div>
              {selectedTemplate.isRecurring && selectedTemplate.recurringDays && (
                <div className="text-sm text-muted-foreground">
                  Sends {selectedTemplate.recurringDays.join(", ")} days before due date
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPreviewDialog(false)}>
              Close
            </Button>
            <Button className="gap-2">
              <Send className="h-4 w-4" />
              Send Test
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
