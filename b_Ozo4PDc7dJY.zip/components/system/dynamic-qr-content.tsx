"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { 
  Plus,
  MoreHorizontal,
  QrCode,
  CheckCircle2,
  XCircle,
  Clock,
  Settings,
  Trash2,
  Edit,
  MapPin,
  Download,
  Activity,
  IndianRupee,
  Copy,
  ExternalLink,
  Printer,
  Share2,
  Eye,
  RefreshCw,
  Smartphone,
} from "lucide-react"
import { Textarea } from "@/components/ui/textarea"

const qrProviders = [
  { id: "razorpay", name: "Razorpay QR", logo: "RP" },
  { id: "paytm", name: "Paytm QR", logo: "PT" },
  { id: "phonepe", name: "PhonePe QR", logo: "PP" },
  { id: "bharatpe", name: "BharatPe", logo: "BP" },
  { id: "gpay", name: "Google Pay Business", logo: "GP" },
  { id: "bhim", name: "BHIM UPI", logo: "BH" },
]

const qrCodes = [
  {
    id: "QR001",
    name: "Main Office Reception",
    provider: "razorpay",
    providerName: "Razorpay QR",
    type: "static",
    upiId: "feeflo.main@razorpay",
    location: "Main Building - Reception",
    status: "active",
    todayTransactions: 15,
    todayAmount: 125000,
    totalTransactions: 456,
    totalAmount: 2850000,
    createdAt: "2024-01-01",
    lastUsed: "2024-01-15 10:45 AM",
  },
  {
    id: "QR002",
    name: "Accounts Office",
    provider: "razorpay",
    providerName: "Razorpay QR",
    type: "static",
    upiId: "feeflo.accounts@razorpay",
    location: "Admin Block - Room 102",
    status: "active",
    todayTransactions: 8,
    todayAmount: 95000,
    totalTransactions: 234,
    totalAmount: 1560000,
    createdAt: "2024-01-01",
    lastUsed: "2024-01-15 10:30 AM",
  },
  {
    id: "QR003",
    name: "Branch Office",
    provider: "paytm",
    providerName: "Paytm QR",
    type: "static",
    upiId: "feeflo.branch@paytm",
    location: "Branch Campus - Counter",
    status: "active",
    todayTransactions: 5,
    todayAmount: 42000,
    totalTransactions: 189,
    totalAmount: 890000,
    createdAt: "2024-01-05",
    lastUsed: "2024-01-15 09:15 AM",
  },
  {
    id: "QR004",
    name: "Canteen Counter",
    provider: "phonepe",
    providerName: "PhonePe QR",
    type: "static",
    upiId: "feeflo.canteen@ybl",
    location: "Canteen Building",
    status: "inactive",
    todayTransactions: 0,
    todayAmount: 0,
    totalTransactions: 567,
    totalAmount: 125000,
    createdAt: "2024-01-10",
    lastUsed: "2024-01-10 02:30 PM",
  },
]

const dynamicQRHistory = [
  {
    id: "DQR001",
    studentName: "Arjun Sharma",
    studentId: "STU001",
    amount: 25000,
    purpose: "Term 2 Tuition Fee",
    status: "paid",
    createdAt: "2024-01-15 10:30 AM",
    paidAt: "2024-01-15 10:32 AM",
    expiresAt: "2024-01-15 11:30 AM",
    transactionId: "TXN789456123",
  },
  {
    id: "DQR002",
    studentName: "Priya Patel",
    studentId: "STU002",
    amount: 15000,
    purpose: "Transport Fee Q4",
    status: "paid",
    createdAt: "2024-01-15 10:15 AM",
    paidAt: "2024-01-15 10:18 AM",
    expiresAt: "2024-01-15 11:15 AM",
    transactionId: "TXN789456124",
  },
  {
    id: "DQR003",
    studentName: "Rahul Kumar",
    studentId: "STU003",
    amount: 35000,
    purpose: "Annual Fee",
    status: "pending",
    createdAt: "2024-01-15 10:00 AM",
    paidAt: null,
    expiresAt: "2024-01-15 11:00 AM",
    transactionId: null,
  },
  {
    id: "DQR004",
    studentName: "Sneha Reddy",
    studentId: "STU004",
    amount: 12500,
    purpose: "Lab Fee",
    status: "expired",
    createdAt: "2024-01-14 03:00 PM",
    paidAt: null,
    expiresAt: "2024-01-14 04:00 PM",
    transactionId: null,
  },
]

const providerConfigs = [
  {
    id: "razorpay",
    name: "Razorpay QR",
    logo: "RP",
    status: "active",
    merchantId: "RZP_MID_123456",
    totalQRs: 2,
    activeQRs: 2,
    supportsDynamic: true,
    supportsStatic: true,
    settlementAccount: "HDFC ****1234",
    enabled: true,
  },
  {
    id: "paytm",
    name: "Paytm QR",
    logo: "PT",
    status: "active",
    merchantId: "PTM_MID_789456",
    totalQRs: 1,
    activeQRs: 1,
    supportsDynamic: true,
    supportsStatic: true,
    settlementAccount: "ICICI ****5678",
    enabled: true,
  },
  {
    id: "phonepe",
    name: "PhonePe QR",
    logo: "PP",
    status: "inactive",
    merchantId: "PP_MID_456123",
    totalQRs: 1,
    activeQRs: 0,
    supportsDynamic: false,
    supportsStatic: true,
    settlementAccount: "HDFC ****1234",
    enabled: false,
  },
]

export function DynamicQRContent() {
  const [showCreateQR, setShowCreateQR] = useState(false)
  const [showGenerateDynamic, setShowGenerateDynamic] = useState(false)
  const [showAddProvider, setShowAddProvider] = useState(false)
  const [showQRPreview, setShowQRPreview] = useState(false)

  const totalQRs = qrCodes.length
  const activeQRs = qrCodes.filter(q => q.status === "active").length
  const todayTotal = qrCodes.reduce((sum, q) => sum + q.todayAmount, 0)
  const todayTxnCount = qrCodes.reduce((sum, q) => sum + q.todayTransactions, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Dynamic QR Codes</h1>
          <p className="text-sm text-muted-foreground">
            Manage static and dynamic QR codes for UPI payments
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={showGenerateDynamic} onOpenChange={setShowGenerateDynamic}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <QrCode className="mr-2 h-4 w-4" />
                Generate Dynamic QR
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Generate Dynamic QR Code</DialogTitle>
                <DialogDescription>
                  Create a one-time QR code for a specific payment
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Select Student</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Search student..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="stu001">Arjun Sharma (STU001)</SelectItem>
                      <SelectItem value="stu002">Priya Patel (STU002)</SelectItem>
                      <SelectItem value="stu003">Rahul Kumar (STU003)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Amount</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                    <Input className="pl-7" placeholder="Enter amount" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Purpose / Fee Heads</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select fee head" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tuition">Tuition Fee</SelectItem>
                      <SelectItem value="transport">Transport Fee</SelectItem>
                      <SelectItem value="lab">Lab Fee</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>QR Provider</Label>
                  <Select defaultValue="razorpay">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {providerConfigs.filter(p => p.supportsDynamic && p.enabled).map((provider) => (
                        <SelectItem key={provider.id} value={provider.id}>
                          <div className="flex items-center gap-2">
                            <div className="flex h-5 w-5 items-center justify-center rounded bg-primary/10 text-[10px] font-bold text-primary">
                              {provider.logo}
                            </div>
                            {provider.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>QR Expiry</Label>
                  <Select defaultValue="60">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="1440">24 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Description (Optional)</Label>
                  <Textarea placeholder="Add a note for this payment..." />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowGenerateDynamic(false)}>
                  Cancel
                </Button>
                <Button onClick={() => {
                  setShowGenerateDynamic(false)
                  setShowQRPreview(true)
                }}>
                  Generate QR
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          <Dialog open={showCreateQR} onOpenChange={setShowCreateQR}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Create Static QR
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Create Static QR Code</DialogTitle>
                <DialogDescription>
                  Create a permanent QR code for a counter or location
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>QR Name</Label>
                  <Input placeholder="e.g., Main Office Reception" />
                </div>
                <div className="space-y-2">
                  <Label>QR Provider</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select provider" />
                    </SelectTrigger>
                    <SelectContent>
                      {providerConfigs.filter(p => p.supportsStatic && p.enabled).map((provider) => (
                        <SelectItem key={provider.id} value={provider.id}>
                          <div className="flex items-center gap-2">
                            <div className="flex h-5 w-5 items-center justify-center rounded bg-primary/10 text-[10px] font-bold text-primary">
                              {provider.logo}
                            </div>
                            {provider.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>UPI ID</Label>
                  <Input placeholder="e.g., feeflo.office@razorpay" />
                  <p className="text-xs text-muted-foreground">This will be auto-generated based on provider</p>
                </div>
                <div className="space-y-2">
                  <Label>Location / Counter</Label>
                  <Input placeholder="e.g., Admin Block - Room 102" />
                </div>
                <div className="space-y-2">
                  <Label>Description (Optional)</Label>
                  <Textarea placeholder="Add notes about this QR code..." />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowCreateQR(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setShowCreateQR(false)}>
                  Create QR
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* QR Preview Dialog */}
      <Dialog open={showQRPreview} onOpenChange={setShowQRPreview}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>QR Code Generated</DialogTitle>
            <DialogDescription>
              Scan or share this QR code to receive payment
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center py-6">
            <div className="rounded-xl border-2 border-dashed border-muted-foreground/25 p-6">
              <div className="flex h-48 w-48 items-center justify-center bg-muted rounded-lg">
                <QrCode className="h-32 w-32 text-foreground" />
              </div>
            </div>
            <div className="mt-4 text-center">
              <p className="text-2xl font-bold">₹25,000</p>
              <p className="text-sm text-muted-foreground">Term 2 Tuition Fee - Arjun Sharma</p>
            </div>
            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>Expires in 59:45</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1">
              <Copy className="mr-2 h-4 w-4" />
              Copy Link
            </Button>
            <Button variant="outline" className="flex-1">
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
            <Button variant="outline" className="flex-1">
              <Printer className="mr-2 h-4 w-4" />
              Print
            </Button>
          </div>
          <Button className="w-full" onClick={() => setShowQRPreview(false)}>
            Done
          </Button>
        </DialogContent>
      </Dialog>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total QR Codes</p>
                <p className="text-2xl font-bold">{totalQRs}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                <QrCode className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active QRs</p>
                <p className="text-2xl font-bold text-success">{activeQRs}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-success/10">
                <CheckCircle2 className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Today&apos;s Collection</p>
                <p className="text-2xl font-bold">₹{(todayTotal / 1000).toFixed(1)}K</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-chart-1/10">
                <IndianRupee className="h-5 w-5 text-chart-1" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Today&apos;s Scans</p>
                <p className="text-2xl font-bold">{todayTxnCount}</p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-chart-2/10">
                <Activity className="h-5 w-5 text-chart-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="static" className="space-y-4">
        <TabsList>
          <TabsTrigger value="static">Static QR Codes</TabsTrigger>
          <TabsTrigger value="dynamic">Dynamic QR History</TabsTrigger>
          <TabsTrigger value="providers">QR Providers</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="static" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Static QR Codes</CardTitle>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[150px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>QR Code</TableHead>
                    <TableHead>UPI ID</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Today</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {qrCodes.map((qr) => (
                    <TableRow key={qr.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                            <QrCode className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <div>
                            <p className="font-medium">{qr.name}</p>
                            <p className="text-xs text-muted-foreground">{qr.providerName}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{qr.upiId}</code>
                          <Button variant="ghost" size="icon" className="h-6 w-6">
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          <span className="text-sm">{qr.location}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm font-medium">₹{qr.todayAmount.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">{qr.todayTransactions} txns</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm font-medium">₹{(qr.totalAmount / 100000).toFixed(1)}L</p>
                          <p className="text-xs text-muted-foreground">{qr.totalTransactions} txns</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {qr.status === "active" ? (
                          <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                            Active
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-muted text-muted-foreground">
                            Inactive
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View QR
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Download QR
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Printer className="mr-2 h-4 w-4" />
                              Print QR
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Activity className="mr-2 h-4 w-4" />
                              View Transactions
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <RefreshCw className="mr-2 h-4 w-4" />
                              Regenerate QR
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="dynamic" className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Dynamic QR History</CardTitle>
                <div className="flex items-center gap-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-[120px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="expired">Expired</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>QR ID</TableHead>
                    <TableHead>Student</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Purpose</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Transaction ID</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dynamicQRHistory.map((qr) => (
                    <TableRow key={qr.id}>
                      <TableCell className="font-mono text-sm">{qr.id}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{qr.studentName}</p>
                          <p className="text-xs text-muted-foreground">{qr.studentId}</p>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">₹{qr.amount.toLocaleString()}</TableCell>
                      <TableCell className="text-sm">{qr.purpose}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{qr.createdAt}</TableCell>
                      <TableCell>
                        {qr.status === "paid" ? (
                          <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                            Paid
                          </Badge>
                        ) : qr.status === "pending" ? (
                          <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                            <Clock className="mr-1 h-3 w-3" />
                            Pending
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-muted text-muted-foreground">
                            <XCircle className="mr-1 h-3 w-3" />
                            Expired
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {qr.transactionId ? (
                          <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{qr.transactionId}</code>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {qr.status === "pending" && (
                              <>
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View QR
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Share2 className="mr-2 h-4 w-4" />
                                  Resend to Parent
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <RefreshCw className="mr-2 h-4 w-4" />
                                  Extend Expiry
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                              </>
                            )}
                            {qr.status === "paid" && (
                              <DropdownMenuItem>
                                <Download className="mr-2 h-4 w-4" />
                                Download Receipt
                              </DropdownMenuItem>
                            )}
                            {qr.status === "expired" && (
                              <DropdownMenuItem>
                                <RefreshCw className="mr-2 h-4 w-4" />
                                Regenerate QR
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="providers" className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Configure QR code providers and their settings
            </p>
            <Dialog open={showAddProvider} onOpenChange={setShowAddProvider}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Provider
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>Add QR Provider</DialogTitle>
                  <DialogDescription>
                    Configure a new QR code provider
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Select Provider</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a provider" />
                      </SelectTrigger>
                      <SelectContent>
                        {qrProviders.map((provider) => (
                          <SelectItem key={provider.id} value={provider.id}>
                            <div className="flex items-center gap-2">
                              <div className="flex h-6 w-6 items-center justify-center rounded bg-primary/10 text-xs font-bold text-primary">
                                {provider.logo}
                              </div>
                              {provider.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Merchant ID</Label>
                    <Input placeholder="Enter merchant ID from provider" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>API Key</Label>
                      <Input type="password" placeholder="••••••••" />
                    </div>
                    <div className="space-y-2">
                      <Label>Secret Key</Label>
                      <Input type="password" placeholder="••••••••" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Settlement Bank Account</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select bank account" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hdfc">HDFC Bank ****1234</SelectItem>
                        <SelectItem value="icici">ICICI Bank ****5678</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-3">
                    <Label>QR Type Support</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <span className="text-sm">Static QR</span>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between rounded-lg border p-3">
                        <span className="text-sm">Dynamic QR</span>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowAddProvider(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setShowAddProvider(false)}>
                    Add Provider
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {providerConfigs.map((provider) => (
              <Card key={provider.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 font-bold text-primary">
                        {provider.logo}
                      </div>
                      <div>
                        <CardTitle className="text-base">{provider.name}</CardTitle>
                        <CardDescription className="text-xs">
                          MID: {provider.merchantId}
                        </CardDescription>
                      </div>
                    </div>
                    <Switch checked={provider.enabled} />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Total QRs</p>
                      <p className="font-medium">{provider.totalQRs}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Active</p>
                      <p className="font-medium text-success">{provider.activeQRs}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Supported Types</p>
                    <div className="flex gap-1">
                      {provider.supportsStatic && (
                        <Badge variant="secondary" className="text-xs">Static</Badge>
                      )}
                      {provider.supportsDynamic && (
                        <Badge variant="secondary" className="text-xs">Dynamic</Badge>
                      )}
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Settlement: {provider.settlementAccount}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Settings className="mr-2 h-3 w-3" />
                      Configure
                    </Button>
                    <Button variant="outline" size="sm">
                      <Activity className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Dynamic QR Settings</CardTitle>
                <CardDescription>Configure dynamic QR code behavior</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Default Expiry Time</Label>
                  <Select defaultValue="60">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="1440">24 hours</SelectItem>
                      <SelectItem value="4320">3 days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Auto-send to Parent</p>
                    <p className="text-xs text-muted-foreground">Send QR via SMS/WhatsApp when generated</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Payment Confirmation</p>
                    <p className="text-xs text-muted-foreground">Notify parent when payment is received</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Expiry Reminder</p>
                    <p className="text-xs text-muted-foreground">Send reminder 15 mins before expiry</p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Static QR Settings</CardTitle>
                <CardDescription>Configure static QR code behavior</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Collect Payer Info</p>
                    <p className="text-xs text-muted-foreground">Ask for student ID when scanning</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Real-time Notifications</p>
                    <p className="text-xs text-muted-foreground">Get notified for every static QR payment</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Sound Alert</p>
                    <p className="text-xs text-muted-foreground">Play sound on successful payment</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="space-y-2">
                  <Label>QR Print Size</Label>
                  <Select defaultValue="medium">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small (5 x 5 cm)</SelectItem>
                      <SelectItem value="medium">Medium (8 x 8 cm)</SelectItem>
                      <SelectItem value="large">Large (12 x 12 cm)</SelectItem>
                      <SelectItem value="standee">Standee (A4)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Limits & Restrictions</CardTitle>
                <CardDescription>Set transaction limits for QR payments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Min Transaction</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                      <Input className="pl-7" defaultValue="1" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Max Transaction</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                      <Input className="pl-7" defaultValue="100000" />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Daily Limit per QR</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                    <Input className="pl-7" defaultValue="1000000" />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  UPI transaction limits are also subject to bank/NPCI limits
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Branding</CardTitle>
                <CardDescription>Customize QR code appearance</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Add Logo to QR</p>
                    <p className="text-xs text-muted-foreground">Show institute logo in center of QR</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Show Amount on Print</p>
                    <p className="text-xs text-muted-foreground">Print amount below dynamic QRs</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Show Student Details</p>
                    <p className="text-xs text-muted-foreground">Print student name on dynamic QRs</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="space-y-2">
                  <Label>QR Color</Label>
                  <div className="flex gap-2">
                    <div className="h-8 w-8 rounded-full bg-foreground border-2 border-primary cursor-pointer" />
                    <div className="h-8 w-8 rounded-full bg-primary cursor-pointer" />
                    <div className="h-8 w-8 rounded-full bg-chart-1 cursor-pointer" />
                    <div className="h-8 w-8 rounded-full bg-chart-2 cursor-pointer" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
