"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  CheckCircle2,
  XCircle,
  RefreshCw,
  Settings2,
  Link2,
  Unlink,
  Play,
  Pause,
  Clock,
  AlertTriangle,
  FileText,
  ArrowRightLeft,
  Download,
  Upload,
  ExternalLink,
  HelpCircle,
  Database,
  Zap,
} from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"

// Zoho Books Logo SVG
function ZohoLogo({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none">
      <rect width="100" height="100" rx="12" fill="#F9423A" />
      <path d="M20 65L35 35H50L35 65H20Z" fill="white" />
      <path d="M45 35H80L65 65H45L60 50L45 35Z" fill="white" />
    </svg>
  )
}

// Tally Logo SVG
function TallyLogo({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none">
      <rect width="100" height="100" rx="12" fill="#FFCC00" />
      <path d="M25 30H75V40H55V70H45V40H25V30Z" fill="#333" />
    </svg>
  )
}

const integrations = [
  {
    id: "zoho-books",
    name: "Zoho Books",
    description: "Sync fee collections, invoices, and financial data with Zoho Books",
    status: "connected",
    lastSync: "2024-01-15 10:30 AM",
    logo: ZohoLogo,
    features: ["Invoices", "Payments", "Contacts", "Chart of Accounts"],
  },
  {
    id: "tally-prime",
    name: "Tally Prime",
    description: "Export vouchers and ledger entries to Tally Prime ERP",
    status: "disconnected",
    lastSync: null,
    logo: TallyLogo,
    features: ["Vouchers", "Ledgers", "Day Book", "Outstanding Reports"],
  },
]

const syncHistory = [
  {
    id: "SYN001",
    integration: "Zoho Books",
    type: "Payments",
    records: 156,
    status: "success",
    timestamp: "2024-01-15 10:30 AM",
    duration: "45s",
  },
  {
    id: "SYN002",
    integration: "Zoho Books",
    type: "Invoices",
    records: 89,
    status: "success",
    timestamp: "2024-01-15 10:28 AM",
    duration: "32s",
  },
  {
    id: "SYN003",
    integration: "Zoho Books",
    type: "Contacts",
    records: 12,
    status: "failed",
    timestamp: "2024-01-14 06:00 PM",
    duration: "12s",
    error: "API rate limit exceeded",
  },
  {
    id: "SYN004",
    integration: "Tally Prime",
    type: "Vouchers",
    records: 234,
    status: "success",
    timestamp: "2024-01-14 02:15 PM",
    duration: "1m 23s",
  },
]

const fieldMappings = {
  zoho: [
    { feefloField: "Student Name", zohoField: "Customer Name", required: true },
    { feefloField: "Admission No", zohoField: "Customer ID", required: true },
    { feefloField: "Fee Head", zohoField: "Item Name", required: true },
    { feefloField: "Amount", zohoField: "Invoice Amount", required: true },
    { feefloField: "Payment Date", zohoField: "Payment Date", required: true },
    { feefloField: "Transaction ID", zohoField: "Reference Number", required: false },
    { feefloField: "Payment Method", zohoField: "Payment Mode", required: false },
    { feefloField: "Parent Email", zohoField: "Customer Email", required: false },
    { feefloField: "Parent Phone", zohoField: "Customer Phone", required: false },
    { feefloField: "Class", zohoField: "Custom Field 1", required: false },
  ],
  tally: [
    { feefloField: "Student Name", tallyField: "Party Name", required: true },
    { feefloField: "Admission No", tallyField: "Party Code", required: true },
    { feefloField: "Fee Head", tallyField: "Ledger Name", required: true },
    { feefloField: "Amount", tallyField: "Voucher Amount", required: true },
    { feefloField: "Payment Date", tallyField: "Voucher Date", required: true },
    { feefloField: "Transaction ID", tallyField: "Voucher Number", required: false },
    { feefloField: "Payment Method", tallyField: "Voucher Type", required: false },
    { feefloField: "GST", tallyField: "GST Amount", required: false },
  ],
}

export function IntegrationsContent() {
  const [selectedIntegration, setSelectedIntegration] = useState<string | null>(null)
  const [showConnectDialog, setShowConnectDialog] = useState(false)
  const [connectingTo, setConnectingTo] = useState<string | null>(null)
  const [syncSettings, setSyncSettings] = useState({
    autoSync: true,
    syncFrequency: "hourly",
    syncInvoices: true,
    syncPayments: true,
    syncContacts: true,
    syncOnPayment: true,
  })
  const [tallySettings, setTallySettings] = useState({
    exportFormat: "xml",
    autoExport: false,
    exportPath: "C:\\Tally\\Import",
    voucherType: "receipt",
    ledgerGroup: "Sundry Debtors",
  })

  const handleConnect = (integrationId: string) => {
    setConnectingTo(integrationId)
    setShowConnectDialog(true)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Integrations</h1>
        <p className="text-sm text-muted-foreground">
          Connect FeeFlo with your accounting software for automated bookkeeping
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="zoho">Zoho Books</TabsTrigger>
          <TabsTrigger value="tally">Tally Prime</TabsTrigger>
          <TabsTrigger value="sync-history">Sync History</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            {integrations.map((integration) => (
              <Card key={integration.id} className="relative">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <integration.logo className="h-12 w-12" />
                      <div>
                        <CardTitle className="text-lg">{integration.name}</CardTitle>
                        <CardDescription className="text-xs mt-0.5">
                          {integration.description}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge
                      variant={integration.status === "connected" ? "default" : "secondary"}
                      className={
                        integration.status === "connected"
                          ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                          : ""
                      }
                    >
                      {integration.status === "connected" ? (
                        <CheckCircle2 className="mr-1 h-3 w-3" />
                      ) : (
                        <XCircle className="mr-1 h-3 w-3" />
                      )}
                      {integration.status === "connected" ? "Connected" : "Not Connected"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-wrap gap-1.5">
                    {integration.features.map((feature) => (
                      <Badge key={feature} variant="outline" className="text-xs font-normal">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  {integration.lastSync && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      Last synced: {integration.lastSync}
                    </div>
                  )}

                  <div className="flex items-center gap-2 pt-2">
                    {integration.status === "connected" ? (
                      <>
                        <Button size="sm" variant="outline" className="flex-1">
                          <RefreshCw className="mr-2 h-3 w-3" />
                          Sync Now
                        </Button>
                        <Button size="sm" variant="outline">
                          <Settings2 className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-destructive">
                          <Unlink className="h-4 w-4" />
                        </Button>
                      </>
                    ) : (
                      <Button
                        size="sm"
                        className="flex-1"
                        onClick={() => handleConnect(integration.id)}
                      >
                        <Link2 className="mr-2 h-3 w-3" />
                        Connect
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Stats */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Records Synced Today</p>
                    <p className="text-2xl font-bold">1,245</p>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <ArrowRightLeft className="h-5 w-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Pending Sync</p>
                    <p className="text-2xl font-bold">23</p>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-warning/10">
                    <Clock className="h-5 w-5 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Failed Syncs</p>
                    <p className="text-2xl font-bold">2</p>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-destructive/10">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Last Sync</p>
                    <p className="text-2xl font-bold">5m ago</p>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                    <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Zoho Books Tab */}
        <TabsContent value="zoho" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Connection Status */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <ZohoLogo className="h-10 w-10" />
                    <div>
                      <CardTitle>Zoho Books</CardTitle>
                      <CardDescription>Connected as: accounts@school.edu</CardDescription>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                    <CheckCircle2 className="mr-1 h-3 w-3" />
                    Active
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Organization</p>
                    <p className="text-sm font-medium">Springfield International School</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Organization ID</p>
                    <p className="text-sm font-mono">10234567890</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">API Version</p>
                    <p className="text-sm font-medium">v3</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Last Sync</p>
                    <p className="text-sm font-medium">Jan 15, 2024 10:30 AM</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button variant="outline">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Sync Now
                  </Button>
                  <Button variant="outline">
                    <ExternalLink className="mr-2 h-4 w-4" />
                    Open Zoho Books
                  </Button>
                  <Button variant="ghost" className="text-destructive">
                    <Unlink className="mr-2 h-4 w-4" />
                    Disconnect
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Sync Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Sync Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Auto Sync</p>
                    <p className="text-xs text-muted-foreground">Sync automatically</p>
                  </div>
                  <Switch
                    checked={syncSettings.autoSync}
                    onCheckedChange={(checked) =>
                      setSyncSettings({ ...syncSettings, autoSync: checked })
                    }
                  />
                </div>

                {syncSettings.autoSync && (
                  <div className="space-y-2">
                    <Label className="text-xs">Sync Frequency</Label>
                    <Select
                      value={syncSettings.syncFrequency}
                      onValueChange={(value) =>
                        setSyncSettings({ ...syncSettings, syncFrequency: value })
                      }
                    >
                      <SelectTrigger className="h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="realtime">Real-time</SelectItem>
                        <SelectItem value="hourly">Every Hour</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <p className="text-sm">Sync on Payment</p>
                  <Switch
                    checked={syncSettings.syncOnPayment}
                    onCheckedChange={(checked) =>
                      setSyncSettings({ ...syncSettings, syncOnPayment: checked })
                    }
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Data to Sync */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Data Sync Configuration</CardTitle>
              <CardDescription>Select what data to sync with Zoho Books</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Invoices</p>
                      <p className="text-xs text-muted-foreground">Fee demands as invoices</p>
                    </div>
                  </div>
                  <Switch
                    checked={syncSettings.syncInvoices}
                    onCheckedChange={(checked) =>
                      setSyncSettings({ ...syncSettings, syncInvoices: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100 dark:bg-green-900/30">
                      <Zap className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Payments</p>
                      <p className="text-xs text-muted-foreground">Collection receipts</p>
                    </div>
                  </div>
                  <Switch
                    checked={syncSettings.syncPayments}
                    onCheckedChange={(checked) =>
                      setSyncSettings({ ...syncSettings, syncPayments: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 dark:bg-blue-900/30">
                      <Database className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Contacts</p>
                      <p className="text-xs text-muted-foreground">Student/Parent data</p>
                    </div>
                  </div>
                  <Switch
                    checked={syncSettings.syncContacts}
                    onCheckedChange={(checked) =>
                      setSyncSettings({ ...syncSettings, syncContacts: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between rounded-lg border p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-100 dark:bg-purple-900/30">
                      <ArrowRightLeft className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Chart of Accounts</p>
                      <p className="text-xs text-muted-foreground">Fee heads mapping</p>
                    </div>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Field Mapping */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">Field Mapping</CardTitle>
                  <CardDescription>Map FeeFlo fields to Zoho Books fields</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  View Guide
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>FeeFlo Field</TableHead>
                    <TableHead>Zoho Books Field</TableHead>
                    <TableHead>Required</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fieldMappings.zoho.map((mapping, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{mapping.feefloField}</TableCell>
                      <TableCell>
                        <Select defaultValue={mapping.zohoField}>
                          <SelectTrigger className="h-8 w-48">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value={mapping.zohoField}>{mapping.zohoField}</SelectItem>
                            <SelectItem value="custom">Custom Field</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        {mapping.required ? (
                          <Badge variant="secondary" className="text-xs">Required</Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">Optional</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Settings2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tally Prime Tab */}
        <TabsContent value="tally" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Connection Status */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <TallyLogo className="h-10 w-10" />
                    <div>
                      <CardTitle>Tally Prime</CardTitle>
                      <CardDescription>Desktop integration via Tally Connector</CardDescription>
                    </div>
                  </div>
                  <Badge variant="secondary">
                    <XCircle className="mr-1 h-3 w-3" />
                    Not Connected
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="rounded-lg border border-dashed p-6 text-center">
                  <TallyLogo className="mx-auto h-16 w-16 opacity-50" />
                  <h3 className="mt-4 text-lg font-medium">Connect Tally Prime</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Export fee collection data directly to Tally Prime for seamless accounting
                  </p>
                  <div className="mt-6 flex items-center justify-center gap-3">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Link2 className="mr-2 h-4 w-4" />
                          Setup Tally Integration
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-lg">
                        <DialogHeader>
                          <DialogTitle>Setup Tally Integration</DialogTitle>
                          <DialogDescription>
                            Configure Tally Prime integration for automated voucher export
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label>Integration Method</Label>
                            <Select defaultValue="connector">
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="connector">Tally Connector (Recommended)</SelectItem>
                                <SelectItem value="xml">XML Export</SelectItem>
                                <SelectItem value="odbc">ODBC Connection</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label>Company Name in Tally</Label>
                            <Input placeholder="Springfield International School" />
                          </div>

                          <div className="space-y-2">
                            <Label>Tally Server IP</Label>
                            <Input placeholder="localhost or 192.168.1.100" />
                          </div>

                          <div className="space-y-2">
                            <Label>Tally Port</Label>
                            <Input placeholder="9000" defaultValue="9000" />
                          </div>

                          <div className="rounded-lg bg-muted p-3">
                            <p className="text-xs text-muted-foreground">
                              <strong>Note:</strong> Ensure Tally Prime is running with ODBC server
                              enabled. Go to Gateway of Tally → F12 → Advanced Configuration →
                              Enable ODBC Server.
                            </p>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline">Download Connector</Button>
                          <Button>Test Connection</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    <Button variant="outline">
                      <Download className="mr-2 h-4 w-4" />
                      Download Connector
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Export Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Export Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs">Export Format</Label>
                  <Select
                    value={tallySettings.exportFormat}
                    onValueChange={(value) =>
                      setTallySettings({ ...tallySettings, exportFormat: value })
                    }
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="xml">Tally XML</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Voucher Type</Label>
                  <Select
                    value={tallySettings.voucherType}
                    onValueChange={(value) =>
                      setTallySettings({ ...tallySettings, voucherType: value })
                    }
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="receipt">Receipt</SelectItem>
                      <SelectItem value="payment">Payment</SelectItem>
                      <SelectItem value="journal">Journal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs">Ledger Group</Label>
                  <Select
                    value={tallySettings.ledgerGroup}
                    onValueChange={(value) =>
                      setTallySettings({ ...tallySettings, ledgerGroup: value })
                    }
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Sundry Debtors">Sundry Debtors</SelectItem>
                      <SelectItem value="Sundry Creditors">Sundry Creditors</SelectItem>
                      <SelectItem value="Direct Income">Direct Income</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div>
                    <p className="text-sm font-medium">Auto Export</p>
                    <p className="text-xs text-muted-foreground">Export on payment</p>
                  </div>
                  <Switch
                    checked={tallySettings.autoExport}
                    onCheckedChange={(checked) =>
                      setTallySettings({ ...tallySettings, autoExport: checked })
                    }
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Ledger Mapping */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">Ledger Mapping</CardTitle>
                  <CardDescription>Map FeeFlo fee heads to Tally ledgers</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <Upload className="mr-2 h-4 w-4" />
                  Import from Tally
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fee Head (FeeFlo)</TableHead>
                    <TableHead>Tally Ledger</TableHead>
                    <TableHead>Ledger Group</TableHead>
                    <TableHead>GST Applicable</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Tuition Fee</TableCell>
                    <TableCell>
                      <Select defaultValue="tuition-fee">
                        <SelectTrigger className="h-8 w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="tuition-fee">Tuition Fee Income</SelectItem>
                          <SelectItem value="fees-income">Fees Income</SelectItem>
                          <SelectItem value="custom">Create New</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">Direct Income</TableCell>
                    <TableCell>
                      <Checkbox defaultChecked />
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        <Settings2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Transport Fee</TableCell>
                    <TableCell>
                      <Select defaultValue="transport-fee">
                        <SelectTrigger className="h-8 w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="transport-fee">Transport Fee Income</SelectItem>
                          <SelectItem value="fees-income">Fees Income</SelectItem>
                          <SelectItem value="custom">Create New</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">Direct Income</TableCell>
                    <TableCell>
                      <Checkbox defaultChecked />
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        <Settings2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Lab Fee</TableCell>
                    <TableCell>
                      <Select defaultValue="lab-fee">
                        <SelectTrigger className="h-8 w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="lab-fee">Laboratory Fee Income</SelectItem>
                          <SelectItem value="fees-income">Fees Income</SelectItem>
                          <SelectItem value="custom">Create New</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">Direct Income</TableCell>
                    <TableCell>
                      <Checkbox />
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        <Settings2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Admission Fee</TableCell>
                    <TableCell>
                      <Select defaultValue="admission-fee">
                        <SelectTrigger className="h-8 w-40">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admission-fee">Admission Fee Income</SelectItem>
                          <SelectItem value="fees-income">Fees Income</SelectItem>
                          <SelectItem value="custom">Create New</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">Direct Income</TableCell>
                    <TableCell>
                      <Checkbox defaultChecked />
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">
                        <Settings2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Manual Export */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Manual Export</CardTitle>
              <CardDescription>Export transactions for a specific date range</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap items-end gap-4">
                <div className="space-y-2">
                  <Label className="text-xs">From Date</Label>
                  <Input type="date" className="w-40" />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">To Date</Label>
                  <Input type="date" className="w-40" />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Export Type</Label>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Transactions</SelectItem>
                      <SelectItem value="payments">Payments Only</SelectItem>
                      <SelectItem value="refunds">Refunds Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button>
                  <Download className="mr-2 h-4 w-4" />
                  Export to Tally
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sync History Tab */}
        <TabsContent value="sync-history" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-base">Sync History</CardTitle>
                  <CardDescription>Recent synchronization activities</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select defaultValue="all">
                    <SelectTrigger className="h-9 w-40">
                      <SelectValue placeholder="Integration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Integrations</SelectItem>
                      <SelectItem value="zoho">Zoho Books</SelectItem>
                      <SelectItem value="tally">Tally Prime</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Export Log
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sync ID</TableHead>
                    <TableHead>Integration</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Records</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {syncHistory.map((sync) => (
                    <TableRow key={sync.id}>
                      <TableCell className="font-mono text-xs">{sync.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {sync.integration === "Zoho Books" ? (
                            <ZohoLogo className="h-5 w-5" />
                          ) : (
                            <TallyLogo className="h-5 w-5" />
                          )}
                          <span className="text-sm">{sync.integration}</span>
                        </div>
                      </TableCell>
                      <TableCell>{sync.type}</TableCell>
                      <TableCell>{sync.records}</TableCell>
                      <TableCell className="text-muted-foreground">{sync.duration}</TableCell>
                      <TableCell>
                        <Badge
                          variant={sync.status === "success" ? "default" : "destructive"}
                          className={
                            sync.status === "success"
                              ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                              : ""
                          }
                        >
                          {sync.status === "success" ? (
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                          ) : (
                            <XCircle className="mr-1 h-3 w-3" />
                          )}
                          {sync.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {sync.timestamp}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View Details
                        </Button>
                        {sync.status === "failed" && (
                          <Button variant="ghost" size="sm">
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Connect Dialog */}
      <Dialog open={showConnectDialog} onOpenChange={setShowConnectDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Connect to Zoho Books</DialogTitle>
            <DialogDescription>
              Authorize FeeFlo to access your Zoho Books account
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-center">
              <ZohoLogo className="h-20 w-20" />
            </div>
            <p className="text-center text-sm text-muted-foreground">
              Click the button below to securely connect your Zoho Books account. You will be
              redirected to Zoho for authorization.
            </p>
            <div className="rounded-lg bg-muted p-3 text-xs text-muted-foreground">
              <p className="font-medium">FeeFlo will be able to:</p>
              <ul className="mt-2 list-inside list-disc space-y-1">
                <li>Create and update invoices</li>
                <li>Record payments and receipts</li>
                <li>Create and manage contacts</li>
                <li>Access chart of accounts</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConnectDialog(false)}>
              Cancel
            </Button>
            <Button className="gap-2">
              <ExternalLink className="h-4 w-4" />
              Connect with Zoho
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
