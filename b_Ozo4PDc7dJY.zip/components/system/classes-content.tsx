"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import {
  School,
  Plus,
  Users,
  Edit2,
  Trash2,
  MoreHorizontal,
  ChevronRight,
  GraduationCap,
  Building2,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const classData = [
  {
    id: 1,
    name: "Class 1",
    divisions: [
      { id: "1-A", name: "A", students: 45, classTeacher: "Mrs. Sharma" },
      { id: "1-B", name: "B", students: 42, classTeacher: "Mrs. Patel" },
      { id: "1-C", name: "C", students: 44, classTeacher: "Mrs. Gupta" },
    ],
    totalStudents: 131,
    feeStructure: "Primary Fee Structure",
  },
  {
    id: 2,
    name: "Class 2",
    divisions: [
      { id: "2-A", name: "A", students: 43, classTeacher: "Mrs. Singh" },
      { id: "2-B", name: "B", students: 41, classTeacher: "Mrs. Verma" },
    ],
    totalStudents: 84,
    feeStructure: "Primary Fee Structure",
  },
  {
    id: 3,
    name: "Class 3",
    divisions: [
      { id: "3-A", name: "A", students: 46, classTeacher: "Mrs. Joshi" },
      { id: "3-B", name: "B", students: 44, classTeacher: "Mrs. Kumar" },
      { id: "3-C", name: "C", students: 45, classTeacher: "Mrs. Reddy" },
    ],
    totalStudents: 135,
    feeStructure: "Primary Fee Structure",
  },
  {
    id: 8,
    name: "Class 8",
    divisions: [
      { id: "8-A", name: "A", students: 48, classTeacher: "Mr. Sharma" },
      { id: "8-B", name: "B", students: 47, classTeacher: "Mr. Patel" },
      { id: "8-C", name: "C", students: 46, classTeacher: "Mr. Mehta" },
    ],
    totalStudents: 141,
    feeStructure: "Middle School Structure",
  },
  {
    id: 9,
    name: "Class 9",
    divisions: [
      { id: "9-A", name: "A", students: 50, classTeacher: "Mr. Verma" },
      { id: "9-B", name: "B", students: 48, classTeacher: "Mr. Singh" },
    ],
    totalStudents: 98,
    feeStructure: "Secondary Fee Structure",
  },
  {
    id: 10,
    name: "Class 10",
    divisions: [
      { id: "10-A", name: "A", students: 52, classTeacher: "Mr. Gupta" },
      { id: "10-B", name: "B", students: 50, classTeacher: "Mr. Kumar" },
    ],
    totalStudents: 102,
    feeStructure: "Secondary Fee Structure",
  },
]

export function ClassesContent() {
  const [showAddClass, setShowAddClass] = useState(false)
  const [showAddDivision, setShowAddDivision] = useState(false)
  const [selectedClass, setSelectedClass] = useState<typeof classData[0] | null>(null)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Classes & Divisions</h1>
          <p className="text-sm text-muted-foreground">
            Configure class structure and divisions for fee management
          </p>
        </div>
        <Button className="gap-2" onClick={() => setShowAddClass(true)}>
          <Plus className="h-4 w-4" />
          Add Class
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Classes</p>
                <p className="text-2xl font-bold">{classData.length}</p>
              </div>
              <div className="rounded-lg bg-primary/10 p-2.5 text-primary">
                <School className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Divisions</p>
                <p className="text-2xl font-bold">
                  {classData.reduce((sum, c) => sum + c.divisions.length, 0)}
                </p>
              </div>
              <div className="rounded-lg bg-blue-100 p-2.5 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
                <Building2 className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold">
                  {classData.reduce((sum, c) => sum + c.totalStudents, 0)}
                </p>
              </div>
              <div className="rounded-lg bg-green-100 p-2.5 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                <Users className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Fee Structures</p>
                <p className="text-2xl font-bold">3</p>
              </div>
              <div className="rounded-lg bg-orange-100 p-2.5 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400">
                <GraduationCap className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Classes Accordion */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-medium">Class Structure</CardTitle>
          <CardDescription>Manage classes and their divisions</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" className="w-full">
            {classData.map((cls) => (
              <AccordionItem key={cls.id} value={cls.id.toString()}>
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center justify-between w-full pr-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary font-semibold text-sm">
                        {cls.id}
                      </div>
                      <div className="text-left">
                        <p className="font-medium">{cls.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {cls.divisions.length} divisions | {cls.totalStudents} students
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge variant="outline" className="font-normal">
                        {cls.feeStructure}
                      </Badge>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="pl-12 pr-4 pb-2">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm text-muted-foreground">Divisions</p>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs gap-1"
                        onClick={() => {
                          setSelectedClass(cls)
                          setShowAddDivision(true)
                        }}
                      >
                        <Plus className="h-3 w-3" />
                        Add Division
                      </Button>
                    </div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Division</TableHead>
                          <TableHead>Class Teacher</TableHead>
                          <TableHead>Students</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cls.divisions.map((div) => (
                          <TableRow key={div.id}>
                            <TableCell>
                              <Badge variant="secondary" className="font-medium">
                                {cls.name}-{div.name}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {div.classTeacher}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Users className="h-3.5 w-3.5 text-muted-foreground" />
                                {div.students}
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>
                                    <Users className="mr-2 h-4 w-4" />
                                    View Students
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Edit2 className="mr-2 h-4 w-4" />
                                    Edit Division
                                  </DropdownMenuItem>
                                  <DropdownMenuItem className="text-destructive">
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete Division
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      {/* Add Class Dialog */}
      <Dialog open={showAddClass} onOpenChange={setShowAddClass}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Class</DialogTitle>
            <DialogDescription>
              Create a new class for fee management
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Class Name</Label>
              <Input placeholder="e.g., Class 11" />
            </div>
            <div className="space-y-2">
              <Label>Class Code</Label>
              <Input placeholder="e.g., 11" />
            </div>
            <div className="space-y-2">
              <Label>Fee Structure</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select fee structure" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="primary">Primary Fee Structure</SelectItem>
                  <SelectItem value="middle">Middle School Structure</SelectItem>
                  <SelectItem value="secondary">Secondary Fee Structure</SelectItem>
                  <SelectItem value="senior">Senior Secondary Structure</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Academic Level</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="primary">Primary (1-5)</SelectItem>
                  <SelectItem value="middle">Middle (6-8)</SelectItem>
                  <SelectItem value="secondary">Secondary (9-10)</SelectItem>
                  <SelectItem value="senior">Senior Secondary (11-12)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddClass(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowAddClass(false)}>Create Class</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Division Dialog */}
      <Dialog open={showAddDivision} onOpenChange={setShowAddDivision}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Division to {selectedClass?.name}</DialogTitle>
            <DialogDescription>
              Create a new division for this class
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Division Name</Label>
              <Input placeholder="e.g., D" />
            </div>
            <div className="space-y-2">
              <Label>Class Teacher</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select teacher" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="teacher1">Mrs. Sharma</SelectItem>
                  <SelectItem value="teacher2">Mr. Patel</SelectItem>
                  <SelectItem value="teacher3">Mrs. Gupta</SelectItem>
                  <SelectItem value="teacher4">Mr. Singh</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Maximum Capacity</Label>
              <Input type="number" placeholder="e.g., 50" defaultValue={50} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDivision(false)}>
              Cancel
            </Button>
            <Button onClick={() => setShowAddDivision(false)}>Add Division</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
