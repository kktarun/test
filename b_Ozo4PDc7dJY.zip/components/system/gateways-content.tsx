"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Separator } from "@/components/ui/separator"
import {
  CreditCard,
  Smartphone,
  QrCode,
  Landmark,
  Wallet,
  Plus,
  CheckCircle2,
  Clock,
  AlertCircle,
  Settings,
  Trash2,
  Edit,
  Star,
  StarOff,
  ArrowUpDown,
  Eye,
  EyeOff,
  Copy,
  ExternalLink,
  Shield,
  Zap,
  RefreshCcw,
  IndianRupee,
  MoreVertical,
  TestTube,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"

interface PaymentGateway {
  id: string
  name: string
  logo: string
  status: "active" | "pending" | "inactive" | "error"
  isPrimary: boolean
  mode: "live" | "test"
  merchantId: string
  apiKey: string
  secretKey: string
  webhookUrl: string
  methods: {
    upi: boolean
    cards: boolean
    netbanking: boolean
    wallets: boolean
    qr: boolean
    emi: boolean
    upiAutopay: boolean
    cardAutopay: boolean
  }
  limits: {
    min: number
    max: number
    daily: number
  }
  fees: {
    upi: number
    cards: number
    netbanking: number
    wallets: number
  }
  successRate: number
  lastTransaction: string
}

const availableGateways = [
  { id: "razorpay", name: "Razorpay", logo: "R", color: "bg-blue-500" },
  { id: "paytm", name: "Paytm PG", logo: "P", color: "bg-sky-500" },
  { id: "phonepe", name: "PhonePe PG", logo: "Ph", color: "bg-purple-500" },
  { id: "billdesk", name: "BillDesk", logo: "B", color: "bg-orange-500" },
  { id: "ccavenue", name: "CCAvenue", logo: "CC", color: "bg-green-500" },
  { id: "cashfree", name: "Cashfree", logo: "CF", color: "bg-emerald-500" },
  { id: "easebuzz", name: "Easebuzz", logo: "E", color: "bg-teal-500" },
  { id: "instamojo", name: "Instamojo", logo: "I", color: "bg-pink-500" },
]

export function GatewaysContent() {
  const [gateways, setGateways] = useState<PaymentGateway[]>([
    {
      id: "razorpay",
      name: "Razorpay",
      logo: "R",
      status: "active",
      isPrimary: true,
      mode: "live",
      merchantId: "rzp_live_abc123xyz",
      apiKey: "rzp_live_abc123xyz456",
      secretKey: "••••••••••••••••",
      webhookUrl: "https://feeflo.app/webhooks/razorpay",
      methods: {
        upi: true,
        cards: true,
        netbanking: true,
        wallets: true,
        qr: true,
        emi: false,
        upiAutopay: true,
        cardAutopay: false,
      },
      limits: { min: 100, max: 500000, daily: 5000000 },
      fees: { upi: 0, cards: 2, netbanking: 1.5, wallets: 1.5 },
      successRate: 97.5,
      lastTransaction: "2 mins ago",
    },
    {
      id: "paytm",
      name: "Paytm PG",
      logo: "P",
      status: "active",
      isPrimary: false,
      mode: "live",
      merchantId: "DPSMID123456789",
      apiKey: "paytm_live_key_789",
      secretKey: "••••••••••••••••",
      webhookUrl: "https://feeflo.app/webhooks/paytm",
      methods: {
        upi: true,
        cards: true,
        netbanking: true,
        wallets: true,
        qr: false,
        emi: true,
        upiAutopay: false,
        cardAutopay: false,
      },
      limits: { min: 100, max: 200000, daily: 2000000 },
      fees: { upi: 0, cards: 1.8, netbanking: 1.5, wallets: 0 },
      successRate: 94.2,
      lastTransaction: "15 mins ago",
    },
    {
      id: "billdesk",
      name: "BillDesk",
      logo: "B",
      status: "pending",
      isPrimary: false,
      mode: "test",
      merchantId: "BDDPS001",
      apiKey: "billdesk_test_key",
      secretKey: "••••••••••••••••",
      webhookUrl: "https://feeflo.app/webhooks/billdesk",
      methods: {
        upi: false,
        cards: true,
        netbanking: true,
        wallets: false,
        qr: false,
        emi: false,
        upiAutopay: false,
        cardAutopay: true,
      },
      limits: { min: 500, max: 1000000, daily: 10000000 },
      fees: { upi: 0, cards: 1.5, netbanking: 1.2, wallets: 0 },
      successRate: 0,
      lastTransaction: "Never",
    },
  ])

  const [selectedGateway, setSelectedGateway] = useState<PaymentGateway | null>(null)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [newGatewayId, setNewGatewayId] = useState("")

  const [routingRules, setRoutingRules] = useState([
    { id: 1, condition: "Amount > ₹50,000", gateway: "Razorpay", priority: 1, enabled: true },
    { id: 2, condition: "Payment Method = UPI", gateway: "Paytm PG", priority: 2, enabled: true },
    { id: 3, condition: "Default Fallback", gateway: "Razorpay", priority: 99, enabled: true },
  ])

  const toggleMethod = (gatewayId: string, method: keyof PaymentGateway["methods"]) => {
    setGateways(gateways.map(g => {
      if (g.id === gatewayId) {
        return { ...g, methods: { ...g.methods, [method]: !g.methods[method] } }
      }
      return g
    }))
  }

  const setPrimaryGateway = (gatewayId: string) => {
    setGateways(gateways.map(g => ({
      ...g,
      isPrimary: g.id === gatewayId
    })))
  }

  const toggleGatewayStatus = (gatewayId: string) => {
    setGateways(gateways.map(g => {
      if (g.id === gatewayId) {
        return { ...g, status: g.status === "active" ? "inactive" : "active" }
      }
      return g
    }))
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-success/10 text-success border-0"><CheckCircle2 className="mr-1 h-3 w-3" />Active</Badge>
      case "pending":
        return <Badge className="bg-warning/10 text-warning-foreground border-0"><Clock className="mr-1 h-3 w-3" />Pending</Badge>
      case "error":
        return <Badge variant="destructive"><AlertCircle className="mr-1 h-3 w-3" />Error</Badge>
      default:
        return <Badge variant="secondary">Inactive</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Payment Gateways</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Configure multiple payment gateways and routing rules
          </p>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Gateway
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add Payment Gateway</DialogTitle>
              <DialogDescription>
                Select a payment gateway to integrate with FeeFlo
              </DialogDescription>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-3 py-4">
              {availableGateways.filter(ag => !gateways.find(g => g.id === ag.id)).map((gateway) => (
                <button
                  key={gateway.id}
                  onClick={() => setNewGatewayId(gateway.id)}
                  className={`p-4 border rounded-lg text-left transition-colors hover:border-primary ${newGatewayId === gateway.id ? "border-primary bg-primary/5" : ""}`}
                >
                  <div className={`h-10 w-10 rounded-lg ${gateway.color} flex items-center justify-center text-white font-semibold mb-2`}>
                    {gateway.logo}
                  </div>
                  <p className="font-medium text-sm">{gateway.name}</p>
                </button>
              ))}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
              <Button disabled={!newGatewayId}>Continue Setup</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Gateways</p>
                <p className="text-2xl font-semibold mt-1">
                  {gateways.filter(g => g.status === "active").length}
                </p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center">
                <CheckCircle2 className="h-5 w-5 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Success Rate</p>
                <p className="text-2xl font-semibold mt-1">
                  {(gateways.filter(g => g.status === "active").reduce((sum, g) => sum + g.successRate, 0) / gateways.filter(g => g.status === "active").length || 0).toFixed(1)}%
                </p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Zap className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Routing Rules</p>
                <p className="text-2xl font-semibold mt-1">{routingRules.length}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                <ArrowUpDown className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Payment Methods</p>
                <p className="text-2xl font-semibold mt-1">8</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                <CreditCard className="h-5 w-5 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="gateways" className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="gateways">Gateways</TabsTrigger>
          <TabsTrigger value="methods">Payment Methods</TabsTrigger>
          <TabsTrigger value="routing">Smart Routing</TabsTrigger>
          <TabsTrigger value="fees">Fees & Limits</TabsTrigger>
        </TabsList>

        {/* Gateways Tab */}
        <TabsContent value="gateways" className="space-y-4">
          {gateways.map((gateway) => (
            <Card key={gateway.id} className="border-border/50">
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <div className={`h-12 w-12 rounded-xl ${availableGateways.find(g => g.id === gateway.id)?.color || "bg-primary"} flex items-center justify-center text-white font-bold`}>
                      {gateway.logo}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-lg">{gateway.name}</h3>
                        {gateway.isPrimary && (
                          <Badge variant="outline" className="text-xs">
                            <Star className="mr-1 h-3 w-3 fill-current" />
                            Primary
                          </Badge>
                        )}
                        {getStatusBadge(gateway.status)}
                        <Badge variant={gateway.mode === "live" ? "default" : "secondary"} className="text-xs">
                          {gateway.mode === "live" ? "Live" : "Test Mode"}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        MID: {gateway.merchantId} | Last txn: {gateway.lastTransaction}
                      </p>
                      {gateway.status === "active" && (
                        <div className="flex items-center gap-4 mt-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">Success Rate</span>
                            <Progress value={gateway.successRate} className="w-20 h-1.5" />
                            <span className="text-xs font-medium">{gateway.successRate}%</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => setSelectedGateway(gateway)}>
                      <Settings className="mr-2 h-4 w-4" />
                      Configure
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {!gateway.isPrimary && (
                          <DropdownMenuItem onClick={() => setPrimaryGateway(gateway.id)}>
                            <Star className="mr-2 h-4 w-4" />
                            Set as Primary
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem>
                          <TestTube className="mr-2 h-4 w-4" />
                          Test Connection
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <RefreshCcw className="mr-2 h-4 w-4" />
                          Sync Status
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => toggleGatewayStatus(gateway.id)}>
                          {gateway.status === "active" ? (
                            <><EyeOff className="mr-2 h-4 w-4" />Disable Gateway</>
                          ) : (
                            <><Eye className="mr-2 h-4 w-4" />Enable Gateway</>
                          )}
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Remove Gateway
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>

                {/* Payment Methods Toggle */}
                <div className="mt-6 pt-4 border-t">
                  <p className="text-sm font-medium mb-3">Enabled Payment Methods</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      { key: "upi", label: "UPI", icon: Smartphone },
                      { key: "cards", label: "Cards", icon: CreditCard },
                      { key: "netbanking", label: "Net Banking", icon: Landmark },
                      { key: "wallets", label: "Wallets", icon: Wallet },
                      { key: "qr", label: "Dynamic QR", icon: QrCode },
                      { key: "emi", label: "EMI", icon: IndianRupee },
                      { key: "upiAutopay", label: "UPI Autopay", icon: RefreshCcw },
                      { key: "cardAutopay", label: "Card Autopay", icon: RefreshCcw },
                    ].map((method) => (
                      <div
                        key={method.key}
                        className={`flex items-center justify-between p-3 border rounded-lg transition-colors ${gateway.methods[method.key as keyof PaymentGateway["methods"]] ? "bg-primary/5 border-primary/30" : "bg-muted/30"}`}
                      >
                        <div className="flex items-center gap-2">
                          <method.icon className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{method.label}</span>
                        </div>
                        <Switch
                          checked={gateway.methods[method.key as keyof PaymentGateway["methods"]]}
                          onCheckedChange={() => toggleMethod(gateway.id, method.key as keyof PaymentGateway["methods"])}
                          disabled={gateway.status !== "active"}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* API Keys Section (Collapsed by default) */}
                <div className="mt-4 pt-4 border-t">
                  <button
                    onClick={() => setShowKeys({ ...showKeys, [gateway.id]: !showKeys[gateway.id] })}
                    className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-2"
                  >
                    <Shield className="h-4 w-4" />
                    {showKeys[gateway.id] ? "Hide API Credentials" : "Show API Credentials"}
                  </button>
                  {showKeys[gateway.id] && (
                    <div className="grid gap-4 md:grid-cols-2 mt-4">
                      <div className="space-y-2">
                        <Label className="text-xs">API Key / Key ID</Label>
                        <div className="flex gap-2">
                          <Input value={gateway.apiKey} readOnly className="font-mono text-xs" />
                          <Button variant="outline" size="icon">
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label className="text-xs">Secret Key</Label>
                        <div className="flex gap-2">
                          <Input value={gateway.secretKey} type="password" readOnly className="font-mono text-xs" />
                          <Button variant="outline" size="icon">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <Label className="text-xs">Webhook URL</Label>
                        <div className="flex gap-2">
                          <Input value={gateway.webhookUrl} readOnly className="font-mono text-xs" />
                          <Button variant="outline" size="icon">
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="icon">
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Payment Methods Tab */}
        <TabsContent value="methods" className="space-y-4">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Global Payment Method Settings</CardTitle>
              <CardDescription>
                Enable or disable payment methods across all gateways. Individual gateway settings can override these.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Payment Method</TableHead>
                    <TableHead>Global Status</TableHead>
                    {gateways.filter(g => g.status === "active").map(g => (
                      <TableHead key={g.id} className="text-center">{g.name}</TableHead>
                    ))}
                    <TableHead className="text-right">Avg. Fee</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[
                    { key: "upi", label: "UPI", icon: Smartphone, fee: "0%" },
                    { key: "cards", label: "Credit/Debit Cards", icon: CreditCard, fee: "1.8-2%" },
                    { key: "netbanking", label: "Net Banking", icon: Landmark, fee: "1.2-1.5%" },
                    { key: "wallets", label: "Wallets", icon: Wallet, fee: "1.5%" },
                    { key: "qr", label: "Dynamic QR", icon: QrCode, fee: "0%" },
                    { key: "emi", label: "EMI", icon: IndianRupee, fee: "0.5-1%" },
                    { key: "upiAutopay", label: "UPI Autopay (Mandates)", icon: RefreshCcw, fee: "0%" },
                    { key: "cardAutopay", label: "Card Autopay (SI)", icon: RefreshCcw, fee: "0.5%" },
                  ].map((method) => {
                    const enabledCount = gateways.filter(g => g.status === "active" && g.methods[method.key as keyof PaymentGateway["methods"]]).length
                    const totalActive = gateways.filter(g => g.status === "active").length
                    return (
                      <TableRow key={method.key}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <method.icon className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{method.label}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={enabledCount > 0 ? "default" : "secondary"}>
                            {enabledCount}/{totalActive} Gateways
                          </Badge>
                        </TableCell>
                        {gateways.filter(g => g.status === "active").map(g => (
                          <TableCell key={g.id} className="text-center">
                            <Switch
                              checked={g.methods[method.key as keyof PaymentGateway["methods"]]}
                              onCheckedChange={() => toggleMethod(g.id, method.key as keyof PaymentGateway["methods"])}
                            />
                          </TableCell>
                        ))}
                        <TableCell className="text-right text-muted-foreground">{method.fee}</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Smart Routing Tab */}
        <TabsContent value="routing" className="space-y-4">
          <Card className="border-border/50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Smart Routing Rules</CardTitle>
                  <CardDescription>
                    Automatically route transactions to the best gateway based on conditions
                  </CardDescription>
                </div>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Rule
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Priority</TableHead>
                    <TableHead>Condition</TableHead>
                    <TableHead>Route To</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {routingRules.map((rule) => (
                    <TableRow key={rule.id}>
                      <TableCell>
                        <Badge variant="outline">#{rule.priority}</Badge>
                      </TableCell>
                      <TableCell className="font-medium">{rule.condition}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{rule.gateway}</Badge>
                      </TableCell>
                      <TableCell>
                        <Switch checked={rule.enabled} />
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Fallback Settings</CardTitle>
              <CardDescription>
                Configure automatic failover when primary gateway fails
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium text-sm">Enable Auto-Retry</p>
                  <p className="text-xs text-muted-foreground">Automatically retry failed transactions on backup gateway</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium text-sm">Retry Timeout</p>
                  <p className="text-xs text-muted-foreground">Wait time before retrying on fallback gateway</p>
                </div>
                <Select defaultValue="5">
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 seconds</SelectItem>
                    <SelectItem value="5">5 seconds</SelectItem>
                    <SelectItem value="10">10 seconds</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium text-sm">Gateway Priority Order</p>
                  <p className="text-xs text-muted-foreground">Order in which gateways are tried for failover</p>
                </div>
                <div className="flex items-center gap-2">
                  {gateways.filter(g => g.status === "active").map((g, i) => (
                    <Badge key={g.id} variant={g.isPrimary ? "default" : "outline"}>
                      {i + 1}. {g.name}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fees & Limits Tab */}
        <TabsContent value="fees" className="space-y-4">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Transaction Fees by Gateway</CardTitle>
              <CardDescription>
                Compare fees across gateways for each payment method
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Gateway</TableHead>
                    <TableHead className="text-center">UPI</TableHead>
                    <TableHead className="text-center">Cards</TableHead>
                    <TableHead className="text-center">Net Banking</TableHead>
                    <TableHead className="text-center">Wallets</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {gateways.map((gateway) => (
                    <TableRow key={gateway.id}>
                      <TableCell className="font-medium">{gateway.name}</TableCell>
                      <TableCell className="text-center">{gateway.fees.upi}%</TableCell>
                      <TableCell className="text-center">{gateway.fees.cards}%</TableCell>
                      <TableCell className="text-center">{gateway.fees.netbanking}%</TableCell>
                      <TableCell className="text-center">{gateway.fees.wallets}%</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Transaction Limits</CardTitle>
              <CardDescription>
                Configure minimum, maximum, and daily limits per gateway
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Gateway</TableHead>
                    <TableHead className="text-right">Min Amount</TableHead>
                    <TableHead className="text-right">Max Amount</TableHead>
                    <TableHead className="text-right">Daily Limit</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {gateways.map((gateway) => (
                    <TableRow key={gateway.id}>
                      <TableCell className="font-medium">{gateway.name}</TableCell>
                      <TableCell className="text-right">₹{gateway.limits.min.toLocaleString()}</TableCell>
                      <TableCell className="text-right">₹{gateway.limits.max.toLocaleString()}</TableCell>
                      <TableCell className="text-right">₹{gateway.limits.daily.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
