"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Plus, 
  Edit, 
  Trash2,
  CheckCircle2,
  Clock,
  AlertCircle,
  Building2,
  Landmark,
  IndianRupee,
  MoreHorizontal,
  ArrowRight,
  PieChart,
  Save,
  Info,
  RefreshCw,
  Copy,
  ExternalLink,
  Shield,
  ShieldCheck,
  Loader2,
  Eye,
  EyeOff,
  Lock,
  ChevronLeft,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { Slider } from "@/components/ui/slider"

// Bank accounts
const bankAccounts = [
  {
    id: "BA001",
    name: "Main Operating Account",
    accountNumber: "1234567890123456",
    ifscCode: "HDFC0001234",
    bankName: "HDFC Bank",
    branch: "Connaught Place, New Delhi",
    accountType: "Current",
    isPrimary: true,
    status: "verified",
    balance: 2450000,
    linkedGateway: "Razorpay",
    vpaId: "dpsdelhi@hdfcbank",
  },
  {
    id: "BA002",
    name: "Transport Fee Account",
    accountNumber: "9876543210987654",
    ifscCode: "ICIC0001234",
    bankName: "ICICI Bank",
    branch: "South Extension, New Delhi",
    accountType: "Current",
    isPrimary: false,
    status: "verified",
    balance: 850000,
    linkedGateway: "Razorpay",
    vpaId: "dpstransport@icici",
  },
  {
    id: "BA003",
    name: "Development Fund Account",
    accountNumber: "5678901234567890",
    ifscCode: "SBIN0001234",
    bankName: "State Bank of India",
    branch: "Parliament Street, New Delhi",
    accountType: "Savings",
    isPrimary: false,
    status: "verified",
    balance: 1250000,
    linkedGateway: "Paytm",
    vpaId: "dpsfund@sbi",
  },
  {
    id: "BA004",
    name: "Hostel Fee Account",
    accountNumber: "3456789012345678",
    ifscCode: "AXIS0001234",
    bankName: "Axis Bank",
    branch: "Nehru Place, New Delhi",
    accountType: "Current",
    isPrimary: false,
    status: "pending",
    balance: 0,
    linkedGateway: null,
    vpaId: null,
  },
]

// Fee heads with split configuration
const feeHeads = [
  {
    id: "FH001",
    name: "Tuition Fee",
    code: "TUI",
    amount: 7500,
    frequency: "Quarterly",
  },
  {
    id: "FH002",
    name: "Admission Fee",
    code: "ADM",
    amount: 5000,
    frequency: "One-time",
  },
  {
    id: "FH003",
    name: "Transport Fee",
    code: "TRN",
    amount: 4500,
    frequency: "Quarterly",
  },
  {
    id: "FH004",
    name: "Activity Fee",
    code: "ACT",
    amount: 3000,
    frequency: "Annual",
  },
  {
    id: "FH005",
    name: "Lab Fee",
    code: "LAB",
    amount: 4000,
    frequency: "Annual",
  },
  {
    id: "FH006",
    name: "Development Fee",
    code: "DEV",
    amount: 2500,
    frequency: "Annual",
  },
  {
    id: "FH007",
    name: "Hostel Fee",
    code: "HST",
    amount: 12000,
    frequency: "Quarterly",
  },
]

// Split configurations
const splitConfigurations = [
  {
    feeHeadId: "FH001",
    feeHeadName: "Tuition Fee",
    splits: [
      { bankAccountId: "BA001", bankName: "HDFC Bank", accountName: "Main Operating Account", percentage: 100 },
    ],
  },
  {
    feeHeadId: "FH002",
    feeHeadName: "Admission Fee",
    splits: [
      { bankAccountId: "BA001", bankName: "HDFC Bank", accountName: "Main Operating Account", percentage: 70 },
      { bankAccountId: "BA003", bankName: "State Bank of India", accountName: "Development Fund Account", percentage: 30 },
    ],
  },
  {
    feeHeadId: "FH003",
    feeHeadName: "Transport Fee",
    splits: [
      { bankAccountId: "BA002", bankName: "ICICI Bank", accountName: "Transport Fee Account", percentage: 100 },
    ],
  },
  {
    feeHeadId: "FH004",
    feeHeadName: "Activity Fee",
    splits: [
      { bankAccountId: "BA001", bankName: "HDFC Bank", accountName: "Main Operating Account", percentage: 50 },
      { bankAccountId: "BA003", bankName: "State Bank of India", accountName: "Development Fund Account", percentage: 50 },
    ],
  },
  {
    feeHeadId: "FH005",
    feeHeadName: "Lab Fee",
    splits: [
      { bankAccountId: "BA001", bankName: "HDFC Bank", accountName: "Main Operating Account", percentage: 100 },
    ],
  },
  {
    feeHeadId: "FH006",
    feeHeadName: "Development Fee",
    splits: [
      { bankAccountId: "BA003", bankName: "State Bank of India", accountName: "Development Fund Account", percentage: 100 },
    ],
  },
  {
    feeHeadId: "FH007",
    feeHeadName: "Hostel Fee",
    splits: [
      { bankAccountId: "BA004", bankName: "Axis Bank", accountName: "Hostel Fee Account", percentage: 100 },
    ],
  },
]

// Recent settlements
const recentSettlements = [
  {
    id: "SET001",
    date: "2024-03-15",
    totalAmount: 125000,
    splits: [
      { bankName: "HDFC Bank", amount: 87500, status: "settled" },
      { bankName: "ICICI Bank", amount: 25000, status: "settled" },
      { bankName: "SBI", amount: 12500, status: "settled" },
    ],
    transactionCount: 45,
    status: "completed",
  },
  {
    id: "SET002",
    date: "2024-03-14",
    totalAmount: 98000,
    splits: [
      { bankName: "HDFC Bank", amount: 68000, status: "settled" },
      { bankName: "ICICI Bank", amount: 18000, status: "settled" },
      { bankName: "SBI", amount: 12000, status: "processing" },
    ],
    transactionCount: 32,
    status: "partial",
  },
]

const supportedBanks = [
  { id: "hdfc", name: "HDFC Bank", loginUrl: "netbanking.hdfcbank.com", color: "bg-blue-500" },
  { id: "icici", name: "ICICI Bank", loginUrl: "infinity.icicibank.com", color: "bg-orange-500" },
  { id: "sbi", name: "State Bank of India", loginUrl: "retail.onlinesbi.sbi", color: "bg-blue-600" },
  { id: "axis", name: "Axis Bank", loginUrl: "axisbank.com", color: "bg-rose-500" },
  { id: "kotak", name: "Kotak Mahindra Bank", loginUrl: "netbanking.kotak.com", color: "bg-red-500" },
  { id: "yes", name: "Yes Bank", loginUrl: "yesbank.in", color: "bg-blue-400" },
  { id: "pnb", name: "Punjab National Bank", loginUrl: "pnbibanking.in", color: "bg-amber-600" },
  { id: "idfc", name: "IDFC First Bank", loginUrl: "my.idfcfirstbank.com", color: "bg-rose-600" },
]

type FetchedAccount = {
  accountNumber: string
  accountType: string
  ifscCode: string
  branch: string
  holderName: string
  balance: number
}

export function BankAccountsContent() {
  const [showAddBank, setShowAddBank] = useState(false)
  const [showConfigureSplit, setShowConfigureSplit] = useState(false)
  const [selectedFeeHead, setSelectedFeeHead] = useState<typeof splitConfigurations[0] | null>(null)
  const [splitValues, setSplitValues] = useState<{ bankAccountId: string; percentage: number }[]>([])

  // Add-bank wizard state
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3>(1)
  const [selectedBank, setSelectedBank] = useState<typeof supportedBanks[0] | null>(null)
  const [nbUserId, setNbUserId] = useState("")
  const [nbPassword, setNbPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [fetchedAccounts, setFetchedAccounts] = useState<FetchedAccount[]>([])
  const [selectedFetchedIdx, setSelectedFetchedIdx] = useState<number | null>(null)

  const resetWizard = () => {
    setWizardStep(1)
    setSelectedBank(null)
    setNbUserId("")
    setNbPassword("")
    setShowPassword(false)
    setFetchedAccounts([])
    setSelectedFetchedIdx(null)
  }

  const handleVerifyNetbanking = () => {
    if (!selectedBank || !nbUserId || !nbPassword) return
    setVerifying(true)
    setTimeout(() => {
      // Simulated accounts fetched from netbanking
      const mockAccounts: FetchedAccount[] = [
        {
          accountNumber: "50100" + Math.floor(Math.random() * 10000000).toString().padStart(7, "0"),
          accountType: "Current",
          ifscCode: selectedBank.id.toUpperCase().slice(0, 4) + "0001234",
          branch: "Connaught Place, New Delhi",
          holderName: "Delhi Public School",
          balance: 2450000,
        },
        {
          accountNumber: "50200" + Math.floor(Math.random() * 10000000).toString().padStart(7, "0"),
          accountType: "Savings",
          ifscCode: selectedBank.id.toUpperCase().slice(0, 4) + "0001234",
          branch: "Connaught Place, New Delhi",
          holderName: "Delhi Public School - Hostel Trust",
          balance: 850000,
        },
      ]
      setFetchedAccounts(mockAccounts)
      setVerifying(false)
      setWizardStep(2)
    }, 1400)
  }

  const openSplitConfig = (config: typeof splitConfigurations[0]) => {
    setSelectedFeeHead(config)
    setSplitValues(config.splits.map(s => ({ bankAccountId: s.bankAccountId, percentage: s.percentage })))
    setShowConfigureSplit(true)
  }

  const addSplitAccount = () => {
    const usedAccounts = splitValues.map(s => s.bankAccountId)
    const availableAccount = bankAccounts.find(b => !usedAccounts.includes(b.id) && b.status === "verified")
    if (availableAccount) {
      setSplitValues([...splitValues, { bankAccountId: availableAccount.id, percentage: 0 }])
    }
  }

  const removeSplitAccount = (index: number) => {
    setSplitValues(splitValues.filter((_, i) => i !== index))
  }

  const updateSplitPercentage = (index: number, percentage: number) => {
    const newValues = [...splitValues]
    newValues[index].percentage = percentage
    setSplitValues(newValues)
  }

  const totalPercentage = splitValues.reduce((sum, s) => sum + s.percentage, 0)

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">Bank Accounts & Split Settlement</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Manage multiple bank accounts and configure automatic payment splits per fee head
            </p>
          </div>
          <Dialog
            open={showAddBank}
            onOpenChange={(open) => {
              setShowAddBank(open)
              if (!open) resetWizard()
            }}
          >
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Bank Account
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {wizardStep > 1 && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => setWizardStep((wizardStep - 1) as 1 | 2 | 3)}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                  )}
                  {wizardStep === 1 && "Connect Your Bank"}
                  {wizardStep === 2 && "Select Account to Link"}
                  {wizardStep === 3 && "Configure Account"}
                </DialogTitle>
                <DialogDescription>
                  {wizardStep === 1 && "Sign in securely with your netbanking credentials to verify account ownership"}
                  {wizardStep === 2 && `Accounts fetched from ${selectedBank?.name}. Select one to add.`}
                  {wizardStep === 3 && "Set a purpose and settlement preferences for this account"}
                </DialogDescription>
              </DialogHeader>

              {/* Progress stepper */}
              <div className="flex items-center gap-2 px-1">
                {[1, 2, 3].map((s, idx) => (
                  <div key={s} className="flex flex-1 items-center gap-2">
                    <div
                      className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold ${
                        wizardStep >= s
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {wizardStep > s ? <CheckCircle2 className="h-4 w-4" /> : s}
                    </div>
                    <span
                      className={`text-xs ${
                        wizardStep >= s ? "font-medium" : "text-muted-foreground"
                      }`}
                    >
                      {s === 1 && "Netbanking"}
                      {s === 2 && "Account"}
                      {s === 3 && "Configure"}
                    </span>
                    {idx < 2 && (
                      <div
                        className={`h-px flex-1 ${
                          wizardStep > s ? "bg-primary" : "bg-border"
                        }`}
                      />
                    )}
                  </div>
                ))}
              </div>

              {/* Step 1: Bank select + netbanking login */}
              {wizardStep === 1 && (
                <div className="space-y-4 py-2">
                  <div className="space-y-2">
                    <Label>Select Your Bank</Label>
                    <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                      {supportedBanks.map((bank) => (
                        <button
                          key={bank.id}
                          type="button"
                          onClick={() => setSelectedBank(bank)}
                          className={`flex flex-col items-center gap-2 rounded-lg border p-3 text-center transition-colors hover:bg-muted ${
                            selectedBank?.id === bank.id
                              ? "border-primary bg-primary/5"
                              : "border-border"
                          }`}
                        >
                          <div
                            className={`flex h-9 w-9 items-center justify-center rounded-md ${bank.color} text-white`}
                          >
                            <Landmark className="h-5 w-5" />
                          </div>
                          <div className="text-xs font-medium leading-tight">
                            {bank.name}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {selectedBank && (
                    <>
                      <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3">
                        <Shield className="mt-0.5 h-4 w-4 text-primary" />
                        <div className="space-y-1 text-xs">
                          <p className="font-medium text-foreground">
                            Secure netbanking verification
                          </p>
                          <p className="text-muted-foreground">
                            You&apos;ll be redirected to {selectedBank.loginUrl}. We use bank-grade TLS and never store your password. Credentials are only used to verify account ownership.
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Netbanking User ID</Label>
                        <Input
                          placeholder="Enter your netbanking user ID"
                          value={nbUserId}
                          onChange={(e) => setNbUserId(e.target.value)}
                          autoComplete="off"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Netbanking Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your netbanking password"
                            className="px-9"
                            value={nbPassword}
                            onChange={(e) => setNbPassword(e.target.value)}
                            autoComplete="new-password"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          An OTP may be sent to your registered mobile number after submission.
                        </p>
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* Step 2: Fetched accounts */}
              {wizardStep === 2 && (
                <div className="space-y-3 py-2">
                  <div className="flex items-center gap-2 rounded-lg border border-success/30 bg-success/5 p-3">
                    <ShieldCheck className="h-4 w-4 text-success" />
                    <p className="text-xs">
                      <span className="font-medium text-foreground">
                        Verified with {selectedBank?.name}
                      </span>
                      <span className="text-muted-foreground">
                        {" "}· {fetchedAccounts.length} account(s) found
                      </span>
                    </p>
                  </div>
                  <div className="space-y-2">
                    {fetchedAccounts.map((acc, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setSelectedFetchedIdx(idx)}
                        className={`w-full rounded-lg border p-4 text-left transition-colors hover:bg-muted ${
                          selectedFetchedIdx === idx
                            ? "border-primary bg-primary/5"
                            : "border-border"
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">
                                •••• {acc.accountNumber.slice(-4)}
                              </span>
                              <Badge variant="outline" className="text-[10px]">
                                {acc.accountType}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {acc.holderName}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {acc.ifscCode} · {acc.branch}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">
                              Available balance
                            </p>
                            <p className="font-semibold">
                              ₹{acc.balance.toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Step 3: Configure */}
              {wizardStep === 3 && selectedFetchedIdx !== null && (
                <div className="space-y-4 py-2">
                  <div className="rounded-lg border bg-muted/40 p-3 text-xs">
                    <p className="text-muted-foreground">Linking account</p>
                    <p className="font-semibold">
                      {selectedBank?.name} •••• {fetchedAccounts[selectedFetchedIdx].accountNumber.slice(-4)} · {fetchedAccounts[selectedFetchedIdx].holderName}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Account Name / Purpose</Label>
                    <Input placeholder="e.g., Transport Fee Account, Tuition Collection, Hostel Fund" />
                    <p className="text-xs text-muted-foreground">
                      This label helps you identify the account in split rules.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>UPI / VPA ID (Optional)</Label>
                    <Input placeholder={`e.g., school@${selectedBank?.id}`} />
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <Label>Set as Primary Account</Label>
                      <p className="text-xs text-muted-foreground">
                        Primary account receives payments not configured for split
                      </p>
                    </div>
                    <Switch />
                  </div>
                  <div className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <Label>Enable for Settlements</Label>
                      <p className="text-xs text-muted-foreground">
                        Gateway settlements will be credited to this account
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              )}

              <DialogFooter>
                {wizardStep === 1 && (
                  <>
                    <Button variant="outline" onClick={() => setShowAddBank(false)}>
                      Cancel
                    </Button>
                    <Button
                      onClick={handleVerifyNetbanking}
                      disabled={!selectedBank || !nbUserId || !nbPassword || verifying}
                    >
                      {verifying ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Connecting to {selectedBank?.name}...
                        </>
                      ) : (
                        <>
                          <ShieldCheck className="mr-2 h-4 w-4" />
                          Verify with Netbanking
                        </>
                      )}
                    </Button>
                  </>
                )}
                {wizardStep === 2 && (
                  <>
                    <Button variant="outline" onClick={() => setWizardStep(1)}>
                      Back
                    </Button>
                    <Button
                      onClick={() => setWizardStep(3)}
                      disabled={selectedFetchedIdx === null}
                    >
                      Continue
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </>
                )}
                {wizardStep === 3 && (
                  <>
                    <Button variant="outline" onClick={() => setWizardStep(2)}>
                      Back
                    </Button>
                    <Button
                      onClick={() => {
                        setShowAddBank(false)
                        resetWizard()
                      }}
                    >
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Link Account
                    </Button>
                  </>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card className="border-border/50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Accounts</p>
                  <p className="text-2xl font-semibold mt-1">{bankAccounts.length}</p>
                </div>
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Landmark className="h-5 w-5 text-primary" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {bankAccounts.filter(b => b.status === "verified").length} verified
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Balance</p>
                  <p className="text-2xl font-semibold mt-1">
                    ₹{(bankAccounts.reduce((sum, b) => sum + b.balance, 0) / 100000).toFixed(1)}L
                  </p>
                </div>
                <div className="h-10 w-10 rounded-full bg-chart-2/10 flex items-center justify-center">
                  <IndianRupee className="h-5 w-5 text-chart-2" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Across all accounts</p>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Fee Heads Configured</p>
                  <p className="text-2xl font-semibold mt-1">{splitConfigurations.length}</p>
                </div>
                <div className="h-10 w-10 rounded-full bg-chart-3/10 flex items-center justify-center">
                  <PieChart className="h-5 w-5 text-chart-3" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {splitConfigurations.filter(c => c.splits.length > 1).length} with splits
              </p>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today&apos;s Settlements</p>
                  <p className="text-2xl font-semibold mt-1">₹1.25L</p>
                </div>
                <div className="h-10 w-10 rounded-full bg-chart-4/10 flex items-center justify-center">
                  <RefreshCw className="h-5 w-5 text-chart-4" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">45 transactions</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="accounts" className="space-y-4">
          <TabsList className="bg-muted/50">
            <TabsTrigger value="accounts">Bank Accounts</TabsTrigger>
            <TabsTrigger value="splits">Fee Head Splits</TabsTrigger>
            <TabsTrigger value="settlements">Settlement History</TabsTrigger>
          </TabsList>

          {/* Bank Accounts Tab */}
          <TabsContent value="accounts" className="space-y-4">
            <div className="grid gap-4">
              {bankAccounts.map((account) => (
                <Card key={account.id} className={`border-border/50 ${account.isPrimary ? 'ring-2 ring-primary/20' : ''}`}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">
                          <Building2 className="h-6 w-6 text-muted-foreground" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{account.name}</h3>
                            {account.isPrimary && (
                              <Badge className="bg-primary/10 text-primary hover:bg-primary/20">Primary</Badge>
                            )}
                            <Badge
                              variant={account.status === "verified" ? "default" : "secondary"}
                              className={account.status === "verified" ? "bg-chart-2/10 text-chart-2 hover:bg-chart-2/20" : ""}
                            >
                              {account.status === "verified" ? (
                                <><CheckCircle2 className="mr-1 h-3 w-3" /> Verified</>
                              ) : (
                                <><Clock className="mr-1 h-3 w-3" /> Pending</>
                              )}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{account.bankName} - {account.branch}</p>
                          <div className="flex items-center gap-4 mt-2">
                            <div className="flex items-center gap-1">
                              <span className="text-xs text-muted-foreground">A/C:</span>
                              <code className="text-xs bg-muted px-1.5 py-0.5 rounded">
                                ****{account.accountNumber.slice(-4)}
                              </code>
                              <Button variant="ghost" size="icon" className="h-6 w-6">
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="text-xs text-muted-foreground">IFSC:</span>
                              <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{account.ifscCode}</code>
                            </div>
                            {account.vpaId && (
                              <div className="flex items-center gap-1">
                                <span className="text-xs text-muted-foreground">UPI:</span>
                                <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{account.vpaId}</code>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Balance</p>
                          <p className="text-lg font-semibold">₹{account.balance.toLocaleString()}</p>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <ExternalLink className="mr-2 h-4 w-4" />
                              View Transactions
                            </DropdownMenuItem>
                            {!account.isPrimary && (
                              <DropdownMenuItem>
                                <CheckCircle2 className="mr-2 h-4 w-4" />
                                Set as Primary
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            {!account.isPrimary && (
                              <DropdownMenuItem className="text-destructive">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Remove Account
                              </DropdownMenuItem>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    {account.linkedGateway && (
                      <div className="mt-4 pt-4 border-t flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">Linked Gateway:</span>
                        <Badge variant="outline">{account.linkedGateway}</Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Fee Head Splits Tab */}
          <TabsContent value="splits" className="space-y-4">
            <Card className="border-border/50">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Fee Head Split Configuration</CardTitle>
                    <CardDescription>
                      Configure how each fee head amount is split across bank accounts for automatic settlement
                    </CardDescription>
                  </div>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <Info className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>When a student pays online or via payment link, the amount is automatically split and settled to the configured bank accounts based on these percentages.</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fee Head</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Split Configuration</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {splitConfigurations.map((config) => {
                      const feeHead = feeHeads.find(f => f.id === config.feeHeadId)
                      return (
                        <TableRow key={config.feeHeadId}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{config.feeHeadName}</p>
                              <p className="text-xs text-muted-foreground">{feeHead?.frequency}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className="font-mono">₹{feeHead?.amount.toLocaleString()}</span>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-2">
                              {config.splits.map((split, idx) => (
                                <div key={idx} className="flex items-center gap-2">
                                  <div className="flex-1">
                                    <div className="flex items-center justify-between text-sm">
                                      <span className="text-muted-foreground">{split.accountName}</span>
                                      <span className="font-medium">{split.percentage}%</span>
                                    </div>
                                    <Progress value={split.percentage} className="h-1.5 mt-1" />
                                  </div>
                                  {feeHead && (
                                    <span className="text-xs text-muted-foreground w-16 text-right">
                                      ₹{Math.round(feeHead.amount * split.percentage / 100).toLocaleString()}
                                    </span>
                                  )}
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openSplitConfig(config)}
                            >
                              <Edit className="mr-2 h-4 w-4" />
                              Configure
                            </Button>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Visual Split Summary */}
            <Card className="border-border/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Settlement Distribution Preview</CardTitle>
                <CardDescription>
                  Example: If a student pays ₹30,000 covering all fee heads
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {bankAccounts.filter(b => b.status === "verified").map((account) => {
                    // Calculate total amount going to this account
                    let totalAmount = 0
                    splitConfigurations.forEach(config => {
                      const feeHead = feeHeads.find(f => f.id === config.feeHeadId)
                      if (feeHead) {
                        const split = config.splits.find(s => s.bankAccountId === account.id)
                        if (split) {
                          totalAmount += Math.round(feeHead.amount * split.percentage / 100)
                        }
                      }
                    })
                    const totalFees = feeHeads.reduce((sum, f) => sum + f.amount, 0)
                    const percentage = Math.round((totalAmount / totalFees) * 100)

                    return (
                      <div key={account.id} className="flex items-center gap-4">
                        <div className="w-48 flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm truncate">{account.name}</span>
                        </div>
                        <div className="flex-1">
                          <Progress value={percentage} className="h-2" />
                        </div>
                        <div className="w-32 text-right">
                          <span className="font-semibold">₹{totalAmount.toLocaleString()}</span>
                          <span className="text-xs text-muted-foreground ml-1">({percentage}%)</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settlement History Tab */}
          <TabsContent value="settlements" className="space-y-4">
            <Card className="border-border/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Recent Split Settlements</CardTitle>
                <CardDescription>
                  Track how payments were split and settled to different accounts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Total Amount</TableHead>
                      <TableHead>Transactions</TableHead>
                      <TableHead>Split Settlement</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentSettlements.map((settlement) => (
                      <TableRow key={settlement.id}>
                        <TableCell>
                          <span className="font-medium">{settlement.date}</span>
                        </TableCell>
                        <TableCell>
                          <span className="font-mono font-semibold">₹{settlement.totalAmount.toLocaleString()}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-muted-foreground">{settlement.transactionCount} txns</span>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {settlement.splits.map((split, idx) => (
                              <div key={idx} className="flex items-center gap-2 text-sm">
                                <span className="text-muted-foreground">{split.bankName}:</span>
                                <span className="font-mono">₹{split.amount.toLocaleString()}</span>
                                {split.status === "settled" ? (
                                  <CheckCircle2 className="h-3 w-3 text-chart-2" />
                                ) : (
                                  <Clock className="h-3 w-3 text-chart-4" />
                                )}
                              </div>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={settlement.status === "completed" ? "default" : "secondary"}
                            className={settlement.status === "completed" ? "bg-chart-2/10 text-chart-2" : "bg-chart-4/10 text-chart-4"}
                          >
                            {settlement.status === "completed" ? "Completed" : "Partial"}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Configure Split Dialog */}
        <Dialog open={showConfigureSplit} onOpenChange={setShowConfigureSplit}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Configure Split for {selectedFeeHead?.feeHeadName}</DialogTitle>
              <DialogDescription>
                Set how this fee head amount should be distributed across bank accounts
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {splitValues.map((split, index) => {
                const account = bankAccounts.find(b => b.id === split.bankAccountId)
                const feeHead = feeHeads.find(f => f.id === selectedFeeHead?.feeHeadId)
                const amount = feeHead ? Math.round(feeHead.amount * split.percentage / 100) : 0

                return (
                  <div key={index} className="space-y-3 p-4 rounded-lg border bg-muted/30">
                    <div className="flex items-center justify-between">
                      <Select
                        value={split.bankAccountId}
                        onValueChange={(value) => {
                          const newValues = [...splitValues]
                          newValues[index].bankAccountId = value
                          setSplitValues(newValues)
                        }}
                      >
                        <SelectTrigger className="w-[200px]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {bankAccounts.filter(b => b.status === "verified").map((acc) => (
                            <SelectItem key={acc.id} value={acc.id}>
                              {acc.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {splitValues.length > 1 && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeSplitAccount(index)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">{account?.bankName}</span>
                        <span className="font-medium">{split.percentage}% = ₹{amount.toLocaleString()}</span>
                      </div>
                      <Slider
                        value={[split.percentage]}
                        onValueChange={(value) => updateSplitPercentage(index, value[0])}
                        max={100}
                        step={5}
                      />
                    </div>
                  </div>
                )
              })}

              <Button
                variant="outline"
                className="w-full"
                onClick={addSplitAccount}
                disabled={splitValues.length >= bankAccounts.filter(b => b.status === "verified").length}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Another Account
              </Button>

              <div className={`flex items-center justify-between p-3 rounded-lg ${totalPercentage === 100 ? 'bg-chart-2/10' : 'bg-destructive/10'}`}>
                <span className="text-sm font-medium">Total Split</span>
                <div className="flex items-center gap-2">
                  <span className={`font-semibold ${totalPercentage === 100 ? 'text-chart-2' : 'text-destructive'}`}>
                    {totalPercentage}%
                  </span>
                  {totalPercentage === 100 ? (
                    <CheckCircle2 className="h-4 w-4 text-chart-2" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-destructive" />
                  )}
                </div>
              </div>

              {totalPercentage !== 100 && (
                <p className="text-xs text-destructive">
                  Total split must equal 100%. Current total: {totalPercentage}%
                </p>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowConfigureSplit(false)}>Cancel</Button>
              <Button onClick={() => setShowConfigureSplit(false)} disabled={totalPercentage !== 100}>
                <Save className="mr-2 h-4 w-4" />
                Save Configuration
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  )
}
