"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Clock,
  User,
  Send,
  Paperclip,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Star,
  FileText,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"

interface TicketDetailContentProps {
  ticketId: string
}

interface Message {
  id: string
  author: string
  role: "customer" | "agent"
  avatar: string
  content: string
  timestamp: string
  attachments?: string[]
}

export function TicketDetailContent({ ticketId }: TicketDetailContentProps) {
  const [status, setStatus] = useState("in-progress")
  const [priority, setPriority] = useState("high")
  const [replyMessage, setReplyMessage] = useState("")

  const ticket = {
    id: ticketId,
    subject: "Settlement not received for January 22 batch",
    category: "Settlements",
    createdBy: "Rajesh Kumar",
    createdAt: "2026-01-22T10:30:00",
    lastUpdated: "2026-01-22T14:45:00",
    assignedTo: "Priya Sharma",
    slaRemaining: "2h 15m",
  }

  const [messages, setMessages] = useState<Message[]>([
    {
      id: "M001",
      author: "Rajesh Kumar",
      role: "customer",
      avatar: "RK",
      content:
        "Hi Team, our settlement for transactions collected on January 21st (amount ₹12,45,000) was expected by 10 AM today but we haven't received it yet. Our reconciliation team is waiting to close the books. Settlement ID mentioned in the portal: STL-2026-0145. Please check and expedite.",
      timestamp: "2026-01-22T10:30:00",
      attachments: ["settlement-report.pdf"],
    },
    {
      id: "M002",
      author: "Priya Sharma",
      role: "agent",
      avatar: "PS",
      content:
        "Hi Rajesh, thank you for reaching out. I've checked the system and can confirm that settlement STL-2026-0145 was processed at 11:45 AM today. The NEFT reference number is NEFT20260122HDFC99812. Please check with your bank — it typically takes 30-60 minutes to reflect.",
      timestamp: "2026-01-22T12:15:00",
    },
    {
      id: "M003",
      author: "Rajesh Kumar",
      role: "customer",
      avatar: "RK",
      content: "Thanks Priya. Let me check with the bank and get back to you.",
      timestamp: "2026-01-22T12:30:00",
    },
    {
      id: "M004",
      author: "Priya Sharma",
      role: "agent",
      avatar: "PS",
      content:
        "Sure, I'll keep the ticket open. In the meantime, I've also escalated with our banking team to fast-track reconciliation. Expect an update by 4 PM.",
      timestamp: "2026-01-22T14:45:00",
    },
  ])

  const handleReply = () => {
    if (!replyMessage.trim()) return
    setMessages([
      ...messages,
      {
        id: `M${messages.length + 1}`.padStart(4, "0"),
        author: "Rajesh Kumar",
        role: "customer",
        avatar: "RK",
        content: replyMessage,
        timestamp: new Date().toISOString(),
      },
    ])
    setReplyMessage("")
  }

  const formatTime = (iso: string) => {
    const d = new Date(iso)
    return d.toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    })
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="mx-auto max-w-6xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/support">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-semibold">{ticket.subject}</h1>
              </div>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-sm text-muted-foreground font-mono">{ticket.id}</span>
                <span className="text-muted-foreground">•</span>
                <Badge variant="outline" className="text-xs">{ticket.category}</Badge>
                <span className="text-muted-foreground">•</span>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" />
                  <span>Created {formatTime(ticket.createdAt)}</span>
                </div>
              </div>
            </div>
          </div>
          <Button variant="outline">
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Mark as Resolved
          </Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
          {/* Conversation */}
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Conversation ({messages.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.role === "agent" ? "flex-row-reverse" : ""}`}
                  >
                    <Avatar className="h-9 w-9 flex-shrink-0">
                      <AvatarFallback
                        className={
                          msg.role === "agent"
                            ? "bg-primary/10 text-primary"
                            : "bg-secondary text-foreground"
                        }
                      >
                        {msg.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`flex-1 ${msg.role === "agent" ? "items-end" : ""}`}>
                      <div
                        className={`rounded-lg p-3 ${
                          msg.role === "agent"
                            ? "bg-primary/5 border border-primary/10"
                            : "bg-secondary/50"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">{msg.author}</span>
                            <Badge
                              variant="outline"
                              className={`text-[10px] ${
                                msg.role === "agent" ? "border-primary/30 text-primary" : ""
                              }`}
                            >
                              {msg.role === "agent" ? "Support Agent" : "Customer"}
                            </Badge>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {formatTime(msg.timestamp)}
                          </span>
                        </div>
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                        {msg.attachments && msg.attachments.length > 0 && (
                          <div className="mt-3 space-y-1">
                            {msg.attachments.map((att) => (
                              <div
                                key={att}
                                className="inline-flex items-center gap-2 px-2 py-1 rounded border border-border bg-background text-xs"
                              >
                                <FileText className="h-3.5 w-3.5" />
                                <span>{att}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Reply */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Reply</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Textarea
                  placeholder="Type your reply..."
                  value={replyMessage}
                  onChange={(e) => setReplyMessage(e.target.value)}
                  rows={5}
                />
                <div className="flex items-center justify-between">
                  <Button variant="ghost" size="sm">
                    <Paperclip className="h-4 w-4 mr-2" />
                    Attach File
                  </Button>
                  <Button onClick={handleReply} disabled={!replyMessage.trim()}>
                    <Send className="h-4 w-4 mr-2" />
                    Send Reply
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Ticket Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">Status</label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="waiting">Waiting for Customer</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">Priority</label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Separator />

                <div className="space-y-3 text-sm">
                  <div className="flex items-start justify-between">
                    <span className="text-muted-foreground">Created by</span>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-5 w-5">
                        <AvatarFallback className="text-[9px]">RK</AvatarFallback>
                      </Avatar>
                      <span className="text-xs">{ticket.createdBy}</span>
                    </div>
                  </div>
                  <div className="flex items-start justify-between">
                    <span className="text-muted-foreground">Assigned to</span>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-5 w-5">
                        <AvatarFallback className="text-[9px] bg-primary/10 text-primary">
                          PS
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs">{ticket.assignedTo}</span>
                    </div>
                  </div>
                  <div className="flex items-start justify-between">
                    <span className="text-muted-foreground">Category</span>
                    <Badge variant="outline" className="text-[10px]">{ticket.category}</Badge>
                  </div>
                  <div className="flex items-start justify-between">
                    <span className="text-muted-foreground">Created</span>
                    <span className="text-xs">{formatTime(ticket.createdAt)}</span>
                  </div>
                  <div className="flex items-start justify-between">
                    <span className="text-muted-foreground">Last updated</span>
                    <span className="text-xs">{formatTime(ticket.lastUpdated)}</span>
                  </div>
                </div>

                <Separator />

                <div className="p-3 rounded-lg bg-chart-5/10 border border-chart-5/20">
                  <div className="flex items-center gap-2 mb-1">
                    <AlertCircle className="h-4 w-4 text-chart-5" />
                    <span className="text-xs font-medium">SLA Countdown</span>
                  </div>
                  <p className="text-lg font-semibold text-chart-5">{ticket.slaRemaining}</p>
                  <p className="text-[11px] text-muted-foreground mt-1">
                    Response required within this time
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Star className="h-4 w-4" />
                  Rate this Support
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground mb-3">
                  How would you rate the support received on this ticket?
                </p>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      className="p-1 hover:scale-110 transition-transform"
                      type="button"
                    >
                      <Star className="h-5 w-5 text-muted-foreground hover:text-chart-4 hover:fill-chart-4" />
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Watchers (3)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  {["RK", "PS", "AM"].map((initial, idx) => (
                    <Avatar key={idx} className="h-7 w-7">
                      <AvatarFallback className="text-[10px]">{initial}</AvatarFallback>
                    </Avatar>
                  ))}
                  <Button variant="ghost" size="sm" className="h-7">
                    <User className="h-3.5 w-3.5 mr-1" />
                    Add
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
