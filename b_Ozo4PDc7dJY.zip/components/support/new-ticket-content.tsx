"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Upload, X, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

const categories = [
  { value: "payments", label: "Payments & Transactions" },
  { value: "settlements", label: "Settlements" },
  { value: "refunds", label: "Refunds" },
  { value: "chargebacks", label: "Chargebacks" },
  { value: "integrations", label: "Integrations" },
  { value: "billing", label: "Billing & Invoicing" },
  { value: "technical", label: "Technical Issues" },
  { value: "other", label: "Other" },
]

const priorities = [
  { value: "low", label: "Low", description: "General inquiries, non-urgent" },
  { value: "medium", label: "Medium", description: "Minor functionality issues" },
  { value: "high", label: "High", description: "Major functionality affected" },
  { value: "urgent", label: "Urgent", description: "Production outage, payment failures" },
]

export function NewTicketContent() {
  const router = useRouter()
  const [subject, setSubject] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [priority, setPriority] = useState("medium")
  const [attachments, setAttachments] = useState<string[]>([])

  const handleAddAttachment = () => {
    const name = `screenshot-${attachments.length + 1}.png`
    setAttachments([...attachments, name])
  }

  const handleRemoveAttachment = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const ticketId = `TKT-${Math.floor(Math.random() * 9000) + 1000}`
    router.push(`/support/${ticketId}`)
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="mx-auto max-w-3xl p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Link href="/support">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Tickets
            </Button>
          </Link>
        </div>

        <div>
          <h1 className="text-2xl font-semibold">Create Support Ticket</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Describe your issue and our team will get back to you within the SLA timeframe.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Ticket Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="subject">Subject <span className="text-destructive">*</span></Label>
                <Input
                  id="subject"
                  placeholder="Brief summary of the issue"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  required
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="category">Category <span className="text-destructive">*</span></Label>
                  <Select value={category} onValueChange={setCategory} required>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger id="priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          <div className="flex flex-col items-start">
                            <span>{p.label}</span>
                            <span className="text-xs text-muted-foreground">{p.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description <span className="text-destructive">*</span></Label>
                <Textarea
                  id="description"
                  placeholder="Provide detailed information about the issue, including steps to reproduce, expected vs actual behavior, and any error messages..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={8}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Minimum 20 characters. Include transaction IDs, timestamps, and screenshots for faster resolution.
                </p>
              </div>

              <div className="space-y-2">
                <Label>Attachments</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground mb-2">
                    Click to upload or drag and drop files
                  </p>
                  <p className="text-xs text-muted-foreground mb-3">
                    PNG, JPG, PDF up to 10MB each
                  </p>
                  <Button type="button" variant="outline" size="sm" onClick={handleAddAttachment}>
                    Choose Files
                  </Button>
                </div>

                {attachments.length > 0 && (
                  <div className="space-y-2">
                    {attachments.map((file, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-2 rounded-md bg-secondary/50"
                      >
                        <div className="flex items-center gap-2">
                          <Upload className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{file}</span>
                          <Badge variant="outline" className="text-[10px]">245 KB</Badge>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveAttachment(idx)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="mt-4">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Send className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">SLA Commitment</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Urgent tickets: 1 hour first response | High: 4 hours | Medium: 12 hours | Low: 24 hours
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-3 mt-6">
            <Link href="/support">
              <Button type="button" variant="outline">Cancel</Button>
            </Link>
            <Button type="submit">
              <Send className="h-4 w-4 mr-2" />
              Submit Ticket
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
