"use client"

import { useState } from "react"
import Link from "next/link"
import {
  LifeBuoy,
  Plus,
  Search,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Zap,
  MessageSquare,
  Filter,
  ArrowUpRight,
  Timer,
  TrendingDown,
  TrendingUp,
  Users,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

type TicketStatus = "open" | "in_progress" | "waiting" | "resolved" | "closed"
type TicketPriority = "low" | "medium" | "high" | "critical"
type TicketCategory =
  | "settlements"
  | "refunds"
  | "chargebacks"
  | "pg"
  | "fee_collection"
  | "banking"
  | "payroll"
  | "compliance"
  | "technical"

interface Ticket {
  id: string
  subject: string
  category: TicketCategory
  priority: TicketPriority
  status: TicketStatus
  createdAt: string
  updatedAt: string
  assignee?: string
  sla: "on_track" | "breaching" | "breached"
  lastMessage: string
  escalated?: boolean
}

const tickets: Ticket[] = [
  {
    id: "TKT-2026-0451",
    subject: "Settlement mismatch on Mar 28 &mdash; ₹4,500 short credit",
    category: "settlements",
    priority: "high",
    status: "in_progress",
    createdAt: "2026-04-19 10:24",
    updatedAt: "2026-04-20 09:12",
    assignee: "Rahul Verma (RM)",
    sla: "on_track",
    lastMessage: "We have raised this with HDFC and expect an update by EOD.",
    escalated: false,
  },
  {
    id: "TKT-2026-0450",
    subject: "Refund stuck in &lsquo;initiated&rsquo; for 48 hours &mdash; TXN-892145",
    category: "refunds",
    priority: "critical",
    status: "open",
    createdAt: "2026-04-20 08:15",
    updatedAt: "2026-04-20 08:15",
    sla: "breaching",
    lastMessage: "Refund has not moved past initiated status since Thursday.",
    escalated: true,
  },
  {
    id: "TKT-2026-0449",
    subject: "Unable to add new payment gateway",
    category: "pg",
    priority: "medium",
    status: "waiting",
    createdAt: "2026-04-18 14:45",
    updatedAt: "2026-04-19 11:30",
    assignee: "Priya Kaur (L2)",
    sla: "on_track",
    lastMessage: "Waiting for Easebuzz API credentials from merchant.",
  },
  {
    id: "TKT-2026-0448",
    subject: "TDS deposit challan not showing on portal",
    category: "compliance",
    priority: "high",
    status: "in_progress",
    createdAt: "2026-04-17 16:20",
    updatedAt: "2026-04-20 07:45",
    assignee: "Amit Mehra (Compliance)",
    sla: "on_track",
    lastMessage: "Traces portal was down. Will verify today.",
  },
  {
    id: "TKT-2026-0447",
    subject: "Chargeback dispute evidence rejected by bank",
    category: "chargebacks",
    priority: "high",
    status: "in_progress",
    createdAt: "2026-04-17 11:10",
    updatedAt: "2026-04-19 18:20",
    assignee: "Neha Kapoor (Risk)",
    sla: "breaching",
    lastMessage: "Preparing additional evidence for the arbitration stage.",
  },
  {
    id: "TKT-2026-0446",
    subject: "Fee reminder SMS not reaching parents",
    category: "fee_collection",
    priority: "medium",
    status: "resolved",
    createdAt: "2026-04-16 09:00",
    updatedAt: "2026-04-18 14:00",
    assignee: "Arjun Tech",
    sla: "on_track",
    lastMessage: "DLT template re-registered. Reminders are flowing correctly now.",
  },
  {
    id: "TKT-2026-0445",
    subject: "Payroll disbursement failed for 3 employees",
    category: "payroll",
    priority: "critical",
    status: "resolved",
    createdAt: "2026-04-15 12:30",
    updatedAt: "2026-04-16 10:20",
    assignee: "Vikram Singh (HR)",
    sla: "on_track",
    lastMessage: "Bank account details corrected. All disbursements successful.",
  },
  {
    id: "TKT-2026-0444",
    subject: "Request to add secondary signatory for HDFC account",
    category: "banking",
    priority: "low",
    status: "closed",
    createdAt: "2026-04-12 14:00",
    updatedAt: "2026-04-17 11:00",
    assignee: "Priya Sharma (CFO)",
    sla: "on_track",
    lastMessage: "Added and board resolution attached.",
  },
]

const categoryCfg: Record<TicketCategory, { label: string; color: string }> = {
  settlements: { label: "Settlements", color: "bg-chart-1/10 text-chart-1" },
  refunds: { label: "Refunds", color: "bg-chart-3/10 text-chart-3" },
  chargebacks: { label: "Chargebacks", color: "bg-destructive/10 text-destructive" },
  pg: { label: "PG issue", color: "bg-chart-2/10 text-chart-2" },
  fee_collection: { label: "Fee collection", color: "bg-chart-1/10 text-chart-1" },
  banking: { label: "Banking", color: "bg-chart-4/10 text-chart-4" },
  payroll: { label: "Payroll", color: "bg-chart-5/10 text-chart-5" },
  compliance: { label: "Compliance", color: "bg-warning/10 text-warning" },
  technical: { label: "Technical", color: "bg-muted text-muted-foreground" },
}

const statusCfg: Record<
  TicketStatus,
  { label: string; variant: "default" | "outline" | "secondary" | "destructive" }
> = {
  open: { label: "Open", variant: "destructive" },
  in_progress: { label: "In progress", variant: "default" },
  waiting: { label: "Waiting", variant: "outline" },
  resolved: { label: "Resolved", variant: "secondary" },
  closed: { label: "Closed", variant: "secondary" },
}

const priorityCfg: Record<TicketPriority, { label: string; color: string }> = {
  low: { label: "Low", color: "text-muted-foreground" },
  medium: { label: "Medium", color: "text-chart-3" },
  high: { label: "High", color: "text-warning" },
  critical: { label: "Critical", color: "text-destructive" },
}

export function SupportContent() {
  const [search, setSearch] = useState("")
  const [cat, setCat] = useState<string>("all")
  const [status, setStatus] = useState<TicketStatus | "all">("all")

  const filtered = tickets.filter(
    (t) =>
      (cat === "all" || t.category === cat) &&
      (status === "all" || t.status === status) &&
      (t.subject.toLowerCase().includes(search.toLowerCase()) ||
        t.id.toLowerCase().includes(search.toLowerCase())),
  )

  const counts = {
    open: tickets.filter((t) => t.status === "open").length,
    inProgress: tickets.filter((t) => t.status === "in_progress").length,
    breaching: tickets.filter((t) => t.sla === "breaching").length,
    avgResolution: "6h 24m",
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <Badge variant="outline" className="gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Live support queue
          </Badge>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">Support Tickets</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Premium B2B operations support &mdash; every issue tracked, escalated and resolved within SLA.
          </p>
        </div>
        <Button asChild>
          <Link href="/support/new">
            <Plus className="mr-2 h-4 w-4" />
            New Ticket
          </Link>
        </Button>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Open tickets</p>
                <p className="text-2xl font-semibold">{counts.open}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Zap className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">In progress</p>
                <p className="text-2xl font-semibold">{counts.inProgress}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/10">
                <Timer className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">SLA breaching</p>
                <p className="text-2xl font-semibold">{counts.breaching}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-info/10">
                <Clock className="h-5 w-5 text-info" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Avg resolution</p>
                <p className="text-2xl font-semibold">{counts.avgResolution}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Issue heatmap */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Issue Heatmap</CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">Top categories over the last 30 days</p>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 md:grid-cols-3">
              {(Object.entries(categoryCfg) as [TicketCategory, { label: string; color: string }][])
                .slice(0, 9)
                .map(([key, cfg]) => {
                  const count = tickets.filter((t) => t.category === key).length
                  const intensity = Math.min(count * 25, 100)
                  return (
                    <div
                      key={key}
                      className="flex items-center justify-between rounded-lg border border-border p-3"
                    >
                      <div>
                        <div className={`inline-block rounded px-2 py-0.5 text-xs font-medium ${cfg.color}`}>
                          {cfg.label}
                        </div>
                        <p className="mt-2 text-xl font-semibold">{count}</p>
                      </div>
                      <div className="h-12 w-1 rounded-full bg-muted">
                        <div
                          className="w-full rounded-full bg-primary"
                          style={{ height: `${intensity}%`, marginTop: `${100 - intensity}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Trends</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <p className="text-xs text-muted-foreground">New this week</p>
                <p className="text-lg font-semibold">14</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-destructive">
                <TrendingUp className="h-3 w-3" />
                <span>+12%</span>
              </div>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <p className="text-xs text-muted-foreground">Resolved this week</p>
                <p className="text-lg font-semibold">18</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-primary">
                <TrendingUp className="h-3 w-3" />
                <span>+24%</span>
              </div>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <p className="text-xs text-muted-foreground">CSAT score</p>
                <p className="text-lg font-semibold">4.6 / 5</p>
              </div>
              <div className="flex items-center gap-1 text-xs text-primary">
                <TrendingUp className="h-3 w-3" />
                <span>+0.2</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tickets list */}
      <Card>
        <div className="flex flex-col gap-3 border-b border-border p-4 md:flex-row md:items-center md:justify-between">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search ticket ID or subject"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Select value={cat} onValueChange={setCat}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {(Object.keys(categoryCfg) as TicketCategory[]).map((k) => (
                  <SelectItem key={k} value={k}>
                    {categoryCfg[k].label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs value={status} onValueChange={(v) => setStatus(v as any)}>
          <TabsList className="m-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="open">Open</TabsTrigger>
            <TabsTrigger value="in_progress">In progress</TabsTrigger>
            <TabsTrigger value="waiting">Waiting</TabsTrigger>
            <TabsTrigger value="resolved">Resolved</TabsTrigger>
            <TabsTrigger value="closed">Closed</TabsTrigger>
          </TabsList>

          <TabsContent value={status} className="space-y-2 p-4 pt-0">
            {filtered.map((t) => {
              const cat = categoryCfg[t.category]
              const st = statusCfg[t.status]
              const prio = priorityCfg[t.priority]
              return (
                <Link
                  key={t.id}
                  href={`/support/${t.id}`}
                  className="block rounded-lg border border-border p-4 transition-colors hover:bg-muted/40"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs text-muted-foreground">{t.id}</span>
                        <div className={`rounded px-2 py-0.5 text-xs font-medium ${cat.color}`}>{cat.label}</div>
                        <span className={`text-xs font-medium ${prio.color}`}>&bull; {prio.label} priority</span>
                        {t.escalated && (
                          <Badge variant="destructive" className="gap-1 text-[10px]">
                            <AlertTriangle className="h-3 w-3" />
                            Escalated
                          </Badge>
                        )}
                        {t.sla === "breaching" && (
                          <Badge variant="destructive" className="gap-1 text-[10px]">
                            <Timer className="h-3 w-3" />
                            SLA breaching
                          </Badge>
                        )}
                      </div>
                      <p
                        className="font-medium text-balance"
                        dangerouslySetInnerHTML={{ __html: t.subject }}
                      />
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1.5">
                          <MessageSquare className="h-3 w-3" />
                          <span className="line-clamp-1">{t.lastMessage}</span>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                        <span>Created: {t.createdAt}</span>
                        <span>&bull;</span>
                        <span>Updated: {t.updatedAt}</span>
                        {t.assignee && (
                          <>
                            <span>&bull;</span>
                            <div className="flex items-center gap-1.5">
                              <Avatar className="h-4 w-4">
                                <AvatarFallback className="bg-primary/10 text-[9px] text-primary">
                                  {t.assignee
                                    .split(" ")
                                    .map((p) => p[0])
                                    .join("")
                                    .slice(0, 2)}
                                </AvatarFallback>
                              </Avatar>
                              <span>{t.assignee}</span>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge variant={st.variant}>{st.label}</Badge>
                      <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                </Link>
              )
            })}
            {filtered.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <LifeBuoy className="h-10 w-10 text-muted-foreground" />
                <p className="mt-3 font-medium">No tickets match your filter</p>
                <p className="text-sm text-muted-foreground">Try different filters or raise a new ticket.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  )
}
