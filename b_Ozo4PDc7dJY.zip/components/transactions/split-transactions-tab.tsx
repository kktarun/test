"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Search,
  Split,
  Building2,
  CheckCircle2,
  Clock,
  AlertCircle,
  Users,
  ChevronRight,
  Copy,
  ExternalLink,
  CreditCard,
  Banknote,
  Wallet,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Split transactions data - transactions that have been split across multiple beneficiaries
const splitTransactionsData = [
  {
    id: "TXN-SPLIT-001",
    orderId: "ORD-2025-001234",
    transactionDate: "2025-01-09",
    transactionTime: "10:30:45",
    institute: {
      name: "Delhi Public School, R.K. Puram",
      code: "DPS-RKP",
    },
    student: {
      name: "Rahul Sharma",
      id: "STU-001",
      class: "Class 10-A",
      phone: "+91 98765 43210",
    },
    totalAmount: 150000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    status: "success",
    splits: [
      {
        id: "SPL-001-A",
        beneficiary: "Delhi Public School, R.K. Puram",
        beneficiaryType: "Institute",
        vendorName: null,
        amount: 105000,
        percentage: 70,
        status: "settled",
      },
      {
        id: "SPL-001-B",
        beneficiary: "Education Trust Fund",
        beneficiaryType: "Trust",
        vendorName: null,
        amount: 30000,
        percentage: 20,
        status: "settled",
      },
      {
        id: "SPL-001-C",
        beneficiary: "Sports Academy",
        beneficiaryType: "Vendor",
        vendorName: "Sports Academy",
        amount: 15000,
        percentage: 10,
        status: "pending",
      },
    ],
  },
  {
    id: "TXN-SPLIT-002",
    orderId: "ORD-2025-001235",
    transactionDate: "2025-01-09",
    transactionTime: "11:15:20",
    institute: {
      name: "St. Mary's Convent School",
      code: "SMCS-DEL",
    },
    student: {
      name: "Priya Patel",
      id: "STU-002",
      class: "Class 12-B",
      phone: "+91 87654 32109",
    },
    totalAmount: 200000,
    gateway: "Cashfree",
    paymentMode: "Net Banking",
    status: "success",
    splits: [
      {
        id: "SPL-002-A",
        beneficiary: "St. Mary's Convent School",
        beneficiaryType: "Institute",
        vendorName: null,
        amount: 160000,
        percentage: 80,
        status: "settled",
      },
      {
        id: "SPL-002-B",
        beneficiary: "Transport Services Ltd",
        beneficiaryType: "Vendor",
        vendorName: "Transport Services Ltd",
        amount: 30000,
        percentage: 15,
        status: "settled",
      },
      {
        id: "SPL-002-C",
        beneficiary: "Canteen Vendor",
        beneficiaryType: "Vendor",
        vendorName: "Canteen Vendor",
        amount: 10000,
        percentage: 5,
        status: "failed",
      },
    ],
  },
  {
    id: "TXN-SPLIT-003",
    orderId: "ORD-2025-001236",
    transactionDate: "2025-01-09",
    transactionTime: "14:45:00",
    institute: {
      name: "Modern Public School",
      code: "MPS-GGN",
    },
    student: {
      name: "Amit Kumar",
      id: "STU-003",
      class: "Class 8-C",
      phone: "+91 76543 21098",
    },
    totalAmount: 85000,
    gateway: "Paytm",
    paymentMode: "UPI",
    status: "success",
    splits: [
      {
        id: "SPL-003-A",
        beneficiary: "Modern Public School",
        beneficiaryType: "Institute",
        vendorName: null,
        amount: 63750,
        percentage: 75,
        status: "settled",
      },
      {
        id: "SPL-003-B",
        beneficiary: "Uniform Supplier Co",
        beneficiaryType: "Vendor",
        vendorName: "Uniform Supplier Co",
        amount: 21250,
        percentage: 25,
        status: "pending",
      },
    ],
  },
  {
    id: "TXN-SPLIT-004",
    orderId: "ORD-2025-001237",
    transactionDate: "2025-01-08",
    transactionTime: "09:20:15",
    institute: {
      name: "Ryan International School",
      code: "RIS-DEL",
    },
    student: {
      name: "Sneha Gupta",
      id: "STU-004",
      class: "Class 5-D",
      phone: "+91 65432 10987",
    },
    totalAmount: 120000,
    gateway: "Razorpay",
    paymentMode: "Debit Card",
    status: "success",
    splits: [
      {
        id: "SPL-004-A",
        beneficiary: "Ryan International School",
        beneficiaryType: "Institute",
        vendorName: null,
        amount: 96000,
        percentage: 80,
        status: "settled",
      },
      {
        id: "SPL-004-B",
        beneficiary: "Book Supplier Pvt Ltd",
        beneficiaryType: "Vendor",
        vendorName: "Book Supplier Pvt Ltd",
        amount: 24000,
        percentage: 20,
        status: "settled",
      },
    ],
  },
]

// Summary statistics
const splitSummaryStats = {
  totalSplitTransactions: 256,
  totalAmount: 25600000,
  totalSplits: 768,
  settledSplits: 680,
  settledAmount: 22400000,
  pendingSplits: 65,
  pendingAmount: 2800000,
  failedSplits: 23,
  failedAmount: 400000,
}

export function SplitTransactionsTab() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedGateway, setSelectedGateway] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedVendor, setSelectedVendor] = useState("all")
  const [selectedTransaction, setSelectedTransaction] = useState<(typeof splitTransactionsData)[0] | null>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)

  // Get unique vendors for filter
  const uniqueVendors = Array.from(new Set(
    splitTransactionsData.flatMap(t => 
      t.splits.filter(s => s.vendorName).map(s => s.vendorName as string)
    )
  ))

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "settled":
      case "success":
        return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Settled</Badge>
      case "pending":
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Pending</Badge>
      case "failed":
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Failed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getBeneficiaryTypeBadge = (type: string) => {
    switch (type) {
      case "Institute":
        return (
          <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/30">
            Institute
          </Badge>
        )
      case "Trust":
        return (
          <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/30">
            Trust
          </Badge>
        )
      case "Vendor":
        return (
          <Badge variant="outline" className="bg-orange-500/10 text-orange-400 border-orange-500/30">
            Vendor
          </Badge>
        )
      default:
        return <Badge variant="outline">{type}</Badge>
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const openDetailModal = (transaction: (typeof splitTransactionsData)[0]) => {
    setSelectedTransaction(transaction)
    setShowDetailModal(true)
  }

  // Filter transactions
  const filteredTransactions = splitTransactionsData.filter((transaction) => {
    if (selectedGateway !== "all" && transaction.gateway.toLowerCase() !== selectedGateway) return false
    if (selectedStatus !== "all" && transaction.status !== selectedStatus) return false
    if (selectedVendor !== "all") {
      const hasVendor = transaction.splits.some(s => s.vendorName === selectedVendor)
      if (!hasVendor) return false
    }
    if (searchTerm) {
      const search = searchTerm.toLowerCase()
      return (
        transaction.id.toLowerCase().includes(search) ||
        transaction.orderId.toLowerCase().includes(search) ||
        transaction.student.name.toLowerCase().includes(search) ||
        transaction.institute.name.toLowerCase().includes(search)
      )
    }
    return true
  })

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Split className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Split Transactions</p>
                <p className="text-xl font-bold text-foreground">{splitSummaryStats.totalSplitTransactions}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.totalAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20">
                <CheckCircle2 className="h-5 w-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Settled Splits</p>
                <p className="text-xl font-bold text-emerald-400">{splitSummaryStats.settledSplits}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.settledAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20">
                <Clock className="h-5 w-5 text-amber-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending Splits</p>
                <p className="text-xl font-bold text-amber-400">{splitSummaryStats.pendingSplits}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.pendingAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-500/20">
                <AlertCircle className="h-5 w-5 text-red-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Failed Splits</p>
                <p className="text-xl font-bold text-red-400">{splitSummaryStats.failedSplits}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.failedAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by transaction ID, order ID, student name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-background"
              />
            </div>
            <Select value={selectedGateway} onValueChange={setSelectedGateway}>
              <SelectTrigger className="w-[150px] bg-background">
                <SelectValue placeholder="Gateway" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Gateways</SelectItem>
                <SelectItem value="razorpay">Razorpay</SelectItem>
                <SelectItem value="cashfree">Cashfree</SelectItem>
                <SelectItem value="paytm">Paytm</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[150px] bg-background">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="success">Success</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedVendor} onValueChange={setSelectedVendor}>
              <SelectTrigger className="w-[200px] bg-background">
                <SelectValue placeholder="Vendor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                {uniqueVendors.map((vendor) => (
                  <SelectItem key={vendor} value={vendor}>{vendor}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Split Transactions Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Split Payment Transactions</CardTitle>
          <CardDescription>
            View transactions with split payments across multiple beneficiaries including vendors
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-muted-foreground">Transaction ID</TableHead>
                <TableHead className="text-muted-foreground">Date & Time</TableHead>
                <TableHead className="text-muted-foreground">Student</TableHead>
                <TableHead className="text-muted-foreground">Vendor Name</TableHead>
                <TableHead className="text-muted-foreground text-right">Total Amount</TableHead>
                <TableHead className="text-muted-foreground">Gateway</TableHead>
                <TableHead className="text-muted-foreground text-center">Splits</TableHead>
                <TableHead className="text-muted-foreground text-center">Status</TableHead>
                <TableHead className="text-muted-foreground text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTransactions.map((transaction) => {
                const vendors = transaction.splits.filter(s => s.vendorName).map(s => s.vendorName)
                return (
                  <TableRow key={transaction.id} className="border-border">
                    <TableCell>
                      <div>
                        <div className="flex items-center gap-1">
                          <p className="font-mono text-sm text-primary">{transaction.id}</p>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-5 w-5"
                            onClick={() => copyToClipboard(transaction.id)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">{transaction.orderId}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm text-foreground">{transaction.transactionDate}</p>
                        <p className="text-xs text-muted-foreground">{transaction.transactionTime}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm text-foreground">{transaction.student.name}</p>
                          <p className="text-xs text-muted-foreground">{transaction.student.id} | {transaction.student.class}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {vendors.length > 0 ? (
                        <div className="space-y-1">
                          {vendors.map((vendor, idx) => (
                            <Badge key={idx} variant="outline" className="bg-orange-500/10 text-orange-400 border-orange-500/30 text-xs">
                              {vendor}
                            </Badge>
                          ))}
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <p className="font-semibold text-foreground">{formatCurrency(transaction.totalAmount)}</p>
                      <p className="text-xs text-muted-foreground">{transaction.paymentMode}</p>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{transaction.gateway}</Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Split className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-sm font-medium">{transaction.splits.length}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {getStatusBadge(transaction.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" className="gap-1" onClick={() => openDetailModal(transaction)}>
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Detail Modal */}
      <Dialog open={showDetailModal} onOpenChange={setShowDetailModal}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedTransaction && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Split className="h-5 w-5 text-primary" />
                  Split Transaction Details
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4 mt-4">
                {/* Transaction Info */}
                <Card className="bg-muted/30 border-border">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Transaction ID</p>
                        <p className="text-sm font-mono text-foreground">{selectedTransaction.id}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Order ID</p>
                        <p className="text-sm font-mono text-foreground">{selectedTransaction.orderId}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Date & Time</p>
                        <p className="text-sm text-foreground">{selectedTransaction.transactionDate} {selectedTransaction.transactionTime}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Total Amount</p>
                        <p className="text-sm font-bold text-foreground">{formatCurrency(selectedTransaction.totalAmount)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Student & Institute Info */}
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-blue-500/20">
                          <Users className="h-4 w-4 text-blue-400" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Student</p>
                          <p className="text-sm font-medium text-foreground">{selectedTransaction.student.name}</p>
                          <p className="text-xs text-muted-foreground">{selectedTransaction.student.id} | {selectedTransaction.student.class}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-purple-500/20">
                          <Building2 className="h-4 w-4 text-purple-400" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Institute</p>
                          <p className="text-sm font-medium text-foreground">{selectedTransaction.institute.name}</p>
                          <p className="text-xs text-muted-foreground">{selectedTransaction.institute.code}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Split Breakdown */}
                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Split Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-border">
                          <TableHead className="text-muted-foreground">Beneficiary</TableHead>
                          <TableHead className="text-muted-foreground">Vendor Name</TableHead>
                          <TableHead className="text-muted-foreground text-right">Amount</TableHead>
                          <TableHead className="text-muted-foreground text-right">%</TableHead>
                          <TableHead className="text-muted-foreground text-center">Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedTransaction.splits.map((split) => (
                          <TableRow key={split.id} className="border-border">
                            <TableCell>
                              <div>
                                <p className="text-sm font-medium text-foreground">{split.beneficiary}</p>
                                {getBeneficiaryTypeBadge(split.beneficiaryType)}
                              </div>
                            </TableCell>
                            <TableCell>
                              {split.vendorName ? (
                                <Badge variant="outline" className="bg-orange-500/10 text-orange-400 border-orange-500/30">
                                  {split.vendorName}
                                </Badge>
                              ) : (
                                <span className="text-muted-foreground text-xs">-</span>
                              )}
                            </TableCell>
                            <TableCell className="text-right">
                              <p className="font-medium text-foreground">{formatCurrency(split.amount)}</p>
                            </TableCell>
                            <TableCell className="text-right">
                              <p className="text-sm text-muted-foreground">{split.percentage}%</p>
                            </TableCell>
                            <TableCell className="text-center">
                              {getStatusBadge(split.status)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
