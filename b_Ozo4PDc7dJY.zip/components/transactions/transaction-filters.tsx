"use client"

import { useState } from "react"
import { Search, X, Filter, ChevronDown, ChevronRight } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { FilterState } from "./transactions-content"

interface TransactionFiltersProps {
  filters: FilterState
  onFilterChange: (key: keyof FilterState, value: string) => void
  onReset: () => void
}

const gateways = [
  { value: "all", label: "All Gateways" },
  { value: "razorpay", label: "Razorpay" },
  { value: "cashfree", label: "Cashfree" },
  { value: "easebuzz", label: "Easebuzz" },
  { value: "paytm", label: "Paytm" },
  { value: "phonepe", label: "PhonePe PG" },
  { value: "ntt", label: "NTT Atom" },
  { value: "worldline", label: "Worldline" },
  { value: "hdfc", label: "HDFC Payment Gateway" },
  { value: "icici", label: "ICICI Payment Gateway" },
  { value: "ccavenue", label: "CCAvenue" },
  { value: "billdesk", label: "BillDesk" },
]

const vendors = [
  { value: "all", label: "All Vendors" },
  { value: "edviron", label: "Edviron" },
  { value: "schoolpay", label: "SchoolPay" },
  { value: "feepay", label: "FeePay" },
  { value: "payschool", label: "PaySchool" },
  { value: "edupay", label: "EduPay" },
]

const paymentModes = [
  { value: "all", label: "All Modes" },
  { value: "credit_card", label: "Credit Card" },
  { value: "debit_card", label: "Debit Card" },
  { value: "upi", label: "UPI" },
  { value: "netbanking", label: "Net Banking" },
  { value: "wallet", label: "Wallet" },
  { value: "bank_transfer", label: "Bank Transfer" },
  { value: "pay_later", label: "Pay Later" },
  { value: "split_and_pay", label: "Split and Pay (Multi-mode)" },
  // School Counter modes
  { value: "demand_draft", label: "Demand Draft" },
  { value: "cheque", label: "Cheque" },
  { value: "cash", label: "Cash" },
  // International Payments
  { value: "international", label: "International Payment" },
]

// Bank Transfer sub-types (for Netbanking Transfer channel)
const bankTransferTypes = [
  { value: "all", label: "All Types" },
  { value: "neft", label: "NEFT" },
  { value: "rtgs", label: "RTGS" },
  { value: "imps", label: "IMPS" },
]

const channels = [
  { value: "all", label: "All Channels" },
  { value: "online", label: "Online" },
  { value: "pos", label: "POS" },
  { value: "link", label: "Payment Link" },
  { value: "form", label: "Payment Form" },
  { value: "auto_debit", label: "Auto Debit" },
  { value: "netbanking_transfer", label: "Netbanking Transfer" },
  { value: "challan", label: "Challan" },
  { value: "static_qr", label: "Static QR Code" },
  { value: "dynamic_qr", label: "Dynamic QR Code" },
  { value: "school_counter", label: "School Counter" },
  { value: "international", label: "International Gateway" },
]

// Payment Mode to Available Channels mapping
const modeToChannelsMap: Record<string, string[]> = {
  credit_card: ["online", "pos", "link", "form"],
  debit_card: ["online", "pos", "link", "form"],
  upi: ["online", "link", "form", "auto_debit", "static_qr", "dynamic_qr"],
  netbanking: ["online", "link", "form"],
  wallet: ["online", "link"],
  bank_transfer: ["netbanking_transfer", "challan"],
  pay_later: ["online", "link", "form"],
  split_and_pay: ["online", "link", "form"],
  demand_draft: ["school_counter"],
  cheque: ["school_counter"],
  cash: ["school_counter"],
  international: ["international", "online", "link"],
}

// Helper function to get available channels for a payment mode
const getAvailableChannels = (paymentMode: string) => {
  if (paymentMode === "all" || !modeToChannelsMap[paymentMode]) {
    return channels
  }
  const allowedChannelValues = modeToChannelsMap[paymentMode]
  return channels.filter(ch => ch.value === "all" || allowedChannelValues.includes(ch.value))
}

const statuses = [
  { value: "all", label: "All Status" },
  { value: "success", label: "Success" },
  { value: "pending", label: "Pending" },
  { value: "failed", label: "Failed" },
  { value: "refunded", label: "Refunded" },
  { value: "user_dropped", label: "User Dropped" },
]

const captureStatuses = [
  { value: "all", label: "All Capture Status" },
  { value: "authorized", label: "Authorized (Pending Capture)" },
  { value: "captured", label: "Captured" },
  { value: "void", label: "Void" },
  { value: "not_applicable", label: "Not Applicable" },
]

// Financing Options
const financingCategories = [
  { value: "all", label: "All Financing" },
  { value: "none", label: "No Financing" },
  { value: "card_emi", label: "Card EMI" },
  { value: "nbfc_financing", label: "NBFC Financing" },
]

const financingTypes = [
  { value: "all", label: "All EMI Types" },
  { value: "emi", label: "EMI" },
  { value: "no_cost_emi", label: "No Cost EMI" },
  { value: "partial_cost_emi", label: "Partial Cost EMI" },
]

const financingCollectionTypes = [
  { value: "all", label: "All Collection Types" },
  { value: "edviron_collection", label: "Edviron Collection" },
  { value: "nbfc_collection", label: "NBFC Handles Collection" },
]

// EMI Cost Bearing options (who pays the EMI charges) - for EMI type
const emiCostBearingOptions = [
  { value: "all", label: "All Cost Bearing" },
  { value: "parent", label: "Parent Bears Cost" },
]

// No Cost EMI Cost Bearing options - for No Cost EMI type
const noCostEmiCostBearingOptions = [
  { value: "all", label: "All Cost Bearing" },
  { value: "institute", label: "Institute Bears Cost" },
  { value: "bank", label: "Bank Bears Cost (Subvention)" },
]

// Partial Cost EMI sharing combinations - for Partial Cost EMI type
const partialCostSharingOptions = [
  { value: "all", label: "All Sharing Types" },
  { value: "parent_institute", label: "Parent + Institute" },
  { value: "bank_institute", label: "Bank + Institute" },
  { value: "parent_bank", label: "Parent + Bank" },
  { value: "parent_bank_institute", label: "Parent + Bank + Institute" },
]

// Financing Charge Percentage options (for all cost bearers)
const chargePercentageOptions = [
  { value: "all", label: "All Percentages" },
  { value: "0", label: "0%" },
  { value: "0.5", label: "0.5%" },
  { value: "1", label: "1%" },
  { value: "1.5", label: "1.5%" },
  { value: "2", label: "2%" },
  { value: "2.5", label: "2.5%" },
  { value: "3", label: "3%" },
  { value: "3.5", label: "3.5%" },
  { value: "4", label: "4%" },
  { value: "5", label: "5%" },
  { value: "6", label: "6%" },
  { value: "custom", label: "Custom Range" },
]

// Transaction Fee Bearing (who pays the convenience fee / MDR)
const transactionFeeBearingOptions = [
  { value: "all", label: "All Fee Bearing" },
  { value: "payer", label: "Payer (Parent) Bears Fee" },
  { value: "merchant", label: "Merchant (Institute) Bears Fee" },
  { value: "partial", label: "Partial (Shared Fee)" },
]

// Partial Transaction Fee Sharing options
const partialFeeSharingOptions = [
  { value: "all", label: "All Sharing Types" },
  { value: "fixed_payer", label: "Fixed Amount by Payer" },
  { value: "fixed_merchant", label: "Fixed Amount by Merchant" },
  { value: "percentage_split", label: "Percentage Split" },
  { value: "mode_based", label: "Mode-based Split" },
]

// NBFC Partners
const nbfcPartners = [
  { value: "all", label: "All NBFCs" },
  { value: "bajaj_finserv", label: "Bajaj Finserv" },
  { value: "hdfc_credila", label: "HDFC Credila" },
  { value: "tata_capital", label: "Tata Capital" },
  { value: "aditya_birla", label: "Aditya Birla Finance" },
  { value: "fullerton", label: "Fullerton India" },
  { value: "incred", label: "InCred" },
  { value: "avanse", label: "Avanse" },
  { value: "eduvanz", label: "Eduvanz" },
  { value: "propelld", label: "Propelld" },
  { value: "auxilo", label: "Auxilo" },
  { value: "credenc", label: "Credenc" },
  { value: "zest_money", label: "ZestMoney" },
  { value: "early_salary", label: "EarlySalary" },
  { value: "home_credit", label: "Home Credit" },
]

// Card Issuing Banks (for Card EMI)
const cardIssuingBanks = [
  { value: "all", label: "All Issuing Banks" },
  // Major Private Sector Banks
  { value: "hdfc", label: "HDFC Bank" },
  { value: "icici", label: "ICICI Bank" },
  { value: "axis", label: "Axis Bank" },
  { value: "kotak", label: "Kotak Mahindra Bank" },
  { value: "indusind", label: "IndusInd Bank" },
  { value: "yesbank", label: "Yes Bank" },
  { value: "idfc", label: "IDFC First Bank" },
  { value: "rbl", label: "RBL Bank" },
  { value: "federal", label: "Federal Bank" },
  // Major Public Sector Banks
  { value: "sbi", label: "SBI Card" },
  { value: "bob", label: "Bank of Baroda" },
  { value: "pnb", label: "Punjab National Bank" },
  { value: "canara", label: "Canara Bank" },
  { value: "union", label: "Union Bank" },
  // Foreign Banks
  { value: "citi", label: "Citibank" },
  { value: "hsbc", label: "HSBC" },
  { value: "scb", label: "Standard Chartered" },
  { value: "amex", label: "American Express" },
]

// Network/Provider Data
const cardNetworks = [
  { value: "all", label: "All Networks" },
  { value: "visa", label: "Visa" },
  { value: "mastercard", label: "Mastercard" },
  { value: "rupay", label: "RuPay" },
  { value: "amex", label: "American Express" },
  { value: "diners", label: "Diners Club" },
  { value: "discover", label: "Discover" },
  { value: "jcb", label: "JCB" },
  { value: "maestro", label: "Maestro" },
]

// International Payment Methods
const internationalPaymentMethods = [
  { value: "all", label: "All Methods" },
  { value: "international_card", label: "International Card" },
  { value: "wire_transfer", label: "Wire Transfer (SWIFT)" },
  { value: "paypal", label: "PayPal" },
  { value: "flywire", label: "Flywire" },
  { value: "western_union", label: "Western Union" },
  { value: "wise", label: "Wise (TransferWise)" },
  { value: "remitly", label: "Remitly" },
]

// International Card Networks (extends regular card networks)
const internationalCardNetworks = [
  { value: "all", label: "All Networks" },
  { value: "visa", label: "Visa" },
  { value: "mastercard", label: "Mastercard" },
  { value: "amex", label: "American Express" },
  { value: "diners", label: "Diners Club" },
  { value: "discover", label: "Discover" },
  { value: "jcb", label: "JCB" },
  { value: "unionpay", label: "UnionPay" },
]

// International Pricing Type (Multi-currency pricing)
const internationalPricingTypes = [
  { value: "all", label: "All Pricing Types" },
  { value: "inr_converted", label: "INR (Direct Conversion)" },
  { value: "foreign_currency", label: "Foreign Currency (Local)" },
]

// Currency options for international payments
const currencies = [
  { value: "all", label: "All Currencies" },
  { value: "inr", label: "INR - Indian Rupee" },
  { value: "usd", label: "USD - US Dollar" },
  { value: "gbp", label: "GBP - British Pound" },
  { value: "eur", label: "EUR - Euro" },
  { value: "aed", label: "AED - UAE Dirham" },
  { value: "sgd", label: "SGD - Singapore Dollar" },
  { value: "aud", label: "AUD - Australian Dollar" },
  { value: "cad", label: "CAD - Canadian Dollar" },
  { value: "jpy", label: "JPY - Japanese Yen" },
  { value: "cny", label: "CNY - Chinese Yuan" },
  { value: "sar", label: "SAR - Saudi Riyal" },
  { value: "qar", label: "QAR - Qatari Riyal" },
  { value: "kwd", label: "KWD - Kuwaiti Dinar" },
  { value: "omr", label: "OMR - Omani Rial" },
  { value: "bhd", label: "BHD - Bahraini Dinar" },
]

const upiPSPs = [
  { value: "all", label: "All PSPs" },
  { value: "googlepay", label: "Google Pay" },
  { value: "phonepe", label: "PhonePe" },
  { value: "paytm", label: "Paytm" },
  { value: "bhim", label: "BHIM" },
  { value: "amazonpay", label: "Amazon Pay" },
  { value: "whatsapp", label: "WhatsApp Pay" },
  { value: "cred", label: "CRED" },
  { value: "mobikwik", label: "MobiKwik" },
  { value: "freecharge", label: "Freecharge" },
  { value: "airtel", label: "Airtel Payments Bank" },
  { value: "jupiter", label: "Jupiter" },
  { value: "slice", label: "Slice" },
]

const wallets = [
  { value: "all", label: "All Wallets" },
  { value: "paytm_wallet", label: "Paytm Wallet" },
  { value: "phonepe_wallet", label: "PhonePe Wallet" },
  { value: "mobikwik_wallet", label: "MobiKwik Wallet" },
  { value: "freecharge_wallet", label: "Freecharge Wallet" },
  { value: "amazonpay_wallet", label: "Amazon Pay Balance" },
  { value: "airtel_wallet", label: "Airtel Money" },
  { value: "jio_wallet", label: "JioMoney" },
  { value: "ola_wallet", label: "Ola Money" },
]

const banks = [
  { value: "all", label: "All Banks" },
  // Public Sector Banks
  { value: "sbi", label: "State Bank of India", group: "public" },
  { value: "pnb", label: "Punjab National Bank", group: "public" },
  { value: "bob", label: "Bank of Baroda", group: "public" },
  { value: "canara", label: "Canara Bank", group: "public" },
  { value: "union", label: "Union Bank of India", group: "public" },
  { value: "indian", label: "Indian Bank", group: "public" },
  { value: "boi", label: "Bank of India", group: "public" },
  { value: "cbi", label: "Central Bank of India", group: "public" },
  { value: "iob", label: "Indian Overseas Bank", group: "public" },
  { value: "uco", label: "UCO Bank", group: "public" },
  { value: "psb", label: "Punjab & Sind Bank", group: "public" },
  // Private Sector Banks
  { value: "hdfc", label: "HDFC Bank", group: "private" },
  { value: "icici", label: "ICICI Bank", group: "private" },
  { value: "axis", label: "Axis Bank", group: "private" },
  { value: "kotak", label: "Kotak Mahindra Bank", group: "private" },
  { value: "indusind", label: "IndusInd Bank", group: "private" },
  { value: "yesbank", label: "Yes Bank", group: "private" },
  { value: "idfc", label: "IDFC First Bank", group: "private" },
  { value: "federal", label: "Federal Bank", group: "private" },
  { value: "rbl", label: "RBL Bank", group: "private" },
  { value: "bandhan", label: "Bandhan Bank", group: "private" },
  { value: "idbi", label: "IDBI Bank", group: "private" },
  { value: "south_indian", label: "South Indian Bank", group: "private" },
  { value: "karur", label: "Karur Vysya Bank", group: "private" },
  { value: "csb", label: "CSB Bank", group: "private" },
  { value: "dcb", label: "DCB Bank", group: "private" },
  // Foreign Banks
  { value: "citi", label: "Citibank", group: "foreign" },
  { value: "hsbc", label: "HSBC", group: "foreign" },
  { value: "scb", label: "Standard Chartered", group: "foreign" },
  { value: "deutsche", label: "Deutsche Bank", group: "foreign" },
  { value: "barclays", label: "Barclays", group: "foreign" },
  // Payments Banks
  { value: "airtel_payments", label: "Airtel Payments Bank", group: "payments" },
  { value: "paytm_payments", label: "Paytm Payments Bank", group: "payments" },
  { value: "fino", label: "Fino Payments Bank", group: "payments" },
  { value: "jio_payments", label: "Jio Payments Bank", group: "payments" },
]

const searchTypes = [
  { value: "all", label: "Search All" },
  { value: "order_id", label: "Order ID" },
  { value: "edviron_order_id", label: "Edviron Order ID" },
  { value: "transaction_id", label: "Transaction ID" },
  { value: "student_name", label: "Student Name" },
  { value: "student_id", label: "Student ID" },
  { value: "payer_phone", label: "Payer Phone" },
  { value: "payer_email", label: "Payer Email" },
  { value: "upi_id", label: "UPI ID" },
  { value: "bank_ref_no", label: "Bank Reference No." },
]

const dateRanges = [
  { value: "all", label: "All Time" },
  { value: "today", label: "Today" },
  { value: "yesterday", label: "Yesterday" },
  { value: "7d", label: "Last 7 Days" },
  { value: "30d", label: "Last 30 Days" },
  { value: "90d", label: "Last 90 Days" },
  { value: "this_month", label: "This Month" },
  { value: "last_month", label: "Last Month" },
  { value: "this_year", label: "This Year" },
  { value: "custom", label: "Custom Range" },
]

export function TransactionFilters({ filters, onFilterChange, onReset }: TransactionFiltersProps) {
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const [showCustomDatePicker, setShowCustomDatePicker] = useState(false)
  const [customStartDate, setCustomStartDate] = useState("")
  const [customEndDate, setCustomEndDate] = useState("")
  
  const handleCustomDateApply = () => {
    if (customStartDate && customEndDate) {
      onFilterChange("dateRange", `${customStartDate}_${customEndDate}`)
      setShowCustomDatePicker(false)
    }
  }
  
  const formatDateRangeDisplay = () => {
    if (filters.dateRange.includes("_")) {
      const [start, end] = filters.dateRange.split("_")
      return `${new Date(start).toLocaleDateString()} - ${new Date(end).toLocaleDateString()}`
    }
    const range = dateRanges.find(r => r.value === filters.dateRange)
    return range?.label || "Select Date"
  }
  
  // Get available channels for current payment mode
  const availableChannels = getAvailableChannels(filters.paymentMode)
  
  // Check if current channel is valid for selected payment mode, if not reset to "all"
  const isCurrentChannelValid = filters.channel === "all" || 
    availableChannels.some(ch => ch.value === filters.channel)
  
  // Auto-reset channel if it becomes invalid due to payment mode change
  if (!isCurrentChannelValid && filters.channel !== "all") {
    onFilterChange("channel", "all")
  }
  
  const hasActiveFilters = Object.entries(filters).some(
    ([key, value]) => key !== "dateRange" && key !== "searchQuery" && key !== "searchType" && value !== "all" && Array.isArray(value) === false,
  )

  const activeFilterCount = Object.entries(filters).filter(
    ([key, value]) => 
      key !== "dateRange" && 
      key !== "searchQuery" && 
      key !== "searchType" &&
      value !== "all" && 
      (Array.isArray(value) ? value.length > 0 : true)
  ).length

  const getSearchPlaceholder = () => {
    const searchType = searchTypes.find(t => t.value === filters.searchType)
    if (filters.searchType === "all" || !searchType) {
      return "Search by Order ID, Transaction ID, Student Name, UPI ID, Bank Ref..."
    }
    return `Search by ${searchType.label}...`
  }

  // Show network filter based on selected payment mode
  const showNetworkFilter = filters.paymentMode && filters.paymentMode !== "all"

  return (
    <Card className="bg-card border-border flex-1">
      <CardContent className="p-4">
        <div className="flex flex-col gap-4">
          {/* Search Row with Type Selector */}
          <div className="flex items-center gap-2">
            <Select value={filters.searchType} onValueChange={(value) => onFilterChange("searchType", value)}>
              <SelectTrigger className="w-48 bg-secondary">
                <SelectValue placeholder="Search Type" />
              </SelectTrigger>
              <SelectContent>
                {searchTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={getSearchPlaceholder()}
                value={filters.searchQuery}
                onChange={(e) => onFilterChange("searchQuery", e.target.value)}
                className="bg-secondary pl-10"
              />
            </div>
            <Popover open={showCustomDatePicker} onOpenChange={setShowCustomDatePicker}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-52 justify-start bg-secondary">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  {formatDateRangeDisplay()}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 p-4" align="end">
                <div className="space-y-4">
                  <h4 className="font-medium">Select Date Range</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {dateRanges.filter(r => r.value !== "custom").map((range) => (
                      <Button
                        key={range.value}
                        variant={filters.dateRange === range.value ? "default" : "outline"}
                        size="sm"
                        className="justify-start"
                        onClick={() => {
                          onFilterChange("dateRange", range.value)
                          setShowCustomDatePicker(false)
                        }}
                      >
                        {range.label}
                      </Button>
                    ))}
                  </div>
                  <div className="border-t pt-4">
                    <h5 className="text-sm font-medium mb-2">Custom Range</h5>
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center gap-2">
                        <label className="text-sm text-muted-foreground w-12">From:</label>
                        <Input
                          type="date"
                          value={customStartDate}
                          onChange={(e) => setCustomStartDate(e.target.value)}
                          className="flex-1"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <label className="text-sm text-muted-foreground w-12">To:</label>
                        <Input
                          type="date"
                          value={customEndDate}
                          onChange={(e) => setCustomEndDate(e.target.value)}
                          className="flex-1"
                        />
                      </div>
                      <Button 
                        onClick={handleCustomDateApply}
                        disabled={!customStartDate || !customEndDate}
                        className="mt-2"
                      >
                        Apply Custom Range
                      </Button>
                    </div>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>

          {/* Primary Filter Row */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Filter className="h-4 w-4" />
              Filters:
              {activeFilterCount > 0 && (
                <Badge variant="secondary" className="ml-1 h-5 px-1.5">
                  {activeFilterCount}
                </Badge>
              )}
            </div>

            <Select value={filters.vendor} onValueChange={(value) => onFilterChange("vendor", value)}>
              <SelectTrigger className="w-36 bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {vendors.map((v) => (
                  <SelectItem key={v.value} value={v.value}>
                    {v.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.gateway} onValueChange={(value) => onFilterChange("gateway", value)}>
              <SelectTrigger className="w-36 bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {gateways.map((gw) => (
                  <SelectItem key={gw.value} value={gw.value}>
                    {gw.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.status} onValueChange={(value) => onFilterChange("status", value)}>
              <SelectTrigger className="w-32 bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {statuses.map((st) => (
                  <SelectItem key={st.value} value={st.value}>
                    {st.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filters.captureStatus} onValueChange={(value) => onFilterChange("captureStatus", value)}>
              <SelectTrigger className="w-48 bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {captureStatuses.map((cs) => (
                  <SelectItem key={cs.value} value={cs.value}>
                    {cs.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className="gap-1 bg-transparent"
            >
              <ChevronRight className={`h-4 w-4 transition-transform ${showAdvancedFilters ? 'rotate-90' : ''}`} />
              Advanced
            </Button>

            {hasActiveFilters && (
              <Button variant="ghost" size="sm" onClick={onReset} className="gap-1 text-muted-foreground">
                <X className="h-4 w-4" />
                Clear
              </Button>
            )}
          </div>

          {/* Advanced Filters (Collapsible) */}
          {showAdvancedFilters && (
            <div className="border-t pt-4 space-y-4">
              {/* Payment Mode & Channel Row */}
              <div className="flex flex-wrap items-start gap-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground w-16">
                  Payment:
                </div>

                <Select value={filters.paymentMode} onValueChange={(value) => onFilterChange("paymentMode", value)}>
                  <SelectTrigger className="w-40 bg-secondary">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentModes.map((mode) => (
                      <SelectItem key={mode.value} value={mode.value}>
                        {mode.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.channel} 
                  onValueChange={(value) => onFilterChange("channel", value)}
                >
                  <SelectTrigger className="w-44 bg-secondary">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableChannels(filters.paymentMode).map((ch) => (
                      <SelectItem key={ch.value} value={ch.value}>
                        {ch.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Dynamic Network Filter based on Payment Mode */}
                {filters.paymentMode === "credit_card" || filters.paymentMode === "debit_card" ? (
                  <Select value={filters.cardNetwork || "all"} onValueChange={(value) => onFilterChange("cardNetwork" as keyof FilterState, value)}>
                    <SelectTrigger className="w-40 bg-secondary">
                      <SelectValue placeholder="Card Network" />
                    </SelectTrigger>
                    <SelectContent>
                      {cardNetworks.map((network) => (
                        <SelectItem key={network.value} value={network.value}>
                          {network.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : filters.paymentMode === "upi" ? (
                  <Select value={filters.upiPsp || "all"} onValueChange={(value) => onFilterChange("upiPsp" as keyof FilterState, value)}>
                    <SelectTrigger className="w-40 bg-secondary">
                      <SelectValue placeholder="UPI PSP" />
                    </SelectTrigger>
                    <SelectContent>
                      <ScrollArea className="h-64">
                        {upiPSPs.map((psp) => (
                          <SelectItem key={psp.value} value={psp.value}>
                            {psp.label}
                          </SelectItem>
                        ))}
                      </ScrollArea>
                    </SelectContent>
                  </Select>
                ) : filters.paymentMode === "netbanking" ? (
                  <Select value={filters.bank || "all"} onValueChange={(value) => onFilterChange("bank" as keyof FilterState, value)}>
                    <SelectTrigger className="w-48 bg-secondary">
                      <SelectValue placeholder="Bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <ScrollArea className="h-72">
                        <SelectItem value="all">All Banks</SelectItem>
                        <SelectGroup>
                          <SelectLabel>Public Sector Banks</SelectLabel>
                          {banks.filter(b => b.group === "public").map((bank) => (
                            <SelectItem key={bank.value} value={bank.value}>
                              {bank.label}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                        <SelectGroup>
                          <SelectLabel>Private Sector Banks</SelectLabel>
                          {banks.filter(b => b.group === "private").map((bank) => (
                            <SelectItem key={bank.value} value={bank.value}>
                              {bank.label}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                        <SelectGroup>
                          <SelectLabel>Foreign Banks</SelectLabel>
                          {banks.filter(b => b.group === "foreign").map((bank) => (
                            <SelectItem key={bank.value} value={bank.value}>
                              {bank.label}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                        <SelectGroup>
                          <SelectLabel>Payments Banks</SelectLabel>
                          {banks.filter(b => b.group === "payments").map((bank) => (
                            <SelectItem key={bank.value} value={bank.value}>
                              {bank.label}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </ScrollArea>
                    </SelectContent>
                  </Select>
                ) : filters.paymentMode === "wallet" ? (
                  <Select value={filters.wallet || "all"} onValueChange={(value) => onFilterChange("wallet" as keyof FilterState, value)}>
                    <SelectTrigger className="w-44 bg-secondary">
                      <SelectValue placeholder="Wallet" />
                    </SelectTrigger>
                    <SelectContent>
                      {wallets.map((w) => (
                        <SelectItem key={w.value} value={w.value}>
                          {w.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : filters.paymentMode === "bank_transfer" ? (
                  <Select value={filters.bankTransferType || "all"} onValueChange={(value) => onFilterChange("bankTransferType" as keyof FilterState, value)}>
                    <SelectTrigger className="w-36 bg-secondary">
                      <SelectValue placeholder="Transfer Type" />
                    </SelectTrigger>
                    <SelectContent>
                      {bankTransferTypes.map((bt) => (
                        <SelectItem key={bt.value} value={bt.value}>
                          {bt.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : filters.paymentMode === "international" ? (
                  <>
                    <Select value={filters.internationalMethod || "all"} onValueChange={(value) => onFilterChange("internationalMethod" as keyof FilterState, value)}>
                      <SelectTrigger className="w-44 bg-secondary">
                        <SelectValue placeholder="Payment Method" />
                      </SelectTrigger>
                      <SelectContent>
                        {internationalPaymentMethods.map((method) => (
                          <SelectItem key={method.value} value={method.value}>
                            {method.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    {filters.internationalMethod === "international_card" && (
                      <Select value={filters.internationalCardNetwork || "all"} onValueChange={(value) => onFilterChange("internationalCardNetwork" as keyof FilterState, value)}>
                        <SelectTrigger className="w-40 bg-secondary">
                          <SelectValue placeholder="Card Network" />
                        </SelectTrigger>
                        <SelectContent>
                          {internationalCardNetworks.map((network) => (
                            <SelectItem key={network.value} value={network.value}>
                              {network.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    
                    <Select value={filters.internationalPricingType || "all"} onValueChange={(value) => onFilterChange("internationalPricingType" as keyof FilterState, value)}>
                      <SelectTrigger className="w-48 bg-secondary">
                        <SelectValue placeholder="Pricing Type" />
                      </SelectTrigger>
                      <SelectContent>
                        {internationalPricingTypes.map((pt) => (
                          <SelectItem key={pt.value} value={pt.value}>
                            {pt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select value={filters.currency || "all"} onValueChange={(value) => onFilterChange("currency" as keyof FilterState, value)}>
                      <SelectTrigger className="w-44 bg-secondary">
                        <SelectValue placeholder="Currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <ScrollArea className="h-64">
                          {currencies.map((curr) => (
                            <SelectItem key={curr.value} value={curr.value}>
                              {curr.label}
                            </SelectItem>
                          ))}
                        </ScrollArea>
                      </SelectContent>
                    </Select>
                  </>
                ) : null}
              </div>
              
              {/* International Payment Info */}
              {filters.paymentMode === "international" && (
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground pl-20">
                  <span className="px-2 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    INR (Direct Conversion): Payer pays in INR, amount auto-converted at checkout
                  </span>
                  <span className="px-2 py-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    Foreign Currency (Local): Payer pays in their local currency (USD, GBP, EUR, etc.)
                  </span>
                </div>
              )}

              {/* Transaction Fee Bearing Row */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground w-16">
                  Txn Fee:
                </div>

                <Select value={filters.transactionFeeBearing || "all"} onValueChange={(value) => onFilterChange("transactionFeeBearing" as keyof FilterState, value)}>
                  <SelectTrigger className="w-52 bg-secondary">
                    <SelectValue placeholder="Fee Bearing" />
                  </SelectTrigger>
                  <SelectContent>
                    {transactionFeeBearingOptions.map((fb) => (
                      <SelectItem key={fb.value} value={fb.value}>
                        {fb.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {filters.transactionFeeBearing === "partial" && (
                  <Select value={filters.partialFeeSharing || "all"} onValueChange={(value) => onFilterChange("partialFeeSharing" as keyof FilterState, value)}>
                    <SelectTrigger className="w-48 bg-secondary">
                      <SelectValue placeholder="Sharing Type" />
                    </SelectTrigger>
                    <SelectContent>
                      {partialFeeSharingOptions.map((pfs) => (
                        <SelectItem key={pfs.value} value={pfs.value}>
                          {pfs.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>

              {/* Transaction Fee Info */}
              <div className="flex flex-wrap gap-2 text-xs text-muted-foreground pl-20">
                <span className="font-medium text-foreground mr-2">Transaction Fee:</span>
                <span className="px-2 py-1 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                  Payer: Parent pays convenience fee
                </span>
                <span className="px-2 py-1 rounded bg-green-500/10 text-green-400 border border-green-500/20">
                  Merchant: Institute absorbs fee
                </span>
                <span className="px-2 py-1 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                  Partial: Fee split between parties
                </span>
              </div>

              {/* Partial Fee Sharing Info */}
              {filters.transactionFeeBearing === "partial" && (
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground pl-20">
                  <span className="font-medium text-foreground mr-2">Sharing Types:</span>
                  <span className="px-2 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    Fixed by Payer: Payer pays fixed amount
                  </span>
                  <span className="px-2 py-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    Fixed by Merchant: Institute pays fixed amount
                  </span>
                  <span className="px-2 py-1 rounded bg-orange-500/10 text-orange-400 border border-orange-500/20">
                    Percentage: Split by percentage
                  </span>
                  <span className="px-2 py-1 rounded bg-teal-500/10 text-teal-400 border border-teal-500/20">
                    Mode-based: Based on payment mode
                  </span>
                </div>
              )}

              {/* Financing Row */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground w-16">
                  Financing:
                </div>

                <Select value={filters.financingCategory || "all"} onValueChange={(value) => onFilterChange("financingCategory" as keyof FilterState, value)}>
                  <SelectTrigger className="w-40 bg-secondary">
                    <SelectValue placeholder="Financing Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {financingCategories.map((fc) => (
                      <SelectItem key={fc.value} value={fc.value}>
                        {fc.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {(filters.financingCategory === "card_emi" || filters.financingCategory === "nbfc_financing") && (
                  <>
                    <Select value={filters.financingType || "all"} onValueChange={(value) => onFilterChange("financingType" as keyof FilterState, value)}>
                      <SelectTrigger className="w-56 bg-secondary">
                        <SelectValue placeholder="EMI Type" />
                      </SelectTrigger>
                      <SelectContent>
                        {financingTypes.map((ft) => (
                          <SelectItem key={ft.value} value={ft.value}>
                            {ft.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    {/* EMI type - Parent bears cost */}
                    {filters.financingType === "emi" && (
                      <Select value={filters.emiCostBearing || "all"} onValueChange={(value) => onFilterChange("emiCostBearing" as keyof FilterState, value)}>
                        <SelectTrigger className="w-44 bg-secondary">
                          <SelectValue placeholder="Cost Bearing" />
                        </SelectTrigger>
                        <SelectContent>
                          {emiCostBearingOptions.map((cb) => (
                            <SelectItem key={cb.value} value={cb.value}>
                              {cb.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {/* No Cost EMI - Institute or Bank bears cost */}
                    {filters.financingType === "no_cost_emi" && (
                      <Select value={filters.emiCostBearing || "all"} onValueChange={(value) => onFilterChange("emiCostBearing" as keyof FilterState, value)}>
                        <SelectTrigger className="w-52 bg-secondary">
                          <SelectValue placeholder="Cost Bearing" />
                        </SelectTrigger>
                        <SelectContent>
                          {noCostEmiCostBearingOptions.map((cb) => (
                            <SelectItem key={cb.value} value={cb.value}>
                              {cb.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}

                    {/* Partial Cost EMI - Shared cost */}
                    {filters.financingType === "partial_cost_emi" && (
                      <Select value={filters.partialCostSharing || "all"} onValueChange={(value) => onFilterChange("partialCostSharing" as keyof FilterState, value)}>
                        <SelectTrigger className="w-56 bg-secondary">
                          <SelectValue placeholder="Cost Sharing" />
                        </SelectTrigger>
                        <SelectContent>
                          {partialCostSharingOptions.map((pcs) => (
                            <SelectItem key={pcs.value} value={pcs.value}>
                              {pcs.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  </>
                )}

                {/* Card EMI - Card Issuing Bank */}
                {filters.financingCategory === "card_emi" && (
                  <Select value={filters.cardIssuingBank || "all"} onValueChange={(value) => onFilterChange("cardIssuingBank" as keyof FilterState, value)}>
                    <SelectTrigger className="w-44 bg-secondary">
                      <SelectValue placeholder="Issuing Bank" />
                    </SelectTrigger>
                    <SelectContent>
                      <ScrollArea className="h-64">
                        {cardIssuingBanks.map((bank) => (
                          <SelectItem key={bank.value} value={bank.value}>
                            {bank.label}
                          </SelectItem>
                        ))}
                      </ScrollArea>
                    </SelectContent>
                  </Select>
                )}

                {filters.financingCategory === "nbfc_financing" && (
                  <>
                    <Select value={filters.nbfcPartner || "all"} onValueChange={(value) => onFilterChange("nbfcPartner" as keyof FilterState, value)}>
                      <SelectTrigger className="w-44 bg-secondary">
                        <SelectValue placeholder="NBFC Partner" />
                      </SelectTrigger>
                      <SelectContent>
                        <ScrollArea className="h-64">
                          {nbfcPartners.map((nbfc) => (
                            <SelectItem key={nbfc.value} value={nbfc.value}>
                              {nbfc.label}
                            </SelectItem>
                          ))}
                        </ScrollArea>
                      </SelectContent>
                    </Select>

                    <Select value={filters.financingCollectionType || "all"} onValueChange={(value) => onFilterChange("financingCollectionType" as keyof FilterState, value)}>
                      <SelectTrigger className="w-48 bg-secondary">
                        <SelectValue placeholder="Collection Type" />
                      </SelectTrigger>
                      <SelectContent>
                        {financingCollectionTypes.map((ct) => (
                          <SelectItem key={ct.value} value={ct.value}>
                            {ct.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </>
                )}
              </div>

              {/* Financing Info */}
              {filters.financingCategory && filters.financingCategory !== "all" && filters.financingCategory !== "none" && (
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground pl-20">
                  {filters.financingCategory === "card_emi" && (
                    <span className="px-2 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                      Card EMI: Bank converts credit card payment to installments
                    </span>
                  )}
                  {filters.financingCategory === "nbfc_financing" && (
                    <>
                      <span className="px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Edviron Collection: We handle EMI collection from parents
                      </span>
                      <span className="px-2 py-1 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        NBFC Collection: NBFC partner handles collection directly
                      </span>
                    </>
                  )}
                </div>
              )}

              {/* EMI Type Info */}
              {(filters.financingCategory === "card_emi" || filters.financingCategory === "nbfc_financing") && (
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground pl-20">
                  <span className="font-medium text-foreground mr-2">EMI Types:</span>
                  <span className="px-2 py-1 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                    EMI: Parent bears all charges
                  </span>
                  <span className="px-2 py-1 rounded bg-green-500/10 text-green-400 border border-green-500/20">
                    No Cost EMI: Institute/Bank bears charges
                  </span>
                  <span className="px-2 py-1 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                    Partial EMI: Cost shared between parties
                  </span>
                </div>
              )}

              {/* No Cost EMI Bearing Info */}
              {filters.financingType === "no_cost_emi" && (
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground pl-20">
                  <span className="font-medium text-foreground mr-2">Cost Bearer:</span>
                  <span className="px-2 py-1 rounded bg-green-500/10 text-green-400 border border-green-500/20">
                    Institute Bears Cost
                  </span>
                  <span className="px-2 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                    Bank Subvention (Bank Bears Cost)
                  </span>
                </div>
              )}

              {/* Partial Cost EMI Sharing Info */}
              {filters.financingType === "partial_cost_emi" && (
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground pl-20">
                  <span className="font-medium text-foreground mr-2">Cost Sharing:</span>
                  <span className="px-2 py-1 rounded bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                    Parent + Institute
                  </span>
                  <span className="px-2 py-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">
                    Bank + Institute
                  </span>
                  <span className="px-2 py-1 rounded bg-orange-500/10 text-orange-400 border border-orange-500/20">
                    Parent + Bank
                  </span>
                  <span className="px-2 py-1 rounded bg-teal-500/10 text-teal-400 border border-teal-500/20">
                    Parent + Bank + Institute
                  </span>
                </div>
              )}

              {/* Split and Pay Info */}
              {filters.paymentMode === "split_and_pay" && (
                <div className="flex items-start gap-2 pl-20">
                  <div className="text-xs text-muted-foreground bg-secondary/50 rounded p-2 border border-border">
                    <span className="font-medium text-foreground">Split and Pay (Multi-mode):</span> Parents can pay large fees (e.g., Rs 2 Lakhs) using multiple payment methods in a single transaction - 
                    e.g., partial amount from Credit Card, remaining from UPI or Net Banking.
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
