"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Settings2, LayoutDashboard, Receipt, Split } from "lucide-react"
import { TransactionStats } from "./transaction-stats"
import { TransactionFilters } from "./transaction-filters"
import { TransactionsTable, type CustomColumnConfig } from "./transactions-table"
import { TransactionDashboard } from "./transaction-dashboard"
import { SplitTransactionsTab } from "./split-transactions-tab"
import { ExportModal } from "./export-modal"
import { CustomColumnsManager } from "./custom-columns-manager"

// Shared filter shape used by child components (dashboard, table, filters)
export interface FilterState {
  institute: string
  dateRange: string
  status: string
  gateway: string
  channel: string
  vendor: string
  captureStatus: string
  paymentMode: string
  searchQuery: string
  searchType: string
  // Payment-mode specifics
  cardNetwork?: string
  upiPsp?: string
  bank?: string
  wallet?: string
  bankTransferType?: string
  // International
  internationalMethod?: string
  internationalCardNetwork?: string
  internationalPricingType?: string
  currency?: string
  // Fee bearing
  transactionFeeBearing?: string
  partialFeeSharing?: string
  parentChargePercentage?: string
  instituteChargePercentage?: string
  bankChargePercentage?: string
  // Financing / EMI
  financingCategory?: string
  financingType?: string
  emiCostBearing?: string
  partialCostSharing?: string
  cardIssuingBank?: string
  nbfcPartner?: string
  financingCollectionType?: string
}

const defaultFilters: FilterState = {
  institute: "all",
  dateRange: "30d",
  status: "all",
  gateway: "all",
  channel: "all",
  vendor: "all",
  captureStatus: "all",
  paymentMode: "all",
  searchQuery: "",
  searchType: "all",
  cardNetwork: "all",
  upiPsp: "all",
  bank: "all",
  wallet: "all",
  bankTransferType: "all",
  internationalMethod: "all",
  internationalCardNetwork: "all",
  internationalPricingType: "all",
  currency: "all",
  transactionFeeBearing: "all",
  partialFeeSharing: "all",
  parentChargePercentage: "all",
  instituteChargePercentage: "all",
  bankChargePercentage: "all",
  financingCategory: "all",
  financingType: "all",
  emiCostBearing: "all",
  partialCostSharing: "all",
  cardIssuingBank: "all",
  nbfcPartner: "all",
  financingCollectionType: "all",
}

export function TransactionsContent() {
  const [filters, setFilters] = useState<FilterState>(defaultFilters)
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [customColumns, setCustomColumns] = useState<CustomColumnConfig[]>([])
  const [visibleCustomColumns, setVisibleCustomColumns] = useState<string[]>([])
  const [showExportModal, setShowExportModal] = useState(false)
  const [showColumnsManager, setShowColumnsManager] = useState(false)

  const handleFilterChange = (key: keyof FilterState, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const resetFilters = () => setFilters(defaultFilters)

  return (
    <div className="space-y-4">
      {/* Page header */}
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Transactions</h1>
          <p className="text-sm text-muted-foreground">
            Search, filter and reconcile every payment across gateways, channels and modes.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowColumnsManager(true)}
          >
            <Settings2 className="mr-2 h-4 w-4" />
            Custom Columns
          </Button>
          <Button size="sm" onClick={() => setShowExportModal(true)}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* High-level stats */}
      <TransactionStats />

      {/* Filters */}
      <TransactionFilters
        filters={filters}
        onFilterChange={handleFilterChange}
        onReset={resetFilters}
      />

      {/* Main tabs */}
      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">
            <Receipt className="mr-2 h-4 w-4" />
            All Transactions
          </TabsTrigger>
          <TabsTrigger value="dashboard">
            <LayoutDashboard className="mr-2 h-4 w-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="split">
            <Split className="mr-2 h-4 w-4" />
            Split Payments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <TransactionsTable
            filters={filters}
            onSelectionChange={setSelectedIds}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={setRowsPerPage}
            customColumns={customColumns}
          />
        </TabsContent>

        <TabsContent value="dashboard" className="space-y-4">
          <TransactionDashboard filters={filters} />
        </TabsContent>

        <TabsContent value="split" className="space-y-4">
          <SplitTransactionsTab />
        </TabsContent>
      </Tabs>

      {/* Export modal */}
      <ExportModal
        open={showExportModal}
        onClose={() => setShowExportModal(false)}
        totalRecords={1247}
        selectedRecords={selectedIds.length}
        filters={{
          dateRange: filters.dateRange,
          status: filters.status,
          gateway: filters.gateway,
        }}
      />

      {/* Custom columns manager */}
      <CustomColumnsManager
        open={showColumnsManager}
        onClose={() => setShowColumnsManager(false)}
        customColumns={customColumns}
        onColumnsChange={setCustomColumns}
        visibleColumns={visibleCustomColumns}
        onVisibleColumnsChange={setVisibleCustomColumns}
      />
    </div>
  )
}
