"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { time: "00:00", razorpay: 98.5, cashfree: 97.2, easebuzz: 96.8, paytm: 95.5 },
  { time: "04:00", razorpay: 99.1, cashfree: 98.1, easebuzz: 97.5, paytm: 96.2 },
  { time: "08:00", razorpay: 97.8, cashfree: 96.5, easebuzz: 95.2, paytm: 94.8 },
  { time: "12:00", razorpay: 98.2, cashfree: 97.8, easebuzz: 96.9, paytm: 95.1 },
  { time: "16:00", razorpay: 99.5, cashfree: 98.9, easebuzz: 98.2, paytm: 97.5 },
  { time: "20:00", razorpay: 98.9, cashfree: 98.2, easebuzz: 97.6, paytm: 96.8 },
  { time: "24:00", razorpay: 99.2, cashfree: 98.5, easebuzz: 97.9, paytm: 97.1 },
]

export function GatewayPerformance() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Gateway Success Rate (24h)</CardTitle>
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-chart-1" />
              <span className="text-muted-foreground">Razorpay</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-chart-2" />
              <span className="text-muted-foreground">Cashfree</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-chart-3" />
              <span className="text-muted-foreground">Easebuzz</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-chart-4" />
              <span className="text-muted-foreground">Paytm</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[280px] w-full">
          {mounted && (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
              <XAxis dataKey="time" stroke="#6b7280" fontSize={12} />
              <YAxis stroke="#6b7280" fontSize={12} domain={[92, 100]} tickFormatter={(v) => `${v}%`} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1e1e2e",
                  border: "1px solid #2a2a3e",
                  borderRadius: "8px",
                }}
                formatter={(value: number) => [`${value}%`, ""]}
              />
              <Line type="monotone" dataKey="razorpay" stroke="#22c55e" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="cashfree" stroke="#3b82f6" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="easebuzz" stroke="#eab308" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="paytm" stroke="#a855f7" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
