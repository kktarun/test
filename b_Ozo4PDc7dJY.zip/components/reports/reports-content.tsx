"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { 
  FileDown, 
  FileText,
  BarChart3,
  PieChart,
  TrendingUp,
  Users,
  IndianRupee,
  Calendar,
  Building2,
  CreditCard,
  Clock,
  CheckCircle2,
  Loader2,
  Download,
  Filter,
  Plus,
  Settings2,
  Eye,
} from "lucide-react"

const reportCategories = [
  {
    title: "Collection Reports",
    description: "Track fee collections and revenue",
    icon: IndianRupee,
    reports: [
      { name: "Daily Collection Report", format: ["PDF", "Excel"] },
      { name: "Monthly Collection Summary", format: ["PDF", "Excel"] },
      { name: "Fee Head-wise Collection", format: ["PDF", "Excel", "CSV"] },
      { name: "Branch-wise Collection", format: ["PDF", "Excel"] },
      { name: "Payment Method Analysis", format: ["PDF", "Excel"] },
    ],
  },
  {
    title: "Due Reports",
    description: "Outstanding fees and defaulters",
    icon: Clock,
    reports: [
      { name: "Student-wise Dues", format: ["PDF", "Excel"] },
      { name: "Class-wise Dues Summary", format: ["PDF", "Excel"] },
      { name: "Defaulter List", format: ["PDF", "Excel", "CSV"] },
      { name: "Overdue Analysis", format: ["PDF", "Excel"] },
      { name: "Aging Report", format: ["PDF", "Excel"] },
    ],
  },
  {
    title: "Reconciliation Reports",
    description: "Payment gateway and bank records",
    icon: CheckCircle2,
    reports: [
      { name: "Gateway Transaction Report", format: ["PDF", "Excel"] },
      { name: "UTR Reconciliation Report", format: ["PDF", "Excel"] },
      { name: "Settlement Report", format: ["PDF", "Excel", "CSV"] },
      { name: "Bank Reconciliation", format: ["PDF", "Excel"] },
      { name: "Unmatched Transactions", format: ["PDF", "Excel"] },
    ],
  },
  {
    title: "Finance Reports",
    description: "Financial analytics and summaries",
    icon: BarChart3,
    reports: [
      { name: "Fee Head Revenue Report", format: ["PDF", "Excel"] },
      { name: "Discount & Scholarship Report", format: ["PDF", "Excel"] },
      { name: "Refund Report", format: ["PDF", "Excel"] },
      { name: "Adjustment Report", format: ["PDF", "Excel"] },
      { name: "Annual Financial Summary", format: ["PDF", "Excel"] },
    ],
  },
]

const quickStats = [
  { label: "Reports Generated Today", value: "24", icon: FileText },
  { label: "Scheduled Reports", value: "8", icon: Calendar },
  { label: "Saved Templates", value: "12", icon: FileDown },
]

const recentReports = [
  { id: 1, name: "Daily Collection Report", date: "Apr 19, 2026", format: "PDF", size: "245 KB", status: "ready" },
  { id: 2, name: "Student-wise Dues", date: "Apr 18, 2026", format: "Excel", size: "1.2 MB", status: "ready" },
  { id: 3, name: "Gateway Transaction Report", date: "Apr 18, 2026", format: "CSV", size: "890 KB", status: "ready" },
  { id: 4, name: "Monthly Collection Summary", date: "Apr 15, 2026", format: "PDF", size: "156 KB", status: "ready" },
  { id: 5, name: "Defaulter List", date: "Apr 14, 2026", format: "Excel", size: "320 KB", status: "ready" },
]

export function ReportsContent() {
  const [showGenerateDialog, setShowGenerateDialog] = useState(false)
  const [selectedReport, setSelectedReport] = useState<{ name: string; category: string; format: string } | null>(null)
  const [generating, setGenerating] = useState(false)
  const [generationProgress, setGenerationProgress] = useState(0)
  const [generationComplete, setGenerationComplete] = useState(false)
  const [dateFrom, setDateFrom] = useState("2026-04-01")
  const [dateTo, setDateTo] = useState("2026-04-20")
  const [selectedFormat, setSelectedFormat] = useState("PDF")
  const [selectedBranch, setSelectedBranch] = useState("all")
  const [selectedClass, setSelectedClass] = useState("all")

  const handleGenerateReport = (reportName: string, category: string, format: string) => {
    setSelectedReport({ name: reportName, category, format })
    setSelectedFormat(format)
    setShowGenerateDialog(true)
    setGenerating(false)
    setGenerationComplete(false)
    setGenerationProgress(0)
  }

  const startGeneration = () => {
    setGenerating(true)
    setGenerationProgress(0)
    
    const interval = setInterval(() => {
      setGenerationProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setGenerating(false)
          setGenerationComplete(true)
          return 100
        }
        return prev + 10
      })
    }, 200)
  }

  const resetDialog = () => {
    setShowGenerateDialog(false)
    setSelectedReport(null)
    setGenerating(false)
    setGenerationComplete(false)
    setGenerationProgress(0)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">
            Generate and download financial and operational reports
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select defaultValue="2024-25">
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Academic Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024-25">2024-25</SelectItem>
              <SelectItem value="2023-24">2023-24</SelectItem>
              <SelectItem value="2022-23">2022-23</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Calendar className="mr-2 h-4 w-4" />
            Schedule Report
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        {quickStats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="flex items-center gap-4 p-4">
              <div className="rounded-lg bg-primary/10 p-2">
                <stat.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Report Categories */}
      <div className="grid gap-6 md:grid-cols-2">
        {reportCategories.map((category) => (
          <Card key={category.title}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="rounded-lg bg-primary/10 p-2">
                  <category.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle className="text-lg">{category.title}</CardTitle>
                  <CardDescription>{category.description}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {category.reports.map((report) => (
                  <div
                    key={report.name}
                    className="flex items-center justify-between rounded-lg border p-3 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">{report.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {report.format.map((fmt) => (
                        <Button
                          key={fmt}
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs"
                          onClick={() => handleGenerateReport(report.name, category.title, fmt)}
                        >
                          <FileDown className="mr-1 h-3 w-3" />
                          {fmt}
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Custom Report Builder */}
      <Card>
        <CardHeader>
          <CardTitle>Custom Report Builder</CardTitle>
          <CardDescription>
            Create custom reports with specific filters and data fields
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Report Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="collection">Collection Report</SelectItem>
                <SelectItem value="dues">Dues Report</SelectItem>
                <SelectItem value="reconciliation">Reconciliation</SelectItem>
                <SelectItem value="finance">Finance Report</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                <SelectItem value="main">Main Campus</SelectItem>
                <SelectItem value="north">North Branch</SelectItem>
                <SelectItem value="south">South Branch</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="1-5">Class 1-5</SelectItem>
                <SelectItem value="6-8">Class 6-8</SelectItem>
                <SelectItem value="9-10">Class 9-10</SelectItem>
                <SelectItem value="11-12">Class 11-12</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => handleGenerateReport("Custom Report", "Custom", "PDF")}>
              <BarChart3 className="mr-2 h-4 w-4" />
              Generate Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
          <CardDescription>
            Download previously generated reports
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentReports.map((report) => (
              <div
                key={report.id}
                className="flex items-center justify-between rounded-lg border p-3 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-primary/10 p-2">
                    <FileText className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{report.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {report.date} · {report.format} · {report.size}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">
                    Ready
                  </Badge>
                  <Button variant="ghost" size="sm">
                    <Eye className="mr-1 h-3 w-3" />
                    Preview
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="mr-1 h-3 w-3" />
                    Download
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Generate Report Dialog */}
      <Dialog open={showGenerateDialog} onOpenChange={resetDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Generate Report</DialogTitle>
            <DialogDescription>
              {selectedReport?.name} - Configure options and generate
            </DialogDescription>
          </DialogHeader>

          {!generating && !generationComplete && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>From Date</Label>
                  <Input
                    type="date"
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>To Date</Label>
                  <Input
                    type="date"
                    value={dateTo}
                    onChange={(e) => setDateTo(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Format</Label>
                <RadioGroup
                  value={selectedFormat}
                  onValueChange={setSelectedFormat}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="PDF" id="pdf" />
                    <Label htmlFor="pdf" className="cursor-pointer">PDF</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Excel" id="excel" />
                    <Label htmlFor="excel" className="cursor-pointer">Excel</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="CSV" id="csv" />
                    <Label htmlFor="csv" className="cursor-pointer">CSV</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Branch</Label>
                  <Select value={selectedBranch} onValueChange={setSelectedBranch}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Branches</SelectItem>
                      <SelectItem value="main">Main Campus</SelectItem>
                      <SelectItem value="north">North Branch</SelectItem>
                      <SelectItem value="south">South Branch</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Class</Label>
                  <Select value={selectedClass} onValueChange={setSelectedClass}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Classes</SelectItem>
                      <SelectItem value="1-5">Class 1-5</SelectItem>
                      <SelectItem value="6-8">Class 6-8</SelectItem>
                      <SelectItem value="9-10">Class 9-10</SelectItem>
                      <SelectItem value="11-12">Class 11-12</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-3 rounded-lg border p-3">
                <Label className="text-sm font-medium">Include in Report</Label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="summary" defaultChecked />
                    <Label htmlFor="summary" className="text-sm cursor-pointer">Summary Section</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="details" defaultChecked />
                    <Label htmlFor="details" className="text-sm cursor-pointer">Detailed Records</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="charts" defaultChecked />
                    <Label htmlFor="charts" className="text-sm cursor-pointer">Charts & Graphs</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="footer" defaultChecked />
                    <Label htmlFor="footer" className="text-sm cursor-pointer">Footer & Signatures</Label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {generating && (
            <div className="space-y-4 py-6">
              <div className="flex flex-col items-center gap-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <div className="text-center">
                  <p className="font-medium">Generating Report...</p>
                  <p className="text-sm text-muted-foreground">
                    Processing {selectedReport?.name}
                  </p>
                </div>
              </div>
              <Progress value={generationProgress} className="h-2" />
              <p className="text-center text-xs text-muted-foreground">
                {generationProgress}% complete
              </p>
            </div>
          )}

          {generationComplete && (
            <div className="space-y-4 py-6">
              <div className="flex flex-col items-center gap-4">
                <div className="rounded-full bg-success/10 p-3">
                  <CheckCircle2 className="h-8 w-8 text-success" />
                </div>
                <div className="text-center">
                  <p className="font-medium">Report Generated Successfully</p>
                  <p className="text-sm text-muted-foreground">
                    {selectedReport?.name} ({selectedFormat})
                  </p>
                </div>
              </div>
              <div className="flex justify-center gap-2">
                <Button variant="outline">
                  <Eye className="mr-2 h-4 w-4" />
                  Preview
                </Button>
                <Button>
                  <Download className="mr-2 h-4 w-4" />
                  Download {selectedFormat}
                </Button>
              </div>
            </div>
          )}

          <DialogFooter>
            {!generating && !generationComplete && (
              <>
                <Button variant="outline" onClick={resetDialog}>
                  Cancel
                </Button>
                <Button onClick={startGeneration}>
                  <FileDown className="mr-2 h-4 w-4" />
                  Generate Report
                </Button>
              </>
            )}
            {generationComplete && (
              <Button variant="outline" onClick={resetDialog}>
                Close
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
