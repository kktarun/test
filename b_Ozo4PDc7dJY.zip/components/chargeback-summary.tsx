"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, ArrowRight, Clock, XCircle, CheckCircle2, AlertCircle } from "lucide-react"
import Link from "next/link"

const chargebackStats = {
  total: 23,
  totalAmount: 487500,
  pendingResponse: 8,
  underReview: 6,
  won: 5,
  lost: 4,
  responseDeadlines: [
    { id: "CB-2024-0023", institute: "Delhi Public School", amount: 45000, daysLeft: 2 },
    { id: "CB-2024-0022", institute: "Delhi Public School", amount: 32000, daysLeft: 5 },
    { id: "CB-2024-0021", institute: "Delhi Public School", amount: 28500, daysLeft: 7 },
  ],
  recentChargebacks: [
    {
      id: "CB-2024-0023",
      institute: "Delhi Public School",
      student: "Rahul Sharma",
      amount: 45000,
      reason: "Service not provided",
      status: "pending_response",
      date: "2024-01-06",
    },
    {
      id: "CB-2024-0022",
      institute: "Delhi Public School",
      student: "Priya Patel",
      amount: 32000,
      reason: "Duplicate charge",
      status: "under_review",
      date: "2024-01-05",
    },
    {
      id: "CB-2024-0021",
      institute: "Delhi Public School",
      student: "Amit Kumar",
      amount: 28500,
      reason: "Unauthorized transaction",
      status: "won",
      date: "2024-01-04",
    },
    {
      id: "CB-2024-0020",
      institute: "Delhi Public School",
      student: "Sneha Reddy",
      amount: 18000,
      reason: "Product not received",
      status: "lost",
      date: "2024-01-03",
    },
  ],
}

const statusConfig: Record<
  string,
  { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof AlertTriangle }
> = {
  pending_response: { label: "Pending Response", variant: "destructive", icon: Clock },
  under_review: { label: "Under Review", variant: "secondary", icon: AlertCircle },
  won: { label: "Won", variant: "default", icon: CheckCircle2 },
  lost: { label: "Lost", variant: "outline", icon: XCircle },
}

export function ChargebackSummary() {
  const winRate =
    chargebackStats.total > 0
      ? Math.round((chargebackStats.won / (chargebackStats.won + chargebackStats.lost)) * 100)
      : 0

  return (
    <Card className="bg-card border-border">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-destructive/10">
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </div>
          <CardTitle className="text-lg font-semibold">Chargebacks</CardTitle>
        </div>
        <Link href="/chargebacks">
          <Button variant="ghost" size="sm" className="gap-1 text-xs">
            View All <ArrowRight className="h-3 w-3" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <p className="text-xs text-muted-foreground">Total Active</p>
            <p className="text-xl font-bold text-foreground">{chargebackStats.total}</p>
            <p className="text-xs text-muted-foreground">Rs. {(chargebackStats.totalAmount / 100000).toFixed(2)} L</p>
          </div>
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <p className="text-xs text-muted-foreground">Win Rate</p>
            <p className="text-xl font-bold text-foreground">{winRate}%</p>
            <Progress value={winRate} className="mt-1 h-1.5" />
          </div>
        </div>

        {/* Status Breakdown */}
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center gap-1.5 rounded-full bg-destructive/10 px-2.5 py-1">
            <Clock className="h-3 w-3 text-destructive" />
            <span className="text-xs font-medium text-destructive">{chargebackStats.pendingResponse} Pending</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1">
            <AlertCircle className="h-3 w-3 text-muted-foreground" />
            <span className="text-xs font-medium text-muted-foreground">{chargebackStats.underReview} In Review</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-full bg-success/10 px-2.5 py-1">
            <CheckCircle2 className="h-3 w-3 text-success" />
            <span className="text-xs font-medium text-success">{chargebackStats.won} Won</span>
          </div>
        </div>

        {/* Urgent Deadlines */}
        {chargebackStats.responseDeadlines.length > 0 && (
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Response Deadlines</p>
            <div className="space-y-2">
              {chargebackStats.responseDeadlines.slice(0, 2).map((item) => (
                <div
                  key={item.id}
                  className={`flex items-center justify-between rounded-lg border p-2 ${
                    item.daysLeft <= 3 ? "border-destructive/50 bg-destructive/5" : "border-border bg-muted/30"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Clock
                      className={`h-3.5 w-3.5 ${item.daysLeft <= 3 ? "text-destructive" : "text-muted-foreground"}`}
                    />
                    <div>
                      <p className="text-xs font-medium text-foreground">{item.institute}</p>
                      <p className="text-xs text-muted-foreground">{item.id}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p
                      className={`text-xs font-semibold ${item.daysLeft <= 3 ? "text-destructive" : "text-foreground"}`}
                    >
                      {item.daysLeft} days left
                    </p>
                    <p className="text-xs text-muted-foreground">Rs. {item.amount.toLocaleString("en-IN")}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent Chargebacks */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Recent Chargebacks</p>
          <div className="space-y-2">
            {chargebackStats.recentChargebacks.slice(0, 3).map((chargeback) => {
              const config = statusConfig[chargeback.status]
              const StatusIcon = config.icon
              return (
                <div
                  key={chargeback.id}
                  className="flex items-center justify-between rounded-lg border border-border bg-muted/30 p-2"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <StatusIcon
                      className={`h-3.5 w-3.5 shrink-0 ${
                        chargeback.status === "pending_response"
                          ? "text-destructive"
                          : chargeback.status === "won"
                            ? "text-success"
                            : chargeback.status === "lost"
                              ? "text-muted-foreground"
                              : "text-muted-foreground"
                      }`}
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{chargeback.student}</p>
                      <p className="text-xs text-muted-foreground truncate">{chargeback.reason}</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0 ml-2">
                    <p className="text-xs font-semibold text-foreground">
                      Rs. {chargeback.amount.toLocaleString("en-IN")}
                    </p>
                    <Badge variant={config.variant} className="text-[10px] px-1.5 py-0">
                      {config.label}
                    </Badge>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
