"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { 
  Plus, 
  Search, 
  CheckCircle2,
  Clock,
  XCircle,
  Eye,
  MoreHorizontal,
  GitBranch,
  ArrowRight,
  Check,
  X,
  AlertTriangle,
  FileText,
  Receipt,
  Gift,
  IndianRupee,
  Users,
  RefreshCw,
  Settings,
  History,
  ChevronRight,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Workflow types that require approval
const workflowTypes = [
  { id: "fee_structure", name: "Fee Structure", icon: Receipt, color: "bg-blue-500" },
  { id: "scholarship", name: "Scholarship", icon: Gift, color: "bg-purple-500" },
  { id: "discount", name: "Discount", icon: IndianRupee, color: "bg-green-500" },
  { id: "refund", name: "Refund", icon: RefreshCw, color: "bg-orange-500" },
  { id: "fee_waiver", name: "Fee Waiver", icon: FileText, color: "bg-pink-500" },
  { id: "concession", name: "Concession", icon: Users, color: "bg-cyan-500" },
]

const pendingApprovals = [
  {
    id: "WF001",
    type: "fee_structure",
    title: "Class 11-12 Science Fee Structure",
    description: "New fee structure for academic year 2024-25",
    amount: 85000,
    submittedBy: { name: "Finance Team", avatar: "FT" },
    submittedAt: "2024-03-15 10:30 AM",
    currentStage: "checker",
    stages: [
      { name: "Maker", status: "completed", user: "Finance Team", date: "2024-03-15" },
      { name: "Checker", status: "pending", user: "Accounts Head", date: null },
      { name: "Approver", status: "pending", user: "Principal", date: null },
    ],
    details: {
      classes: ["11-Sci", "12-Sci"],
      feeHeads: [
        { name: "Tuition Fee", amount: 45000 },
        { name: "Lab Fee", amount: 15000 },
        { name: "Library Fee", amount: 5000 },
        { name: "Activity Fee", amount: 10000 },
        { name: "Exam Fee", amount: 10000 },
      ],
    },
    priority: "high",
  },
  {
    id: "WF002",
    type: "scholarship",
    title: "Merit Scholarship - Arjun Sharma",
    description: "20% scholarship for academic excellence",
    amount: 13000,
    submittedBy: { name: "Admin", avatar: "AD" },
    submittedAt: "2024-03-14 02:15 PM",
    currentStage: "approver",
    stages: [
      { name: "Maker", status: "completed", user: "Admin", date: "2024-03-14" },
      { name: "Checker", status: "completed", user: "Accounts Head", date: "2024-03-14" },
      { name: "Approver", status: "pending", user: "Principal", date: null },
    ],
    details: {
      studentName: "Arjun Sharma",
      studentId: "STU001",
      class: "10-A",
      percentage: "20%",
      reason: "Academic Excellence - 95% in previous exam",
    },
    priority: "medium",
  },
  {
    id: "WF003",
    type: "refund",
    title: "Refund Request - Priya Patel",
    description: "Transport fee refund for Q4 (relocated)",
    amount: 4000,
    submittedBy: { name: "Accounts", avatar: "AC" },
    submittedAt: "2024-03-16 09:00 AM",
    currentStage: "checker",
    stages: [
      { name: "Maker", status: "completed", user: "Accounts", date: "2024-03-16" },
      { name: "Checker", status: "pending", user: "Finance Head", date: null },
      { name: "Approver", status: "pending", user: "Director", date: null },
    ],
    details: {
      studentName: "Priya Patel",
      studentId: "STU002",
      class: "8-B",
      feeHead: "Transport Fee Q4",
      reason: "Family relocated - No longer using transport",
      bankAccount: "XXXX1234",
    },
    priority: "low",
  },
  {
    id: "WF004",
    type: "discount",
    title: "Sibling Discount - Kumar Family",
    description: "10% sibling discount for 2 students",
    amount: 11700,
    submittedBy: { name: "Admin", avatar: "AD" },
    submittedAt: "2024-03-15 11:45 AM",
    currentStage: "checker",
    stages: [
      { name: "Maker", status: "completed", user: "Admin", date: "2024-03-15" },
      { name: "Checker", status: "pending", user: "Accounts Head", date: null },
      { name: "Approver", status: "pending", user: "Principal", date: null },
    ],
    details: {
      students: [
        { name: "Rahul Kumar", class: "12-A", fee: 85000 },
        { name: "Riya Kumar", class: "8-B", fee: 52000 },
      ],
      discountType: "Sibling Discount",
      percentage: "10%",
    },
    priority: "medium",
  },
  {
    id: "WF005",
    type: "fee_waiver",
    title: "Fee Waiver - Sneha Reddy",
    description: "Complete tuition fee waiver - Financial hardship",
    amount: 65000,
    submittedBy: { name: "Counselor", avatar: "CO" },
    submittedAt: "2024-03-13 03:30 PM",
    currentStage: "approver",
    stages: [
      { name: "Maker", status: "completed", user: "Counselor", date: "2024-03-13" },
      { name: "Checker", status: "completed", user: "Principal", date: "2024-03-14" },
      { name: "Approver", status: "pending", user: "Managing Director", date: null },
    ],
    details: {
      studentName: "Sneha Reddy",
      studentId: "STU004",
      class: "9-C",
      waiverType: "Full",
      reason: "Financial hardship - Single parent family",
      documents: ["Income Certificate", "BPL Card"],
    },
    priority: "high",
  },
]

const approvalHistory = [
  {
    id: "WF100",
    type: "scholarship",
    title: "Sports Scholarship - Amit Verma",
    amount: 15000,
    action: "approved",
    actionBy: "Principal",
    actionAt: "2024-03-12",
  },
  {
    id: "WF099",
    type: "fee_structure",
    title: "Class 9-10 Fee Revision",
    amount: 65000,
    action: "approved",
    actionBy: "Principal",
    actionAt: "2024-03-10",
  },
  {
    id: "WF098",
    type: "refund",
    title: "Admission Fee Refund - Student Left",
    amount: 25000,
    action: "rejected",
    actionBy: "Director",
    actionAt: "2024-03-08",
  },
  {
    id: "WF097",
    type: "discount",
    title: "Staff Child Discount",
    amount: 45000,
    action: "approved",
    actionBy: "Principal",
    actionAt: "2024-03-05",
  },
]

const workflowConfigs = [
  {
    type: "fee_structure",
    name: "Fee Structure",
    levels: 3,
    stages: ["Maker", "Checker", "Approver"],
    roles: {
      maker: ["Finance Team", "Admin"],
      checker: ["Accounts Head"],
      approver: ["Principal", "Director"],
    },
    autoApproveBelow: null,
    requiresDocument: false,
  },
  {
    type: "scholarship",
    name: "Scholarship",
    levels: 3,
    stages: ["Maker", "Checker", "Approver"],
    roles: {
      maker: ["Admin", "Teacher"],
      checker: ["Accounts Head", "HOD"],
      approver: ["Principal"],
    },
    autoApproveBelow: 5000,
    requiresDocument: true,
  },
  {
    type: "discount",
    name: "Discount",
    levels: 2,
    stages: ["Maker", "Approver"],
    roles: {
      maker: ["Admin", "Accounts"],
      approver: ["Principal"],
    },
    autoApproveBelow: 2000,
    requiresDocument: false,
  },
  {
    type: "refund",
    name: "Refund",
    levels: 3,
    stages: ["Maker", "Checker", "Approver"],
    roles: {
      maker: ["Accounts"],
      checker: ["Finance Head"],
      approver: ["Director"],
    },
    autoApproveBelow: null,
    requiresDocument: true,
  },
  {
    type: "fee_waiver",
    name: "Fee Waiver",
    levels: 3,
    stages: ["Maker", "Checker", "Approver"],
    roles: {
      maker: ["Counselor", "Admin"],
      checker: ["Principal"],
      approver: ["Managing Director"],
    },
    autoApproveBelow: null,
    requiresDocument: true,
  },
  {
    type: "concession",
    name: "Concession",
    levels: 2,
    stages: ["Maker", "Approver"],
    roles: {
      maker: ["Admin"],
      approver: ["Principal"],
    },
    autoApproveBelow: 3000,
    requiresDocument: false,
  },
]

export function ApprovalsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")
  const [selectedApproval, setSelectedApproval] = useState<typeof pendingApprovals[0] | null>(null)
  const [isDetailOpen, setIsDetailOpen] = useState(false)
  const [isConfigOpen, setIsConfigOpen] = useState(false)
  const [rejectReason, setRejectReason] = useState("")
  const [showRejectDialog, setShowRejectDialog] = useState(false)

  const filteredApprovals = pendingApprovals.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || item.type === typeFilter
    return matchesSearch && matchesType
  })

  const stats = {
    pending: pendingApprovals.length,
    highPriority: pendingApprovals.filter(a => a.priority === "high").length,
    myApprovals: pendingApprovals.filter(a => a.currentStage === "approver").length,
    totalValue: pendingApprovals.reduce((sum, a) => sum + a.amount, 0),
  }

  const getTypeInfo = (type: string) => {
    return workflowTypes.find(t => t.id === type) || workflowTypes[0]
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">Workflow Approvals</h1>
          <p className="text-sm text-muted-foreground">
            Review and approve pending requests across all fee-related workflows
          </p>
        </div>
        <Dialog open={isConfigOpen} onOpenChange={setIsConfigOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">
              <Settings className="mr-2 h-4 w-4" />
              Configure Workflows
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Workflow Configuration</DialogTitle>
              <DialogDescription>
                Configure approval workflows for different fee-related actions
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {workflowConfigs.map((config) => {
                const typeInfo = getTypeInfo(config.type)
                const IconComponent = typeInfo.icon
                return (
                  <Card key={config.type}>
                    <CardContent className="pt-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <div className={`h-10 w-10 rounded-lg ${typeInfo.color} flex items-center justify-center`}>
                            <IconComponent className="h-5 w-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-medium">{config.name}</h4>
                            <div className="flex items-center gap-2 mt-2">
                              {config.stages.map((stage, i) => (
                                <div key={stage} className="flex items-center">
                                  <Badge variant="outline" className="text-xs">
                                    {stage}
                                  </Badge>
                                  {i < config.stages.length - 1 && (
                                    <ChevronRight className="h-4 w-4 text-muted-foreground mx-1" />
                                  )}
                                </div>
                              ))}
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                              {config.autoApproveBelow && (
                                <span>Auto-approve below ₹{config.autoApproveBelow.toLocaleString()}</span>
                              )}
                              {config.requiresDocument && (
                                <span className="flex items-center gap-1">
                                  <FileText className="h-3 w-3" />
                                  Documents required
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Approvals</p>
                <p className="text-2xl font-bold">{stats.pending}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Clock className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Priority</p>
                <p className="text-2xl font-bold">{stats.highPriority}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Awaiting My Action</p>
                <p className="text-2xl font-bold">{stats.myApprovals}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-orange-500/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-orange-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Value</p>
                <p className="text-2xl font-bold">₹{(stats.totalValue / 1000).toFixed(0)}K</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <IndianRupee className="h-5 w-5 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending" className="relative">
            Pending
            {stats.pending > 0 && (
              <span className="ml-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-xs text-destructive-foreground">
                {stats.pending}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <CardTitle>Pending Approvals</CardTitle>
                  <CardDescription>Review and take action on pending requests</CardDescription>
                </div>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search..."
                      className="pl-9 w-[200px]"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-[160px]">
                      <SelectValue placeholder="All Types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {workflowTypes.map((type) => (
                        <SelectItem key={type.id} value={type.id}>{type.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredApprovals.map((approval) => {
                  const typeInfo = getTypeInfo(approval.type)
                  const IconComponent = typeInfo.icon
                  return (
                    <Card key={approval.id} className="border">
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4">
                            <div className={`h-12 w-12 rounded-lg ${typeInfo.color} flex items-center justify-center flex-shrink-0`}>
                              <IconComponent className="h-6 w-6 text-white" />
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <h4 className="font-semibold">{approval.title}</h4>
                                {approval.priority === "high" && (
                                  <Badge variant="destructive" className="text-xs">High Priority</Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{approval.description}</p>
                              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Avatar className="h-4 w-4">
                                    <AvatarFallback className="text-[8px]">{approval.submittedBy.avatar}</AvatarFallback>
                                  </Avatar>
                                  {approval.submittedBy.name}
                                </span>
                                <span>{approval.submittedAt}</span>
                              </div>

                              {/* Workflow Stages */}
                              <div className="flex items-center gap-2 pt-2">
                                {approval.stages.map((stage, i) => (
                                  <div key={stage.name} className="flex items-center">
                                    <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${
                                      stage.status === "completed" 
                                        ? "bg-green-500/10 text-green-600" 
                                        : stage.status === "pending" && approval.currentStage === stage.name.toLowerCase()
                                          ? "bg-primary/10 text-primary ring-1 ring-primary"
                                          : "bg-muted text-muted-foreground"
                                    }`}>
                                      {stage.status === "completed" ? (
                                        <CheckCircle2 className="h-3 w-3" />
                                      ) : (
                                        <Clock className="h-3 w-3" />
                                      )}
                                      {stage.name}
                                    </div>
                                    {i < approval.stages.length - 1 && (
                                      <ArrowRight className="h-4 w-4 text-muted-foreground mx-1" />
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <span className="text-lg font-semibold">₹{approval.amount.toLocaleString()}</span>
                            <div className="flex items-center gap-2">
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => {
                                  setSelectedApproval(approval)
                                  setIsDetailOpen(true)
                                }}
                              >
                                <Eye className="mr-1 h-3 w-3" />
                                View
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="text-destructive hover:text-destructive"
                                onClick={() => {
                                  setSelectedApproval(approval)
                                  setShowRejectDialog(true)
                                }}
                              >
                                <X className="mr-1 h-3 w-3" />
                                Reject
                              </Button>
                              <Button size="sm">
                                <Check className="mr-1 h-3 w-3" />
                                Approve
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Approval History</CardTitle>
              <CardDescription>Past approval decisions</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Action By</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {approvalHistory.map((item) => {
                    const typeInfo = getTypeInfo(item.type)
                    const IconComponent = typeInfo.icon
                    return (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div className={`h-8 w-8 rounded ${typeInfo.color} flex items-center justify-center`}>
                            <IconComponent className="h-4 w-4 text-white" />
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{item.title}</TableCell>
                        <TableCell>₹{item.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          {item.action === "approved" ? (
                            <Badge className="bg-green-500/10 text-green-600 hover:bg-green-500/10">
                              <CheckCircle2 className="mr-1 h-3 w-3" />
                              Approved
                            </Badge>
                          ) : (
                            <Badge variant="destructive">
                              <XCircle className="mr-1 h-3 w-3" />
                              Rejected
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{item.actionBy}</TableCell>
                        <TableCell className="text-muted-foreground">{item.actionAt}</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Detail Dialog */}
      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Approval Details</DialogTitle>
          </DialogHeader>
          {selectedApproval && (
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className={`h-12 w-12 rounded-lg ${getTypeInfo(selectedApproval.type).color} flex items-center justify-center`}>
                  {(() => {
                    const IconComponent = getTypeInfo(selectedApproval.type).icon
                    return <IconComponent className="h-6 w-6 text-white" />
                  })()}
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{selectedApproval.title}</h3>
                  <p className="text-sm text-muted-foreground">{selectedApproval.description}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
                <div>
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p className="text-lg font-semibold">₹{selectedApproval.amount.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Submitted By</p>
                  <p className="font-medium">{selectedApproval.submittedBy.name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Submitted At</p>
                  <p className="font-medium">{selectedApproval.submittedAt}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Current Stage</p>
                  <Badge>{selectedApproval.currentStage.charAt(0).toUpperCase() + selectedApproval.currentStage.slice(1)}</Badge>
                </div>
              </div>

              {/* Workflow Timeline */}
              <div className="space-y-2">
                <h4 className="font-medium">Approval Workflow</h4>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  {selectedApproval.stages.map((stage, i) => (
                    <div key={stage.name} className="flex items-center">
                      <div className={`flex flex-col items-center ${
                        stage.status === "completed" 
                          ? "text-green-600" 
                          : stage.status === "pending" && selectedApproval.currentStage === stage.name.toLowerCase()
                            ? "text-primary"
                            : "text-muted-foreground"
                      }`}>
                        <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                          stage.status === "completed" 
                            ? "bg-green-500 text-white" 
                            : stage.status === "pending" && selectedApproval.currentStage === stage.name.toLowerCase()
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                        }`}>
                          {stage.status === "completed" ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : (
                            <span className="text-xs font-medium">{i + 1}</span>
                          )}
                        </div>
                        <span className="text-xs mt-1 font-medium">{stage.name}</span>
                        <span className="text-[10px]">{stage.user}</span>
                        {stage.date && <span className="text-[10px]">{stage.date}</span>}
                      </div>
                      {i < selectedApproval.stages.length - 1 && (
                        <div className={`flex-1 h-0.5 mx-4 ${
                          stage.status === "completed" ? "bg-green-500" : "bg-muted"
                        }`} />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Details Section */}
              <div className="space-y-2">
                <h4 className="font-medium">Details</h4>
                <div className="p-4 border rounded-lg space-y-2 text-sm">
                  {Object.entries(selectedApproval.details).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                      <span className="font-medium">
                        {Array.isArray(value) 
                          ? value.map((v: any) => typeof v === 'object' ? v.name : v).join(", ")
                          : typeof value === 'object' 
                            ? JSON.stringify(value)
                            : String(value)
                        }
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDetailOpen(false)}>
                  Close
                </Button>
                <Button 
                  variant="outline" 
                  className="text-destructive hover:text-destructive"
                  onClick={() => {
                    setIsDetailOpen(false)
                    setShowRejectDialog(true)
                  }}
                >
                  <X className="mr-2 h-4 w-4" />
                  Reject
                </Button>
                <Button>
                  <Check className="mr-2 h-4 w-4" />
                  Approve
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Request</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejection
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Rejection Reason</Label>
              <Textarea
                placeholder="Enter reason for rejection..."
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
              Cancel
            </Button>
            <Button variant="destructive" disabled={!rejectReason}>
              <X className="mr-2 h-4 w-4" />
              Confirm Rejection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
