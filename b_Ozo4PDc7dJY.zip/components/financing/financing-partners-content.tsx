"use client"

import { useState } from "react"
import {
  Building2,
  Plus,
  CheckCircle2,
  TrendingUp,
  Percent,
  Clock,
  IndianRupee,
  Users,
  Star,
  Shield,
  ExternalLink,
  Settings,
  Phone,
  Mail,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

const partners = [
  {
    id: "P1",
    name: "HDFC Credila",
    code: "HDFC",
    type: "NBFC",
    status: "Active",
    tier: "Premium",
    rateRange: { min: 10, max: 14 },
    maxTenure: 12,
    processingFee: 1.0,
    approvalTime: "48 hrs",
    approvalRate: 82,
    disbursed: 1810000,
    activeLoans: 32,
    applications: 48,
    rating: 4.7,
    contact: { email: "partners@hdfccredila.com", phone: "+91 22 6712 3456" },
    features: ["Instant approval", "No collateral", "Tax benefits", "Flexible tenure"],
    color: "hsl(var(--chart-1))",
  },
  {
    id: "P2",
    name: "Bajaj Finserv",
    code: "BF",
    type: "NBFC",
    status: "Active",
    tier: "Premium",
    rateRange: { min: 9, max: 12 },
    maxTenure: 18,
    processingFee: 1.5,
    approvalTime: "72 hrs",
    approvalRate: 75,
    disbursed: 1025000,
    activeLoans: 18,
    applications: 26,
    rating: 4.5,
    contact: { email: "education@bajajfinserv.in", phone: "+91 20 7120 8888" },
    features: ["Low interest", "Long tenure", "Pre-approved offers", "Zero prepayment"],
    color: "hsl(var(--chart-2))",
  },
  {
    id: "P3",
    name: "Propelld",
    code: "PP",
    type: "Fintech",
    status: "Active",
    tier: "Standard",
    rateRange: { min: 10, max: 13 },
    maxTenure: 24,
    processingFee: 0.5,
    approvalTime: "24 hrs",
    approvalRate: 88,
    disbursed: 770000,
    activeLoans: 14,
    applications: 17,
    rating: 4.6,
    contact: { email: "schools@propelld.com", phone: "+91 80 4567 1234" },
    features: ["Fastest approval", "100% digital", "K-12 focus", "Low processing fee"],
    color: "hsl(var(--chart-3))",
  },
  {
    id: "P4",
    name: "Eduvanz",
    code: "EV",
    type: "NBFC",
    status: "Active",
    tier: "Standard",
    rateRange: { min: 11, max: 15 },
    maxTenure: 12,
    processingFee: 1.0,
    approvalTime: "48 hrs",
    approvalRate: 70,
    disbursed: 515000,
    activeLoans: 9,
    applications: 14,
    rating: 4.2,
    contact: { email: "partners@eduvanz.com", phone: "+91 22 6123 7890" },
    features: ["Education focused", "Parent income based", "Co-applicant option"],
    color: "hsl(var(--chart-4))",
  },
  {
    id: "P5",
    name: "Auxilo",
    code: "AX",
    type: "NBFC",
    status: "Inactive",
    tier: "Standard",
    rateRange: { min: 11, max: 14 },
    maxTenure: 12,
    processingFee: 1.0,
    approvalTime: "72 hrs",
    approvalRate: 65,
    disbursed: 172000,
    activeLoans: 3,
    applications: 8,
    rating: 3.9,
    contact: { email: "info@auxilofinance.com", phone: "+91 11 4567 2345" },
    features: ["Flexible eligibility", "Custom EMI plans"],
    color: "hsl(var(--chart-5))",
  },
]

export function FinancingPartnersContent() {
  const [selected, setSelected] = useState<(typeof partners)[0] | null>(partners[0])

  const volumeData = partners.map((p) => ({
    name: p.code,
    disbursed: p.disbursed / 100000,
    color: p.color,
  }))

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Finance Partners</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Manage relationships with NBFCs and fintechs enabling fee financing.
            </p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Partner
          </Button>
        </div>

        {/* Summary */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <Building2 className="h-3.5 w-3.5 text-primary" />
                <p className="text-xs text-muted-foreground">Active Partners</p>
              </div>
              <p className="text-2xl font-semibold">{partners.filter((p) => p.status === "Active").length}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">of {partners.length} total</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <IndianRupee className="h-3.5 w-3.5 text-chart-2" />
                <p className="text-xs text-muted-foreground">Total Disbursed</p>
              </div>
              <p className="text-2xl font-semibold">
                ₹{(partners.reduce((s, p) => s + p.disbursed, 0) / 100000).toFixed(1)}L
              </p>
              <p className="text-[11px] text-muted-foreground mt-0.5">across all partners</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <Users className="h-3.5 w-3.5 text-chart-1" />
                <p className="text-xs text-muted-foreground">Active Loans</p>
              </div>
              <p className="text-2xl font-semibold">{partners.reduce((s, p) => s + p.activeLoans, 0)}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">borrowers financed</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <Percent className="h-3.5 w-3.5 text-chart-5" />
                <p className="text-xs text-muted-foreground">Avg. Approval Rate</p>
              </div>
              <p className="text-2xl font-semibold">
                {Math.round(partners.reduce((s, p) => s + p.approvalRate, 0) / partners.length)}%
              </p>
              <p className="text-[11px] text-muted-foreground mt-0.5">portfolio weighted</p>
            </CardContent>
          </Card>
        </div>

        {/* Disbursement by partner */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Disbursement Volume by Partner</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">
              Total loans disbursed (in ₹ Lakhs) — last 12 months
            </p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={volumeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" unit="L" />
                <Tooltip
                  contentStyle={{
                    background: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                  formatter={(value: number) => [`₹${value.toFixed(2)}L`, "Disbursed"]}
                />
                <Bar dataKey="disbursed" radius={[4, 4, 0, 0]}>
                  {volumeData.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Partners list */}
          <div className="lg:col-span-2 space-y-3">
            {partners.map((p) => (
              <Card
                key={p.id}
                className={`cursor-pointer transition-all ${
                  selected?.id === p.id ? "border-primary ring-1 ring-primary/20" : "hover:border-primary/40"
                }`}
                onClick={() => setSelected(p)}
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 min-w-0">
                      <div
                        className="h-12 w-12 rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0"
                        style={{ backgroundColor: `${p.color}20`, color: p.color }}
                      >
                        {p.code}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold text-sm">{p.name}</h3>
                          <Badge
                            variant="outline"
                            className={
                              p.status === "Active"
                                ? "bg-chart-2/10 text-chart-2 border-chart-2/20 text-[10px]"
                                : "bg-muted text-muted-foreground text-[10px]"
                            }
                          >
                            {p.status}
                          </Badge>
                          <Badge variant="outline" className="text-[10px]">
                            {p.type}
                          </Badge>
                          {p.tier === "Premium" && (
                            <Badge
                              variant="outline"
                              className="bg-chart-4/10 text-chart-4 border-chart-4/20 text-[10px]"
                            >
                              <Star className="h-2.5 w-2.5 mr-0.5 fill-current" />
                              Premium
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-1.5 text-[11px] text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Percent className="h-3 w-3" />
                            {p.rateRange.min}–{p.rateRange.max}% p.a.
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {p.approvalTime}
                          </span>
                          <span className="flex items-center gap-1">
                            <Star className="h-3 w-3 fill-chart-4 text-chart-4" />
                            {p.rating}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-sm font-semibold">₹{(p.disbursed / 100000).toFixed(2)}L</p>
                      <p className="text-[11px] text-muted-foreground">
                        {p.activeLoans} active loans
                      </p>
                    </div>
                  </div>

                  <Separator className="my-3" />

                  <div className="grid grid-cols-3 gap-3 text-xs">
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase">Approval Rate</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Progress value={p.approvalRate} className="h-1.5 flex-1" />
                        <span className="font-medium">{p.approvalRate}%</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase">Max Tenure</p>
                      <p className="font-medium mt-1">{p.maxTenure} months</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase">Processing Fee</p>
                      <p className="font-medium mt-1">{p.processingFee}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Selected partner detail */}
          {selected && (
            <Card className="lg:sticky lg:top-6 h-fit">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="h-10 w-10 rounded-lg flex items-center justify-center font-bold text-sm"
                      style={{ backgroundColor: `${selected.color}20`, color: selected.color }}
                    >
                      {selected.code}
                    </div>
                    <div>
                      <CardTitle className="text-base">{selected.name}</CardTitle>
                      <p className="text-[11px] text-muted-foreground">{selected.type} Partner</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Settings className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase mb-2">Performance</p>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2.5 rounded-md bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">Applications</p>
                      <p className="text-lg font-semibold">{selected.applications}</p>
                    </div>
                    <div className="p-2.5 rounded-md bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">Active</p>
                      <p className="text-lg font-semibold">{selected.activeLoans}</p>
                    </div>
                    <div className="p-2.5 rounded-md bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">Disbursed</p>
                      <p className="text-lg font-semibold">
                        ₹{(selected.disbursed / 100000).toFixed(1)}L
                      </p>
                    </div>
                    <div className="p-2.5 rounded-md bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">Avg. Loan</p>
                      <p className="text-lg font-semibold">
                        ₹{Math.round(selected.disbursed / selected.activeLoans / 1000)}K
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="text-[10px] text-muted-foreground uppercase mb-2">Key Features</p>
                  <div className="space-y-1.5">
                    {selected.features.map((f) => (
                      <div key={f} className="flex items-center gap-2 text-xs">
                        <CheckCircle2 className="h-3 w-3 text-chart-2 flex-shrink-0" />
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <p className="text-[10px] text-muted-foreground uppercase mb-2">Contact</p>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center gap-2">
                      <Mail className="h-3 w-3 text-muted-foreground" />
                      <span>{selected.contact.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-3 w-3 text-muted-foreground" />
                      <span>{selected.contact.phone}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Shield className="h-3.5 w-3.5 mr-1.5" />
                    Agreement
                  </Button>
                  <Button size="sm" className="flex-1">
                    <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                    Portal
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
