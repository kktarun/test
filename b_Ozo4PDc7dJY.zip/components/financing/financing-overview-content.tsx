"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Search,
  PiggyBank,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Download,
  Eye,
  TrendingUp,
  Calendar,
  MoreHorizontal,
  IndianRupee,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const financingStats = [
  { label: "Active Loans", value: "67", trend: "Total financed students", icon: PiggyBank, color: "text-primary" },
  { label: "Total Financed", value: "32.5L", trend: "This academic year", icon: TrendingUp, color: "text-green-600 dark:text-green-400" },
  { label: "EMI Due", value: "4.8L", trend: "This month", icon: Calendar, color: "text-orange-600 dark:text-orange-400" },
  { label: "Overdue EMIs", value: "8", trend: "Requires follow-up", icon: AlertTriangle, color: "text-red-600 dark:text-red-400" },
]

const financingRecords = [
  {
    id: "FIN001",
    studentId: "STU001",
    studentName: "Arjun Sharma",
    class: "10-A",
    loanAmount: 85000,
    totalEMIs: 10,
    paidEMIs: 6,
    emiAmount: 8500,
    nextDue: "2024-04-05",
    status: "active",
    partner: "Bajaj Finserv",
  },
  {
    id: "FIN002",
    studentId: "STU002",
    studentName: "Priya Patel",
    class: "9-B",
    loanAmount: 65000,
    totalEMIs: 12,
    paidEMIs: 12,
    emiAmount: 5417,
    nextDue: null,
    status: "completed",
    partner: "HDFC Credila",
  },
  {
    id: "FIN003",
    studentId: "STU003",
    studentName: "Rahul Verma",
    class: "8-C",
    loanAmount: 72000,
    totalEMIs: 8,
    paidEMIs: 2,
    emiAmount: 9000,
    nextDue: "2024-03-15",
    status: "overdue",
    partner: "Bajaj Finserv",
  },
  {
    id: "FIN004",
    studentId: "STU004",
    studentName: "Ananya Gupta",
    class: "10-A",
    loanAmount: 95000,
    totalEMIs: 10,
    paidEMIs: 4,
    emiAmount: 9500,
    nextDue: "2024-04-10",
    status: "active",
    partner: "Tata Capital",
  },
  {
    id: "FIN005",
    studentId: "STU005",
    studentName: "Vikram Singh",
    class: "7-A",
    loanAmount: 55000,
    totalEMIs: 6,
    paidEMIs: 1,
    emiAmount: 9167,
    nextDue: "2024-04-01",
    status: "active",
    partner: "HDFC Credila",
  },
]

export function FinancingOverviewContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [partnerFilter, setPartnerFilter] = useState("all")

  const filteredRecords = financingRecords.filter((record) => {
    const matchesSearch =
      record.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || record.status === statusFilter
    const matchesPartner = partnerFilter === "all" || record.partner === partnerFilter
    return matchesSearch && matchesStatus && matchesPartner
  })

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Fee Financing</h1>
          <p className="text-sm text-muted-foreground">
            Track students with fee financing and EMI-based payment plans
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Export Report
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {financingStats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.trend}</p>
                </div>
                <div className={`rounded-lg bg-muted p-2.5 ${stat.color}`}>
                  <stat.icon className="h-5 w-5" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Partner Summary */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium">Bajaj Finserv</span>
              <Badge variant="outline">28 students</Badge>
            </div>
            <p className="text-lg font-bold">{formatCurrency(1250000)}</p>
            <p className="text-xs text-muted-foreground">Total disbursed</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium">HDFC Credila</span>
              <Badge variant="outline">24 students</Badge>
            </div>
            <p className="text-lg font-bold">{formatCurrency(980000)}</p>
            <p className="text-xs text-muted-foreground">Total disbursed</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium">Tata Capital</span>
              <Badge variant="outline">15 students</Badge>
            </div>
            <p className="text-lg font-bold">{formatCurrency(720000)}</p>
            <p className="text-xs text-muted-foreground">Total disbursed</p>
          </CardContent>
        </Card>
      </div>

      {/* Financing Table */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base font-medium">Financing Records</CardTitle>
              <CardDescription>Students with active fee financing plans</CardDescription>
            </div>
            <div className="flex gap-2">
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search records..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
              <Select value={partnerFilter} onValueChange={setPartnerFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="Partner" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Partners</SelectItem>
                  <SelectItem value="Bajaj Finserv">Bajaj Finserv</SelectItem>
                  <SelectItem value="HDFC Credila">HDFC Credila</SelectItem>
                  <SelectItem value="Tata Capital">Tata Capital</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Finance Partner</TableHead>
                <TableHead>Loan Amount</TableHead>
                <TableHead>EMI Progress</TableHead>
                <TableHead>Monthly EMI</TableHead>
                <TableHead>Next Due</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRecords.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{record.studentName}</p>
                      <p className="text-xs text-muted-foreground">
                        {record.studentId} | Class {record.class}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-normal">
                      {record.partner}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-medium">{formatCurrency(record.loanAmount)}</TableCell>
                  <TableCell>
                    <div className="w-32 space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>{record.paidEMIs}/{record.totalEMIs}</span>
                        <span className="text-muted-foreground">
                          {Math.round((record.paidEMIs / record.totalEMIs) * 100)}%
                        </span>
                      </div>
                      <Progress value={(record.paidEMIs / record.totalEMIs) * 100} className="h-1.5" />
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{formatCurrency(record.emiAmount)}</TableCell>
                  <TableCell className={record.status === "overdue" ? "text-red-600 dark:text-red-400" : "text-muted-foreground"}>
                    {record.nextDue || "Completed"}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        record.status === "active"
                          ? "border-green-200 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-900/30 dark:text-green-400"
                          : record.status === "completed"
                          ? "border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
                          : "border-red-200 bg-red-50 text-red-700 dark:border-red-800 dark:bg-red-900/30 dark:text-red-400"
                      }
                    >
                      {record.status === "active" && <Clock className="mr-1 h-3 w-3" />}
                      {record.status === "completed" && <CheckCircle2 className="mr-1 h-3 w-3" />}
                      {record.status === "overdue" && <AlertTriangle className="mr-1 h-3 w-3" />}
                      {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="mr-2 h-4 w-4" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Calendar className="mr-2 h-4 w-4" />
                          EMI Schedule
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="mr-2 h-4 w-4" />
                          Download Statement
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
