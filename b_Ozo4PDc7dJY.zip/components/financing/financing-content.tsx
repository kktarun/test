"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { 
  Search, 
  Filter, 
  Download, 
  Plus, 
  CreditCard, 
  Building2, 
  Users, 
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  IndianRupee,
  Calendar,
  Eye,
  MoreHorizontal,
  FileText,
  Percent
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

// Mock data for financing applications
const financingApplications = [
  {
    id: "FIN001",
    studentName: "Aarav Sharma",
    studentId: "STU0001",
    class: "Class 10-A",
    parentName: "Rajesh Sharma",
    phone: "+91 98765 43210",
    totalFee: 91500,
    financingAmount: 91500,
    emiAmount: 15250,
    tenure: 6,
    interestRate: 12,
    processingFee: 915,
    partner: "HDFC Credila",
    status: "approved",
    appliedDate: "2024-03-15",
    approvedDate: "2024-03-18",
    disbursedDate: "2024-03-20",
    paidEmis: 2,
    nextEmiDate: "2024-05-20",
    nextEmiAmount: 15250,
  },
  {
    id: "FIN002",
    studentName: "Ananya Gupta",
    studentId: "STU0002",
    class: "Class 12-A",
    parentName: "Vikram Gupta",
    phone: "+91 98765 43211",
    totalFee: 112500,
    financingAmount: 112500,
    emiAmount: 9625,
    tenure: 12,
    interestRate: 10,
    processingFee: 1125,
    partner: "Bajaj Finserv",
    status: "pending",
    appliedDate: "2024-04-01",
    paidEmis: 0,
  },
  {
    id: "FIN003",
    studentName: "Rohan Mehta",
    studentId: "STU0003",
    class: "Class 11-B",
    parentName: "Sunil Mehta",
    phone: "+91 98765 43212",
    totalFee: 112500,
    financingAmount: 75000,
    emiAmount: 12917,
    tenure: 6,
    interestRate: 11,
    processingFee: 750,
    partner: "Eduvanz",
    status: "disbursed",
    appliedDate: "2024-02-20",
    approvedDate: "2024-02-23",
    disbursedDate: "2024-02-25",
    paidEmis: 3,
    nextEmiDate: "2024-05-25",
    nextEmiAmount: 12917,
  },
  {
    id: "FIN004",
    studentName: "Diya Choudhury",
    studentId: "STU0012",
    class: "Class 9-C",
    parentName: "Rajan Choudhury",
    phone: "+91 98765 43213",
    totalFee: 91500,
    financingAmount: 50000,
    emiAmount: 8611,
    tenure: 6,
    interestRate: 12,
    processingFee: 500,
    partner: "HDFC Credila",
    status: "rejected",
    appliedDate: "2024-03-25",
    rejectedDate: "2024-03-28",
    rejectionReason: "Incomplete documentation",
  },
  {
    id: "FIN005",
    studentName: "Krishna Iyer",
    studentId: "STU0009",
    class: "Class 10-B",
    parentName: "Subramaniam Iyer",
    phone: "+91 98765 43214",
    totalFee: 91500,
    financingAmount: 91500,
    emiAmount: 7875,
    tenure: 12,
    interestRate: 10.5,
    processingFee: 915,
    partner: "Propelld",
    status: "approved",
    appliedDate: "2024-04-05",
    approvedDate: "2024-04-08",
    paidEmis: 0,
    nextEmiDate: "2024-05-10",
    nextEmiAmount: 7875,
  },
]

// Finance partners
const financePartners = [
  { id: "P1", name: "HDFC Credila", logo: "HDFC", minRate: 10, maxRate: 14, maxTenure: 12, processingFee: 1 },
  { id: "P2", name: "Bajaj Finserv", logo: "BF", minRate: 9, maxRate: 12, maxTenure: 18, processingFee: 1.5 },
  { id: "P3", name: "Eduvanz", logo: "EV", minRate: 11, maxRate: 15, maxTenure: 12, processingFee: 1 },
  { id: "P4", name: "Propelld", logo: "PP", minRate: 10, maxRate: 13, maxTenure: 24, processingFee: 0.5 },
  { id: "P5", name: "Auxilo", logo: "AX", minRate: 11, maxRate: 14, maxTenure: 12, processingFee: 1 },
]

const getStatusBadge = (status: string) => {
  switch (status) {
    case "approved":
      return <Badge className="bg-blue-500/10 text-blue-600 border-blue-200">Approved</Badge>
    case "pending":
      return <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-200">Pending</Badge>
    case "disbursed":
      return <Badge className="bg-green-500/10 text-green-600 border-green-200">Disbursed</Badge>
    case "rejected":
      return <Badge className="bg-red-500/10 text-red-600 border-red-200">Rejected</Badge>
    default:
      return <Badge variant="outline">{status}</Badge>
  }
}

export function FinancingContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [partnerFilter, setPartnerFilter] = useState("all")
  const [selectedApplication, setSelectedApplication] = useState<typeof financingApplications[0] | null>(null)
  const [showNewApplicationModal, setShowNewApplicationModal] = useState(false)

  const stats = {
    totalApplications: financingApplications.length,
    pending: financingApplications.filter(a => a.status === "pending").length,
    approved: financingApplications.filter(a => a.status === "approved" || a.status === "disbursed").length,
    rejected: financingApplications.filter(a => a.status === "rejected").length,
    totalFinanced: financingApplications
      .filter(a => a.status === "approved" || a.status === "disbursed")
      .reduce((sum, a) => sum + a.financingAmount, 0),
    totalCollected: financingApplications
      .filter(a => a.status === "disbursed")
      .reduce((sum, a) => sum + (a.paidEmis || 0) * a.emiAmount, 0),
  }

  const filteredApplications = financingApplications.filter(app => {
    const matchesSearch = 
      app.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.parentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.id.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || app.status === statusFilter
    const matchesPartner = partnerFilter === "all" || app.partner === partnerFilter
    return matchesSearch && matchesStatus && matchesPartner
  })

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Fee Financing</h1>
          <p className="text-muted-foreground">Manage EMI plans and student fee financing</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button size="sm" className="gap-2" onClick={() => setShowNewApplicationModal(true)}>
            <Plus className="h-4 w-4" />
            New Application
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalApplications}</div>
            <p className="text-xs text-muted-foreground">
              {stats.pending} pending review
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.approved}</div>
            <p className="text-xs text-muted-foreground">
              {((stats.approved / stats.totalApplications) * 100).toFixed(0)}% approval rate
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Financed</CardTitle>
            <IndianRupee className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(stats.totalFinanced / 100000).toFixed(1)}L
            </div>
            <p className="text-xs text-muted-foreground">
              Across {stats.approved} students
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">EMIs Collected</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(stats.totalCollected / 100000).toFixed(2)}L
            </div>
            <p className="text-xs text-muted-foreground">
              From active financing
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="applications" className="space-y-4">
        <TabsList>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="partners">Finance Partners</TabsTrigger>
          <TabsTrigger value="emi-tracker">EMI Tracker</TabsTrigger>
        </TabsList>

        <TabsContent value="applications" className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by student, parent, or application ID..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="disbursed">Disbursed</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Select value={partnerFilter} onValueChange={setPartnerFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Partner" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Partners</SelectItem>
                {financePartners.map(p => (
                  <SelectItem key={p.id} value={p.name}>{p.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Applications Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Application ID</TableHead>
                    <TableHead>Student</TableHead>
                    <TableHead>Finance Amount</TableHead>
                    <TableHead>EMI</TableHead>
                    <TableHead>Partner</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Applied Date</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredApplications.map((app) => (
                    <TableRow key={app.id} className="cursor-pointer hover:bg-muted/50" onClick={() => setSelectedApplication(app)}>
                      <TableCell className="font-medium">{app.id}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{app.studentName}</div>
                          <div className="text-sm text-muted-foreground">{app.class}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">
                          {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(app.financingAmount)}
                        </div>
                        <div className="text-sm text-muted-foreground">{app.tenure} months</div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">
                          {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(app.emiAmount)}
                        </div>
                        <div className="text-sm text-muted-foreground">{app.interestRate}% p.a.</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{app.partner}</Badge>
                      </TableCell>
                      <TableCell>{getStatusBadge(app.status)}</TableCell>
                      <TableCell className="text-muted-foreground">{app.appliedDate}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setSelectedApplication(app)}>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Download className="mr-2 h-4 w-4" />
                              Download Agreement
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="partners" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {financePartners.map((partner) => (
              <Card key={partner.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 font-bold text-primary">
                        {partner.logo}
                      </div>
                      <div>
                        <CardTitle className="text-base">{partner.name}</CardTitle>
                        <CardDescription>Education Finance</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline" className="bg-green-500/10 text-green-600">Active</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Interest Rate</p>
                      <p className="font-medium">{partner.minRate}% - {partner.maxRate}% p.a.</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Max Tenure</p>
                      <p className="font-medium">{partner.maxTenure} months</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Processing Fee</p>
                      <p className="font-medium">{partner.processingFee}%</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Applications</p>
                      <p className="font-medium">{financingApplications.filter(a => a.partner === partner.name).length}</p>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full" size="sm">
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="emi-tracker" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming EMIs</CardTitle>
              <CardDescription>Track EMI payments due this month</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>EMI Amount</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>EMI #</TableHead>
                    <TableHead>Partner</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {financingApplications
                    .filter(a => a.status === "disbursed" || a.status === "approved")
                    .filter(a => a.nextEmiDate)
                    .map((app) => (
                      <TableRow key={app.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{app.studentName}</div>
                            <div className="text-sm text-muted-foreground">{app.class}</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">
                          {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(app.nextEmiAmount || 0)}
                        </TableCell>
                        <TableCell>{app.nextEmiDate}</TableCell>
                        <TableCell>
                          {(app.paidEmis || 0) + 1} of {app.tenure}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{app.partner}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-200">
                            Due
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Application Detail Modal */}
      <Dialog open={!!selectedApplication} onOpenChange={() => setSelectedApplication(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Financing Application Details</DialogTitle>
            <DialogDescription>Application ID: {selectedApplication?.id}</DialogDescription>
          </DialogHeader>
          {selectedApplication && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-lg">{selectedApplication.studentName}</h3>
                  <p className="text-muted-foreground">{selectedApplication.class} | {selectedApplication.studentId}</p>
                </div>
                {getStatusBadge(selectedApplication.status)}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Finance Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Total Fee</span>
                      <span className="font-medium">
                        {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(selectedApplication.totalFee)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Financed Amount</span>
                      <span className="font-medium">
                        {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(selectedApplication.financingAmount)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">EMI Amount</span>
                      <span className="font-medium">
                        {new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(selectedApplication.emiAmount)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Interest Rate</span>
                      <span className="font-medium">{selectedApplication.interestRate}% p.a.</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Tenure</span>
                      <span className="font-medium">{selectedApplication.tenure} months</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Payment Progress</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {selectedApplication.status === "disbursed" || selectedApplication.status === "approved" ? (
                      <>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">EMIs Paid</span>
                          <span className="font-medium">{selectedApplication.paidEmis || 0} of {selectedApplication.tenure}</span>
                        </div>
                        <Progress value={((selectedApplication.paidEmis || 0) / selectedApplication.tenure) * 100} className="h-2" />
                        {selectedApplication.nextEmiDate && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            Next EMI: {selectedApplication.nextEmiDate}
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="text-sm text-muted-foreground">
                        {selectedApplication.status === "pending" && "Awaiting approval"}
                        {selectedApplication.status === "rejected" && (
                          <div className="text-red-600">
                            Rejected: {selectedApplication.rejectionReason}
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Parent Name</p>
                    <p className="font-medium">{selectedApplication.parentName}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Phone</p>
                    <p className="font-medium">{selectedApplication.phone}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Finance Partner</p>
                    <p className="font-medium">{selectedApplication.partner}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Applied Date</p>
                    <p className="font-medium">{selectedApplication.appliedDate}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedApplication(null)}>
              Close
            </Button>
            {selectedApplication?.status === "pending" && (
              <>
                <Button variant="destructive">Reject</Button>
                <Button>Approve</Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Application Modal */}
      <Dialog open={showNewApplicationModal} onOpenChange={setShowNewApplicationModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New Financing Application</DialogTitle>
            <DialogDescription>Create a new fee financing application for a student</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Student</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select student" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="STU0001">Aarav Sharma - Class 10-A</SelectItem>
                  <SelectItem value="STU0002">Ananya Gupta - Class 12-A</SelectItem>
                  <SelectItem value="STU0003">Rohan Mehta - Class 11-B</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Finance Partner</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select partner" />
                </SelectTrigger>
                <SelectContent>
                  {financePartners.map(p => (
                    <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Amount to Finance</Label>
                <Input type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label>Tenure (months)</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 months</SelectItem>
                    <SelectItem value="6">6 months</SelectItem>
                    <SelectItem value="9">9 months</SelectItem>
                    <SelectItem value="12">12 months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewApplicationModal(false)}>
              Cancel
            </Button>
            <Button>Create Application</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
