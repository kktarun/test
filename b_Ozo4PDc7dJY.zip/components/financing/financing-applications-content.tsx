"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  Download,
  Plus,
  Eye,
  CheckCircle2,
  Clock,
  XCircle,
  TrendingUp,
  FileCheck,
  AlertCircle,
  IndianRupee,
  CreditCard,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"

const applications = [
  {
    id: "FIN-2026-045",
    studentName: "Aarav Sharma",
    studentId: "STU0001",
    class: "Class 10-A",
    parentName: "Rajesh Sharma",
    parentPhone: "+91 98765 43210",
    totalFee: 91500,
    amount: 91500,
    emi: 15250,
    tenure: 6,
    rate: 12,
    processingFee: 915,
    partner: "HDFC Credila",
    status: "Active",
    appliedOn: "2026-01-10",
    approvedOn: "2026-01-12",
    disbursedOn: "2026-01-14",
    paidEmis: 2,
    nextEmi: "2026-02-14",
    creditScore: 780,
  },
  {
    id: "FIN-2026-044",
    studentName: "Krishna Iyer",
    studentId: "STU0009",
    class: "Class 10-B",
    parentName: "Subramaniam Iyer",
    parentPhone: "+91 98765 43214",
    totalFee: 91500,
    amount: 91500,
    emi: 7875,
    tenure: 12,
    rate: 10.5,
    processingFee: 915,
    partner: "Propelld",
    status: "Active",
    appliedOn: "2026-01-08",
    approvedOn: "2026-01-10",
    disbursedOn: "2026-01-12",
    paidEmis: 1,
    nextEmi: "2026-02-12",
    creditScore: 745,
  },
  {
    id: "FIN-2026-043",
    studentName: "Ananya Gupta",
    studentId: "STU0002",
    class: "Class 12-A",
    parentName: "Vikram Gupta",
    parentPhone: "+91 98765 43211",
    totalFee: 112500,
    amount: 112500,
    emi: 9625,
    tenure: 12,
    rate: 10,
    processingFee: 1125,
    partner: "Bajaj Finserv",
    status: "Under Review",
    appliedOn: "2026-01-15",
    paidEmis: 0,
    creditScore: 710,
  },
  {
    id: "FIN-2026-042",
    studentName: "Rohan Mehta",
    studentId: "STU0003",
    class: "Class 11-B",
    parentName: "Sunil Mehta",
    parentPhone: "+91 98765 43212",
    totalFee: 112500,
    amount: 75000,
    emi: 12917,
    tenure: 6,
    rate: 11,
    processingFee: 750,
    partner: "Eduvanz",
    status: "Active",
    appliedOn: "2026-01-05",
    approvedOn: "2026-01-07",
    disbursedOn: "2026-01-09",
    paidEmis: 3,
    nextEmi: "2026-02-09",
    creditScore: 760,
  },
  {
    id: "FIN-2026-041",
    studentName: "Diya Choudhury",
    studentId: "STU0012",
    class: "Class 9-C",
    parentName: "Rajan Choudhury",
    parentPhone: "+91 98765 43213",
    totalFee: 91500,
    amount: 50000,
    emi: 8611,
    tenure: 6,
    rate: 12,
    processingFee: 500,
    partner: "HDFC Credila",
    status: "Rejected",
    appliedOn: "2026-01-03",
    rejectedOn: "2026-01-05",
    rejectionReason: "Credit score below threshold (650 required)",
    creditScore: 620,
  },
  {
    id: "FIN-2026-040",
    studentName: "Ishaan Kapoor",
    studentId: "STU0015",
    class: "Class 12-Sci",
    parentName: "Manoj Kapoor",
    parentPhone: "+91 98765 43215",
    totalFee: 125000,
    amount: 125000,
    emi: 11200,
    tenure: 12,
    rate: 10.5,
    processingFee: 1250,
    partner: "HDFC Credila",
    status: "Active",
    appliedOn: "2026-01-02",
    approvedOn: "2026-01-04",
    disbursedOn: "2026-01-06",
    paidEmis: 1,
    nextEmi: "2026-02-06",
    creditScore: 800,
  },
  {
    id: "FIN-2026-039",
    studentName: "Meera Iyer",
    studentId: "STU0018",
    class: "Class 8-A",
    parentName: "Anand Iyer",
    parentPhone: "+91 98765 43216",
    totalFee: 78000,
    amount: 78000,
    emi: 13500,
    tenure: 6,
    rate: 11.5,
    processingFee: 780,
    partner: "Propelld",
    status: "Defaulted",
    appliedOn: "2025-09-15",
    approvedOn: "2025-09-17",
    disbursedOn: "2025-09-19",
    paidEmis: 2,
    nextEmi: "2025-12-19",
    daysOverdue: 34,
    creditScore: 680,
  },
]

export function FinancingApplicationsContent() {
  const [search, setSearch] = useState("")
  const [tab, setTab] = useState("all")
  const [status, setStatus] = useState("all")
  const [partner, setPartner] = useState("all")
  const [selected, setSelected] = useState<(typeof applications)[0] | null>(null)

  const filtered = applications.filter((a) => {
    const matchesSearch =
      a.studentName.toLowerCase().includes(search.toLowerCase()) ||
      a.id.toLowerCase().includes(search.toLowerCase()) ||
      a.parentName.toLowerCase().includes(search.toLowerCase())
    const matchesStatus = status === "all" || a.status === status
    const matchesPartner = partner === "all" || a.partner === partner
    const matchesTab =
      tab === "all" ||
      (tab === "active" && a.status === "Active") ||
      (tab === "review" && a.status === "Under Review") ||
      (tab === "rejected" && a.status === "Rejected") ||
      (tab === "defaulted" && a.status === "Defaulted")
    return matchesSearch && matchesStatus && matchesPartner && matchesTab
  })

  const getStatusBadge = (s: string) => {
    const styles: Record<string, string> = {
      Active: "bg-chart-2/10 text-chart-2 border-chart-2/20",
      "Under Review": "bg-chart-1/10 text-chart-1 border-chart-1/20",
      Rejected: "bg-destructive/10 text-destructive border-destructive/20",
      Defaulted: "bg-chart-5/10 text-chart-5 border-chart-5/20",
    }
    return styles[s] || "bg-muted text-muted-foreground"
  }

  const stats = {
    total: applications.length,
    active: applications.filter((a) => a.status === "Active").length,
    review: applications.filter((a) => a.status === "Under Review").length,
    defaulted: applications.filter((a) => a.status === "Defaulted").length,
    disbursed: applications
      .filter((a) => a.status === "Active" || a.status === "Defaulted")
      .reduce((s, a) => s + a.amount, 0),
  }

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Financing Applications</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Review, approve, and track student fee financing applications.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Application
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">Total</p>
              <p className="text-xl font-semibold">{stats.total}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle2 className="h-3.5 w-3.5 text-chart-2" />
                <p className="text-xs text-muted-foreground">Active</p>
              </div>
              <p className="text-xl font-semibold text-chart-2">{stats.active}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <Clock className="h-3.5 w-3.5 text-chart-1" />
                <p className="text-xs text-muted-foreground">Under Review</p>
              </div>
              <p className="text-xl font-semibold text-chart-1">{stats.review}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <AlertCircle className="h-3.5 w-3.5 text-chart-5" />
                <p className="text-xs text-muted-foreground">Defaulted</p>
              </div>
              <p className="text-xl font-semibold text-chart-5">{stats.defaulted}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <IndianRupee className="h-3.5 w-3.5 text-primary" />
                <p className="text-xs text-muted-foreground">Total Disbursed</p>
              </div>
              <p className="text-xl font-semibold">₹{(stats.disbursed / 100000).toFixed(2)}L</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4 space-y-4">
            <Tabs value={tab} onValueChange={setTab}>
              <TabsList>
                <TabsTrigger value="all">All ({applications.length})</TabsTrigger>
                <TabsTrigger value="active">Active ({stats.active})</TabsTrigger>
                <TabsTrigger value="review">Under Review ({stats.review})</TabsTrigger>
                <TabsTrigger value="defaulted">Defaulted ({stats.defaulted})</TabsTrigger>
                <TabsTrigger value="rejected">
                  Rejected ({applications.filter((a) => a.status === "Rejected").length})
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by student, parent, or application ID..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={partner} onValueChange={setPartner}>
                <SelectTrigger className="w-full sm:w-44">
                  <SelectValue placeholder="Partner" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Partners</SelectItem>
                  <SelectItem value="HDFC Credila">HDFC Credila</SelectItem>
                  <SelectItem value="Bajaj Finserv">Bajaj Finserv</SelectItem>
                  <SelectItem value="Propelld">Propelld</SelectItem>
                  <SelectItem value="Eduvanz">Eduvanz</SelectItem>
                  <SelectItem value="Auxilo">Auxilo</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                More
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Applications Table */}
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full">
              <thead className="bg-secondary/50">
                <tr className="border-b border-border">
                  <th className="p-3 text-left text-[11px] font-medium uppercase text-muted-foreground">
                    Application
                  </th>
                  <th className="p-3 text-left text-[11px] font-medium uppercase text-muted-foreground">
                    Student / Parent
                  </th>
                  <th className="p-3 text-left text-[11px] font-medium uppercase text-muted-foreground">
                    Amount
                  </th>
                  <th className="p-3 text-left text-[11px] font-medium uppercase text-muted-foreground">
                    EMI / Tenure
                  </th>
                  <th className="p-3 text-left text-[11px] font-medium uppercase text-muted-foreground">
                    Partner
                  </th>
                  <th className="p-3 text-left text-[11px] font-medium uppercase text-muted-foreground">
                    Progress
                  </th>
                  <th className="p-3 text-left text-[11px] font-medium uppercase text-muted-foreground">
                    Status
                  </th>
                  <th className="p-3 text-right text-[11px] font-medium uppercase text-muted-foreground">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((app) => (
                  <tr
                    key={app.id}
                    className="border-b border-border hover:bg-secondary/30 transition-colors"
                  >
                    <td className="p-3">
                      <p className="text-sm font-medium font-mono">{app.id}</p>
                      <p className="text-[11px] text-muted-foreground">
                        Applied {new Date(app.appliedOn).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })}
                      </p>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="text-[10px]">
                            {app.studentName.split(" ").map((n) => n[0]).join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{app.studentName}</p>
                          <p className="text-[11px] text-muted-foreground">
                            {app.class} • {app.parentName}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3">
                      <p className="text-sm font-semibold">₹{app.amount.toLocaleString("en-IN")}</p>
                      <p className="text-[11px] text-muted-foreground">
                        of ₹{app.totalFee.toLocaleString("en-IN")}
                      </p>
                    </td>
                    <td className="p-3">
                      <p className="text-sm">₹{app.emi.toLocaleString("en-IN")}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {app.tenure} months @ {app.rate}%
                      </p>
                    </td>
                    <td className="p-3">
                      <Badge variant="outline" className="text-[10px]">
                        {app.partner}
                      </Badge>
                    </td>
                    <td className="p-3">
                      {app.status === "Active" || app.status === "Defaulted" ? (
                        <div className="w-32">
                          <div className="flex items-center justify-between text-[10px] mb-1">
                            <span className="text-muted-foreground">
                              {app.paidEmis}/{app.tenure} EMIs
                            </span>
                            <span className="font-medium">
                              {Math.round(((app.paidEmis || 0) / app.tenure) * 100)}%
                            </span>
                          </div>
                          <Progress value={((app.paidEmis || 0) / app.tenure) * 100} className="h-1" />
                        </div>
                      ) : (
                        <span className="text-[11px] text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="p-3">
                      <Badge variant="outline" className={`${getStatusBadge(app.status)} text-[10px]`}>
                        {app.status}
                      </Badge>
                    </td>
                    <td className="p-3 text-right">
                      <Button variant="ghost" size="sm" onClick={() => setSelected(app)}>
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <span>{selected.id}</span>
                  <Badge variant="outline" className={getStatusBadge(selected.status)}>
                    {selected.status}
                  </Badge>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-5">
                <div>
                  <p className="text-xs text-muted-foreground uppercase mb-2">Student & Parent</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">STUDENT</p>
                      <p className="text-sm font-medium">{selected.studentName}</p>
                      <p className="text-[11px] text-muted-foreground">{selected.class} • {selected.studentId}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">PARENT / GUARDIAN</p>
                      <p className="text-sm font-medium">{selected.parentName}</p>
                      <p className="text-[11px] text-muted-foreground">{selected.parentPhone}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-muted-foreground uppercase mb-2">Loan Details</p>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
                      <p className="text-[10px] text-muted-foreground">LOAN AMOUNT</p>
                      <p className="text-lg font-semibold">₹{selected.amount.toLocaleString("en-IN")}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">EMI</p>
                      <p className="text-lg font-semibold">₹{selected.emi.toLocaleString("en-IN")}</p>
                      <p className="text-[10px] text-muted-foreground">{selected.tenure} months</p>
                    </div>
                    <div className="p-3 rounded-lg bg-secondary/30">
                      <p className="text-[10px] text-muted-foreground">INTEREST RATE</p>
                      <p className="text-lg font-semibold">{selected.rate}%</p>
                      <p className="text-[10px] text-muted-foreground">per annum</p>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">Partner</p>
                    <p className="font-medium">{selected.partner}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Credit Score</p>
                    <p className="font-medium">
                      {selected.creditScore}{" "}
                      <span
                        className={`text-[10px] ${
                          selected.creditScore >= 750
                            ? "text-chart-2"
                            : selected.creditScore >= 700
                            ? "text-chart-1"
                            : "text-chart-5"
                        }`}
                      >
                        ({selected.creditScore >= 750 ? "Excellent" : selected.creditScore >= 700 ? "Good" : "Average"})
                      </span>
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Processing Fee</p>
                    <p className="font-medium">₹{selected.processingFee.toLocaleString("en-IN")}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Applied On</p>
                    <p className="font-medium">
                      {new Date(selected.appliedOn).toLocaleDateString("en-IN", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })}
                    </p>
                  </div>
                </div>

                {selected.status === "Active" && (
                  <div className="p-4 rounded-lg bg-chart-2/5 border border-chart-2/20">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm font-medium">Repayment Progress</p>
                      <Badge variant="outline" className="bg-chart-2/10 text-chart-2 border-chart-2/20">
                        On Track
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-muted-foreground">
                        {selected.paidEmis} of {selected.tenure} EMIs paid
                      </span>
                      <span className="font-medium">
                        {Math.round(((selected.paidEmis || 0) / selected.tenure) * 100)}%
                      </span>
                    </div>
                    <Progress value={((selected.paidEmis || 0) / selected.tenure) * 100} className="h-2" />
                    <p className="text-[11px] text-muted-foreground mt-2">
                      Next EMI due on{" "}
                      {new Date(selected.nextEmi!).toLocaleDateString("en-IN", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })}
                    </p>
                  </div>
                )}

                {selected.status === "Defaulted" && (
                  <div className="p-4 rounded-lg bg-destructive/5 border border-destructive/20">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-destructive flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-destructive">
                          Payment Overdue — {selected.daysOverdue} days
                        </p>
                        <p className="text-[11px] text-muted-foreground mt-1">
                          Account has been flagged for collection. Partner notified.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {selected.status === "Rejected" && selected.rejectionReason && (
                  <div className="p-4 rounded-lg bg-destructive/5 border border-destructive/20">
                    <div className="flex items-start gap-2">
                      <XCircle className="h-4 w-4 text-destructive flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-destructive">Application Rejected</p>
                        <p className="text-[11px] text-muted-foreground mt-1">{selected.rejectionReason}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setSelected(null)}>
                  Close
                </Button>
                {selected.status === "Active" && (
                  <Button>
                    <Download className="h-4 w-4 mr-2" />
                    Download Agreement
                  </Button>
                )}
                {selected.status === "Under Review" && (
                  <>
                    <Button variant="outline" className="text-destructive">
                      <XCircle className="h-4 w-4 mr-2" />
                      Reject
                    </Button>
                    <Button>
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      Approve
                    </Button>
                  </>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
