import { DashboardLayout } from "@/components/dashboard-layout"
import { NotificationsContent } from "@/components/notifications/notifications-content"

export default function NotificationsPage() {
  return (
    <DashboardLayout>
      <NotificationsContent />
    </DashboardLayout>
  )
}
