import { DashboardLayout } from "@/components/dashboard-layout"
import { FeeStructureContent } from "@/components/fees/fee-structure-content"

export default function FeeStructurePage() {
  return (
    <DashboardLayout>
      <FeeStructureContent />
    </DashboardLayout>
  )
}
