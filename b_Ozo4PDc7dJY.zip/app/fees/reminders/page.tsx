import { DashboardLayout } from "@/components/dashboard-layout"
import { RemindersContent } from "@/components/fees/reminders-content"

export default function RemindersPage() {
  return (
    <DashboardLayout>
      <RemindersContent />
    </DashboardLayout>
  )
}
