import { DashboardLayout } from "@/components/dashboard-layout"
import { ScholarshipsContent } from "@/components/fees/scholarships-content"

export default function ScholarshipsPage() {
  return (
    <DashboardLayout>
      <ScholarshipsContent />
    </DashboardLayout>
  )
}
