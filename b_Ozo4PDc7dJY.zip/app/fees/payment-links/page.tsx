import { DashboardLayout } from "@/components/dashboard-layout"
import { PaymentLinksContent } from "@/components/fees/payment-links-content"

export default function PaymentLinksPage() {
  return (
    <DashboardLayout>
      <PaymentLinksContent />
    </DashboardLayout>
  )
}
