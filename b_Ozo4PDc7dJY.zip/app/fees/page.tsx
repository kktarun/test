import { DashboardLayout } from "@/components/dashboard-layout"
import { FeesDashboard } from "@/components/fees/fees-dashboard"

export default function FeesPage() {
  return (
    <DashboardLayout>
      <FeesDashboard />
    </DashboardLayout>
  )
}
