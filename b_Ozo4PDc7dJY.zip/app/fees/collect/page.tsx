import { DashboardLayout } from "@/components/dashboard-layout"
import { CollectFee } from "@/components/fees/collect-fee"

export default function CollectFeePage() {
  return (
    <DashboardLayout>
      <CollectFee />
    </DashboardLayout>
  )
}
