import { DashboardLayout } from "@/components/dashboard-layout"
import { TransportSlabsContent } from "@/components/fees/transport-slabs-content"

export default function TransportSlabsPage() {
  return (
    <DashboardLayout>
      <TransportSlabsContent />
    </DashboardLayout>
  )
}
