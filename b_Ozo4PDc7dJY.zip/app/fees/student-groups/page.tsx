import { DashboardLayout } from "@/components/dashboard-layout"
import { StudentGroupsContent } from "@/components/fees/student-groups-content"

export default function StudentGroupsPage() {
  return (
    <DashboardLayout>
      <StudentGroupsContent />
    </DashboardLayout>
  )
}
