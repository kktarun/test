import { DashboardLayout } from "@/components/dashboard-layout"
import { StudentsContent } from "@/components/fees/students-content"

export default function StudentsPage() {
  return (
    <DashboardLayout>
      <StudentsContent />
    </DashboardLayout>
  )
}
