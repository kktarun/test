import { DashboardLayout } from "@/components/dashboard-layout"
import { PreviousDuesContent } from "@/components/fees/previous-dues-content"

export default function PreviousDuesPage() {
  return (
    <DashboardLayout>
      <PreviousDuesContent />
    </DashboardLayout>
  )
}
