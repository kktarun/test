import { DashboardLayout } from "@/components/dashboard-layout"
import { FeeHeadsContent } from "@/components/fees/fee-heads-content"

export default function FeeHeadsPage() {
  return (
    <DashboardLayout>
      <FeeHeadsContent />
    </DashboardLayout>
  )
}
