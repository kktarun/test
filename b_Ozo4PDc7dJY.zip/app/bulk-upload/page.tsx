import { DashboardLayout } from "@/components/dashboard-layout"
import { BulkUploadContent } from "@/components/bulk-upload/bulk-upload-content"

export default function BulkUploadPage() {
  return (
    <DashboardLayout>
      <BulkUploadContent />
    </DashboardLayout>
  )
}
