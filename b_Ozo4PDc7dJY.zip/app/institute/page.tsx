import { DashboardLayout } from "@/components/dashboard-layout"
import { InstituteInfoContent } from "@/components/institute/institute-info-content"

export default function InstituteInfoPage() {
  return (
    <DashboardLayout>
      <InstituteInfoContent />
    </DashboardLayout>
  )
}
