import { DashboardLayout } from "@/components/dashboard-layout"
import { ReconciliationContent } from "@/components/reconciliation/reconciliation-content"

export default function ReconciliationPage() {
  return (
    <DashboardLayout>
      <ReconciliationContent />
    </DashboardLayout>
  )
}
