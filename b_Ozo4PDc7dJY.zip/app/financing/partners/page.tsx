import { DashboardLayout } from "@/components/dashboard-layout"
import { FinancingPartnersContent } from "@/components/financing/financing-partners-content"

export default function FinancingPartnersPage() {
  return (
    <DashboardLayout>
      <FinancingPartnersContent />
    </DashboardLayout>
  )
}
