import { DashboardLayout } from "@/components/dashboard-layout"
import { FinancingOverviewContent } from "@/components/financing/financing-overview-content"

export default function FinancingPage() {
  return (
    <DashboardLayout>
      <FinancingOverviewContent />
    </DashboardLayout>
  )
}
