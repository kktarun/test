import { DashboardLayout } from "@/components/dashboard-layout"
import { FinancingApplicationsContent } from "@/components/financing/financing-applications-content"

export default function FinancingApplicationsPage() {
  return (
    <DashboardLayout>
      <FinancingApplicationsContent />
    </DashboardLayout>
  )
}
