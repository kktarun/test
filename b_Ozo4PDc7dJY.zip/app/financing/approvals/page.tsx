import { DashboardLayout } from "@/components/dashboard-layout"
import { ApprovalsContent } from "@/components/financing/approvals-content"

export default function ApprovalsPage() {
  return (
    <DashboardLayout>
      <ApprovalsContent />
    </DashboardLayout>
  )
}
