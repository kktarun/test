import { DashboardLayout } from "@/components/dashboard-layout"
import { CommunicationOverviewContent } from "@/components/communication/communication-overview-content"

export default function CommunicationPage() {
  return (
    <DashboardLayout>
      <CommunicationOverviewContent />
    </DashboardLayout>
  )
}
