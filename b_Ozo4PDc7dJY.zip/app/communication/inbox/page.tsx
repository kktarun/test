import { DashboardLayout } from "@/components/dashboard-layout"
import { InboxContent } from "@/components/communication/inbox-content"

export default function InboxPage() {
  return (
    <DashboardLayout>
      <InboxContent />
    </DashboardLayout>
  )
}
