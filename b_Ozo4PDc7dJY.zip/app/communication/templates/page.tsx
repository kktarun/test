import { DashboardLayout } from "@/components/dashboard-layout"
import { TemplatesContent } from "@/components/communication/templates-content"

export default function TemplatesPage() {
  return (
    <DashboardLayout>
      <TemplatesContent />
    </DashboardLayout>
  )
}
