import { DashboardLayout } from "@/components/dashboard-layout"
import { CampaignsContent } from "@/components/communication/campaigns-content"

export default function CampaignsPage() {
  return (
    <DashboardLayout>
      <CampaignsContent />
    </DashboardLayout>
  )
}
