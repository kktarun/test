import { DashboardLayout } from "@/components/dashboard-layout"
import { NewTicketContent } from "@/components/support/new-ticket-content"

export default function NewTicketPage() {
  return (
    <DashboardLayout>
      <NewTicketContent />
    </DashboardLayout>
  )
}
