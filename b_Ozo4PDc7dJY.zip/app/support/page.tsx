import { DashboardLayout } from "@/components/dashboard-layout"
import { SupportContent } from "@/components/support/support-content"

export default function SupportPage() {
  return (
    <DashboardLayout>
      <SupportContent />
    </DashboardLayout>
  )
}
