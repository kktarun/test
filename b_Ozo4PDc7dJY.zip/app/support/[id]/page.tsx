import { DashboardLayout } from "@/components/dashboard-layout"
import { TicketDetailContent } from "@/components/support/ticket-detail-content"

export default async function TicketDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return (
    <DashboardLayout>
      <TicketDetailContent ticketId={id} />
    </DashboardLayout>
  )
}
