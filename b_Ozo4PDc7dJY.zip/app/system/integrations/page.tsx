import { DashboardLayout } from "@/components/dashboard-layout"
import { IntegrationsContent } from "@/components/system/integrations-content"

export default function IntegrationsPage() {
  return (
    <DashboardLayout>
      <IntegrationsContent />
    </DashboardLayout>
  )
}
