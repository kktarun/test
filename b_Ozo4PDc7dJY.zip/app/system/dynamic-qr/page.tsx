import { DashboardLayout } from "@/components/dashboard-layout"
import { DynamicQRContent } from "@/components/system/dynamic-qr-content"

export default function DynamicQRPage() {
  return (
    <DashboardLayout>
      <DynamicQRContent />
    </DashboardLayout>
  )
}
