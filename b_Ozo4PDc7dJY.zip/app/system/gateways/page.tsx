import { DashboardLayout } from "@/components/dashboard-layout"
import { GatewaysContent } from "@/components/system/gateways-content"

export default function GatewaysPage() {
  return (
    <DashboardLayout>
      <GatewaysContent />
    </DashboardLayout>
  )
}
