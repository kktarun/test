import { DashboardLayout } from "@/components/dashboard-layout"
import { BankAccountsContent } from "@/components/system/bank-accounts-content"

export default function BankAccountsPage() {
  return (
    <DashboardLayout>
      <BankAccountsContent />
    </DashboardLayout>
  )
}
