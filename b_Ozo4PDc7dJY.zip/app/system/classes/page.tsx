import { DashboardLayout } from "@/components/dashboard-layout"
import { ClassesContent } from "@/components/system/classes-content"

export default function ClassesPage() {
  return (
    <DashboardLayout>
      <ClassesContent />
    </DashboardLayout>
  )
}
