import { DashboardLayout } from "@/components/dashboard-layout"
import { CashFlowContent } from "@/components/treasury/cash-flow-content"

export default function CashFlowPage() {
  return (
    <DashboardLayout>
      <CashFlowContent />
    </DashboardLayout>
  )
}
