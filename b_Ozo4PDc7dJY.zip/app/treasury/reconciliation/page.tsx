import { DashboardLayout } from "@/components/dashboard-layout"
import { TreasuryReconciliationContent } from "@/components/treasury/treasury-reconciliation-content"

export default function TreasuryReconciliationPage() {
  return (
    <DashboardLayout>
      <TreasuryReconciliationContent />
    </DashboardLayout>
  )
}
