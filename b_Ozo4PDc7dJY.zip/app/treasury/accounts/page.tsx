import { DashboardLayout } from "@/components/dashboard-layout"
import { TreasuryAccountsContent } from "@/components/treasury/treasury-accounts-content"

export default function TreasuryAccountsPage() {
  return (
    <DashboardLayout>
      <TreasuryAccountsContent />
    </DashboardLayout>
  )
}
