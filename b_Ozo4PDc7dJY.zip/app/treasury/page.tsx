import { DashboardLayout } from "@/components/dashboard-layout"
import { TreasuryOverviewContent } from "@/components/treasury/treasury-overview-content"

export default function TreasuryPage() {
  return (
    <DashboardLayout>
      <TreasuryOverviewContent />
    </DashboardLayout>
  )
}
