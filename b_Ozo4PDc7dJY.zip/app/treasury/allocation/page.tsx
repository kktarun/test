import { DashboardLayout } from "@/components/dashboard-layout"
import { AllocationRulesContent } from "@/components/treasury/allocation-rules-content"

export default function AllocationPage() {
  return (
    <DashboardLayout>
      <AllocationRulesContent />
    </DashboardLayout>
  )
}
