import { DashboardLayout } from "@/components/dashboard-layout"
import { ComplianceContent } from "@/components/payroll/compliance-content"

export default function CompliancePage() {
  return (
    <DashboardLayout>
      <ComplianceContent />
    </DashboardLayout>
  )
}
