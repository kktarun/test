import { DashboardLayout } from "@/components/dashboard-layout"
import { EmployeesContent } from "@/components/payroll/employees-content"

export default function EmployeesPage() {
  return (
    <DashboardLayout>
      <EmployeesContent />
    </DashboardLayout>
  )
}
