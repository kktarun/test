import { DashboardLayout } from "@/components/dashboard-layout"
import { PayrollRunsContent } from "@/components/payroll/payroll-runs-content"

export default function PayrollRunsPage() {
  return (
    <DashboardLayout>
      <PayrollRunsContent />
    </DashboardLayout>
  )
}
