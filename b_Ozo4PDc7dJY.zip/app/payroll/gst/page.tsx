import { DashboardLayout } from "@/components/dashboard-layout"
import { GstContent } from "@/components/payroll/gst-content"

export default function GstPage() {
  return (
    <DashboardLayout>
      <GstContent />
    </DashboardLayout>
  )
}
