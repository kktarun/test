import { DashboardLayout } from "@/components/dashboard-layout"
import { PayrollOverviewContent } from "@/components/payroll/payroll-overview-content"

export default function PayrollPage() {
  return (
    <DashboardLayout>
      <PayrollOverviewContent />
    </DashboardLayout>
  )
}
