// Unified Shared Data Module for Merchant Dashboard
// Single Institute View - Delhi Public School
// Based on actual transaction CSV data structure

// ============================================
// TYPE DEFINITIONS
// ============================================

export type TransactionStatus = "success" | "pending" | "failed" | "refunded" | "user_dropped"
export type RefundStatus = "completed" | "pending" | "initiated" | "failed" | "rejected"
export type ChargebackStatus = "open" | "under_review" | "response_submitted" | "won" | "lost" | "expired"
export type SettlementStatus = "settled" | "pending" | "processing" | "failed"
export type SplitStatus = "settled" | "pending" | "processing" | "failed"
export type MdrBearing = "merchant" | "surcharge" | "parent"
export type FeeFrequency = "annual" | "quarterly" | "monthly" | "one_time"
export type FeeCategory = "academic" | "transport" | "hostel" | "misc"
export type StudentFeeStatus = "pending" | "partial" | "paid" | "overdue"
export type PaymentLinkStatus = "active" | "paid" | "expired" | "cancelled"
export type MandateStatus = "pending" | "active" | "paused" | "cancelled" | "expired"

export interface Student {
  id: string
  name: string
  email: string
  phone: string
  class: string
  division: string
  rollNumber: string
  enrollmentNumber: string
}

export interface Institute {
  id: string
  name: string
  code: string
}

export interface PaymentInstrument {
  type: string
  details: string
  cardBrand?: string
  cardType?: string
  cardIssuer?: string
  cardIssuingBank?: string
  psp?: string
  upiId?: string
  walletName?: string
  bankName?: string
}

export interface FinancingDetails {
  category: string
  type: string
  tenure?: number
  amount?: number
  costBearing?: string
  partialCostSharing?: string
  nbfcPartner?: string
  collectionType?: string
  charges?: {
    totalCharges: number
    parentChargePercentage: number
    parentCharge: number
    instituteChargePercentage: number
    instituteCharge: number
    bankChargePercentage: number
    bankCharge: number
    subventionAmount?: number
  }
}

export interface SplitBeneficiary {
  beneficiary: string
  account: string
  ifsc: string
  amount: number
  percentage: number
  status: SplitStatus
}

export interface SplitPaymentInstallment {
  splitNumber: number
  amount: number
  dueDate: string
  paidDate?: string
  paidTime?: string
  status: "completed" | "pending" | "failed" | "overdue"
  paymentMode?: string
  mdrPercentage?: number
  mdrAmount?: number
  erpCommissionPercentage?: number
  erpCommission?: number
  netAmount?: number
  gatewayTransactionId?: string
  transactionId?: string
}

export interface RefundDetails {
  refundId: string
  refundStatus: RefundStatus
  refundDate: string
  refundArn?: string
  refundReason: string
  originalOrderAmount: number
  pgChargesDeducted: number
  erpCommissionDeducted: number
  netRefundToParent: number
}

export interface ChargebackDetails {
  chargebackId: string
  chargebackStatus: ChargebackStatus
  chargebackDate: string
  chargebackAmount: number
  chargebackReason: string
  disputeDeadline: string
  evidenceSubmitted: boolean
  responseSubmittedAt?: string
  arbNumber?: string
  chargebackFee: number
}

export interface TransactionLifecycleEvent {
  event: string
  timestamp: string
  description: string
  status: "success" | "warning" | "error"
  metadata?: Record<string, string>
}

export interface CustomFields {
  fatherName?: string
  motherName?: string
  session?: string
  admissionNumber?: string
  [key: string]: string | undefined
}

// ============================================
// FEE COLLECTION TYPES
// ============================================

export interface FeeHead {
  id: string
  code: string
  name: string
  description?: string
  category: FeeCategory
  amount: number
  frequency: FeeFrequency
  dueDay?: number
  dueMonth?: number
  lateFeeEnabled: boolean
  lateFeeType?: "percentage" | "fixed"
  lateFeeValue?: number
  gracePeriodDays: number
  lateFeeMaxAmount?: number
  paymentMode: "online" | "offline" | "both"
  allowPartialPayment: boolean
  minPartialAmount?: number
  paymentPriority: number
  gstApplicable: boolean
  gstPercentage?: number
  hsnCode?: string
  isActive: boolean
}

export interface FeeStructure {
  id: string
  name: string
  description?: string
  academicYear: string
  status: "draft" | "pending_approval" | "active" | "archived"
  classes: string[]
  feeHeads: {
    feeHeadId: string
    feeHead: FeeHead
    amountOverride?: number
    dueDateOverride?: string
    isMandatory: boolean
  }[]
  totalAmount: number
  createdAt: string
  createdBy: string
}

export interface StudentWithFees extends Student {
  admissionNumber: string
  admissionDate: string
  status: "active" | "inactive" | "transferred" | "alumni"
  siblingGroupId?: string
  fatherName: string
  motherName: string
  guardianPhone: string
  guardianEmail: string
  address: string
  feeStructureId: string
  totalFee: number
  discountAmount: number
  netFee: number
  paidAmount: number
  pendingAmount: number
  feeStatus: StudentFeeStatus
  lastPaymentDate?: string
  nextDueDate?: string
  feeHeadStatus: {
    feeHeadId: string
    feeHeadName: string
    amount: number
    paidAmount: number
    pendingAmount: number
    dueDate: string
    status: StudentFeeStatus
  }[]
}

export interface PaymentLink {
  id: string
  linkCode: string
  shortUrl: string
  studentId: string
  student: Student
  amount: number
  feeHeads: { feeHeadId: string; name: string; amount: number }[]
  expiresAt: string
  sentVia: { sms: boolean; whatsapp: boolean; email: boolean }
  sentAt?: string
  viewCount: number
  lastViewedAt?: string
  status: PaymentLinkStatus
  paidAt?: string
  transactionId?: string
  createdBy: string
  createdAt: string
}

export interface PaymentLinkBatch {
  id: string
  name: string
  filters: { classes?: string[]; groups?: string[]; dueStatus?: string }
  totalStudents: number
  totalAmount: number
  sentCount: number
  deliveredCount: number
  paidCount: number
  collectedAmount: number
  channels: { sms: boolean; whatsapp: boolean; email: boolean }
  status: "processing" | "completed" | "failed"
  createdBy: string
  createdAt: string
}

export interface Mandate {
  id: string
  studentId: string
  student: Student
  umrn: string
  mandateType: "nach" | "upi_autopay" | "emandate"
  bankAccountNumber: string
  bankIfsc: string
  bankName: string
  accountHolderName: string
  maxAmount: number
  frequency: "monthly" | "quarterly" | "as_presented"
  validFrom: string
  validTo: string
  status: MandateStatus
  registeredAt?: string
  lastDebitDate?: string
  lastDebitAmount?: number
  schedules: MandateSchedule[]
}

export interface MandateSchedule {
  id: string
  mandateId: string
  installmentNumber: number
  scheduledDate: string
  amount: number
  status: "scheduled" | "presented" | "success" | "failed" | "skipped"
  presentedAt?: string
  transactionId?: string
  failureReason?: string
  retryCount: number
  nextRetryDate?: string
}

export interface Scholarship {
  id: string
  name: string
  description?: string
  type: "merit" | "need_based" | "sports" | "staff" | "sibling" | "other"
  discountType: "percentage" | "fixed"
  discountValue: number
  maxDiscount?: number
  eligibilityCriteria?: string
  documentRequirements?: string[]
  validFrom?: string
  validTo?: string
  requiresApproval: boolean
  isActive: boolean
}

export interface ScholarshipApplication {
  id: string
  scholarshipId: string
  scholarship: Scholarship
  studentId: string
  student: Student
  academicYear: string
  appliedAmount: number
  approvedAmount?: number
  status: "pending" | "approved" | "rejected"
  approvalStage?: "pending_checker" | "pending_approver" | "completed"
  documents?: string[]
  remarks?: string
  appliedBy: string
  appliedAt: string
  approvedBy?: string
  approvedAt?: string
}

export interface Transaction {
  id: string
  orderId: string
  edvironOrderId: string
  gatewayTransactionId: string
  bankReferenceNumber: string
  status: TransactionStatus
  statusReason: string
  orderAmount: number
  transactionAmount: number
  vendorAmount: number
  gateway: string
  paymentMode: string
  channel: string
  date: string
  time: string
  student: Student
  institute: Institute
  feeType: string
  mdrAmount: number
  mdrPercentage: number
  mdrBearing: MdrBearing
  erpCommission: number
  erpCommissionPercentage: number
  instrument: PaymentInstrument
  isSettled: boolean
  settlementId?: string
  settlementUtr?: string
  settlementDate?: string
  isSplitPayment: boolean
  isInternational: boolean
  internationalMethod?: string
  currency: string
  originalAmount?: number
  exchangeRate?: number
  captureApiUsed: boolean
  captureStatus?: string
  authorizedAt?: string
  capturedAt?: string
  financing?: FinancingDetails
  autopayDetails?: {
    mandateId: string
    mandateType: string
    mandateStatus: string
    maxAmount: number
    frequency: string
    validUntil: string
  }
  schoolCounterDetails?: {
    mode: string
    receiptNumber: string
    collectedBy: string
    collectionDate: string
  }
  bankTransferDetails?: {
    type: string
    bankName: string
    utrNumber: string
    branchName: string
  }
  splitPayTimeline?: SplitPaymentInstallment[]
  splitPayModes?: { mode: string; amount: number; status: string; [key: string]: unknown }[]
  refundDetails?: RefundDetails
  chargebackDetails?: ChargebackDetails
  transactionLifecycle?: TransactionLifecycleEvent[]
  splitDetails?: SplitBeneficiary[]
  customFields?: CustomFields
}

export interface Settlement {
  id: string
  settlementDate: string
  processedDate?: string
  gateway: string
  utr: string
  transactionCount: number
  totalAmount: number
  pgCharges: number
  erpCommission: number
  netAmount: number
  adjustments: {
    refunds: number
    chargebacks: number
    recoveries: number
  }
  finalAmount: number
  status: SettlementStatus
  institute: Institute
  transactionIds: string[]
  refundIds: string[]
  chargebackIds: string[]
  merchantSettlement: {
    amount: number
    utr: string
    transactions: string[]
  }
  vendorSettlements: {
    vendorName: string
    amount: number
    utr: string
    transactions: string[]
  }[]
}

export interface Refund {
  id: string
  transactionId: string
  orderId: string
  institute: string
  studentName: string
  studentId: string
  orderAmount: number
  refundAmount: number
  gateway: string
  paymentMode: string
  accountType: "merchant" | "vendor"
  vendorName?: string
  status: RefundStatus
  reason: string
  refundArn?: string
  requestedBy: string
  requestedAt: string
  processedAt?: string
  pgChargesDeducted: number
  erpCommissionDeducted: number
  netRefundToParent: number
  deductedFromSettlement?: {
    id: string
    date: string
    amount: number
  }
  isSplitRefund?: boolean
}

export interface Chargeback {
  id: string
  transactionId: string
  orderId: string
  institute: string
  studentName: string
  studentId: string
  amount: number
  gateway: string
  paymentMode: string
  reason: string
  reasonCode?: string
  status: ChargebackStatus
  raisedBy: string
  raisedDate: string
  dueDate: string
  closedDate?: string
  evidenceSubmitted: boolean
  responseSubmittedAt?: string
  arbNumber?: string
  chargebackFee: number
  originalSettlement?: {
    id: string
    date: string
  }
  deductedFromSettlement?: {
    id: string
    date: string
    amount: number
  }
  recoveryInfo?: {
    creditedToSettlement: string
    creditedDate: string
    amount: number
  }
}

export interface SplitPayment {
  id: string
  transactionId: string
  orderId: string
  institute: Institute
  student: Student
  totalAmount: number
  gateway: string
  paymentMode: string
  date: string
  status: TransactionStatus
  splits: SplitBeneficiary[]
  vendorSplits: {
    vendorName: string
    amount: number
    percentage: number
    status: SplitStatus
    settlementId?: string
    settlementUtr?: string
    settlementDate?: string
  }[]
  merchantSplit: {
    amount: number
    percentage: number
    status: SplitStatus
    settlementId?: string
    settlementUtr?: string
    settlementDate?: string
  }
}

// ============================================
// MERCHANT INFO - Delhi Public School
// ============================================

export const merchantInstitute: Institute = {
  id: "INST-DPS-NOI",
  name: "Delhi Public School",
  code: "DPS-NOI"
}

// ============================================
// SAMPLE DATA - Single Institute Transactions
// ============================================

export const unifiedTransactions: Transaction[] = [
  // Transaction 1 - Successful UPI Payment
  {
    id: "TXNDPS001A7B8C9",
    orderId: "ORDDPS2024001",
    edvironOrderId: "EDVDPS001ABC",
    gatewayTransactionId: "RPY001A7B8C9D0E1",
    bankReferenceNumber: "825202024001",
    status: "success",
    statusReason: "Payment successful",
    orderAmount: 45000,
    transactionAmount: 45000,
    vendorAmount: 43650,
    gateway: "Razorpay",
    paymentMode: "UPI",
    channel: "Mobile App",
    date: "2026-04-15",
    time: "09:15:22",
    student: {
      id: "STUDPS001",
      name: "Aarav Sharma",
      email: "aarav.sharma@gmail.com",
      phone: "+919876543210",
      class: "10th",
      division: "A",
      rollNumber: "12",
      enrollmentNumber: "DPS2024001"
    },
    institute: merchantInstitute,
    feeType: "Tuition Fee",
    mdrAmount: 900,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 450,
    erpCommissionPercentage: 1,
    instrument: {
      type: "UPI",
      details: "aarav.sharma@oksbi",
      psp: "Google Pay",
      upiId: "aarav.sharma@oksbi"
    },
    isSettled: true,
    settlementId: "STLDPS001",
    settlementUtr: "494482582887001",
    settlementDate: "2026-04-16",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-15 09:15:22", description: "Payment order created for ₹45000", status: "success", metadata: { gateway: "Razorpay", paymentMode: "UPI" } },
      { event: "Payment Initiated", timestamp: "2026-04-15 09:15:45", description: "Payment initiated via UPI", status: "success" },
      { event: "Payment Authorized", timestamp: "2026-04-15 09:16:12", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "825202024001" } },
      { event: "Payment Captured", timestamp: "2026-04-15 09:16:30", description: "Payment captured successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Rajesh Sharma",
      motherName: "Priya Sharma",
      session: "2024-25",
      admissionNumber: "ADM001234"
    }
  },
  // Transaction 2 - Credit Card Payment with Refund
  {
    id: "TXNDPS002B8C9D0",
    orderId: "ORDDPS2024002",
    edvironOrderId: "EDVDPS002BCD",
    gatewayTransactionId: "PPE002B8C9D0E1F2",
    bankReferenceNumber: "825202024002",
    status: "refunded",
    statusReason: "Fee waived by institute",
    orderAmount: 35000,
    transactionAmount: 35000,
    vendorAmount: 33775,
    gateway: "PhonePe PG",
    paymentMode: "Credit Card",
    channel: "Online",
    date: "2026-04-16",
    time: "14:30:45",
    student: {
      id: "STUDPS002",
      name: "Ananya Gupta",
      email: "ananya.gupta@gmail.com",
      phone: "+919876543211",
      class: "8th",
      division: "B",
      rollNumber: "25",
      enrollmentNumber: "DPS2024002"
    },
    institute: merchantInstitute,
    feeType: "Lab Fee",
    mdrAmount: 875,
    mdrPercentage: 2.5,
    mdrBearing: "merchant",
    erpCommission: 350,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Card",
      details: "Visa ending 4532",
      cardBrand: "Visa",
      cardType: "Credit",
      cardIssuer: "HDFC Bank",
      cardIssuingBank: "HDFC Bank"
    },
    isSettled: true,
    settlementId: "STLDPS001",
    settlementUtr: "494482582887001",
    settlementDate: "2026-04-17",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    refundDetails: {
      refundId: "RFDDPS001",
      refundStatus: "completed",
      refundDate: "2026-04-12",
      refundArn: "71935653191669001",
      refundReason: "Fee waived due to scholarship",
      originalOrderAmount: 35000,
      pgChargesDeducted: 875,
      erpCommissionDeducted: 350,
      netRefundToParent: 33775
    },
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-16 14:30:45", description: "Payment order created for ₹35000", status: "success", metadata: { gateway: "PhonePe PG", paymentMode: "Credit Card" } },
      { event: "Payment Initiated", timestamp: "2026-04-16 14:31:10", description: "Payment initiated via Credit Card", status: "success" },
      { event: "Payment Authorized", timestamp: "2026-04-16 14:32:05", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "825202024002" } },
      { event: "Payment Captured", timestamp: "2026-04-16 14:32:25", description: "Payment captured successfully", status: "success" },
      { event: "Refund Initiated", timestamp: "2026-04-12 10:00:00", description: "Refund initiated for ₹33775", status: "warning" },
      { event: "Refund Completed", timestamp: "2026-04-12 14:30:00", description: "Refund processed successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Vikram Gupta",
      motherName: "Sunita Gupta",
      session: "2024-25",
      admissionNumber: "ADM001235"
    }
  },
  // Transaction 3 - EMI Payment
  {
    id: "TXNDPS003C9D0E1",
    orderId: "ORDDPS2024003",
    edvironOrderId: "EDVDPS003CDE",
    gatewayTransactionId: "CFE003C9D0E1F2G3",
    bankReferenceNumber: "825202024003",
    status: "success",
    statusReason: "EMI payment successful",
    orderAmount: 85000,
    transactionAmount: 87125,
    vendorAmount: 83300,
    gateway: "Cashfree",
    paymentMode: "Card EMI",
    channel: "Mobile App",
    date: "2026-04-17",
    time: "11:45:30",
    student: {
      id: "STUDPS003",
      name: "Rohan Mehta",
      email: "rohan.mehta@gmail.com",
      phone: "+919876543212",
      class: "12th",
      division: "A",
      rollNumber: "08",
      enrollmentNumber: "DPS2024003"
    },
    institute: merchantInstitute,
    feeType: "Annual Fee",
    mdrAmount: 1700,
    mdrPercentage: 2,
    mdrBearing: "surcharge",
    erpCommission: 850,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Card EMI",
      details: "HDFC EMI ending 8901",
      cardBrand: "Mastercard",
      cardType: "Credit",
      cardIssuer: "HDFC Bank",
      cardIssuingBank: "HDFC Bank"
    },
    isSettled: true,
    settlementId: "STLDPS002",
    settlementUtr: "494482582887002",
    settlementDate: "2026-04-18",
    isSplitPayment: true,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    financing: {
      category: "card_emi",
      type: "low_cost_emi",
      tenure: 6,
      amount: 14521,
      costBearing: "parent",
      charges: {
        totalCharges: 2125,
        parentChargePercentage: 40,
        parentCharge: 850,
        instituteChargePercentage: 30,
        instituteCharge: 638,
        bankChargePercentage: 30,
        bankCharge: 637
      }
    },
    splitDetails: [
      { beneficiary: "Delhi Public School - Main Account", account: "85434700051492", ifsc: "HDFC0001234", amount: 59500, percentage: 70, status: "settled" },
      { beneficiary: "Delhi Public School - Trust Fund", account: "85434700051493", ifsc: "HDFC0001234", amount: 23800, percentage: 30, status: "settled" }
    ],
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-17 11:45:30", description: "Payment order created for ₹85000", status: "success", metadata: { gateway: "Cashfree", paymentMode: "Card EMI" } },
      { event: "EMI Selection", timestamp: "2026-04-17 11:46:00", description: "6 month EMI selected", status: "success" },
      { event: "Payment Initiated", timestamp: "2026-04-17 11:46:30", description: "Payment initiated via Card EMI", status: "success" },
      { event: "Payment Authorized", timestamp: "2026-04-17 11:47:45", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "825202024003" } },
      { event: "Payment Captured", timestamp: "2026-04-17 11:48:10", description: "Payment captured successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Suresh Mehta",
      motherName: "Kavita Mehta",
      session: "2024-25",
      admissionNumber: "ADM001236"
    }
  },
  // Transaction 4 - Pending Payment
  {
    id: "TXNDPS004D0E1F2",
    orderId: "ORDDPS2024004",
    edvironOrderId: "EDVDPS004DEF",
    gatewayTransactionId: "RPY004D0E1F2G3H4",
    bankReferenceNumber: "",
    status: "pending",
    statusReason: "Payment processing",
    orderAmount: 28000,
    transactionAmount: 28560,
    vendorAmount: 27160,
    gateway: "Razorpay",
    paymentMode: "Net Banking",
    channel: "Online",
    date: "2026-04-18",
    time: "16:20:15",
    student: {
      id: "STUDPS004",
      name: "Ishaan Patel",
      email: "ishaan.patel@gmail.com",
      phone: "+919876543213",
      class: "9th",
      division: "C",
      rollNumber: "18",
      enrollmentNumber: "DPS2024004"
    },
    institute: merchantInstitute,
    feeType: "Transport Fee",
    mdrAmount: 560,
    mdrPercentage: 2,
    mdrBearing: "surcharge",
    erpCommission: 280,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Net Banking",
      details: "SBI Net Banking",
      bankName: "State Bank of India"
    },
    isSettled: false,
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: true,
    captureStatus: "authorized",
    authorizedAt: "2026-04-18 16:21:00",
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-18 16:20:15", description: "Payment order created for ₹28000", status: "success", metadata: { gateway: "Razorpay", paymentMode: "Net Banking" } },
      { event: "Payment Initiated", timestamp: "2026-04-18 16:20:45", description: "Payment initiated via Net Banking", status: "success" },
      { event: "Awaiting Confirmation", timestamp: "2026-04-18 16:21:30", description: "Waiting for bank confirmation", status: "warning" }
    ],
    customFields: {
      fatherName: "Amit Patel",
      motherName: "Neha Patel",
      session: "2024-25",
      admissionNumber: "ADM001237"
    }
  },
  // Transaction 5 - Failed Payment
  {
    id: "TXNDPS005E1F2G3",
    orderId: "ORDDPS2024005",
    edvironOrderId: "EDVDPS005EFG",
    gatewayTransactionId: "PPE005E1F2G3H4I5",
    bankReferenceNumber: "",
    status: "failed",
    statusReason: "Insufficient funds",
    orderAmount: 52000,
    transactionAmount: 52000,
    vendorAmount: 50440,
    gateway: "PhonePe PG",
    paymentMode: "Debit Card",
    channel: "Online",
    date: "2026-04-19",
    time: "10:35:50",
    student: {
      id: "STUDPS005",
      name: "Diya Verma",
      email: "diya.verma@gmail.com",
      phone: "+919876543214",
      class: "11th",
      division: "A",
      rollNumber: "31",
      enrollmentNumber: "DPS2024005"
    },
    institute: merchantInstitute,
    feeType: "Exam Fee",
    mdrAmount: 1040,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 520,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Card",
      details: "Rupay ending 7890",
      cardBrand: "Rupay",
      cardType: "Debit",
      cardIssuer: "ICICI Bank",
      cardIssuingBank: "ICICI Bank"
    },
    isSettled: false,
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-19 10:35:50", description: "Payment order created for ₹52000", status: "success", metadata: { gateway: "PhonePe PG", paymentMode: "Debit Card" } },
      { event: "Payment Initiated", timestamp: "2026-04-19 10:36:15", description: "Payment initiated via Debit Card", status: "success" },
      { event: "Payment Failed", timestamp: "2026-04-19 10:37:30", description: "Insufficient funds in account", status: "error" }
    ],
    customFields: {
      fatherName: "Rakesh Verma",
      motherName: "Sneha Verma",
      session: "2024-25",
      admissionNumber: "ADM001238"
    }
  },
  // Transaction 6 - UPI Autopay
  {
    id: "TXNDPS006F2G3H4",
    orderId: "ORDDPS2024006",
    edvironOrderId: "EDVDPS006FGH",
    gatewayTransactionId: "CFE006F2G3H4I5J6",
    bankReferenceNumber: "825202024006",
    status: "success",
    statusReason: "Auto-debit successful",
    orderAmount: 15000,
    transactionAmount: 15000,
    vendorAmount: 14550,
    gateway: "Cashfree",
    paymentMode: "UPI Autopay",
    channel: "QR Code",
    date: "2026-04-14",
    time: "08:00:00",
    student: {
      id: "STUDPS006",
      name: "Arjun Kumar",
      email: "arjun.kumar@gmail.com",
      phone: "+919876543215",
      class: "7th",
      division: "D",
      rollNumber: "42",
      enrollmentNumber: "DPS2024006"
    },
    institute: merchantInstitute,
    feeType: "Library Fee",
    mdrAmount: 300,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 150,
    erpCommissionPercentage: 1,
    instrument: {
      type: "UPI Mandate",
      details: "arjun.kumar@ybl",
      psp: "PhonePe",
      upiId: "arjun.kumar@ybl"
    },
    isSettled: true,
    settlementId: "STLDPS003",
    settlementUtr: "494482582887003",
    settlementDate: "2024-07-07",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    autopayDetails: {
      mandateId: "MNDDPS001",
      mandateType: "recurring",
      mandateStatus: "active",
      maxAmount: 50000,
      frequency: "monthly",
      validUntil: "2025-07-06"
    },
    transactionLifecycle: [
      { event: "Auto-Debit Initiated", timestamp: "2026-04-14 08:00:00", description: "Scheduled auto-debit for ₹15000", status: "success", metadata: { mandateId: "MNDDPS001" } },
      { event: "Payment Authorized", timestamp: "2026-04-14 08:00:15", description: "Payment authorized via mandate", status: "success", metadata: { bankRef: "825202024006" } },
      { event: "Payment Captured", timestamp: "2026-04-14 08:00:30", description: "Payment captured successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Sanjay Kumar",
      motherName: "Meena Kumar",
      session: "2024-25",
      admissionNumber: "ADM001239"
    }
  },
  // Transaction 7 - With Chargeback
  {
    id: "TXNDPS007G3H4I5",
    orderId: "ORDDPS2024007",
    edvironOrderId: "EDVDPS007GHI",
    gatewayTransactionId: "RPY007G3H4I5J6K7",
    bankReferenceNumber: "825202024007",
    status: "success",
    statusReason: "Payment successful",
    orderAmount: 42000,
    transactionAmount: 42000,
    vendorAmount: 40740,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Online",
    date: "2026-04-13",
    time: "15:45:20",
    student: {
      id: "STUDPS007",
      name: "Kavya Singh",
      email: "kavya.singh@gmail.com",
      phone: "+919876543216",
      class: "6th",
      division: "B",
      rollNumber: "15",
      enrollmentNumber: "DPS2024007"
    },
    institute: merchantInstitute,
    feeType: "Admission Fee",
    mdrAmount: 840,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 420,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Card",
      details: "Mastercard ending 2345",
      cardBrand: "Mastercard",
      cardType: "Credit",
      cardIssuer: "Axis Bank",
      cardIssuingBank: "Axis Bank"
    },
    isSettled: true,
    settlementId: "STLDPS003",
    settlementUtr: "494482582887003",
    settlementDate: "2024-07-09",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    chargebackDetails: {
      chargebackId: "CBKDPS001",
      chargebackStatus: "under_review",
      chargebackDate: "2024-08-01",
      chargebackAmount: 42000,
      chargebackReason: "Card holder claims transaction not recognized",
      disputeDeadline: "2024-09-01",
      evidenceSubmitted: true,
      responseSubmittedAt: "2024-08-05 14:30:00",
      arbNumber: "934194513001",
      chargebackFee: 500
    },
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-13 15:45:20", description: "Payment order created for ₹42000", status: "success", metadata: { gateway: "Razorpay", paymentMode: "Credit Card" } },
      { event: "Payment Initiated", timestamp: "2026-04-13 15:45:50", description: "Payment initiated via Credit Card", status: "success" },
      { event: "Payment Authorized", timestamp: "2026-04-13 15:46:30", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "825202024007" } },
      { event: "Payment Captured", timestamp: "2026-04-13 15:46:55", description: "Payment captured successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Vikrant Singh",
      motherName: "Pooja Singh",
      session: "2024-25",
      admissionNumber: "ADM001240"
    }
  },
  // Transaction 8 - Split Payment with Multiple Vendors
  {
    id: "TXNDPS008H4I5J6",
    orderId: "ORDDPS2024008",
    edvironOrderId: "EDVDPS008HIJ",
    gatewayTransactionId: "PPE008H4I5J6K7L8",
    bankReferenceNumber: "825202024008",
    status: "success",
    statusReason: "Payment successful",
    orderAmount: 125000,
    transactionAmount: 125000,
    vendorAmount: 121250,
    gateway: "PhonePe PG",
    paymentMode: "UPI",
    channel: "SDK",
    date: "2026-04-12",
    time: "12:30:00",
    student: {
      id: "STUDPS008",
      name: "Advait Reddy",
      email: "advait.reddy@gmail.com",
      phone: "+919876543217",
      class: "10th",
      division: "A",
      rollNumber: "05",
      enrollmentNumber: "DPS2024008"
    },
    institute: merchantInstitute,
    feeType: "Hostel Fee",
    mdrAmount: 2500,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 1250,
    erpCommissionPercentage: 1,
    instrument: {
      type: "UPI",
      details: "advait.reddy@oksbi",
      psp: "Google Pay",
      upiId: "advait.reddy@oksbi"
    },
    isSettled: true,
    settlementId: "STLDPS004",
    settlementUtr: "494482582887004",
    settlementDate: "2024-07-11",
    isSplitPayment: true,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    splitDetails: [
      { beneficiary: "Delhi Public School - Main Account", account: "85434700051492", ifsc: "HDFC0001234", amount: 75000, percentage: 60, status: "settled" },
      { beneficiary: "Delhi Public School - Hostel Fund", account: "85434700051494", ifsc: "HDFC0001234", amount: 37500, percentage: 30, status: "settled" },
      { beneficiary: "DPS Catering Services", account: "85434700051495", ifsc: "ICIC0001234", amount: 12500, percentage: 10, status: "settled" }
    ],
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-12 12:30:00", description: "Payment order created for ₹125000", status: "success", metadata: { gateway: "PhonePe PG", paymentMode: "UPI" } },
      { event: "Payment Initiated", timestamp: "2026-04-12 12:30:30", description: "Payment initiated via UPI", status: "success" },
      { event: "Payment Authorized", timestamp: "2026-04-12 12:31:15", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "825202024008" } },
      { event: "Payment Captured", timestamp: "2026-04-12 12:31:40", description: "Payment captured successfully", status: "success" },
      { event: "Split Initiated", timestamp: "2026-04-12 12:32:00", description: "Split payment initiated to 3 beneficiaries", status: "success" }
    ],
    customFields: {
      fatherName: "Suresh Reddy",
      motherName: "Lakshmi Reddy",
      session: "2024-25",
      admissionNumber: "ADM001241"
    }
  },
  // Transaction 9 - Wallet Payment
  {
    id: "TXNDPS009I5J6K7",
    orderId: "ORDDPS2024009",
    edvironOrderId: "EDVDPS009IJK",
    gatewayTransactionId: "CFE009I5J6K7L8M9",
    bankReferenceNumber: "825202024009",
    status: "success",
    statusReason: "Payment successful",
    orderAmount: 8500,
    transactionAmount: 8500,
    vendorAmount: 8245,
    gateway: "Cashfree",
    paymentMode: "Wallet",
    channel: "Mobile App",
    date: "2026-04-11",
    time: "09:15:30",
    student: {
      id: "STUDPS009",
      name: "Priya Joshi",
      email: "priya.joshi@gmail.com",
      phone: "+919876543218",
      class: "4th",
      division: "C",
      rollNumber: "28",
      enrollmentNumber: "DPS2024009"
    },
    institute: merchantInstitute,
    feeType: "Sports Fee",
    mdrAmount: 170,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 85,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Wallet",
      details: "Paytm Wallet",
      walletName: "Paytm Wallet"
    },
    isSettled: true,
    settlementId: "STLDPS005",
    settlementUtr: "494482582887005",
    settlementDate: "2024-07-13",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-11 09:15:30", description: "Payment order created for ₹8500", status: "success", metadata: { gateway: "Cashfree", paymentMode: "Wallet" } },
      { event: "Payment Initiated", timestamp: "2026-04-11 09:15:50", description: "Payment initiated via Wallet", status: "success" },
      { event: "Payment Captured", timestamp: "2026-04-11 09:16:10", description: "Payment captured successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Manish Joshi",
      motherName: "Rekha Joshi",
      session: "2024-25",
      admissionNumber: "ADM001242"
    }
  },
  // Transaction 10 - International Payment
  {
    id: "TXNDPS010J6K7L8",
    orderId: "ORDDPS2024010",
    edvironOrderId: "EDVDPS010JKL",
    gatewayTransactionId: "RPY010J6K7L8M9N0",
    bankReferenceNumber: "825202024010",
    status: "success",
    statusReason: "International payment successful",
    orderAmount: 95000,
    transactionAmount: 97850,
    vendorAmount: 92625,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Online",
    date: "2026-04-10",
    time: "18:45:00",
    student: {
      id: "STUDPS010",
      name: "Aditya Krishnan",
      email: "aditya.krishnan@gmail.com",
      phone: "+14155551234",
      class: "12th",
      division: "A",
      rollNumber: "02",
      enrollmentNumber: "DPS2024010"
    },
    institute: merchantInstitute,
    feeType: "Annual Fee",
    mdrAmount: 2850,
    mdrPercentage: 3,
    mdrBearing: "surcharge",
    erpCommission: 950,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Card",
      details: "Visa ending 9012",
      cardBrand: "Visa",
      cardType: "Credit",
      cardIssuer: "Chase Bank",
      cardIssuingBank: "Chase Bank"
    },
    isSettled: true,
    settlementId: "STLDPS006",
    settlementUtr: "494482582887006",
    settlementDate: "2024-07-17",
    isSplitPayment: false,
    isInternational: true,
    internationalMethod: "Card",
    currency: "USD",
    originalAmount: 1140,
    exchangeRate: 83.33,
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-10 18:45:00", description: "Payment order created for $1140 (₹95000)", status: "success", metadata: { gateway: "Razorpay", paymentMode: "Credit Card" } },
      { event: "Currency Conversion", timestamp: "2026-04-10 18:45:15", description: "USD to INR conversion at rate 83.33", status: "success" },
      { event: "Payment Initiated", timestamp: "2026-04-10 18:45:30", description: "Payment initiated via Credit Card", status: "success" },
      { event: "Payment Authorized", timestamp: "2026-04-10 18:46:15", description: "Payment authorized by international bank", status: "success", metadata: { bankRef: "825202024010" } },
      { event: "Payment Captured", timestamp: "2026-04-10 18:46:45", description: "Payment captured successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Venkat Krishnan",
      motherName: "Padma Krishnan",
      session: "2024-25",
      admissionNumber: "ADM001243"
    }
  },
  // Transaction 11 - User Dropped
  {
    id: "TXNDPS011K7L8M9",
    orderId: "ORDDPS2024011",
    edvironOrderId: "EDVDPS011KLM",
    gatewayTransactionId: "PPE011K7L8M9N0O1",
    bankReferenceNumber: "",
    status: "user_dropped",
    statusReason: "User abandoned payment",
    orderAmount: 22000,
    transactionAmount: 22000,
    vendorAmount: 21340,
    gateway: "PhonePe PG",
    paymentMode: "UPI",
    channel: "Mobile App",
    date: "2026-04-09",
    time: "14:20:00",
    student: {
      id: "STUDPS011",
      name: "Vivaan Malhotra",
      email: "vivaan.malhotra@gmail.com",
      phone: "+919876543219",
      class: "5th",
      division: "B",
      rollNumber: "35",
      enrollmentNumber: "DPS2024011"
    },
    institute: merchantInstitute,
    feeType: "Term Fee",
    mdrAmount: 440,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 220,
    erpCommissionPercentage: 1,
    instrument: {
      type: "UPI",
      details: "vivaan.malhotra@paytm",
      psp: "Paytm",
      upiId: "vivaan.malhotra@paytm"
    },
    isSettled: false,
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-09 14:20:00", description: "Payment order created for ₹22000", status: "success", metadata: { gateway: "PhonePe PG", paymentMode: "UPI" } },
      { event: "Payment Initiated", timestamp: "2026-04-09 14:20:30", description: "Payment initiated via UPI", status: "success" },
      { event: "User Dropped", timestamp: "2026-04-09 14:25:00", description: "User did not complete payment", status: "error" }
    ],
    customFields: {
      fatherName: "Rajiv Malhotra",
      motherName: "Anita Malhotra",
      session: "2024-25",
      admissionNumber: "ADM001244"
    }
  },
  // Transaction 12 - Another Successful UPI
  {
    id: "TXNDPS012L8M9N0",
    orderId: "ORDDPS2024012",
    edvironOrderId: "EDVDPS012LMN",
    gatewayTransactionId: "CFE012L8M9N0O1P2",
    bankReferenceNumber: "825202024012",
    status: "success",
    statusReason: "Payment successful",
    orderAmount: 38000,
    transactionAmount: 38000,
    vendorAmount: 36860,
    gateway: "Cashfree",
    paymentMode: "UPI",
    channel: "Payment Link",
    date: "2026-04-08",
    time: "11:30:45",
    student: {
      id: "STUDPS012",
      name: "Saanvi Agarwal",
      email: "saanvi.agarwal@gmail.com",
      phone: "+919876543220",
      class: "9th",
      division: "A",
      rollNumber: "22",
      enrollmentNumber: "DPS2024012"
    },
    institute: merchantInstitute,
    feeType: "Tuition Fee",
    mdrAmount: 760,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 380,
    erpCommissionPercentage: 1,
    instrument: {
      type: "UPI",
      details: "saanvi.agarwal@icici",
      psp: "ICICI Bank",
      upiId: "saanvi.agarwal@icici"
    },
    isSettled: true,
    settlementId: "STLDPS007",
    settlementUtr: "494482582887007",
    settlementDate: "2024-07-19",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2026-04-08 11:30:45", description: "Payment order created for ₹38000", status: "success", metadata: { gateway: "Cashfree", paymentMode: "UPI" } },
      { event: "Payment Initiated", timestamp: "2026-04-08 11:31:10", description: "Payment initiated via UPI", status: "success" },
      { event: "Payment Authorized", timestamp: "2026-04-08 11:31:45", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "825202024012" } },
      { event: "Payment Captured", timestamp: "2026-04-08 11:32:05", description: "Payment captured successfully", status: "success" }
    ],
    customFields: {
      fatherName: "Nitin Agarwal",
      motherName: "Shilpa Agarwal",
      session: "2024-25",
      admissionNumber: "ADM001245"
    }
  }
]

// ============================================
// DERIVED DATA - REFUNDS
// ============================================

export const unifiedRefunds: Refund[] = unifiedTransactions
  .filter(txn => txn.refundDetails)
  .map(txn => ({
    id: txn.refundDetails!.refundId,
    transactionId: txn.id,
    orderId: txn.orderId,
    institute: txn.institute.name,
    studentName: txn.student.name,
    studentId: txn.student.id,
    orderAmount: txn.orderAmount,
    refundAmount: txn.refundDetails!.netRefundToParent,
    gateway: txn.gateway,
    paymentMode: txn.paymentMode,
    accountType: "merchant" as const,
    status: txn.refundDetails!.refundStatus,
    reason: txn.refundDetails!.refundReason,
    refundArn: txn.refundDetails!.refundArn,
    requestedBy: "Admin",
    requestedAt: txn.refundDetails!.refundDate,
    processedAt: txn.refundDetails!.refundStatus === "completed" ? txn.refundDetails!.refundDate : undefined,
    pgChargesDeducted: txn.refundDetails!.pgChargesDeducted,
    erpCommissionDeducted: txn.refundDetails!.erpCommissionDeducted,
    netRefundToParent: txn.refundDetails!.netRefundToParent,
    deductedFromSettlement: txn.settlementId ? {
      id: txn.settlementId,
      date: txn.settlementDate || "",
      amount: txn.refundDetails!.netRefundToParent
    } : undefined
  }))

// ============================================
// DERIVED DATA - CHARGEBACKS
// ============================================

export const unifiedChargebacks: Chargeback[] = unifiedTransactions
  .filter(txn => txn.chargebackDetails)
  .map(txn => ({
    id: txn.chargebackDetails!.chargebackId,
    transactionId: txn.id,
    orderId: txn.orderId,
    institute: txn.institute.name,
    studentName: txn.student.name,
    studentId: txn.student.id,
    amount: txn.chargebackDetails!.chargebackAmount,
    gateway: txn.gateway,
    paymentMode: txn.paymentMode,
    reason: txn.chargebackDetails!.chargebackReason,
    status: txn.chargebackDetails!.chargebackStatus,
    raisedBy: txn.instrument.cardIssuingBank || txn.instrument.psp || "Bank",
    raisedDate: txn.chargebackDetails!.chargebackDate,
    dueDate: txn.chargebackDetails!.disputeDeadline,
    evidenceSubmitted: txn.chargebackDetails!.evidenceSubmitted,
    responseSubmittedAt: txn.chargebackDetails!.responseSubmittedAt,
    arbNumber: txn.chargebackDetails!.arbNumber,
    chargebackFee: txn.chargebackDetails!.chargebackFee,
    originalSettlement: txn.settlementId ? {
      id: txn.settlementId,
      date: txn.settlementDate || ""
    } : undefined,
    deductedFromSettlement: txn.settlementId && txn.chargebackDetails!.chargebackStatus !== "won" ? {
      id: txn.settlementId,
      date: txn.settlementDate || "",
      amount: txn.chargebackDetails!.chargebackAmount
    } : undefined,
    recoveryInfo: txn.chargebackDetails!.chargebackStatus === "won" ? {
      creditedToSettlement: txn.settlementId || "",
      creditedDate: txn.settlementDate || "",
      amount: txn.chargebackDetails!.chargebackAmount
    } : undefined
  }))

// ============================================
// DERIVED DATA - SETTLEMENTS
// ============================================

export const unifiedSettlements: Settlement[] = [
  {
    id: "STLDPS001",
    settlementDate: "2026-04-16",
    processedDate: "2026-04-16",
    gateway: "Razorpay",
    utr: "494482582887001",
    transactionCount: 5,
    totalAmount: 180000,
    pgCharges: 3600,
    erpCommission: 1800,
    netAmount: 174600,
    adjustments: { refunds: 33775, chargebacks: 0, recoveries: 0 },
    finalAmount: 140825,
    status: "settled",
    institute: merchantInstitute,
    transactionIds: ["TXNDPS001A7B8C9", "TXNDPS002B8C9D0"],
    refundIds: ["RFDDPS001"],
    chargebackIds: [],
    merchantSettlement: { amount: 140825, utr: "494482582887001", transactions: ["TXNDPS001A7B8C9", "TXNDPS002B8C9D0"] },
    vendorSettlements: []
  },
  {
    id: "STLDPS002",
    settlementDate: "2026-04-18",
    processedDate: "2026-04-18",
    gateway: "Cashfree",
    utr: "494482582887002",
    transactionCount: 3,
    totalAmount: 245000,
    pgCharges: 4900,
    erpCommission: 2450,
    netAmount: 237650,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 237650,
    status: "settled",
    institute: merchantInstitute,
    transactionIds: ["TXNDPS003C9D0E1"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 178238, utr: "494482582887002", transactions: ["TXNDPS003C9D0E1"] },
    vendorSettlements: [{ vendorName: "Delhi Public School - Trust Fund", amount: 59412, utr: "494482582887002-V1", transactions: ["TXNDPS003C9D0E1"] }]
  },
  {
    id: "STLDPS003",
    settlementDate: "2024-07-07",
    processedDate: "2024-07-07",
    gateway: "Cashfree",
    utr: "494482582887003",
    transactionCount: 4,
    totalAmount: 157000,
    pgCharges: 3140,
    erpCommission: 1570,
    netAmount: 152290,
    adjustments: { refunds: 0, chargebacks: 42000, recoveries: 0 },
    finalAmount: 110290,
    status: "settled",
    institute: merchantInstitute,
    transactionIds: ["TXNDPS006F2G3H4", "TXNDPS007G3H4I5"],
    refundIds: [],
    chargebackIds: ["CBKDPS001"],
    merchantSettlement: { amount: 110290, utr: "494482582887003", transactions: ["TXNDPS006F2G3H4", "TXNDPS007G3H4I5"] },
    vendorSettlements: []
  },
  {
    id: "STLDPS004",
    settlementDate: "2024-07-11",
    processedDate: "2024-07-11",
    gateway: "PhonePe PG",
    utr: "494482582887004",
    transactionCount: 6,
    totalAmount: 325000,
    pgCharges: 6500,
    erpCommission: 3250,
    netAmount: 315250,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 315250,
    status: "settled",
    institute: merchantInstitute,
    transactionIds: ["TXNDPS008H4I5J6"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 189150, utr: "494482582887004", transactions: ["TXNDPS008H4I5J6"] },
    vendorSettlements: [
      { vendorName: "Delhi Public School - Hostel Fund", amount: 94575, utr: "494482582887004-V1", transactions: ["TXNDPS008H4I5J6"] },
      { vendorName: "DPS Catering Services", amount: 31525, utr: "494482582887004-V2", transactions: ["TXNDPS008H4I5J6"] }
    ]
  },
  {
    id: "STLDPS005",
    settlementDate: "2024-07-13",
    processedDate: "2024-07-13",
    gateway: "Cashfree",
    utr: "494482582887005",
    transactionCount: 8,
    totalAmount: 85000,
    pgCharges: 1700,
    erpCommission: 850,
    netAmount: 82450,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 82450,
    status: "settled",
    institute: merchantInstitute,
    transactionIds: ["TXNDPS009I5J6K7"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 82450, utr: "494482582887005", transactions: ["TXNDPS009I5J6K7"] },
    vendorSettlements: []
  },
  {
    id: "STLDPS006",
    settlementDate: "2024-07-17",
    processedDate: "2024-07-17",
    gateway: "Razorpay",
    utr: "494482582887006",
    transactionCount: 4,
    totalAmount: 285000,
    pgCharges: 8550,
    erpCommission: 2850,
    netAmount: 273600,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 273600,
    status: "settled",
    institute: merchantInstitute,
    transactionIds: ["TXNDPS010J6K7L8"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 273600, utr: "494482582887006", transactions: ["TXNDPS010J6K7L8"] },
    vendorSettlements: []
  },
  {
    id: "STLDPS007",
    settlementDate: "2024-07-19",
    processedDate: "2024-07-19",
    gateway: "Cashfree",
    utr: "494482582887007",
    transactionCount: 5,
    totalAmount: 138000,
    pgCharges: 2760,
    erpCommission: 1380,
    netAmount: 133860,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 133860,
    status: "settled",
    institute: merchantInstitute,
    transactionIds: ["TXNDPS012L8M9N0"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 133860, utr: "494482582887007", transactions: ["TXNDPS012L8M9N0"] },
    vendorSettlements: []
  },
  {
    id: "STLDPS008",
    settlementDate: "2024-07-20",
    processedDate: "",
    gateway: "Razorpay",
    utr: "",
    transactionCount: 3,
    totalAmount: 95000,
    pgCharges: 1900,
    erpCommission: 950,
    netAmount: 92150,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 92150,
    status: "pending",
    institute: merchantInstitute,
    transactionIds: [],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 92150, utr: "", transactions: [] },
    vendorSettlements: []
  }
]

// ============================================
// DERIVED DATA - SPLIT PAYMENTS
// ============================================

export const unifiedSplitPayments: SplitPayment[] = unifiedTransactions
  .filter(txn => txn.isSplitPayment && txn.splitDetails && txn.splitDetails.length > 0)
  .map(txn => ({
    id: `SPL-${txn.id}`,
    transactionId: txn.id,
    orderId: txn.orderId,
    institute: txn.institute,
    student: txn.student,
    totalAmount: txn.orderAmount,
    gateway: txn.gateway,
    paymentMode: txn.paymentMode,
    date: txn.date,
    status: txn.status,
    splits: txn.splitDetails!,
    vendorSplits: txn.splitDetails!
      .filter(s => s.beneficiary.includes("Trust") || s.beneficiary.includes("Fund") || s.beneficiary.includes("Catering"))
      .map(s => ({
        vendorName: s.beneficiary,
        amount: s.amount,
        percentage: s.percentage,
        status: s.status,
        settlementId: txn.settlementId,
        settlementUtr: txn.settlementUtr,
        settlementDate: txn.settlementDate
      })),
    merchantSplit: {
      amount: txn.splitDetails!.find(s => s.beneficiary.includes("Main Account"))?.amount || txn.orderAmount * 0.6,
      percentage: txn.splitDetails!.find(s => s.beneficiary.includes("Main Account"))?.percentage || 60,
      status: txn.splitDetails!.find(s => s.beneficiary.includes("Main Account"))?.status || "settled",
      settlementId: txn.settlementId,
      settlementUtr: txn.settlementUtr,
      settlementDate: txn.settlementDate
    }
  }))

// ============================================
// HELPER FUNCTIONS
// ============================================

export function getAllVendors(): string[] {
  const vendors = new Set<string>()
  unifiedTransactions.forEach(txn => {
    if (txn.splitDetails) {
      txn.splitDetails.forEach(split => {
        if (split.beneficiary.includes("Trust") || split.beneficiary.includes("Fund") || split.beneficiary.includes("Catering")) {
          vendors.add(split.beneficiary)
        }
      })
    }
  })
  return Array.from(vendors).sort()
}

export function getAllInstitutes(): Institute[] {
  return [merchantInstitute]
}

export function getAllGateways(): string[] {
  return [...new Set(unifiedTransactions.map(txn => txn.gateway))].sort()
}

export function getTransactionsByStatus(status: TransactionStatus): Transaction[] {
  return unifiedTransactions.filter(txn => txn.status === status)
}

export function getSplitTransactions(): Transaction[] {
  return unifiedTransactions.filter(txn => txn.isSplitPayment)
}

export function getInternationalTransactions(): Transaction[] {
  return unifiedTransactions.filter(txn => txn.isInternational)
}

export function getTransactionById(id: string): Transaction | undefined {
  return unifiedTransactions.find(txn => txn.id === id)
}

export function getSettlementById(id: string): Settlement | undefined {
  return unifiedSettlements.find(s => s.id === id)
}

export function getRefundById(id: string): Refund | undefined {
  return unifiedRefunds.find(r => r.id === id)
}

export function getChargebackById(id: string): Chargeback | undefined {
  return unifiedChargebacks.find(c => c.id === id)
}

// Fee category statistics for dashboard
export function getFeeTypeStats() {
  const feeStats = new Map<string, { count: number; amount: number }>()
  
  unifiedTransactions
    .filter(txn => txn.status === "success")
    .forEach(txn => {
      const existing = feeStats.get(txn.feeType) || { count: 0, amount: 0 }
      feeStats.set(txn.feeType, {
        count: existing.count + 1,
        amount: existing.amount + txn.orderAmount
      })
    })
  
  return Array.from(feeStats.entries())
    .map(([feeType, stats]) => ({ feeType, ...stats }))
    .sort((a, b) => b.amount - a.amount)
}

// Gateway statistics
export function getGatewayStats() {
  const gatewayStats = new Map<string, { count: number; amount: number; successRate: number }>()
  
  unifiedTransactions.forEach(txn => {
    const existing = gatewayStats.get(txn.gateway) || { count: 0, amount: 0, successCount: 0 }
    gatewayStats.set(txn.gateway, {
      count: existing.count + 1,
      amount: existing.amount + (txn.status === "success" ? txn.orderAmount : 0),
      successCount: (existing as any).successCount + (txn.status === "success" ? 1 : 0)
    })
  })
  
  return Array.from(gatewayStats.entries())
    .map(([gateway, stats]) => ({
      gateway,
      count: stats.count,
      amount: stats.amount,
      successRate: ((stats as any).successCount / stats.count * 100).toFixed(1)
    }))
    .sort((a, b) => b.amount - a.amount)
}

// Dashboard summary statistics
export function getDashboardStats() {
  const successfulTxns = unifiedTransactions.filter(t => t.status === "success")
  const totalCollections = successfulTxns.reduce((sum, t) => sum + t.orderAmount, 0)
  const totalTransactions = unifiedTransactions.length
  const successRate = (successfulTxns.length / totalTransactions * 100).toFixed(1)
  const uniqueStudents = new Set(unifiedTransactions.map(t => t.student.id)).size
  
  return {
    totalCollections,
    totalTransactions,
    successRate,
    activeStudents: uniqueStudents,
    pendingSettlements: unifiedSettlements.filter(s => s.status === "pending").length,
    openChargebacks: unifiedChargebacks.filter(c => c.status === "open" || c.status === "under_review").length,
    pendingRefunds: unifiedRefunds.filter(r => r.status === "pending" || r.status === "initiated").length
  }
}

// ============================================
// FEE COLLECTION DATA
// ============================================

export const feeHeads: FeeHead[] = [
  {
    id: "FH001",
    code: "TF",
    name: "Tuition Fee",
    description: "Monthly tuition fee for academic instruction",
    category: "academic",
    amount: 15000,
    frequency: "quarterly",
    dueDay: 10,
    lateFeeEnabled: true,
    lateFeeType: "percentage",
    lateFeeValue: 2,
    gracePeriodDays: 7,
    lateFeeMaxAmount: 1000,
    paymentMode: "both",
    allowPartialPayment: true,
    minPartialAmount: 5000,
    paymentPriority: 1,
    gstApplicable: false,
    isActive: true
  },
  {
    id: "FH002",
    code: "AF",
    name: "Annual Fee",
    description: "Annual development and infrastructure fee",
    category: "academic",
    amount: 25000,
    frequency: "annual",
    dueMonth: 4,
    dueDay: 15,
    lateFeeEnabled: true,
    lateFeeType: "fixed",
    lateFeeValue: 500,
    gracePeriodDays: 15,
    paymentMode: "both",
    allowPartialPayment: false,
    paymentPriority: 2,
    gstApplicable: false,
    isActive: true
  },
  {
    id: "FH003",
    code: "TRF",
    name: "Transport Fee",
    description: "School bus transportation fee",
    category: "transport",
    amount: 3500,
    frequency: "monthly",
    dueDay: 5,
    lateFeeEnabled: true,
    lateFeeType: "fixed",
    lateFeeValue: 100,
    gracePeriodDays: 5,
    paymentMode: "both",
    allowPartialPayment: false,
    paymentPriority: 3,
    gstApplicable: true,
    gstPercentage: 5,
    hsnCode: "996601",
    isActive: true
  },
  {
    id: "FH004",
    code: "HF",
    name: "Hostel Fee",
    description: "Boarding and lodging charges",
    category: "hostel",
    amount: 45000,
    frequency: "quarterly",
    dueDay: 1,
    lateFeeEnabled: true,
    lateFeeType: "percentage",
    lateFeeValue: 1.5,
    gracePeriodDays: 10,
    lateFeeMaxAmount: 2000,
    paymentMode: "both",
    allowPartialPayment: true,
    minPartialAmount: 15000,
    paymentPriority: 4,
    gstApplicable: false,
    isActive: true
  },
  {
    id: "FH005",
    code: "LF",
    name: "Lab Fee",
    description: "Science and computer lab usage fee",
    category: "academic",
    amount: 5000,
    frequency: "annual",
    dueMonth: 4,
    dueDay: 15,
    lateFeeEnabled: false,
    gracePeriodDays: 30,
    paymentMode: "both",
    allowPartialPayment: false,
    paymentPriority: 5,
    gstApplicable: false,
    isActive: true
  },
  {
    id: "FH006",
    code: "SF",
    name: "Sports Fee",
    description: "Sports equipment and facilities",
    category: "misc",
    amount: 3000,
    frequency: "annual",
    dueMonth: 4,
    dueDay: 15,
    lateFeeEnabled: false,
    gracePeriodDays: 30,
    paymentMode: "both",
    allowPartialPayment: false,
    paymentPriority: 6,
    gstApplicable: false,
    isActive: true
  },
  {
    id: "FH007",
    code: "EXF",
    name: "Exam Fee",
    description: "Term examination fee",
    category: "academic",
    amount: 2000,
    frequency: "quarterly",
    dueDay: 1,
    lateFeeEnabled: true,
    lateFeeType: "fixed",
    lateFeeValue: 200,
    gracePeriodDays: 5,
    paymentMode: "both",
    allowPartialPayment: false,
    paymentPriority: 7,
    gstApplicable: false,
    isActive: true
  },
  {
    id: "FH008",
    code: "LIB",
    name: "Library Fee",
    description: "Library access and book maintenance",
    category: "academic",
    amount: 1500,
    frequency: "annual",
    dueMonth: 4,
    dueDay: 15,
    lateFeeEnabled: false,
    gracePeriodDays: 30,
    paymentMode: "both",
    allowPartialPayment: false,
    paymentPriority: 8,
    gstApplicable: false,
    isActive: true
  }
]

export const feeStructures: FeeStructure[] = [
  {
    id: "FS001",
    name: "Class 9-10 Standard",
    description: "Standard fee structure for classes 9 and 10",
    academicYear: "2024-25",
    status: "active",
    classes: ["Class 9", "Class 10"],
    feeHeads: [
      { feeHeadId: "FH001", feeHead: feeHeads[0], isMandatory: true },
      { feeHeadId: "FH002", feeHead: feeHeads[1], isMandatory: true },
      { feeHeadId: "FH005", feeHead: feeHeads[4], isMandatory: true },
      { feeHeadId: "FH006", feeHead: feeHeads[5], isMandatory: false },
      { feeHeadId: "FH007", feeHead: feeHeads[6], isMandatory: true },
      { feeHeadId: "FH008", feeHead: feeHeads[7], isMandatory: true }
    ],
    totalAmount: 91500,
    createdAt: "2024-03-01",
    createdBy: "Admin"
  },
  {
    id: "FS002",
    name: "Class 11-12 Science",
    description: "Fee structure for science stream students",
    academicYear: "2024-25",
    status: "active",
    classes: ["Class 11", "Class 12"],
    feeHeads: [
      { feeHeadId: "FH001", feeHead: feeHeads[0], amountOverride: 18000, isMandatory: true },
      { feeHeadId: "FH002", feeHead: feeHeads[1], amountOverride: 30000, isMandatory: true },
      { feeHeadId: "FH005", feeHead: feeHeads[4], amountOverride: 8000, isMandatory: true },
      { feeHeadId: "FH006", feeHead: feeHeads[5], isMandatory: false },
      { feeHeadId: "FH007", feeHead: feeHeads[6], amountOverride: 2500, isMandatory: true },
      { feeHeadId: "FH008", feeHead: feeHeads[7], isMandatory: true }
    ],
    totalAmount: 112500,
    createdAt: "2024-03-01",
    createdBy: "Admin"
  },
  {
    id: "FS003",
    name: "Day Scholar with Transport",
    description: "For students availing school transport",
    academicYear: "2024-25",
    status: "active",
    classes: ["Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8"],
    feeHeads: [
      { feeHeadId: "FH001", feeHead: feeHeads[0], amountOverride: 12000, isMandatory: true },
      { feeHeadId: "FH002", feeHead: feeHeads[1], amountOverride: 20000, isMandatory: true },
      { feeHeadId: "FH003", feeHead: feeHeads[2], isMandatory: true },
      { feeHeadId: "FH006", feeHead: feeHeads[5], isMandatory: false },
      { feeHeadId: "FH007", feeHead: feeHeads[6], isMandatory: true },
      { feeHeadId: "FH008", feeHead: feeHeads[7], isMandatory: true }
    ],
    totalAmount: 110000,
    createdAt: "2024-03-01",
    createdBy: "Admin"
  },
  {
    id: "FS004",
    name: "Hostel Boarder",
    description: "For residential students",
    academicYear: "2024-25",
    status: "active",
    classes: ["Class 9", "Class 10", "Class 11", "Class 12"],
    feeHeads: [
      { feeHeadId: "FH001", feeHead: feeHeads[0], isMandatory: true },
      { feeHeadId: "FH002", feeHead: feeHeads[1], isMandatory: true },
      { feeHeadId: "FH004", feeHead: feeHeads[3], isMandatory: true },
      { feeHeadId: "FH005", feeHead: feeHeads[4], isMandatory: true },
      { feeHeadId: "FH006", feeHead: feeHeads[5], isMandatory: false },
      { feeHeadId: "FH007", feeHead: feeHeads[6], isMandatory: true },
      { feeHeadId: "FH008", feeHead: feeHeads[7], isMandatory: true }
    ],
    totalAmount: 276500,
    createdAt: "2024-03-01",
    createdBy: "Admin"
  }
]

// Generate students with fee data
const studentNames = [
  { first: "Aarav", last: "Sharma", father: "Rajesh Sharma", mother: "Priya Sharma" },
  { first: "Vivaan", last: "Patel", father: "Amit Patel", mother: "Neha Patel" },
  { first: "Aditya", last: "Singh", father: "Vikram Singh", mother: "Anjali Singh" },
  { first: "Vihaan", last: "Kumar", father: "Suresh Kumar", mother: "Meena Kumar" },
  { first: "Arjun", last: "Gupta", father: "Rakesh Gupta", mother: "Sunita Gupta" },
  { first: "Sai", last: "Reddy", father: "Krishna Reddy", mother: "Lakshmi Reddy" },
  { first: "Reyansh", last: "Joshi", father: "Mohan Joshi", mother: "Kavita Joshi" },
  { first: "Ayaan", last: "Verma", father: "Anil Verma", mother: "Rita Verma" },
  { first: "Krishna", last: "Iyer", father: "Subramaniam Iyer", mother: "Geetha Iyer" },
  { first: "Ishaan", last: "Nair", father: "Vijay Nair", mother: "Deepa Nair" },
  { first: "Ananya", last: "Mishra", father: "Prakash Mishra", mother: "Suman Mishra" },
  { first: "Diya", last: "Choudhury", father: "Rajan Choudhury", mother: "Anita Choudhury" },
  { first: "Myra", last: "Das", father: "Sanjay Das", mother: "Poonam Das" },
  { first: "Saanvi", last: "Mehta", father: "Vijay Mehta", mother: "Shilpa Mehta" },
  { first: "Aanya", last: "Kapoor", father: "Rahul Kapoor", mother: "Divya Kapoor" },
  { first: "Aadhya", last: "Rao", father: "Suresh Rao", mother: "Padma Rao" },
  { first: "Kiara", last: "Malhotra", father: "Ajay Malhotra", mother: "Pooja Malhotra" },
  { first: "Navya", last: "Agarwal", father: "Vinod Agarwal", mother: "Rekha Agarwal" },
  { first: "Riya", last: "Banerjee", father: "Debashish Banerjee", mother: "Soma Banerjee" },
  { first: "Pihu", last: "Saxena", father: "Amit Saxena", mother: "Neelam Saxena" }
]

const classes = ["Class 9", "Class 10", "Class 11", "Class 12"]
const divisions = ["A", "B", "C"]
const feeStatuses: StudentFeeStatus[] = ["paid", "partial", "pending", "overdue"]

export const studentsWithFees: StudentWithFees[] = studentNames.map((name, index) => {
  const classIndex = index % classes.length
  const className = classes[classIndex]
  const division = divisions[index % divisions.length]
  const feeStatus = feeStatuses[index % feeStatuses.length]
  const feeStructure = feeStructures[classIndex < 2 ? 0 : 1]
  
  const totalFee = feeStructure.totalAmount
  const discountAmount = index % 5 === 0 ? totalFee * 0.1 : 0 // 10% discount for every 5th student
  const netFee = totalFee - discountAmount
  
  let paidAmount = 0
  if (feeStatus === "paid") paidAmount = netFee
  else if (feeStatus === "partial") paidAmount = Math.floor(netFee * 0.4)
  else if (feeStatus === "overdue") paidAmount = Math.floor(netFee * 0.2)
  
  const pendingAmount = netFee - paidAmount
  
  return {
    id: `STU${String(index + 1).padStart(4, "0")}`,
    name: `${name.first} ${name.last}`,
    email: `${name.first.toLowerCase()}.${name.last.toLowerCase()}@gmail.com`,
    phone: `98${String(Math.floor(Math.random() * 100000000)).padStart(8, "0")}`,
    class: className,
    division,
    rollNumber: String(index + 1),
    enrollmentNumber: `EN${String(2024000 + index).padStart(7, "0")}`,
    admissionNumber: `ADM${String(2020000 + index).padStart(7, "0")}`,
    admissionDate: "2022-04-01",
    status: "active",
    fatherName: name.father,
    motherName: name.mother,
    guardianPhone: `91${String(Math.floor(Math.random() * 1000000000)).padStart(10, "0")}`,
    guardianEmail: `${name.father.split(" ")[0].toLowerCase()}@gmail.com`,
    address: `${Math.floor(Math.random() * 500) + 1}, Sector ${Math.floor(Math.random() * 50) + 1}, Noida, UP`,
    feeStructureId: feeStructure.id,
    totalFee,
    discountAmount,
    netFee,
    paidAmount,
    pendingAmount,
    feeStatus,
    lastPaymentDate: paidAmount > 0 ? "2024-03-15" : undefined,
    nextDueDate: pendingAmount > 0 ? "2024-04-10" : undefined,
    feeHeadStatus: feeStructure.feeHeads.map(fh => {
      const amount = fh.amountOverride || fh.feeHead.amount
      const fhPaidAmount = feeStatus === "paid" ? amount : 
        (feeStatus === "partial" ? Math.floor(amount * 0.4) : 
        (feeStatus === "overdue" ? Math.floor(amount * 0.2) : 0))
      return {
        feeHeadId: fh.feeHeadId,
        feeHeadName: fh.feeHead.name,
        amount,
        paidAmount: fhPaidAmount,
        pendingAmount: amount - fhPaidAmount,
        dueDate: "2024-04-10",
        status: fhPaidAmount >= amount ? "paid" : (fhPaidAmount > 0 ? "partial" : (feeStatus === "overdue" ? "overdue" : "pending"))
      }
    })
  }
})

export const scholarships: Scholarship[] = [
  {
    id: "SCH001",
    name: "Merit Scholarship",
    description: "For students scoring above 90% in previous year",
    type: "merit",
    discountType: "percentage",
    discountValue: 25,
    maxDiscount: 50000,
    eligibilityCriteria: "90%+ marks in previous academic year",
    documentRequirements: ["Previous year marksheet", "Character certificate"],
    requiresApproval: true,
    isActive: true
  },
  {
    id: "SCH002",
    name: "Sibling Discount",
    description: "Discount for second child onwards",
    type: "sibling",
    discountType: "percentage",
    discountValue: 10,
    eligibilityCriteria: "Second or subsequent child studying in the school",
    requiresApproval: false,
    isActive: true
  },
  {
    id: "SCH003",
    name: "Staff Ward Concession",
    description: "Fee concession for children of school staff",
    type: "staff",
    discountType: "percentage",
    discountValue: 50,
    eligibilityCriteria: "Child of permanent school employee",
    documentRequirements: ["Staff ID card", "Employment certificate"],
    requiresApproval: true,
    isActive: true
  },
  {
    id: "SCH004",
    name: "Sports Excellence Award",
    description: "For state/national level sports achievers",
    type: "sports",
    discountType: "percentage",
    discountValue: 30,
    maxDiscount: 75000,
    eligibilityCriteria: "State or national level sports achievement",
    documentRequirements: ["Sports achievement certificate", "Participation proof"],
    requiresApproval: true,
    isActive: true
  },
  {
    id: "SCH005",
    name: "EWS Scholarship",
    description: "For economically weaker section students",
    type: "need_based",
    discountType: "percentage",
    discountValue: 100,
    eligibilityCriteria: "Family income below Rs. 2 lakhs per annum",
    documentRequirements: ["Income certificate", "BPL card", "Ration card"],
    requiresApproval: true,
    isActive: true
  }
]

export const paymentLinks: PaymentLink[] = studentsWithFees
  .filter(s => s.feeStatus === "pending" || s.feeStatus === "overdue")
  .slice(0, 10)
  .map((student, index) => ({
    id: `PL${String(index + 1).padStart(4, "0")}`,
    linkCode: `PAY${String(Math.random().toString(36).substring(2, 10)).toUpperCase()}`,
    shortUrl: `https://pay.clearn.in/${String(Math.random().toString(36).substring(2, 8))}`,
    studentId: student.id,
    student: {
      id: student.id,
      name: student.name,
      email: student.email,
      phone: student.phone,
      class: student.class,
      division: student.division,
      rollNumber: student.rollNumber,
      enrollmentNumber: student.enrollmentNumber
    },
    amount: student.pendingAmount,
    feeHeads: student.feeHeadStatus
      .filter(fh => fh.pendingAmount > 0)
      .map(fh => ({ feeHeadId: fh.feeHeadId, name: fh.feeHeadName, amount: fh.pendingAmount })),
    expiresAt: "2024-04-30T23:59:59",
    sentVia: { sms: true, whatsapp: index % 2 === 0, email: true },
    sentAt: "2024-04-01T10:00:00",
    viewCount: Math.floor(Math.random() * 5),
    lastViewedAt: index % 3 === 0 ? "2024-04-02T14:30:00" : undefined,
    status: "active",
    createdBy: "Admin",
    createdAt: "2024-04-01T09:00:00"
  }))

// Fee collection statistics
export function getFeeCollectionStats() {
  const totalStudents = studentsWithFees.length
  const totalFees = studentsWithFees.reduce((sum, s) => sum + s.netFee, 0)
  const collectedAmount = studentsWithFees.reduce((sum, s) => sum + s.paidAmount, 0)
  const pendingAmount = studentsWithFees.reduce((sum, s) => sum + s.pendingAmount, 0)
  
  const paidStudents = studentsWithFees.filter(s => s.feeStatus === "paid").length
  const partialStudents = studentsWithFees.filter(s => s.feeStatus === "partial").length
  const pendingStudents = studentsWithFees.filter(s => s.feeStatus === "pending").length
  const overdueStudents = studentsWithFees.filter(s => s.feeStatus === "overdue").length
  
  return {
    totalStudents,
    totalFees,
    collectedAmount,
    pendingAmount,
    collectionRate: ((collectedAmount / totalFees) * 100).toFixed(1),
    paidStudents,
    partialStudents,
    pendingStudents,
    overdueStudents,
    activePaymentLinks: paymentLinks.filter(l => l.status === "active").length
  }
}

export function getStudentById(id: string): StudentWithFees | undefined {
  return studentsWithFees.find(s => s.id === id)
}

export function getStudentsByClass(className: string): StudentWithFees[] {
  return studentsWithFees.filter(s => s.class === className)
}

export function getStudentsByFeeStatus(status: StudentFeeStatus): StudentWithFees[] {
  return studentsWithFees.filter(s => s.feeStatus === status)
}

export function getFeeHeadById(id: string): FeeHead | undefined {
  return feeHeads.find(fh => fh.id === id)
}

export function getFeeStructureById(id: string): FeeStructure | undefined {
  return feeStructures.find(fs => fs.id === id)
}
