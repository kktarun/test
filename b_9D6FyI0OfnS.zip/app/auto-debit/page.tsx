import { DashboardLayout } from "@/components/dashboard-layout"
import { AutoDebitContent } from "@/components/auto-debit/auto-debit-content"

export default function AutoDebitPage() {
  return (
    <DashboardLayout>
      <AutoDebitContent />
    </DashboardLayout>
  )
}
