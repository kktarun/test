import { DashboardLayout } from "@/components/dashboard-layout"
import { GatewayAnalyticsContent } from "@/components/gateway-analytics/gateway-analytics-content"

export default function GatewayAnalyticsPage() {
  return (
    <DashboardLayout>
      <GatewayAnalyticsContent />
    </DashboardLayout>
  )
}
