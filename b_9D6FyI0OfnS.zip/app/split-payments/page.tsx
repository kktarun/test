import { DashboardLayout } from "@/components/dashboard-layout"
import { SplitPaymentsContent } from "@/components/split-payments/split-payments-content"

export default function SplitPaymentsPage() {
  return (
    <DashboardLayout>
      <SplitPaymentsContent />
    </DashboardLayout>
  )
}
