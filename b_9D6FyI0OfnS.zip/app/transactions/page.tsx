import { DashboardLayout } from "@/components/dashboard-layout"
import { TransactionsContent } from "@/components/transactions/transactions-content"

export default function TransactionsPage() {
  return (
    <DashboardLayout>
      <TransactionsContent />
    </DashboardLayout>
  )
}
