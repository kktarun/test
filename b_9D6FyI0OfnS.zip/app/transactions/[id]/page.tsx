"use client"

import { use, useMemo } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Calendar,
  Copy,
  Download,
  RotateCcw,
  User,
  CreditCard,
  Smartphone,
  Building2,
  Mail,
  Phone,
  GraduationCap,
  Hash,
  Wallet,
  Landmark,
  AlertCircle,
  SplitSquareVertical,
  FileText,
  ArrowRight,
  CalendarClock,
  Banknote,
  TrendingUp,
  Globe,
  Layers,
  Receipt,
  History,
  XCircle,
  AlertTriangle,
  RefreshCw,
  ArrowUpRight,
  CircleDollarSign,
  Percent,
  ExternalLink,
  Loader2,
} from "lucide-react"
import Link from "next/link"
import { type Transaction } from "@/components/transactions/transactions-table"
import { useTransactionsData, type RawTransaction } from "@/hooks/use-transactions-data"
import { ScrollArea } from "@/components/ui/scroll-area"

// Transform raw JSON transaction data to Transaction interface
function transformRawTransaction(raw: RawTransaction): Transaction {
  const instituteName = typeof raw.institute === "string" ? raw.institute : "Unknown Institute"
  const orderAmount = raw.order_amount || 0
  const transactionAmount = raw.transaction_amount || orderAmount
  const vendorAmount = raw.vendor_amount || 0
  
  const statusMap: Record<string, Transaction["status"]> = {
    "success": "success",
    "completed": "success",
    "paid": "success",
    "failed": "failed",
    "failure": "failed",
    "pending": "pending",
    "processing": "pending",
    "refunded": "refunded",
    "partially_refunded": "partially_refunded",
    "chargeback": "chargeback",
    "disputed": "chargeback",
  }
  
  return {
    id: raw.id || "",
    orderId: raw.order_id || "",
    edvironOrderId: raw.edviron_order_id || raw.order_id || "",
    gatewayTransactionId: raw.gateway_transaction_id,
    bankReferenceNumber: raw.bank_reference_number,
    institute: instituteName,
    studentName: raw.student_name || "Unknown",
    studentId: raw.student_id || "",
    orderAmount: orderAmount,
    transactionAmount: transactionAmount,
    vendorAmount: vendorAmount,
    amount: transactionAmount,
    gateway: raw.gateway || "",
    paymentMode: raw.payment_mode || "",
    channel: raw.channel || "Online",
    status: statusMap[raw.status?.toLowerCase()] || "pending",
    statusReason: raw.status_reason || "",
    date: raw.date || "",
    time: raw.time || "",
    payerEmail: raw.payer_email || "",
    payerMobile: raw.payer_mobile || "",
    studentClass: raw.student_class || "",
    studentDivision: raw.student_division || "",
    enrollmentNumber: raw.enrollment_number || "",
    rollNumber: raw.roll_number || "",
    feeType: raw.fee_type || "",
    instrumentType: raw.instrument_type || raw.payment_mode || "",
    instrumentDetails: raw.instrument_details || "",
    psp: raw.psp || undefined,
    cardBrand: raw.card_brand || undefined,
    cardType: raw.card_type || undefined,
    cardIssuer: raw.card_issuer || raw.card_issuing_bank || undefined,
    bankName: raw.bank_name || undefined,
    upiId: raw.upi_id || undefined,
    walletName: raw.wallet_name || undefined,
    isSettled: raw.is_settled === 1,
    settlementId: raw.settlement_id || undefined,
    settlementUtr: raw.settlement_utr || undefined,
    settlementDate: raw.settlement_date || undefined,
    captureApiUsed: raw.capture_api_used === 1,
    captureStatus: raw.capture_status || "not_applicable",
    isSplitPayment: raw.is_split_payment === 1,
    splitDetails: raw.split_details?.splits ? {
      totalSplits: raw.split_details.splits.length,
      splits: raw.split_details.splits.map(s => ({
        beneficiary: s.beneficiary,
        account: s.account,
        ifsc: s.ifsc,
        amount: s.amount,
        percentage: s.percentage,
        status: s.status as "settled" | "pending",
      })),
    } : undefined,
    vendor: raw.split_details?.splits?.find(s => s.beneficiary !== instituteName)?.beneficiary || "",
    mdrAmount: raw.mdr_amount || 0,
    mdrPercentage: raw.mdr_percentage || 0,
    mdrBearing: raw.mdr_bearing as "surcharge" | "merchant_bearing" | undefined,
    erpCommission: raw.erp_commission || 0,
    erpCommissionPercentage: raw.erp_commission_percentage || 0,
    customFields: raw.custom_fields || {},
    refundDetails: raw.refund_details ? {
      refundId: raw.refund_details.refundId,
      refundDate: raw.refund_details.refundDate,
      refundedAmount: raw.refund_details.originalOrderAmount || 0,
      originalOrderAmount: raw.refund_details.originalOrderAmount || 0,
      pgChargesDeducted: raw.refund_details.pgChargesDeducted || 0,
      erpCommissionDeducted: raw.refund_details.erpCommissionDeducted || 0,
      netRefundToParent: raw.refund_details.netRefundToParent || 0,
      refundReason: raw.refund_details.refundReason || "",
      refundStatus: raw.refund_details.refundStatus as "initiated" | "processing" | "completed" | "failed",
      refundArn: raw.refund_details.refundArn,
    } : undefined,
    chargebackDetails: raw.chargeback_details ? {
      chargebackId: raw.chargeback_details.chargebackId,
      chargebackDate: raw.chargeback_details.raisedDate,
      chargebackAmount: raw.chargeback_details.chargebackAmount || 0,
      chargebackReason: raw.chargeback_details.chargebackReason || "",
      chargebackStatus: raw.chargeback_details.chargebackStatus as "initiated" | "under_review" | "won" | "lost" | "closed",
      disputeDeadline: raw.chargeback_details.dueDate,
      responseSubmittedAt: raw.chargeback_details.responseSubmittedAt,
      evidenceSubmitted: raw.chargeback_details.evidenceSubmitted || false,
      arbNumber: raw.chargeback_details.arbNumber,
      chargebackFee: raw.chargeback_details.chargebackFee || 0,
    } : undefined,
    transactionLifecycle: raw.transaction_lifecycle?.map(e => ({
      event: e.event,
      timestamp: e.timestamp,
      description: e.description || e.event,
      status: e.status as "success" | "info" | "warning" | "error",
    })),
  }
}

interface TransactionDetailPageProps {
  params: Promise<{
    id: string
  }>
}

const statusColors = {
  success: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
  refunded: "bg-info/10 text-info border-info/20",
  user_dropped: "bg-gray-500/10 text-gray-400 border-gray-500/20",
}

const pspColors: Record<string, string> = {
  PhonePe: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  "Google Pay": "bg-blue-500/10 text-blue-400 border-blue-500/20",
  Paytm: "bg-sky-500/10 text-sky-400 border-sky-500/20",
  CRED: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  "Amazon Pay": "bg-orange-500/10 text-orange-400 border-orange-500/20",
  WhatsApp: "bg-green-500/10 text-green-400 border-green-500/20",
}

const cardBrandColors: Record<string, string> = {
  Visa: "bg-blue-600/10 text-blue-400 border-blue-600/20",
  Mastercard: "bg-red-500/10 text-red-400 border-red-500/20",
  RuPay: "bg-green-600/10 text-green-400 border-green-600/20",
  Amex: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
}

export default function TransactionDetailPage({ params }: TransactionDetailPageProps) {
  const { id } = use(params)
  
  // Load transactions from JSON file using hook
  const { transactions: rawTransactions, isLoading } = useTransactionsData()
  
  // Transform and find the specific transaction
  const transaction = useMemo(() => {
    const transformed = rawTransactions.map(transformRawTransaction)
    return transformed.find((t) => t.id === id)
  }, [rawTransactions, id])

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading transaction details...</p>
        </div>
      </DashboardLayout>
    )
  }

  if (!transaction) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
          <AlertCircle className="h-16 w-16 text-muted-foreground" />
          <h2 className="text-xl font-semibold">Transaction Not Found</h2>
          <p className="text-muted-foreground">The transaction with ID "{id}" could not be found.</p>
          <Link href="/transactions">
            <Button variant="outline" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Transactions
            </Button>
          </Link>
        </div>
      </DashboardLayout>
    )
  }

  const getPaymentIcon = () => {
    switch (transaction.paymentMode) {
      case "UPI":
      case "UPI Autopay":
        return <Smartphone className="h-5 w-5" />
      case "Credit Card":
      case "Debit Card":
      case "Card EMI":
        return <CreditCard className="h-5 w-5" />
      case "Net Banking":
        return <Landmark className="h-5 w-5" />
      case "Wallet":
        return <Wallet className="h-5 w-5" />
      case "Bank Transfer":
        return <Building2 className="h-5 w-5" />
      case "Split and Pay":
        return <SplitSquareVertical className="h-5 w-5" />
      case "Pay Later":
        return <CalendarClock className="h-5 w-5" />
      case "International Payment":
        return <Globe className="h-5 w-5" />
      default:
        return <Receipt className="h-5 w-5" />
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/transactions">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                Back to Transactions
              </Button>
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Download Receipt
            </Button>
            {transaction.status === "success" && (
              <Button variant="outline" size="sm" className="gap-2 text-destructive hover:text-destructive">
                <RotateCcw className="h-4 w-4" />
                Initiate Refund
              </Button>
            )}
          </div>
        </div>

        {/* Transaction Overview */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <Card className="bg-card border-border lg:col-span-2">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    {getPaymentIcon()}
                    <CardTitle>{transaction.orderId}</CardTitle>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    <span>Transaction ID: {transaction.id}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-5 w-5"
                      onClick={() => copyToClipboard(transaction.id)}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground font-mono">
                    Edviron Order ID: {transaction.edvironOrderId}
                  </p>
                  {transaction.gatewayTransactionId && (
                    <p className="text-xs text-muted-foreground font-mono">
                      Gateway Txn ID: {transaction.gatewayTransactionId}
                    </p>
                  )}
                </div>
                <Badge className={statusColors[transaction.status]}>{transaction.status.replace("_", " ").toUpperCase()}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-secondary/50 p-4 rounded-lg border border-border">
                <p className="text-sm text-muted-foreground mb-1">Status Reason</p>
                <p className="text-sm font-medium">{transaction.statusReason}</p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Order Amount</p>
                  <p className="text-2xl font-bold">₹{transaction.orderAmount.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Transaction Amount</p>
                  <p className="text-2xl font-bold">₹{transaction.transactionAmount.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Vendor Amount</p>
                  <p className="text-2xl font-bold text-success">₹{transaction.vendorAmount.toLocaleString()}</p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-4 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Gateway</p>
                  <p className="font-medium">{transaction.gateway}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Mode</p>
                  <p className="font-medium">{transaction.paymentMode}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Channel</p>
                  <p className="font-medium">{transaction.channel}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Date & Time</p>
                  <p className="font-medium">
                    {transaction.date} {transaction.time}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Info Sidebar */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-base">Quick Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-xs text-muted-foreground uppercase mb-1">Institute</p>
                <p className="font-medium text-sm">{transaction.institute}</p>
              </div>
              <Separator />
              <div>
                <p className="text-xs text-muted-foreground uppercase mb-1">Student</p>
                <p className="font-medium text-sm">{transaction.studentName}</p>
                <p className="text-xs text-muted-foreground">{transaction.studentId}</p>
              </div>
              <Separator />
              <div>
                <p className="text-xs text-muted-foreground uppercase mb-1">ERP Commission</p>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm text-emerald-500">
                    ₹{(transaction.erpCommission || 0).toLocaleString()}
                  </p>
                  {transaction.erpCommissionPercentage && (
                    <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-400">
                      {transaction.erpCommissionPercentage}%
                    </Badge>
                  )}
                </div>
              </div>
              <Separator />
              <div>
                <p className="text-xs text-muted-foreground uppercase mb-1">MDR</p>
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm">
                    ₹{(transaction.mdrAmount || 0).toLocaleString()}
                  </p>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${
                      transaction.mdrBearing === "surcharge" 
                        ? "bg-red-500/10 text-red-400" 
                        : "bg-green-500/10 text-green-400"
                    }`}
                  >
                    {transaction.mdrBearing === "surcharge" ? "Surcharge" : "Merchant"}
                  </Badge>
                </div>
              </div>
              {transaction.isSettled && (
                <>
                  <Separator />
                  <div>
                    <p className="text-xs text-muted-foreground uppercase mb-1">Settlement</p>
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="h-4 w-4 text-success" />
                      <p className="font-medium text-sm text-success">Settled</p>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{transaction.settlementDate}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="receipt" className="w-full">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="receipt">Receipt</TabsTrigger>
<TabsTrigger value="payment-details">Payment Details</TabsTrigger>
                  <TabsTrigger value="student-details">Student Details</TabsTrigger>
                  <TabsTrigger value="split-pay">Split & Pay</TabsTrigger>
                  <TabsTrigger value="financing">Financing</TabsTrigger>
                  <TabsTrigger value="settlement">Settlement</TabsTrigger>
                  <TabsTrigger value="lifecycle">
                    <History className="h-4 w-4 mr-1" />
                    Lifecycle
                  </TabsTrigger>
                  <TabsTrigger value="refund">Refund</TabsTrigger>
                  {transaction.chargebackDetails && (
                    <TabsTrigger value="chargeback" className="text-destructive">
                      <AlertTriangle className="h-4 w-4 mr-1" />
                      Chargeback
                    </TabsTrigger>
                  )}
                </TabsList>

          {/* Receipt Tab */}
          <TabsContent value="receipt">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Receipt className="h-5 w-5" />
                  Transaction Receipt
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Order IDs */}
                <div className="grid grid-cols-3 gap-4 p-4 rounded-lg bg-secondary/30">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">School Order ID</p>
                    <p className="font-mono text-sm font-medium">{transaction.orderId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Edviron Order ID</p>
                    <p className="font-mono text-sm font-medium">{transaction.edvironOrderId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Gateway Txn ID</p>
                    <p className="font-mono text-sm font-medium">{transaction.gatewayTransactionId || transaction.bankReferenceNumber || "-"}</p>
                  </div>
                </div>

                {/* Amount Breakdown */}
                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase">Amount Breakdown</h4>
                  <div className="space-y-2 bg-secondary/30 p-4 rounded-lg">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Order Amount</span>
                      <span className="font-medium">₹{transaction.orderAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Transaction Amount</span>
                      <span className="font-medium">₹{transaction.transactionAmount.toLocaleString()}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">MDR / PG Charges ({transaction.mdrPercentage || 2}%)</span>
                      <span className="text-destructive">-₹{(transaction.mdrAmount || Math.floor(transaction.transactionAmount * 0.02)).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">ERP Commission ({transaction.erpCommissionPercentage || 1}%)</span>
                      <span className="text-emerald-500">₹{(transaction.erpCommission || Math.floor(transaction.transactionAmount * 0.01)).toLocaleString()}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between font-semibold">
                      <span>Net Settlement to Institute</span>
                      <span className="text-primary">₹{transaction.vendorAmount.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* MDR Bearing */}
                <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                  <div>
                    <p className="text-sm font-medium">MDR Bearing</p>
                    <p className="text-xs text-muted-foreground">Who pays the payment gateway charges</p>
                  </div>
                  <Badge 
                    className={`${
                      transaction.mdrBearing === "surcharge" 
                        ? "bg-red-500/10 text-red-400 border-red-500/20" 
                        : "bg-green-500/10 text-green-400 border-green-500/20"
                    }`}
                  >
                    {transaction.mdrBearing === "surcharge" ? "Surcharge (Parent Pays)" : "Merchant Bearing (Institute Pays)"}
                  </Badge>
                </div>

                {/* Payment Mode Details */}
                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase">Payment Mode Details</h4>
                  <div className="grid grid-cols-2 gap-4 bg-secondary/30 p-4 rounded-lg">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Mode</span>
                      <span className="font-medium">{transaction.paymentMode}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Channel</span>
                      <span className="font-medium">{transaction.channel}</span>
                    </div>
                    {transaction.cardBrand && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Card Network</span>
                        <Badge className={cardBrandColors[transaction.cardBrand] || "bg-secondary"}>
                          {transaction.cardBrand}
                        </Badge>
                      </div>
                    )}
                    {transaction.cardIssuer && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Issuing Bank</span>
                        <span className="font-medium">{transaction.cardIssuer}</span>
                      </div>
                    )}
                    {transaction.psp && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">UPI PSP</span>
                        <Badge className={pspColors[transaction.psp] || "bg-secondary"}>
                          {transaction.psp}
                        </Badge>
                      </div>
                    )}
                    {transaction.upiId && (
                      <div className="flex justify-between text-sm col-span-2">
                        <span className="text-muted-foreground">UPI ID</span>
                        <span className="font-mono text-xs">{transaction.upiId}</span>
                      </div>
                    )}
                    {transaction.walletName && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Wallet</span>
                        <Badge variant="outline">{transaction.walletName}</Badge>
                      </div>
                    )}
                    {transaction.bankName && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Bank</span>
                        <span className="font-medium">{transaction.bankName}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payment Details Tab */}
          <TabsContent value="payment-details">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base">Payment Gateway Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Gateway Information</h4>
                    <div className="space-y-3 bg-secondary/50 p-4 rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Payment Gateway</span>
                        <span className="font-medium">{transaction.gateway}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Gateway Transaction ID</span>
                        <span className="font-mono text-sm">{transaction.gatewayTransactionId || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Bank Reference Number</span>
                        <span className="font-mono text-sm">{transaction.bankReferenceNumber || "-"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Payment Mode</span>
                        <span className="font-medium">{transaction.paymentMode}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Channel</span>
                        <span className="font-medium">{transaction.channel}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Instrument Details</h4>
                    <div className="space-y-3 bg-secondary/50 p-4 rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Instrument Type</span>
                        <span className="font-medium">{transaction.instrumentType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Details</span>
                        <span className="font-medium">{transaction.instrumentDetails}</span>
                      </div>
                      {transaction.cardBrand && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Card Brand</span>
                          <Badge className={cardBrandColors[transaction.cardBrand] || "bg-secondary"}>
                            {transaction.cardBrand}
                          </Badge>
                        </div>
                      )}
                      {transaction.cardType && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Card Type</span>
                          <span className="font-medium">{transaction.cardType}</span>
                        </div>
                      )}
                      {transaction.cardIssuer && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">Issuing Bank</span>
                          <span className="font-medium">{transaction.cardIssuer}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Capture Details */}
                {transaction.captureApiUsed && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Capture Details</h4>
                    <div className="space-y-3 bg-secondary/50 p-4 rounded-lg">
                      <div className="grid grid-cols-4 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Capture API Used</p>
                          <p className="font-medium">{transaction.captureApiUsed ? "Yes" : "No"}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Capture Status</p>
                          <Badge className={transaction.captureStatus === "captured" ? "bg-success/20 text-success" : "bg-warning/20 text-warning"}>
                            {transaction.captureStatus.toUpperCase()}
                          </Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Authorized At</p>
                          <p className="font-medium text-sm">{transaction.authorizedAt || "-"}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Captured At</p>
                          <p className="font-medium text-sm">{transaction.capturedAt || "-"}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* International Payment Details */}
                {transaction.isInternational && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Globe className="h-4 w-4" />
                      International Payment Details
                    </h4>
                    <div className="space-y-3 bg-blue-500/5 border border-blue-500/20 p-4 rounded-lg">
                      <div className="grid grid-cols-4 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Payment Method</p>
                          <p className="font-medium capitalize">{transaction.internationalMethod}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Original Currency</p>
                          <Badge variant="outline">{transaction.currency}</Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Original Amount</p>
                          <p className="font-medium">{transaction.currency} {transaction.originalAmount?.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Exchange Rate</p>
                          <p className="font-medium">1 {transaction.currency} = ₹{transaction.exchangeRate}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Autopay Details */}
                {transaction.autopayDetails && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <CalendarClock className="h-4 w-4" />
                      Autopay / Mandate Details
                    </h4>
                    <div className="space-y-3 bg-cyan-500/5 border border-cyan-500/20 p-4 rounded-lg">
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Mandate ID</p>
                          <p className="font-mono text-sm">{transaction.autopayDetails.mandateId}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Mandate Type</p>
                          <Badge variant="outline">{transaction.autopayDetails.mandateType}</Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Status</p>
                          <Badge className={
                            transaction.autopayDetails.mandateStatus === "active" 
                              ? "bg-green-500/10 text-green-400"
                              : "bg-yellow-500/10 text-yellow-400"
                          }>
                            {transaction.autopayDetails.mandateStatus}
                          </Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Max Amount</p>
                          <p className="font-medium">₹{transaction.autopayDetails.maxAmount.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Frequency</p>
                          <p className="font-medium capitalize">{transaction.autopayDetails.frequency.replace("_", " ")}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Valid Until</p>
                          <p className="font-medium">{transaction.autopayDetails.validUntil}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* School Counter Details */}
                {transaction.schoolCounterDetails && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Building2 className="h-4 w-4" />
                      School Counter Collection
                    </h4>
                    <div className="space-y-3 bg-amber-500/5 border border-amber-500/20 p-4 rounded-lg">
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Collection Mode</p>
                          <Badge variant="outline" className="capitalize">{transaction.schoolCounterDetails.mode.replace("_", " ")}</Badge>
                        </div>
                        {transaction.schoolCounterDetails.ddNumber && (
                          <div>
                            <p className="text-xs text-muted-foreground">DD Number</p>
                            <p className="font-mono text-sm">{transaction.schoolCounterDetails.ddNumber}</p>
                          </div>
                        )}
                        {transaction.schoolCounterDetails.chequeNumber && (
                          <div>
                            <p className="text-xs text-muted-foreground">Cheque Number</p>
                            <p className="font-mono text-sm">{transaction.schoolCounterDetails.chequeNumber}</p>
                          </div>
                        )}
                        {transaction.schoolCounterDetails.issuingBank && (
                          <div>
                            <p className="text-xs text-muted-foreground">Issuing Bank</p>
                            <p className="font-medium">{transaction.schoolCounterDetails.issuingBank}</p>
                          </div>
                        )}
                        {transaction.schoolCounterDetails.receiptNumber && (
                          <div>
                            <p className="text-xs text-muted-foreground">Receipt Number</p>
                            <p className="font-mono text-sm">{transaction.schoolCounterDetails.receiptNumber}</p>
                          </div>
                        )}
                        {transaction.schoolCounterDetails.collectedBy && (
                          <div>
                            <p className="text-xs text-muted-foreground">Collected By</p>
                            <p className="font-medium">{transaction.schoolCounterDetails.collectedBy}</p>
                          </div>
                        )}
                        {transaction.schoolCounterDetails.collectionDate && (
                          <div>
                            <p className="text-xs text-muted-foreground">Collection Date</p>
                            <p className="font-medium">{transaction.schoolCounterDetails.collectionDate}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Bank Transfer Details */}
                {transaction.bankTransferDetails && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Landmark className="h-4 w-4" />
                      Bank Transfer Details
                    </h4>
                    <div className="space-y-3 bg-secondary/50 p-4 rounded-lg">
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Transfer Type</p>
                          <Badge variant="outline" className="uppercase">{transaction.bankTransferDetails.type}</Badge>
                        </div>
                        {transaction.bankTransferDetails.bankName && (
                          <div>
                            <p className="text-xs text-muted-foreground">Bank Name</p>
                            <p className="font-medium">{transaction.bankTransferDetails.bankName}</p>
                          </div>
                        )}
                        {transaction.bankTransferDetails.utrNumber && (
                          <div>
                            <p className="text-xs text-muted-foreground">UTR Number</p>
                            <p className="font-mono text-sm">{transaction.bankTransferDetails.utrNumber}</p>
                          </div>
                        )}
                        {transaction.bankTransferDetails.branchName && (
                          <div>
                            <p className="text-xs text-muted-foreground">Branch</p>
                            <p className="font-medium">{transaction.bankTransferDetails.branchName}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Student Details Tab */}
          <TabsContent value="student-details">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <GraduationCap className="h-5 w-5" />
                  Student Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Personal Details</h4>
                    <div className="space-y-3 bg-secondary/50 p-4 rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Student Name</span>
                        <span className="font-medium">{transaction.studentName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Student ID</span>
                        <span className="font-mono text-sm">{transaction.studentId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Email</span>
                        <span className="text-sm">{transaction.payerEmail}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Mobile</span>
                        <span className="font-medium">{transaction.payerMobile}</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Academic Details</h4>
                    <div className="space-y-3 bg-secondary/50 p-4 rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Institute</span>
                        <span className="font-medium">{transaction.institute}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Class / Division</span>
                        <span className="font-medium">{transaction.studentClass} - {transaction.studentDivision}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Roll Number</span>
                        <span className="font-medium">{transaction.rollNumber}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Enrollment Number</span>
                        <span className="font-mono text-sm">{transaction.enrollmentNumber}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase">Fee Details</h4>
                  <div className="bg-secondary/50 p-4 rounded-lg">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Fee Type</span>
                      <span className="font-medium">{transaction.feeType}</span>
                    </div>
                  </div>
                </div>

                {/* Custom Fields */}
                {transaction.customFields && Object.keys(transaction.customFields).length > 0 && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Custom Fields from ERP</h4>
                    <div className="grid grid-cols-4 gap-4">
                      {Object.entries(transaction.customFields).map(([key, value]) => (
                        <div key={key} className="bg-secondary/50 p-3 rounded-lg">
                          <p className="text-xs text-muted-foreground capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                          <p className="font-medium text-sm">{String(value)}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Split & Pay Tab */}
          <TabsContent value="split-pay">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <SplitSquareVertical className="h-5 w-5" />
                  Split & Pay Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {transaction.paymentMode === "Split and Pay" ? (
                  <>
                    {/* Split Pay Timeline with Detailed Charges */}
                    {transaction.splitPayTimeline && transaction.splitPayTimeline.length > 0 && (
                      <div className="space-y-4">
                        <h4 className="text-sm font-semibold text-muted-foreground uppercase">Payment Schedule with Charges</h4>
                        <div className="space-y-4">
                          {transaction.splitPayTimeline.map((split, index) => (
                            <div 
                              key={index}
                              className={`rounded-lg overflow-hidden ${
                                split.status === "completed" 
                                  ? "bg-success/5 border border-success/20"
                                  : split.status === "failed"
                                    ? "bg-destructive/5 border border-destructive/20"
                                    : "bg-secondary/30 border border-border"
                              }`}
                            >
                              {/* Header Row */}
                              <div className="flex items-center justify-between p-4 border-b border-border/50">
                                <div className="flex items-center gap-4">
                                  <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                                    split.status === "completed" 
                                      ? "bg-success/20 text-success"
                                      : split.status === "failed"
                                        ? "bg-destructive/20 text-destructive"
                                        : "bg-secondary text-muted-foreground"
                                  }`}>
                                    {split.status === "completed" ? (
                                      <CheckCircle2 className="h-5 w-5" />
                                    ) : split.status === "failed" ? (
                                      <XCircle className="h-5 w-5" />
                                    ) : (
                                      <Clock className="h-5 w-5" />
                                    )}
                                  </div>
                                  <div>
                                    <p className="font-medium">Payment {split.splitNumber} of {transaction.splitPayTimeline.length}</p>
                                    <div className="flex items-center gap-2 mt-1">
                                      {split.paymentMode && (
                                        <Badge variant="outline" className="text-xs">
                                          {split.paymentMode}
                                        </Badge>
                                      )}
                                      <Badge 
                                        className={`text-xs ${
                                          split.status === "completed" 
                                            ? "bg-success/10 text-success"
                                            : split.status === "failed"
                                              ? "bg-destructive/10 text-destructive"
                                              : "bg-warning/10 text-warning"
                                        }`}
                                      >
                                        {split.status.toUpperCase()}
                                      </Badge>
                                    </div>
                                  </div>
                                </div>
                                <div className="text-right">
                                  <p className="text-xl font-bold">₹{split.amount.toLocaleString()}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {split.status === "completed" && split.paidDate 
                                      ? `Paid: ${split.paidDate}${split.paidTime ? ` at ${split.paidTime}` : ''}`
                                      : split.dueDate 
                                        ? `Due: ${split.dueDate}`
                                        : "Scheduled"}
                                  </p>
                                </div>
                              </div>
                              
                              {/* Charges Breakdown */}
                              <div className="p-4 bg-background/50">
                                <div className="grid grid-cols-5 gap-4 text-sm">
                                  {/* MDR */}
                                  <div className="text-center">
                                    <p className="text-xs text-muted-foreground mb-1">MDR ({split.mdrPercentage || 0}%)</p>
                                    <p className={`font-medium ${split.mdrAmount ? "text-destructive" : "text-muted-foreground"}`}>
                                      {split.mdrAmount ? `-₹${split.mdrAmount.toLocaleString()}` : "-"}
                                    </p>
                                  </div>
                                  {/* ERP Commission */}
                                  <div className="text-center">
                                    <p className="text-xs text-muted-foreground mb-1">ERP Comm ({split.erpCommissionPercentage || 0}%)</p>
                                    <p className={`font-medium ${split.erpCommission ? "text-emerald-500" : "text-muted-foreground"}`}>
                                      {split.erpCommission ? `₹${split.erpCommission.toLocaleString()}` : "-"}
                                    </p>
                                  </div>
                                  {/* Net Amount */}
                                  <div className="text-center">
                                    <p className="text-xs text-muted-foreground mb-1">Net Settlement</p>
                                    <p className={`font-medium ${split.netAmount ? "text-primary" : "text-muted-foreground"}`}>
                                      {split.netAmount ? `₹${split.netAmount.toLocaleString()}` : "-"}
                                    </p>
                                  </div>
                                  {/* Gateway Txn ID */}
                                  <div className="text-center">
                                    <p className="text-xs text-muted-foreground mb-1">Gateway Txn ID</p>
                                    <p className="font-mono text-xs truncate">
                                      {split.gatewayTransactionId || "-"}
                                    </p>
                                  </div>
                                  {/* Transaction ID */}
                                  <div className="text-center">
                                    <p className="text-xs text-muted-foreground mb-1">Txn ID</p>
                                    <p className="font-mono text-xs truncate">
                                      {split.transactionId || "-"}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        {/* Summary */}
                        <div className="p-4 rounded-lg bg-primary/5 border border-primary/20 space-y-3">
                          <h5 className="text-sm font-semibold">Split Pay Summary</h5>
                          <div className="grid grid-cols-5 gap-4 text-sm">
                            <div>
                              <p className="text-xs text-muted-foreground">Total Order</p>
                              <p className="font-semibold">₹{transaction.orderAmount.toLocaleString()}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Total MDR</p>
                              <p className="font-semibold text-destructive">
                                -₹{transaction.splitPayTimeline.reduce((sum, s) => sum + (s.mdrAmount || 0), 0).toLocaleString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Total ERP Comm</p>
                              <p className="font-semibold text-emerald-500">
                                ₹{transaction.splitPayTimeline.reduce((sum, s) => sum + (s.erpCommission || 0), 0).toLocaleString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Net Settlement</p>
                              <p className="font-semibold text-primary">
                                ₹{transaction.splitPayTimeline.reduce((sum, s) => sum + (s.netAmount || 0), 0).toLocaleString()}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Payments Done</p>
                              <p className="font-semibold">
                                {transaction.splitPayTimeline.filter(s => s.status === "completed").length}/{transaction.splitPayTimeline.length}
                              </p>
                            </div>
                          </div>
                        </div>
                        
                        {/* Progress */}
                        <div className="pt-2">
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-muted-foreground">Payment Progress</span>
                            <span className="font-medium">
                              {transaction.splitPayTimeline.filter(s => s.status === "completed").length} of {transaction.splitPayTimeline.length} completed
                            </span>
                          </div>
                          <Progress 
                            value={(transaction.splitPayTimeline.filter(s => s.status === "completed").length / transaction.splitPayTimeline.length) * 100} 
                            className="h-2"
                          />
                        </div>
                      </div>
                    )}

                    {/* Multi-mode Split Pay */}
                    {transaction.splitPayModes && transaction.splitPayModes.length > 0 && (
                      <div className="space-y-4">
                        <h4 className="text-sm font-semibold text-muted-foreground uppercase">Payment Modes Used</h4>
                        <div className="space-y-3">
                          {transaction.splitPayModes.map((mode, index) => (
                            <div 
                              key={index}
                              className={`flex items-center justify-between p-4 rounded-lg ${
                                mode.status === "success" 
                                  ? "bg-success/10 border border-success/20"
                                  : mode.status === "failed"
                                    ? "bg-destructive/10 border border-destructive/20"
                                    : "bg-warning/10 border border-warning/20"
                              }`}
                            >
                              <div className="flex items-center gap-4">
                                <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                                  mode.status === "success" 
                                    ? "bg-success/20 text-success"
                                    : mode.status === "failed"
                                      ? "bg-destructive/20 text-destructive"
                                      : "bg-warning/20 text-warning"
                                }`}>
                                  {mode.mode === "Credit Card" || mode.mode === "Debit Card" ? (
                                    <CreditCard className="h-5 w-5" />
                                  ) : mode.mode === "UPI" ? (
                                    <Smartphone className="h-5 w-5" />
                                  ) : mode.mode === "Net Banking" ? (
                                    <Landmark className="h-5 w-5" />
                                  ) : (
                                    <Wallet className="h-5 w-5" />
                                  )}
                                </div>
                                <div>
                                  <p className="font-medium">{mode.mode}</p>
                                  <div className="flex items-center gap-2 mt-1">
                                    {mode.cardNetwork && (
                                      <Badge className={cardBrandColors[mode.cardNetwork] || "bg-secondary"} variant="outline">
                                        {mode.cardNetwork}
                                      </Badge>
                                    )}
                                    {mode.upiPsp && (
                                      <Badge className={pspColors[mode.upiPsp] || "bg-secondary"} variant="outline">
                                        {mode.upiPsp}
                                      </Badge>
                                    )}
                                    {mode.bankName && (
                                      <Badge variant="outline">{mode.bankName}</Badge>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-lg font-semibold">₹{mode.amount.toLocaleString()}</p>
                                <Badge className={
                                  mode.status === "success" 
                                    ? "bg-success/10 text-success"
                                    : mode.status === "failed"
                                      ? "bg-destructive/10 text-destructive"
                                      : "bg-warning/10 text-warning"
                                }>
                                  {mode.status.toUpperCase()}
                                </Badge>
                                {mode.transactionId && (
                                  <p className="text-[10px] font-mono text-muted-foreground mt-1">{mode.transactionId}</p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                        
                        {/* Total */}
                        <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                          <div className="flex justify-between">
                            <span className="font-medium">Total Amount</span>
                            <span className="text-xl font-bold text-primary">
                              ₹{transaction.splitPayModes.reduce((sum, m) => sum + m.amount, 0).toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-12">
                    <div className="flex justify-center mb-4">
                      <div className="h-16 w-16 rounded-full bg-secondary/50 flex items-center justify-center">
                        <SplitSquareVertical className="h-8 w-8 text-muted-foreground" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Not a Split & Pay Transaction</h3>
                    <p className="text-sm text-muted-foreground">
                      This transaction was paid in a single payment using {transaction.paymentMode}.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Financing Tab */}
          <TabsContent value="financing">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Financing Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {transaction.financingCategory ? (
                  <>
                    {/* Financing Overview */}
                    <div className="grid grid-cols-4 gap-4">
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">Category</p>
                        <Badge variant="outline" className="mt-1 capitalize">
                          {transaction.financingCategory.replace("_", " ")}
                        </Badge>
                      </div>
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">Type</p>
                        <Badge variant="outline" className="mt-1 capitalize">
                          {transaction.financingType?.replace("_", " ") || "-"}
                        </Badge>
                      </div>
                      {transaction.emiTenure && (
                        <div className="bg-secondary/50 p-4 rounded-lg">
                          <p className="text-xs text-muted-foreground uppercase">Tenure</p>
                          <p className="font-medium">{transaction.emiTenure} Months</p>
                        </div>
                      )}
                      {transaction.emiAmount && (
                        <div className="bg-secondary/50 p-4 rounded-lg">
                          <p className="text-xs text-muted-foreground uppercase">EMI Amount</p>
                          <p className="font-medium">₹{transaction.emiAmount.toLocaleString()}/month</p>
                        </div>
                      )}
                    </div>

                    {/* Card EMI Details */}
                    {transaction.financingCategory === "card_emi" && (
                      <div className="space-y-4">
                        <h4 className="text-sm font-semibold text-muted-foreground uppercase">Card EMI Details</h4>
                        <div className="grid grid-cols-3 gap-4 bg-secondary/50 p-4 rounded-lg">
                          <div>
                            <p className="text-xs text-muted-foreground">Card Network</p>
                            <Badge className={cardBrandColors[transaction.cardBrand || ""] || "bg-secondary"}>
                              {transaction.cardBrand}
                            </Badge>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Issuing Bank</p>
                            <p className="font-medium">{transaction.cardIssuingBank || transaction.cardIssuer}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Cost Bearing</p>
                            <Badge variant="outline" className="capitalize">
                              {transaction.emiCostBearing || transaction.partialCostSharing?.replace("_", " + ")}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* NBFC Details */}
                    {transaction.financingCategory === "nbfc_financing" && (
                      <div className="space-y-4">
                        <h4 className="text-sm font-semibold text-muted-foreground uppercase">NBFC Partner Details</h4>
                        <div className="grid grid-cols-2 gap-4 bg-secondary/50 p-4 rounded-lg">
                          <div>
                            <p className="text-xs text-muted-foreground">NBFC Partner</p>
                            <p className="font-medium">{transaction.nbfcPartner}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Collection Type</p>
                            <Badge variant="outline" className="capitalize">
                              {transaction.financingCollectionType?.replace("_", " ")}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Financing Charges Breakdown */}
                    {transaction.financingCharges && (
                      <div className="space-y-4">
                        <h4 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                          <Percent className="h-4 w-4" />
                          Charges Breakdown
                        </h4>
                        <div className="bg-gradient-to-br from-indigo-500/5 to-purple-500/5 border border-indigo-500/20 p-4 rounded-lg space-y-4">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">Total Financing Charges</span>
                            <span className="font-semibold text-lg">₹{transaction.financingCharges.totalCharges.toLocaleString()}</span>
                          </div>
                          <Separator />
                          <div className="space-y-3">
                            {/* Parent Bears */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-red-500" />
                                <span className="text-sm text-muted-foreground">
                                  Parent Bears ({transaction.financingCharges.parentChargePercentage}%)
                                </span>
                              </div>
                              <span className="font-medium text-red-400">
                                ₹{transaction.financingCharges.parentCharge.toLocaleString()}
                              </span>
                            </div>
                            {/* Institute Bears */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-green-500" />
                                <span className="text-sm text-muted-foreground">
                                  Institute Bears ({transaction.financingCharges.instituteChargePercentage}%)
                                </span>
                              </div>
                              <span className="font-medium text-green-400">
                                ₹{transaction.financingCharges.instituteCharge.toLocaleString()}
                              </span>
                            </div>
                            {/* Bank Bears */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-blue-500" />
                                <span className="text-sm text-muted-foreground">
                                  Bank Bears ({transaction.financingCharges.bankChargePercentage}%)
                                </span>
                              </div>
                              <span className="font-medium text-blue-400">
                                ₹{transaction.financingCharges.bankCharge.toLocaleString()}
                              </span>
                            </div>
                          </div>
                          
                          {/* Visual Bar */}
                          <div className="pt-2">
                            <div className="flex h-3 rounded-full overflow-hidden">
                              <div 
                                className="bg-red-500" 
                                style={{ width: `${(transaction.financingCharges.parentCharge / transaction.financingCharges.totalCharges) * 100}%` }}
                              />
                              <div 
                                className="bg-green-500" 
                                style={{ width: `${(transaction.financingCharges.instituteCharge / transaction.financingCharges.totalCharges) * 100}%` }}
                              />
                              <div 
                                className="bg-blue-500" 
                                style={{ width: `${(transaction.financingCharges.bankCharge / transaction.financingCharges.totalCharges) * 100}%` }}
                              />
                            </div>
                            <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                              <span>Parent: {transaction.financingCharges.parentChargePercentage}%</span>
                              <span>Institute: {transaction.financingCharges.instituteChargePercentage}%</span>
                              <span>Bank: {transaction.financingCharges.bankChargePercentage}%</span>
                            </div>
                          </div>

                          {transaction.financingCharges.subventionAmount && (
                            <>
                              <Separator />
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-muted-foreground">Subvention (Bank Subsidy)</span>
                                <span className="font-medium text-primary">
                                  ₹{transaction.financingCharges.subventionAmount.toLocaleString()}
                                </span>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-12">
                    <div className="flex justify-center mb-4">
                      <div className="h-16 w-16 rounded-full bg-secondary/50 flex items-center justify-center">
                        <TrendingUp className="h-8 w-8 text-muted-foreground" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">No Financing Applied</h3>
                    <p className="text-sm text-muted-foreground">
                      This transaction was paid directly without EMI or Pay Later options.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settlement Tab */}
          <TabsContent value="settlement">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Banknote className="h-5 w-5" />
                  Settlement Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {transaction.isSettled ? (
                  <>
                    <div className="grid grid-cols-4 gap-4">
                      <div className="bg-success/10 border border-success/20 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">Status</p>
                        <div className="flex items-center gap-2 mt-1">
                          <CheckCircle2 className="h-4 w-4 text-success" />
                          <span className="font-medium text-success">Settled</span>
                        </div>
                      </div>
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">Settlement ID</p>
                        <p className="font-mono text-sm">{transaction.settlementId}</p>
                      </div>
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">UTR</p>
                        <p className="font-mono text-sm">{transaction.settlementUtr}</p>
                      </div>
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">Settlement Date</p>
                        <p className="font-medium">{transaction.settlementDate}</p>
                      </div>
                    </div>

                    {/* Split Settlement */}
                    {transaction.isSplitPayment && transaction.splitDetails && (
                      <div className="space-y-4">
                        <h4 className="text-sm font-semibold text-muted-foreground uppercase">Split Settlement</h4>
                        <div className="space-y-3">
                          {transaction.splitDetails.splits.map((split, index) => (
                            <div 
                              key={index}
                              className={`flex items-center justify-between p-4 rounded-lg ${
                                split.status === "settled" 
                                  ? "bg-success/10 border border-success/20"
                                  : "bg-warning/10 border border-warning/20"
                              }`}
                            >
                              <div>
                                <p className="font-medium">{split.beneficiary}</p>
                                <p className="text-xs text-muted-foreground font-mono">
                                  {split.account} | {split.ifsc}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="font-semibold">₹{split.amount.toLocaleString()}</p>
                                <p className="text-xs text-muted-foreground">{split.percentage}%</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-12">
                    <div className="flex justify-center mb-4">
                      <div className="h-16 w-16 rounded-full bg-warning/10 flex items-center justify-center">
                        <Clock className="h-8 w-8 text-warning" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Settlement Pending</h3>
                    <p className="text-sm text-muted-foreground">
                      This transaction is awaiting settlement. Expected within T+1 to T+3 days.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Refund Tab */}
          <TabsContent value="refund">
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <RefreshCw className="h-5 w-5" />
                  Refund Details
                </CardTitle>
                {transaction.status === "success" && (
                  <Button size="sm" variant="destructive" className="gap-2">
                    <RotateCcw className="h-4 w-4" />
                    Initiate Refund
                  </Button>
                )}
              </CardHeader>
              <CardContent className="space-y-6">
                {transaction.refundDetails ? (
                  <>
                    {/* Refund Status */}
                    <div className="grid grid-cols-4 gap-4">
                      <div className={`p-4 rounded-lg ${
                        transaction.refundDetails.refundStatus === "completed"
                          ? "bg-success/10 border border-success/20"
                          : transaction.refundDetails.refundStatus === "failed"
                            ? "bg-destructive/10 border border-destructive/20"
                            : "bg-warning/10 border border-warning/20"
                      }`}>
                        <p className="text-xs text-muted-foreground uppercase">Status</p>
                        <Badge className={
                          transaction.refundDetails.refundStatus === "completed"
                            ? "bg-success/20 text-success"
                            : transaction.refundDetails.refundStatus === "failed"
                              ? "bg-destructive/20 text-destructive"
                              : "bg-warning/20 text-warning"
                        }>
                          {transaction.refundDetails.refundStatus.toUpperCase()}
                        </Badge>
                      </div>
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">Refund ID</p>
                        <p className="font-mono text-sm">{transaction.refundDetails.refundId}</p>
                      </div>
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">Refund Date</p>
                        <p className="font-medium">{transaction.refundDetails.refundDate}</p>
                      </div>
                      {transaction.refundDetails.refundArn && (
                        <div className="bg-secondary/50 p-4 rounded-lg">
                          <p className="text-xs text-muted-foreground uppercase">ARN</p>
                          <p className="font-mono text-xs">{transaction.refundDetails.refundArn}</p>
                        </div>
                      )}
                    </div>

                    {/* Refund Reason */}
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <p className="text-xs text-muted-foreground uppercase mb-1">Refund Reason</p>
                      <p className="font-medium">{transaction.refundDetails.refundReason}</p>
                    </div>

                    {/* Refund Breakdown */}
                    <div className="space-y-4">
                      <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="h-4 w-4 text-orange-400 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-sm text-orange-400 font-semibold">
                              Important: Refund is processed on ORDER AMOUNT
                            </p>
                            <p className="text-xs text-orange-400/80 mt-1">
                              Refund amount is calculated from the original order amount (₹{transaction.refundDetails?.originalOrderAmount.toLocaleString()}), 
                              not the transaction amount. PG charges and ERP commission are non-refundable.
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-secondary/50 p-4 rounded-lg space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Original Order Amount</span>
                          <span>₹{transaction.refundDetails.originalOrderAmount.toLocaleString()}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">PG Charges (Non-refundable)</span>
                          <span className="text-destructive">-₹{transaction.refundDetails.pgChargesDeducted.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">ERP Commission (Non-refundable)</span>
                          <span className="text-destructive">-₹{transaction.refundDetails.erpCommissionDeducted.toLocaleString()}</span>
                        </div>
                        <Separator />
                        <div className="flex justify-between font-semibold text-lg">
                          <span>Net Refund to Parent</span>
                          <span className="text-orange-500">₹{transaction.refundDetails.netRefundToParent.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </>
                ) : transaction.status === "refunded" ? (
                  <div className="text-center py-12">
                    <div className="flex justify-center mb-4">
                      <div className="h-16 w-16 rounded-full bg-info/10 flex items-center justify-center">
                        <RefreshCw className="h-8 w-8 text-info" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Transaction Refunded</h3>
                    <p className="text-sm text-muted-foreground">
                      This transaction has been refunded. Detailed breakdown is not available.
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="flex justify-center mb-4">
                      <div className="h-16 w-16 rounded-full bg-secondary/50 flex items-center justify-center">
                        <RefreshCw className="h-8 w-8 text-muted-foreground" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">No Refund Processed</h3>
                    <p className="text-sm text-muted-foreground">
                      No refund has been processed for this transaction.
                    </p>
                    {transaction.status === "success" && (
                      <Button className="mt-4 gap-2" variant="outline">
                        <RotateCcw className="h-4 w-4" />
                        Initiate Refund
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Lifecycle Tab */}
          <TabsContent value="lifecycle">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Transaction Lifecycle
                </CardTitle>
              </CardHeader>
              <CardContent>
                {transaction.transactionLifecycle && transaction.transactionLifecycle.length > 0 ? (
                  <div className="relative">
                    {/* Timeline Line */}
                    <div className="absolute left-5 top-3 bottom-3 w-0.5 bg-border" />
                    
                    <div className="space-y-0">
                      {transaction.transactionLifecycle.map((event, index) => (
                        <div key={index} className="relative flex gap-4 pb-6 last:pb-0">
                          {/* Timeline Dot */}
                          <div className={`relative z-10 flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                            event.status === "success" 
                              ? "bg-success/10 border-success text-success"
                              : event.status === "error"
                                ? "bg-destructive/10 border-destructive text-destructive"
                                : event.status === "warning"
                                  ? "bg-warning/10 border-warning text-warning"
                                  : "bg-secondary border-border text-muted-foreground"
                          }`}>
                            {event.status === "success" ? (
                              <CheckCircle2 className="h-4 w-4" />
                            ) : event.status === "error" ? (
                              <XCircle className="h-4 w-4" />
                            ) : event.status === "warning" ? (
                              <AlertTriangle className="h-4 w-4" />
                            ) : (
                              <Clock className="h-4 w-4" />
                            )}
                          </div>
                          
                          {/* Event Content */}
                          <div className={`flex-1 rounded-lg p-4 ${
                            event.status === "success" 
                              ? "bg-success/5 border border-success/20"
                              : event.status === "error"
                                ? "bg-destructive/5 border border-destructive/20"
                                : event.status === "warning"
                                  ? "bg-warning/5 border border-warning/20"
                                  : "bg-secondary/50 border border-border"
                          }`}>
                            <div className="flex items-center justify-between mb-1">
                              <h4 className="font-semibold text-sm">{event.event}</h4>
                              <span className="text-xs text-muted-foreground font-mono">
                                {event.timestamp}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">{event.description}</p>
                            
                            {/* Metadata if available */}
                            {event.metadata && Object.keys(event.metadata).length > 0 && (
                              <div className="mt-2 flex flex-wrap gap-2">
                                {Object.entries(event.metadata).map(([key, value]) => (
                                  <Badge key={key} variant="outline" className="text-xs">
                                    {key}: {value}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="flex justify-center mb-4">
                      <div className="h-16 w-16 rounded-full bg-secondary/50 flex items-center justify-center">
                        <History className="h-8 w-8 text-muted-foreground" />
                      </div>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Lifecycle Not Available</h3>
                    <p className="text-sm text-muted-foreground">
                      Detailed lifecycle events are not available for this transaction.
                    </p>
                    {/* Basic lifecycle from available data */}
                    <div className="mt-6 text-left max-w-md mx-auto space-y-3">
                      <div className="flex items-center gap-3 text-sm">
                        <div className="w-8 h-8 rounded-full bg-info/10 flex items-center justify-center">
                          <Clock className="h-4 w-4 text-info" />
                        </div>
                        <span>Order Created: {transaction.date} {transaction.time}</span>
                      </div>
                      {transaction.status === "success" && (
                        <div className="flex items-center gap-3 text-sm">
                          <div className="w-8 h-8 rounded-full bg-success/10 flex items-center justify-center">
                            <CheckCircle2 className="h-4 w-4 text-success" />
                          </div>
                          <span>Payment Completed: {transaction.date} {transaction.time}</span>
                        </div>
                      )}
                      {transaction.isSettled && (
                        <div className="flex items-center gap-3 text-sm">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                            <Banknote className="h-4 w-4 text-primary" />
                          </div>
                          <span>Settled: {transaction.settlementDate}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chargeback Tab */}
          {transaction.chargebackDetails && (
            <TabsContent value="chargeback">
              <Card className="bg-card border-border border-destructive/30">
                <CardHeader className="bg-destructive/5">
                  <CardTitle className="text-base flex items-center gap-2 text-destructive">
                    <AlertTriangle className="h-5 w-5" />
                    Chargeback Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6 pt-6">
                  {/* Important Note */}
                  <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/30">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-destructive">Chargeback in Progress</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          The cardholder has disputed the ORDER AMOUNT of ₹{transaction.chargebackDetails.chargebackAmount.toLocaleString()}, 
                          not the transaction amount. Chargebacks are always processed on the original order amount.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Chargeback Status Grid */}
                  <div className="grid grid-cols-4 gap-4">
                    <div className={`p-4 rounded-lg ${
                      transaction.chargebackDetails.chargebackStatus === "won" 
                        ? "bg-success/10 border border-success/20"
                        : transaction.chargebackDetails.chargebackStatus === "lost"
                          ? "bg-destructive/10 border border-destructive/20"
                          : "bg-warning/10 border border-warning/20"
                    }`}>
                      <p className="text-xs text-muted-foreground uppercase">Status</p>
                      <Badge className={
                        transaction.chargebackDetails.chargebackStatus === "won"
                          ? "bg-success/20 text-success"
                          : transaction.chargebackDetails.chargebackStatus === "lost"
                            ? "bg-destructive/20 text-destructive"
                            : "bg-warning/20 text-warning"
                      }>
                        {transaction.chargebackDetails.chargebackStatus.toUpperCase().replace("_", " ")}
                      </Badge>
                    </div>
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <p className="text-xs text-muted-foreground uppercase">Chargeback ID</p>
                      <p className="font-mono text-sm">{transaction.chargebackDetails.chargebackId}</p>
                    </div>
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <p className="text-xs text-muted-foreground uppercase">Filed Date</p>
                      <p className="font-medium">{transaction.chargebackDetails.chargebackDate}</p>
                    </div>
                    <div className="bg-destructive/10 p-4 rounded-lg border border-destructive/20">
                      <p className="text-xs text-muted-foreground uppercase">Disputed Amount</p>
                      <p className="font-bold text-lg text-destructive">
                        ₹{transaction.chargebackDetails.chargebackAmount.toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {/* Reason */}
                  <div className="bg-secondary/50 p-4 rounded-lg">
                    <p className="text-xs text-muted-foreground uppercase mb-1">Dispute Reason</p>
                    <p className="font-medium">{transaction.chargebackDetails.chargebackReason}</p>
                  </div>

                  {/* Timeline Info */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className={`p-4 rounded-lg ${
                      new Date(transaction.chargebackDetails.disputeDeadline) < new Date()
                        ? "bg-destructive/10 border border-destructive/20"
                        : "bg-warning/10 border border-warning/20"
                    }`}>
                      <p className="text-xs text-muted-foreground uppercase">Response Deadline</p>
                      <p className="font-semibold">{transaction.chargebackDetails.disputeDeadline}</p>
                    </div>
                    <div className="bg-secondary/50 p-4 rounded-lg">
                      <p className="text-xs text-muted-foreground uppercase">Evidence Submitted</p>
                      <Badge variant={transaction.chargebackDetails.evidenceSubmitted ? "default" : "destructive"}>
                        {transaction.chargebackDetails.evidenceSubmitted ? "Yes" : "No"}
                      </Badge>
                      {transaction.chargebackDetails.responseSubmittedAt && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {transaction.chargebackDetails.responseSubmittedAt}
                        </p>
                      )}
                    </div>
                    {transaction.chargebackDetails.arbNumber && (
                      <div className="bg-secondary/50 p-4 rounded-lg">
                        <p className="text-xs text-muted-foreground uppercase">ARB Number</p>
                        <p className="font-mono text-sm">{transaction.chargebackDetails.arbNumber}</p>
                      </div>
                    )}
                  </div>

                  {/* Financial Impact */}
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-muted-foreground uppercase">Financial Impact</h4>
                    <div className="bg-gradient-to-br from-destructive/5 to-orange-500/5 border border-destructive/20 p-4 rounded-lg space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Disputed Order Amount</span>
                        <span className="text-destructive font-semibold">
                          ₹{transaction.chargebackDetails.chargebackAmount.toLocaleString()}
                        </span>
                      </div>
                      {transaction.chargebackDetails.chargebackFee && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Chargeback Fee</span>
                          <span className="text-destructive">
                            ₹{transaction.chargebackDetails.chargebackFee.toLocaleString()}
                          </span>
                        </div>
                      )}
                      <Separator />
                      <div className="flex justify-between font-semibold">
                        <span>Total At-Risk Amount</span>
                        <span className="text-destructive text-lg">
                          ₹{(transaction.chargebackDetails.chargebackAmount + (transaction.chargebackDetails.chargebackFee || 0)).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  {transaction.chargebackDetails.chargebackStatus === "under_review" && (
                    <div className="flex gap-3">
                      <Button variant="outline" className="gap-2">
                        <FileText className="h-4 w-4" />
                        View Evidence
                      </Button>
                      <Button variant="outline" className="gap-2">
                        <Download className="h-4 w-4" />
                        Download Case File
                      </Button>
                      {!transaction.chargebackDetails.evidenceSubmitted && (
                        <Button variant="destructive" className="gap-2">
                          <ArrowUpRight className="h-4 w-4" />
                          Submit Evidence
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
