"use client"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  ChevronLeft,
  ChevronRight,
  Download,
  Play,
  Pause,
  LayoutDashboard,
  CreditCard,
  Landmark,
  QrCode,
  Building2,
  FileText,
  RefreshCcw,
  Shield,
  Split,
  BarChart3,
  Users,
  Settings,
  ArrowRight,
  CheckCircle2,
  Monitor,
  Zap,
  School,
  Eye,
  Calendar,
  Banknote,
  Receipt,
  AlertTriangle,
  Clock,
  TrendingUp,
  Lock,
  Globe,
  Phone,
  Mail,
  MapPin,
  Award,
  Target,
  Layers,
  Cpu,
  Smartphone,
} from "lucide-react"

const slides = [
  { id: 1, title: "Cover", component: CoverSlide },
  { id: 2, title: "Why ClearN", component: WhyClearNSlide },
  { id: 3, title: "One Dashboard", component: OneDashboardSlide },
  { id: 4, title: "Payment Gateway Partners", component: PaymentGatewayPartnersSlide },
  { id: 5, title: "POS Machine Partners", component: POSPartnersSlide },
  { id: 6, title: "Single KYC", component: SingleKYCSlide },
  { id: 7, title: "Unified Payments", component: UnifiedPaymentsSlide },
  { id: 8, title: "Branded Checkout", component: BrandedCheckoutSlide },
  { id: 9, title: "Transaction Management", component: TransactionManagementSlide },
  { id: 10, title: "Settlement Management", component: SettlementSlide },
  { id: 11, title: "Refunds", component: RefundsSlide },
  { id: 12, title: "POS & QR", component: PosQrSlide },
  { id: 13, title: "Bank Transfer", component: BankTransferSlide },
  { id: 14, title: "Chargebacks", component: ChargebackSlide },
  { id: 15, title: "Split Payments", component: SplitPaymentSlide },
  { id: 16, title: "Payment Forms", component: PaymentFormsSlide },
  { id: 17, title: "120+ Payment Modes", component: PaymentModesSlide },
  { id: 18, title: "Reports & Analytics", component: ReportsSlide },
  { id: 19, title: "Security", component: SecuritySlide },
  { id: 20, title: "Summary", component: SummarySlide },
  { id: 21, title: "Contact", component: ContactSlide },
]

export default function BrochurePage() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(false)
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false)
  const contentRef = useRef<HTMLDivElement>(null)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  const downloadPdf = async () => {
    setIsGeneratingPdf(true)
    try {
      const { default: jsPDF } = await import("jspdf")
      
      const pdf = new jsPDF({
        orientation: "landscape",
        unit: "mm",
        format: "a4"
      })
      
      const pageWidth = 297
      const pageHeight = 210
      const margin = 15
      const contentWidth = pageWidth - (margin * 2)
      
      // Colors
      const colors = {
        bg: [15, 18, 25] as [number, number, number],
        card: [26, 31, 46] as [number, number, number],
        primary: [34, 197, 94] as [number, number, number],
        text: [240, 240, 245] as [number, number, number],
        muted: [156, 163, 175] as [number, number, number],
        warning: [245, 158, 11] as [number, number, number],
        info: [59, 130, 246] as [number, number, number],
      }

      const addPage = (isFirst: boolean = false) => {
        if (!isFirst) pdf.addPage()
        pdf.setFillColor(...colors.bg)
        pdf.rect(0, 0, pageWidth, pageHeight, "F")
      }

      const setTextColor = (color: [number, number, number]) => {
        pdf.setTextColor(...color)
      }

      // Slide 1: Cover
      addPage(true)
      pdf.setFillColor(...colors.primary)
      pdf.rect(0, 0, pageWidth, 8, "F")
      setTextColor(colors.primary)
      pdf.setFontSize(48)
      pdf.setFont("helvetica", "bold")
      pdf.text("ClearN", pageWidth / 2, 60, { align: "center" })
      setTextColor(colors.text)
      pdf.setFontSize(24)
      pdf.text("Payment Orchestration Platform", pageWidth / 2, 75, { align: "center" })
      pdf.setFontSize(16)
      setTextColor(colors.muted)
      pdf.text("For Education Institutes", pageWidth / 2, 88, { align: "center" })
      
      // Stats
      const stats = [
        { value: "1000+", label: "Schools" },
        { value: "50L+", label: "Students" },
        { value: "Rs 500Cr+", label: "Processed" },
        { value: "99.9%", label: "Uptime" },
      ]
      let xPos = margin + 30
      stats.forEach((stat) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, 110, 50, 35, 3, 3, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(18)
        pdf.setFont("helvetica", "bold")
        pdf.text(stat.value, xPos + 25, 125, { align: "center" })
        setTextColor(colors.muted)
        pdf.setFontSize(10)
        pdf.setFont("helvetica", "normal")
        pdf.text(stat.label, xPos + 25, 138, { align: "center" })
        xPos += 60
      })

      // Slide 2: Why ClearN
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Why Education Institutes Prefer ClearN", pageWidth / 2, 30, { align: "center" })
      
      const reasons = [
        "Single dashboard for ALL payment modes",
        "School-branded checkout pages",
        "T+1 settlements with full transparency",
        "120+ payment options supported",
        "POS, QR, Bank Transfer - all integrated",
        "Complete refund & chargeback management",
      ]
      let yPos = 55
      reasons.forEach((reason) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(margin, yPos, contentWidth, 18, 2, 2, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(12)
        pdf.text("✓", margin + 8, yPos + 12)
        setTextColor(colors.text)
        pdf.text(reason, margin + 20, yPos + 12)
        yPos += 22
      })

      // Slide 3: Payment Gateway Partners
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Payment Gateway Partners", pageWidth / 2, 30, { align: "center" })
      setTextColor(colors.muted)
      pdf.setFontSize(14)
      pdf.setFont("helvetica", "normal")
      pdf.text("Integrated with India's leading payment gateways", pageWidth / 2, 42, { align: "center" })
      
      const gateways = [
        { name: "Razorpay", desc: "India's #1 Payment Gateway" },
        { name: "Cashfree", desc: "Fast & Reliable Payments" },
        { name: "Easebuzz", desc: "Complete Payment Suite" },
        { name: "Paytm", desc: "Trusted by Millions" },
        { name: "PayU", desc: "Enterprise Payment Solutions" },
        { name: "NTT DATA Atom", desc: "Secure Payment Processing" },
      ]
      
      xPos = margin
      yPos = 60
      gateways.forEach((gw, i) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, yPos, 82, 40, 3, 3, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(14)
        pdf.setFont("helvetica", "bold")
        pdf.text(gw.name, xPos + 41, yPos + 18, { align: "center" })
        setTextColor(colors.muted)
        pdf.setFontSize(9)
        pdf.setFont("helvetica", "normal")
        pdf.text(gw.desc, xPos + 41, yPos + 30, { align: "center" })
        xPos += 88
        if ((i + 1) % 3 === 0) {
          xPos = margin
          yPos += 48
        }
      })

      // Single KYC Banner
      pdf.setFillColor(...colors.primary)
      pdf.roundedRect(margin, 165, contentWidth, 30, 3, 3, "F")
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(14)
      pdf.setFont("helvetica", "bold")
      pdf.text("Single KYC - One KYC activates ALL Payment Gateways!", pageWidth / 2, 183, { align: "center" })

      // Slide 4: POS Partners
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("POS Machine Partners", pageWidth / 2, 30, { align: "center" })
      setTextColor(colors.muted)
      pdf.setFontSize(14)
      pdf.setFont("helvetica", "normal")
      pdf.text("Accept card & UPI payments at school counters", pageWidth / 2, 42, { align: "center" })
      
      const posPartners = [
        { name: "Pine Labs", features: ["Card Swipe & Tap", "UPI Payments", "EMI Options"] },
        { name: "Razorpay Ezetap", features: ["Smart POS", "Cloud Connected", "Real-time Sync"] },
        { name: "Paytm POS", features: ["All-in-One Device", "QR + Card", "Instant Settlement"] },
        { name: "Others", features: ["Mswipe", "BharatPe", "PhonePe POS"] },
      ]
      
      xPos = margin
      yPos = 55
      posPartners.forEach((pos) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, yPos, 62, 65, 3, 3, "F")
        setTextColor(colors.info)
        pdf.setFontSize(12)
        pdf.setFont("helvetica", "bold")
        pdf.text(pos.name, xPos + 31, yPos + 15, { align: "center" })
        setTextColor(colors.muted)
        pdf.setFontSize(8)
        pdf.setFont("helvetica", "normal")
        let featY = yPos + 28
        pos.features.forEach((f) => {
          pdf.text("• " + f, xPos + 8, featY)
          featY += 10
        })
        xPos += 68
      })

      // Single KYC for POS
      pdf.setFillColor(...colors.info)
      pdf.roundedRect(margin, 135, contentWidth, 25, 3, 3, "F")
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(12)
      pdf.setFont("helvetica", "bold")
      pdf.text("Same KYC activates POS machines - No additional documentation!", pageWidth / 2, 151, { align: "center" })

      // Slide 5: Single KYC
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Single KYC for Everything", pageWidth / 2, 30, { align: "center" })
      setTextColor(colors.muted)
      pdf.setFontSize(14)
      pdf.text("One-time documentation, unlimited possibilities", pageWidth / 2, 42, { align: "center" })

      // KYC Flow
      const kycSteps = ["Submit KYC Once", "ClearN Verification", "All PGs Activated", "POS Ready"]
      xPos = margin + 10
      kycSteps.forEach((step, i) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, 60, 55, 30, 3, 3, "F")
        setTextColor(colors.text)
        pdf.setFontSize(9)
        pdf.setFont("helvetica", "bold")
        pdf.text(step, xPos + 27.5, 78, { align: "center" })
        if (i < kycSteps.length - 1) {
          setTextColor(colors.primary)
          pdf.text("→", xPos + 60, 75)
        }
        xPos += 68
      })

      // Benefits
      const kycBenefits = [
        "No separate KYC for each gateway",
        "No separate POS onboarding",
        "Activate in 24-48 hours",
        "One dashboard, all services",
      ]
      yPos = 105
      kycBenefits.forEach((benefit) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(margin, yPos, contentWidth, 16, 2, 2, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(11)
        pdf.text("✓", margin + 8, yPos + 11)
        setTextColor(colors.text)
        pdf.text(benefit, margin + 20, yPos + 11)
        yPos += 20
      })

      // Slide 6: Unified Payments
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Unified Payments Dashboard", pageWidth / 2, 30, { align: "center" })
      
      const paymentTypes = [
        { name: "Payment Gateway", desc: "UPI, Cards, Net Banking, Wallets" },
        { name: "POS Machines", desc: "Card swipe/tap at counters" },
        { name: "Dynamic QR", desc: "Scan & pay anywhere" },
        { name: "Bank Transfer", desc: "NEFT, RTGS, IMPS, Challan" },
      ]
      
      xPos = margin
      yPos = 50
      paymentTypes.forEach((pt) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, yPos, 62, 40, 3, 3, "F")
        setTextColor(colors.text)
        pdf.setFontSize(11)
        pdf.setFont("helvetica", "bold")
        pdf.text(pt.name, xPos + 31, yPos + 15, { align: "center" })
        setTextColor(colors.muted)
        pdf.setFontSize(8)
        pdf.setFont("helvetica", "normal")
        const lines = pdf.splitTextToSize(pt.desc, 55)
        pdf.text(lines, xPos + 31, yPos + 28, { align: "center" })
        xPos += 68
      })

      // Arrow to unified
      setTextColor(colors.primary)
      pdf.setFontSize(24)
      pdf.text("↓", pageWidth / 2, 105, { align: "center" })
      
      pdf.setFillColor(...colors.primary)
      pdf.roundedRect(margin + 60, 115, contentWidth - 120, 40, 3, 3, "F")
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(16)
      pdf.setFont("helvetica", "bold")
      pdf.text("ONE UNIFIED DASHBOARD", pageWidth / 2, 135, { align: "center" })
      pdf.setFontSize(10)
      pdf.setFont("helvetica", "normal")
      pdf.text("All payments visible in single view", pageWidth / 2, 148, { align: "center" })

      // Slide 7: Branded Checkout
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("School-Branded Checkout Page", pageWidth / 2, 30, { align: "center" })

      // Before vs After
      pdf.setFillColor(60, 30, 30)
      pdf.roundedRect(margin, 50, (contentWidth / 2) - 5, 80, 3, 3, "F")
      setTextColor([239, 68, 68])
      pdf.setFontSize(14)
      pdf.setFont("helvetica", "bold")
      pdf.text("Before ClearN", margin + 65, 65, { align: "center" })
      setTextColor(colors.muted)
      pdf.setFontSize(10)
      pdf.setFont("helvetica", "normal")
      pdf.text("Parent sees: 'Pay to Razorpay'", margin + 65, 85, { align: "center" })
      pdf.text("• Generic payment page", margin + 20, 100)
      pdf.text("• No school branding", margin + 20, 112)
      pdf.text("• Parents feel unsafe", margin + 20, 124)

      pdf.setFillColor(30, 60, 30)
      pdf.roundedRect(margin + (contentWidth / 2) + 5, 50, (contentWidth / 2) - 5, 80, 3, 3, "F")
      setTextColor(colors.primary)
      pdf.setFontSize(14)
      pdf.setFont("helvetica", "bold")
      pdf.text("With ClearN", margin + (contentWidth / 2) + 70, 65, { align: "center" })
      setTextColor(colors.muted)
      pdf.setFontSize(10)
      pdf.setFont("helvetica", "normal")
      pdf.text("Parent sees: 'Pay to DPS School'", margin + (contentWidth / 2) + 70, 85, { align: "center" })
      pdf.text("• School logo displayed", margin + (contentWidth / 2) + 20, 100)
      pdf.text("• School name prominent", margin + (contentWidth / 2) + 20, 112)
      pdf.text("• Higher trust & completion", margin + (contentWidth / 2) + 20, 124)

      // Slide 8: Transaction Management
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Transaction Management", pageWidth / 2, 30, { align: "center" })

      const txnFeatures = [
        "Real-time transaction tracking",
        "Student & parent details linked",
        "Payment mode & gateway visible",
        "Status with reason codes",
        "Settlement tracking",
        "Complete audit trail",
        "Export to PDF, Excel, CSV",
        "Custom column filters",
      ]
      
      xPos = margin
      yPos = 50
      txnFeatures.forEach((feat, i) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, yPos, (contentWidth / 2) - 5, 18, 2, 2, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(10)
        pdf.text("✓", xPos + 8, yPos + 12)
        setTextColor(colors.text)
        pdf.text(feat, xPos + 18, yPos + 12)
        if ((i + 1) % 2 === 0) {
          xPos = margin
          yPos += 22
        } else {
          xPos = margin + (contentWidth / 2) + 5
        }
      })

      // Slide 9: Settlement
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Settlement Management", pageWidth / 2, 30, { align: "center" })
      setTextColor(colors.muted)
      pdf.setFontSize(14)
      pdf.text("T+1 settlements with complete transparency", pageWidth / 2, 42, { align: "center" })

      // Settlement breakdown
      pdf.setFillColor(...colors.card)
      pdf.roundedRect(margin, 55, contentWidth, 70, 3, 3, "F")
      
      const settlementItems = [
        { label: "Gross Collection", value: "Rs 1,01,000", color: colors.text },
        { label: "Transaction Fees", value: "- Rs 1,000", color: [239, 68, 68] as [number, number, number] },
        { label: "Refund Adjustments", value: "- Rs 300", color: colors.warning },
        { label: "Chargeback Adjustments", value: "- Rs 200", color: colors.warning },
        { label: "Net Settlement", value: "Rs 99,500", color: colors.primary },
      ]
      
      yPos = 68
      settlementItems.forEach((item) => {
        setTextColor(colors.muted)
        pdf.setFontSize(11)
        pdf.text(item.label, margin + 15, yPos)
        setTextColor(item.color)
        pdf.setFont("helvetica", "bold")
        pdf.text(item.value, margin + contentWidth - 15, yPos, { align: "right" })
        pdf.setFont("helvetica", "normal")
        yPos += 12
      })

      // Bank holiday note
      pdf.setFillColor(...colors.info)
      pdf.roundedRect(margin, 135, contentWidth, 20, 2, 2, "F")
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(10)
      pdf.text("Bank Holiday Calendar included - settlements auto-adjust for holidays", pageWidth / 2, 148, { align: "center" })

      // Slide 10: Refunds
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Refund Management", pageWidth / 2, 30, { align: "center" })

      const refundFeatures = [
        "Full & partial refunds",
        "Refund from main account OR split vendor account",
        "Track which settlement was adjusted",
        "Complete refund timeline",
        "Automatic reconciliation",
        "Parent notification support",
      ]
      
      yPos = 55
      refundFeatures.forEach((feat) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(margin, yPos, contentWidth, 16, 2, 2, "F")
        setTextColor(colors.warning)
        pdf.setFontSize(10)
        pdf.text("✓", margin + 8, yPos + 11)
        setTextColor(colors.text)
        pdf.text(feat, margin + 20, yPos + 11)
        yPos += 20
      })

      // Slide 11: Chargebacks
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Chargeback & Dispute Management", pageWidth / 2, 30, { align: "center" })

      const cbFeatures = [
        "Track all chargebacks with deadline alerts",
        "See which settlement was affected",
        "Upload evidence for disputes",
        "Win rate tracking",
        "Auto-credit on won chargebacks",
        "Complete chargeback timeline",
      ]
      
      yPos = 55
      cbFeatures.forEach((feat) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(margin, yPos, contentWidth, 16, 2, 2, "F")
        setTextColor([239, 68, 68])
        pdf.setFontSize(10)
        pdf.text("!", margin + 8, yPos + 11)
        setTextColor(colors.text)
        pdf.text(feat, margin + 20, yPos + 11)
        yPos += 20
      })

      // Slide 12: Split Payments
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Split Payments", pageWidth / 2, 30, { align: "center" })
      setTextColor(colors.muted)
      pdf.setFontSize(14)
      pdf.text("Automatically split payments to multiple vendors", pageWidth / 2, 42, { align: "center" })

      // Split example
      pdf.setFillColor(...colors.card)
      pdf.roundedRect(margin, 55, contentWidth, 80, 3, 3, "F")
      
      setTextColor(colors.text)
      pdf.setFontSize(12)
      pdf.setFont("helvetica", "bold")
      pdf.text("Example: Rs 50,000 Fee Payment", margin + 15, 70)
      
      const splits = [
        { name: "School Account", amount: "Rs 40,000 (80%)" },
        { name: "Transport Vendor", amount: "Rs 5,000 (10%)" },
        { name: "Canteen Vendor", amount: "Rs 3,000 (6%)" },
        { name: "Platform Fee", amount: "Rs 2,000 (4%)" },
      ]
      
      yPos = 85
      splits.forEach((split) => {
        setTextColor(colors.muted)
        pdf.setFontSize(10)
        pdf.setFont("helvetica", "normal")
        pdf.text(split.name, margin + 20, yPos)
        setTextColor(colors.primary)
        pdf.text(split.amount, margin + contentWidth - 20, yPos, { align: "right" })
        yPos += 12
      })

      // Split settlement tracking
      pdf.setFillColor(...colors.primary)
      pdf.roundedRect(margin, 145, contentWidth, 20, 2, 2, "F")
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(10)
      pdf.text("Track settlement status for each split beneficiary separately", pageWidth / 2, 158, { align: "center" })

      // Slide 13: 120+ Payment Modes
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("120+ Payment Modes", pageWidth / 2, 30, { align: "center" })

      const modes = [
        { category: "UPI Apps", items: "Google Pay, PhonePe, Paytm, BHIM, Amazon Pay, etc." },
        { category: "Cards", items: "Visa, Mastercard, RuPay, American Express, Diners" },
        { category: "Net Banking", items: "52+ banks including SBI, HDFC, ICICI, Axis, etc." },
        { category: "Wallets", items: "Paytm, PhonePe, Amazon, Freecharge, Mobikwik" },
        { category: "EMI", items: "Credit Card EMI, Debit Card EMI, Cardless EMI" },
        { category: "Bank Transfer", items: "NEFT, RTGS, IMPS, Virtual Account, Challan" },
      ]
      
      xPos = margin
      yPos = 50
      modes.forEach((mode, i) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, yPos, (contentWidth / 2) - 5, 35, 2, 2, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(11)
        pdf.setFont("helvetica", "bold")
        pdf.text(mode.category, xPos + 8, yPos + 12)
        setTextColor(colors.muted)
        pdf.setFontSize(8)
        pdf.setFont("helvetica", "normal")
        const lines = pdf.splitTextToSize(mode.items, (contentWidth / 2) - 20)
        pdf.text(lines, xPos + 8, yPos + 24)
        if ((i + 1) % 2 === 0) {
          xPos = margin
          yPos += 40
        } else {
          xPos = margin + (contentWidth / 2) + 5
        }
      })

      // Slide 14: Reports
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Reports & Analytics", pageWidth / 2, 30, { align: "center" })

      const reports = [
        "Daily, weekly, monthly transaction reports",
        "Gateway-wise performance comparison",
        "Mode-wise revenue breakdown",
        "Institute-wise collection reports",
        "Settlement reconciliation reports",
        "Refund & chargeback reports",
        "Export in PDF, Excel, CSV formats",
        "Scheduled report delivery via email",
      ]
      
      xPos = margin
      yPos = 50
      reports.forEach((report, i) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, yPos, (contentWidth / 2) - 5, 18, 2, 2, "F")
        setTextColor(colors.info)
        pdf.setFontSize(10)
        pdf.text("📊", xPos + 8, yPos + 12)
        setTextColor(colors.text)
        pdf.text(report, xPos + 20, yPos + 12)
        if ((i + 1) % 2 === 0) {
          xPos = margin
          yPos += 22
        } else {
          xPos = margin + (contentWidth / 2) + 5
        }
      })

      // Slide 15: Security
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Security & Compliance", pageWidth / 2, 30, { align: "center" })

      const security = [
        { title: "PCI DSS Compliant", desc: "Bank-grade security standards" },
        { title: "256-bit Encryption", desc: "All data encrypted in transit & at rest" },
        { title: "Two-Factor Auth", desc: "Secure login for all users" },
        { title: "Role-Based Access", desc: "Granular permission controls" },
        { title: "Audit Logs", desc: "Complete activity tracking" },
        { title: "99.9% Uptime", desc: "Highly available infrastructure" },
      ]
      
      xPos = margin
      yPos = 50
      security.forEach((item, i) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(xPos, yPos, (contentWidth / 3) - 5, 45, 2, 2, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(10)
        pdf.setFont("helvetica", "bold")
        pdf.text(item.title, xPos + ((contentWidth / 3) - 5) / 2, yPos + 18, { align: "center" })
        setTextColor(colors.muted)
        pdf.setFontSize(8)
        pdf.setFont("helvetica", "normal")
        pdf.text(item.desc, xPos + ((contentWidth / 3) - 5) / 2, yPos + 32, { align: "center" })
        if ((i + 1) % 3 === 0) {
          xPos = margin
          yPos += 52
        } else {
          xPos += (contentWidth / 3)
        }
      })

      // Slide 16: Summary
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(28)
      pdf.setFont("helvetica", "bold")
      pdf.text("Why Choose ClearN?", pageWidth / 2, 30, { align: "center" })

      const summary = [
        "6 Payment Gateways: Razorpay, Cashfree, Easebuzz, Paytm, PayU, NTT Atom",
        "4 POS Partners: Pine Labs, Razorpay Ezetap, Paytm POS & more",
        "Single KYC for ALL gateways and POS activation",
        "120+ payment modes in one dashboard",
        "T+1 settlements with full transparency",
        "Complete refund & chargeback management",
        "Split payments with per-beneficiary settlement tracking",
        "Bank-grade security with 99.9% uptime",
      ]
      
      yPos = 50
      summary.forEach((item) => {
        pdf.setFillColor(...colors.card)
        pdf.roundedRect(margin, yPos, contentWidth, 16, 2, 2, "F")
        setTextColor(colors.primary)
        pdf.setFontSize(10)
        pdf.text("★", margin + 8, yPos + 11)
        setTextColor(colors.text)
        pdf.text(item, margin + 20, yPos + 11)
        yPos += 19
      })

      // Slide 17: Contact
      addPage()
      setTextColor(colors.primary)
      pdf.setFontSize(36)
      pdf.setFont("helvetica", "bold")
      pdf.text("Get Started with ClearN", pageWidth / 2, 50, { align: "center" })
      
      setTextColor(colors.muted)
      pdf.setFontSize(14)
      pdf.setFont("helvetica", "normal")
      pdf.text("Contact our team for a personalized demo", pageWidth / 2, 65, { align: "center" })

      pdf.setFillColor(...colors.card)
      pdf.roundedRect(margin + 50, 80, contentWidth - 100, 80, 5, 5, "F")
      
      setTextColor(colors.text)
      pdf.setFontSize(12)
      pdf.text("Website: www.edviron.com", pageWidth / 2, 105, { align: "center" })
      pdf.text("Email: sales@edviron.com", pageWidth / 2, 120, { align: "center" })
      pdf.text("Phone: +91-XXXXXXXXXX", pageWidth / 2, 135, { align: "center" })

      pdf.setFillColor(...colors.primary)
      pdf.roundedRect(margin + 80, 170, contentWidth - 160, 25, 3, 3, "F")
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(14)
      pdf.setFont("helvetica", "bold")
      pdf.text("Schedule a Demo Today!", pageWidth / 2, 186, { align: "center" })

      pdf.save("ClearN-Sales-Brochure.pdf")
    } catch (error) {
      console.error("Error generating PDF:", error)
      alert("Error generating PDF. Please try again.")
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  const CurrentSlideComponent = slides[currentSlide].component

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold text-primary">EDVIRON</h1>
            <span className="text-muted-foreground">Sales Brochure</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              Slide {currentSlide + 1} of {slides.length}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
            >
              {isAutoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button
              onClick={downloadPdf}
              disabled={isGeneratingPdf}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              {isGeneratingPdf ? "Generating..." : "Download PDF"}
            </Button>
          </div>
        </div>
        {/* Progress bar */}
        <div className="h-1 bg-muted">
          <div
            className="h-full bg-primary transition-all duration-300"
            style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Slide navigation dots */}
      <div className="fixed left-4 top-1/2 -translate-y-1/2 z-40 flex flex-col gap-2">
        {slides.map((slide, i) => (
          <button
            type="button"
            key={slide.id}
            onClick={() => setCurrentSlide(i)}
            className={`w-2 h-2 rounded-full transition-all ${
              i === currentSlide ? "bg-primary w-3" : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
            }`}
            title={slide.title}
          />
        ))}
      </div>

      {/* Main content */}
      <div className="pt-20 pb-24 px-8 md:px-16 lg:px-24">
        <div ref={contentRef} className="min-h-[calc(100vh-200px)]">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
            >
              <CurrentSlideComponent />
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Footer navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur border-t border-border">
        <div className="flex items-center justify-between px-6 py-4">
          <Button
            variant="outline"
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className="gap-2 bg-transparent"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </Button>
          
          <div className="flex items-center gap-2">
            <select
              value={currentSlide}
              onChange={(e) => setCurrentSlide(Number(e.target.value))}
              className="bg-card border border-border rounded-md px-3 py-2 text-sm text-foreground"
            >
              {slides.map((slide, i) => (
                <option key={slide.id} value={i}>
                  {slide.title}
                </option>
              ))}
            </select>
          </div>

          <Button
            variant="outline"
            onClick={nextSlide}
            disabled={currentSlide === slides.length - 1}
            className="gap-2 bg-transparent"
          >
            Next
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

// Slide Components
function CoverSlide() {
  return (
    <div className="py-16 text-center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="w-24 h-24 mx-auto rounded-2xl bg-primary flex items-center justify-center mb-8">
          <LayoutDashboard className="w-12 h-12 text-primary-foreground" />
        </div>
        <h1 className="text-6xl font-bold mb-4 text-primary">EDVIRON</h1>
        <p className="text-2xl text-foreground mb-2">Payment Orchestration Platform</p>
        <p className="text-xl text-muted-foreground mb-12">For Education Institutes</p>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
          {[
            { value: "1000+", label: "Schools" },
            { value: "50L+", label: "Students" },
            { value: "Rs 500Cr+", label: "Processed" },
            { value: "99.9%", label: "Uptime" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 + i * 0.1 }}
            >
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="text-3xl font-bold text-primary">{stat.value}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}

function WhyClearNSlide() {
  const reasons = [
    { icon: Monitor, text: "Single dashboard for ALL payment modes" },
    { icon: School, text: "School-branded checkout pages" },
    { icon: Calendar, text: "T+1 settlements with full transparency" },
    { icon: CreditCard, text: "120+ payment options supported" },
    { icon: Layers, text: "POS, QR, Bank Transfer - all integrated" },
    { icon: RefreshCcw, text: "Complete refund & chargeback management" },
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Why ClearN?</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Why Education Institutes Prefer ClearN</h2>
        <p className="text-xl text-muted-foreground">The complete payment solution for schools</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {reasons.map((reason, i) => (
          <motion.div
            key={i}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardContent className="p-6 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <reason.icon className="w-6 h-6 text-primary" />
                </div>
                <p className="text-foreground font-medium">{reason.text}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

function OneDashboardSlide() {
  const paymentTypes = [
    { icon: Globe, label: "Payment Gateway", desc: "Online payments" },
    { icon: CreditCard, label: "POS Machines", desc: "Card swipe/tap" },
    { icon: QrCode, label: "Dynamic QR", desc: "Scan & pay" },
    { icon: Landmark, label: "Bank Transfer", desc: "NEFT/RTGS/IMPS" },
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Core Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">One Dashboard for All Payments</h2>
        <p className="text-xl text-muted-foreground">No more juggling multiple portals</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
        {paymentTypes.map((type, i) => (
          <motion.div
            key={i}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="bg-card border-border text-center">
              <CardContent className="p-6">
                <div className="w-14 h-14 mx-auto rounded-xl bg-primary/20 flex items-center justify-center mb-4">
                  <type.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-1">{type.label}</h3>
                <p className="text-muted-foreground text-xs">{type.desc}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardContent className="p-8">
          <div className="flex items-center justify-center gap-8 mb-8">
            <ArrowRight className="w-8 h-8 text-muted-foreground" />
            <div className="text-center">
              <div className="w-20 h-20 mx-auto rounded-2xl bg-primary flex items-center justify-center mb-3">
                <Monitor className="w-10 h-10 text-primary-foreground" />
              </div>
              <p className="font-semibold text-foreground">Unified Dashboard</p>
            </div>
            <ArrowRight className="w-8 h-8 text-muted-foreground" />
          </div>
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div className="p-4 rounded-xl bg-muted">
              <Zap className="w-8 h-8 text-warning mx-auto mb-2" />
              <h4 className="font-semibold text-foreground">One Login</h4>
              <p className="text-muted-foreground text-sm">Single access point</p>
            </div>
            <div className="p-4 rounded-xl bg-muted">
              <Monitor className="w-8 h-8 text-info mx-auto mb-2" />
              <h4 className="font-semibold text-foreground">One Screen</h4>
              <p className="text-muted-foreground text-sm">All data visible</p>
            </div>
            <div className="p-4 rounded-xl bg-muted">
              <CheckCircle2 className="w-8 h-8 text-primary mx-auto mb-2" />
              <h4 className="font-semibold text-foreground">One Source of Truth</h4>
              <p className="text-muted-foreground text-sm">Accurate & reliable</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function PaymentGatewayPartnersSlide() {
  const gateways = [
    { name: "Razorpay", desc: "India's #1 Payment Gateway", color: "bg-blue-500/20" },
    { name: "Cashfree", desc: "Fast & Reliable Payments", color: "bg-purple-500/20" },
    { name: "Easebuzz", desc: "Complete Payment Suite", color: "bg-green-500/20" },
    { name: "Paytm", desc: "Trusted by Millions", color: "bg-cyan-500/20" },
    { name: "PayU", desc: "Enterprise Solutions", color: "bg-orange-500/20" },
    { name: "NTT DATA Atom", desc: "Secure Processing", color: "bg-red-500/20" },
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-info/20 text-info border-info/30 mb-4">Payment Partners</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Payment Gateway Partners</h2>
        <p className="text-xl text-muted-foreground">Integrated with India's leading payment gateways</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {gateways.map((gw, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="bg-card border-border hover:border-primary/50 transition-colors">
              <CardContent className="p-6 text-center">
                <div className={`w-16 h-16 mx-auto rounded-xl ${gw.color} flex items-center justify-center mb-4`}>
                  <CreditCard className="w-8 h-8 text-foreground" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-1">{gw.name}</h3>
                <p className="text-muted-foreground text-sm">{gw.desc}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="bg-primary/20 border-primary/30">
        <CardContent className="p-6 text-center">
          <Lock className="w-10 h-10 text-primary mx-auto mb-3" />
          <h3 className="text-xl font-bold text-foreground mb-2">Single KYC Activation</h3>
          <p className="text-muted-foreground">One KYC submission activates ALL payment gateways - No separate documentation needed!</p>
        </CardContent>
      </Card>
    </div>
  )
}

function POSPartnersSlide() {
  const posPartners = [
    { name: "Pine Labs", features: ["Card Swipe & Tap", "UPI Payments", "EMI Options", "Multi-currency"] },
    { name: "Razorpay Ezetap", features: ["Smart POS Terminal", "Cloud Connected", "Real-time Dashboard Sync", "Auto Reconciliation"] },
    { name: "Paytm POS", features: ["All-in-One Device", "QR + Card Payments", "Instant Settlement", "Offline Mode"] },
    { name: "Others", features: ["Mswipe", "BharatPe", "PhonePe POS", "And more..."] },
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-warning/20 text-warning border-warning/30 mb-4">POS Partners</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">POS Machine Partners</h2>
        <p className="text-xl text-muted-foreground">Accept card & UPI payments at school counters</p>
      </div>

      <div className="grid md:grid-cols-4 gap-6 mb-8">
        {posPartners.map((pos, i) => (
          <motion.div
            key={i}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="bg-card border-border h-full">
              <CardContent className="p-5">
                <div className="w-12 h-12 rounded-xl bg-info/20 flex items-center justify-center mb-4">
                  <Cpu className="w-6 h-6 text-info" />
                </div>
                <h3 className="font-bold text-foreground mb-3">{pos.name}</h3>
                <ul className="space-y-2">
                  {pos.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-3 h-3 text-primary flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="bg-info/20 border-info/30">
        <CardContent className="p-6 text-center">
          <Smartphone className="w-10 h-10 text-info mx-auto mb-3" />
          <h3 className="text-xl font-bold text-foreground mb-2">Same KYC for POS</h3>
          <p className="text-muted-foreground">Same KYC activates POS machines - No additional documentation required!</p>
        </CardContent>
      </Card>
    </div>
  )
}

function SingleKYCSlide() {
  const steps = [
    { icon: FileText, label: "Submit KYC Once", desc: "Single documentation" },
    { icon: Shield, label: "ClearN Verifies", desc: "Quick verification" },
    { icon: Globe, label: "All PGs Activated", desc: "6 gateways ready" },
    { icon: Cpu, label: "POS Ready", desc: "Machines activated" },
  ]

  const benefits = [
    "No separate KYC for Razorpay, Cashfree, Paytm, etc.",
    "No separate POS onboarding documentation",
    "Activation within 24-48 hours",
    "One dashboard access for all services",
    "Reduced paperwork by 80%",
    "Single point of contact for support",
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Key Benefit</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Single KYC for Everything</h2>
        <p className="text-xl text-muted-foreground">One-time documentation, unlimited possibilities</p>
      </div>

      <div className="flex items-center justify-center gap-4 mb-10">
        {steps.map((step, i) => (
          <div key={i} className="flex items-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.15 }}
              className="text-center"
            >
              <div className="w-16 h-16 mx-auto rounded-xl bg-primary/20 flex items-center justify-center mb-2">
                <step.icon className="w-7 h-7 text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground">{step.label}</p>
              <p className="text-xs text-muted-foreground">{step.desc}</p>
            </motion.div>
            {i < steps.length - 1 && (
              <ArrowRight className="w-6 h-6 text-primary mx-2" />
            )}
          </div>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 text-foreground text-center">Benefits of Single KYC</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {benefits.map((benefit, i) => (
              <div key={i} className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-muted-foreground">{benefit}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function UnifiedPaymentsSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-chart-4/20 text-chart-4 border-chart-4/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Unified Payments Dashboard</h2>
        <p className="text-xl text-muted-foreground">Gateway + POS + QR + Bank - All Combined</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-foreground">
              <CreditCard className="w-5 h-5 text-primary" />
              Payment Methods Supported
            </h3>
            <div className="space-y-3">
              {[
                "Online payments (UPI, Card, Net Banking)",
                "POS machines (swipe/tap at counters)",
                "Dynamic QR codes",
                "Bank transfer/challan (NEFT/RTGS)",
              ].map((method, i) => (
                <div key={i} className="flex items-center gap-3">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">{method}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-foreground">
              <School className="w-5 h-5 text-info" />
              Real-Life School Example
            </h3>
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-muted">
                <p className="text-sm text-muted-foreground">Parent A</p>
                <p className="text-foreground">Pays via UPI from home</p>
              </div>
              <div className="p-3 rounded-lg bg-muted">
                <p className="text-sm text-muted-foreground">Parent B</p>
                <p className="text-foreground">Pays via card at school counter</p>
              </div>
              <div className="p-3 rounded-lg bg-muted">
                <p className="text-sm text-muted-foreground">Parent C</p>
                <p className="text-foreground">Pays via bank transfer</p>
              </div>
              <div className="p-3 rounded-lg bg-primary/20 border border-primary/30">
                <p className="text-primary font-medium">ClearN shows all three payments together!</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function BrandedCheckoutSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-warning/20 text-warning border-warning/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">School-Branded Checkout Page</h2>
        <p className="text-xl text-muted-foreground">Parents see YOUR school's identity</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="bg-destructive/10 border-destructive/30">
          <CardContent className="p-6">
            <Badge variant="outline" className="border-destructive/50 text-destructive mb-4">Before ClearN</Badge>
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-card">
                <p className="text-muted-foreground text-sm mb-2">Parent sees:</p>
                <p className="text-foreground font-medium">"Pay to Razorpay" or "Pay to Paytm"</p>
              </div>
              <div className="space-y-2">
                {["Parents feel unsafe", "Worried about fraud", "Generic payment page"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-destructive">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="text-sm">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-primary/10 border-primary/30">
          <CardContent className="p-6">
            <Badge variant="outline" className="border-primary/50 text-primary mb-4">With ClearN</Badge>
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-card">
                <p className="text-muted-foreground text-sm mb-2">Parent sees:</p>
                <p className="text-foreground font-medium">"Pay to Delhi Public School"</p>
              </div>
              <div className="space-y-2">
                {["School logo displayed", "School name prominent", "Higher trust & completion"].map((item, i) => (
                  <div key={i} className="flex items-center gap-2 text-primary">
                    <CheckCircle2 className="w-4 h-4" />
                    <span className="text-sm">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function TransactionManagementSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-info/20 text-info border-info/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Transaction Management</h2>
        <p className="text-xl text-muted-foreground">Complete visibility into every payment</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {[
          { icon: Eye, title: "Real-time Tracking", desc: "See every transaction as it happens" },
          { icon: FileText, title: "Detailed Records", desc: "Student name, fee type, payment mode" },
          { icon: BarChart3, title: "Analytics Dashboard", desc: "Trends, volumes, success rates" },
        ].map((item, i) => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto rounded-xl bg-primary/20 flex items-center justify-center mb-4">
                <item.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
              <p className="text-muted-foreground text-sm">{item.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 text-foreground">What You Can See</h3>
          <div className="grid md:grid-cols-4 gap-4">
            {[
              "Transaction ID & Reference",
              "Student & Parent Details",
              "Fee Type & Amount",
              "Payment Mode & Gateway",
              "Status & Reason Codes",
              "Settlement Status",
              "Refund History",
              "Export to PDF/Excel/CSV",
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                <span className="text-muted-foreground text-sm">{item}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function SettlementSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Settlement Management</h2>
        <p className="text-xl text-muted-foreground">T+1 settlements with full transparency</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-8">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 text-foreground flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              T+1 Settlement Tracking
            </h3>
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-muted flex justify-between">
                <span className="text-muted-foreground">Transaction Date</span>
                <span className="text-foreground font-medium">Jan 15, 2024</span>
              </div>
              <ArrowRight className="w-5 h-5 text-primary mx-auto" />
              <div className="p-3 rounded-lg bg-primary/20 border border-primary/30 flex justify-between">
                <span className="text-muted-foreground">Settlement Date</span>
                <span className="text-primary font-medium">Jan 16, 2024</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 text-foreground flex items-center gap-2">
              <Banknote className="w-5 h-5 text-primary" />
              Settlement Breakdown
            </h3>
            <div className="space-y-2">
              {[
                { label: "Gross Collection", value: "Rs 1,01,000", color: "text-foreground" },
                { label: "Transaction Fees", value: "- Rs 1,000", color: "text-destructive" },
                { label: "Refund Adjustments", value: "- Rs 300", color: "text-warning" },
                { label: "Chargeback Adjustments", value: "- Rs 200", color: "text-warning" },
                { label: "Net Settlement", value: "Rs 99,500", color: "text-primary" },
              ].map((item, i) => (
                <div key={i} className="flex justify-between p-2 rounded bg-muted">
                  <span className="text-muted-foreground">{item.label}</span>
                  <span className={`font-medium ${item.color}`}>{item.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-info/20 border-info/30">
        <CardContent className="p-4 text-center">
          <p className="text-foreground">Bank Holiday Calendar included - settlements auto-adjust for weekends & holidays</p>
        </CardContent>
      </Card>
    </div>
  )
}

function RefundsSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-warning/20 text-warning border-warning/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Refund Management</h2>
        <p className="text-xl text-muted-foreground">Process refunds with complete control</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {[
          { icon: RefreshCcw, title: "Full & Partial Refunds", desc: "Flexible refund options" },
          { icon: Receipt, title: "Settlement Tracking", desc: "Know which settlement was adjusted" },
          { icon: Split, title: "Refund Source", desc: "Main account OR split vendor account" },
        ].map((item, i) => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto rounded-xl bg-warning/20 flex items-center justify-center mb-4">
                <item.icon className="w-6 h-6 text-warning" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
              <p className="text-muted-foreground text-sm">{item.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 text-foreground text-center">Refund Flow</h3>
          <div className="flex items-center justify-between max-w-3xl mx-auto">
            {[
              { icon: FileText, label: "Request Initiated" },
              { icon: Eye, label: "Review & Approve" },
              { icon: Settings, label: "Processing" },
              { icon: CheckCircle2, label: "Refund Complete" },
            ].map((step, i) => (
              <div key={i} className="flex items-center">
                <div className="text-center">
                  <div className="w-12 h-12 mx-auto rounded-full bg-primary/20 flex items-center justify-center mb-2">
                    <step.icon className="w-5 h-5 text-primary" />
                  </div>
                  <p className="text-xs text-muted-foreground">{step.label}</p>
                </div>
                {i < 3 && <ArrowRight className="w-5 h-5 text-muted-foreground mx-4" />}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function PosQrSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-info/20 text-info border-info/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">POS Machines & Dynamic QR</h2>
        <p className="text-xl text-muted-foreground">Accept payments at school counters</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="w-16 h-16 mx-auto rounded-xl bg-info/20 flex items-center justify-center mb-4">
              <CreditCard className="w-8 h-8 text-info" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center text-foreground">POS Machines</h3>
            <div className="space-y-3">
              {[
                "Swipe & tap card payments",
                "UPI payments at counter",
                "Auto-linked to student record",
                "Real-time dashboard sync",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">{item}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="w-16 h-16 mx-auto rounded-xl bg-primary/20 flex items-center justify-center mb-4">
              <QrCode className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-center text-foreground">Dynamic QR Codes</h3>
            <div className="space-y-3">
              {[
                "Unique QR per transaction",
                "Auto-reconciliation",
                "Scan to pay with any UPI app",
                "Instant payment confirmation",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">{item}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function BankTransferSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Bank Transfer / Challan</h2>
        <p className="text-xl text-muted-foreground">Virtual accounts for seamless reconciliation</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 text-foreground">How It Works</h3>
            <div className="space-y-4">
              {[
                { step: "1", text: "Each student gets unique Virtual Account" },
                { step: "2", text: "Parent transfers via NEFT/RTGS/IMPS" },
                { step: "3", text: "Auto-matched to student record" },
                { step: "4", text: "Instant receipt generation" },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-primary font-bold">{item.step}</span>
                  </div>
                  <span className="text-muted-foreground">{item.text}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4 text-foreground">Benefits</h3>
            <div className="space-y-3">
              {[
                "No manual bank statement checking",
                "Zero reconciliation effort",
                "Works for bulk payments",
                "Supports all major banks",
                "Challan generation support",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">{item}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function ChargebackSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-destructive/20 text-destructive border-destructive/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Chargeback & Dispute Management</h2>
        <p className="text-xl text-muted-foreground">Handle disputes with confidence</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {[
          { icon: AlertTriangle, title: "Deadline Alerts", desc: "Never miss a response deadline" },
          { icon: Receipt, title: "Settlement Impact", desc: "See which settlement was affected" },
          { icon: FileText, title: "Evidence Upload", desc: "Submit proof for disputes" },
          { icon: TrendingUp, title: "Win Rate Tracking", desc: "Monitor dispute outcomes" },
          { icon: Banknote, title: "Auto Credit", desc: "Auto-credit on won chargebacks" },
          { icon: Clock, title: "Complete Timeline", desc: "Full chargeback history" },
        ].map((item, i) => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-destructive/20 flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function SplitPaymentSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-chart-4/20 text-chart-4 border-chart-4/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Split Payments</h2>
        <p className="text-xl text-muted-foreground">Auto-split to multiple vendors</p>
      </div>

      <Card className="bg-card border-border mb-8">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-4 text-foreground">Example: Rs 50,000 Fee Payment</h3>
          <div className="space-y-3">
            {[
              { name: "School Main Account", amount: "Rs 40,000", percent: "80%", color: "bg-primary" },
              { name: "Transport Vendor", amount: "Rs 5,000", percent: "10%", color: "bg-info" },
              { name: "Canteen Vendor", amount: "Rs 3,000", percent: "6%", color: "bg-warning" },
              { name: "Platform Fee", amount: "Rs 2,000", percent: "4%", color: "bg-muted-foreground" },
            ].map((split, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className={`w-3 h-3 rounded-full ${split.color}`} />
                <span className="text-muted-foreground flex-1">{split.name}</span>
                <span className="text-foreground font-medium">{split.amount}</span>
                <Badge variant="outline">{split.percent}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-primary/20 border-primary/30">
        <CardContent className="p-4 text-center">
          <p className="text-foreground font-medium">Track settlement status for each split beneficiary separately!</p>
        </CardContent>
      </Card>
    </div>
  )
}

function PaymentFormsSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-info/20 text-info border-info/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Custom Payment Forms</h2>
        <p className="text-xl text-muted-foreground">Create forms for any fee type</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {[
          { title: "Admission Fees", desc: "New student registration" },
          { title: "Tuition Fees", desc: "Monthly/quarterly collection" },
          { title: "Exam Fees", desc: "Term-wise exam payments" },
          { title: "Transport Fees", desc: "Bus route-based collection" },
          { title: "Event Fees", desc: "Annual day, sports meet" },
          { title: "Custom Forms", desc: "Create any fee type" },
        ].map((form, i) => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <h3 className="font-semibold text-foreground mb-1">{form.title}</h3>
              <p className="text-muted-foreground text-sm">{form.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function PaymentModesSlide() {
  const modes = [
    { category: "UPI Apps", items: ["Google Pay", "PhonePe", "Paytm", "BHIM", "Amazon Pay"] },
    { category: "Cards", items: ["Visa", "Mastercard", "RuPay", "American Express", "Diners"] },
    { category: "Net Banking", items: ["52+ Banks", "SBI", "HDFC", "ICICI", "Axis", "More..."] },
    { category: "Wallets", items: ["Paytm", "PhonePe", "Amazon", "Freecharge", "Mobikwik"] },
    { category: "EMI", items: ["Credit Card EMI", "Debit Card EMI", "Cardless EMI"] },
    { category: "Bank Transfer", items: ["NEFT", "RTGS", "IMPS", "Virtual Account"] },
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Coverage</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">120+ Payment Modes</h2>
        <p className="text-xl text-muted-foreground">Every payment option your parents need</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {modes.map((mode, i) => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="p-4">
              <h3 className="font-semibold text-primary mb-3">{mode.category}</h3>
              <div className="flex flex-wrap gap-2">
                {mode.items.map((item, j) => (
                  <Badge key={j} variant="outline" className="text-muted-foreground">{item}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function ReportsSlide() {
  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-info/20 text-info border-info/30 mb-4">Feature</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Reports & Analytics</h2>
        <p className="text-xl text-muted-foreground">Data-driven insights</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {[
          "Daily, weekly, monthly transaction reports",
          "Gateway-wise performance comparison",
          "Mode-wise revenue breakdown",
          "Institute-wise collection reports",
          "Settlement reconciliation reports",
          "Refund & chargeback reports",
          "Export in PDF, Excel, CSV formats",
          "Scheduled report delivery via email",
        ].map((report, i) => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="p-4 flex items-center gap-3">
              <BarChart3 className="w-5 h-5 text-info flex-shrink-0" />
              <span className="text-muted-foreground">{report}</span>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function SecuritySlide() {
  const features = [
    { icon: Shield, title: "PCI DSS Compliant", desc: "Bank-grade security" },
    { icon: Lock, title: "256-bit Encryption", desc: "Data encrypted always" },
    { icon: Users, title: "Two-Factor Auth", desc: "Secure login" },
    { icon: Settings, title: "Role-Based Access", desc: "Granular permissions" },
    { icon: FileText, title: "Audit Logs", desc: "Complete tracking" },
    { icon: Zap, title: "99.9% Uptime", desc: "High availability" },
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Security</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Security & Compliance</h2>
        <p className="text-xl text-muted-foreground">Enterprise-grade protection</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {features.map((item, i) => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto rounded-xl bg-primary/20 flex items-center justify-center mb-4">
                <item.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
              <p className="text-muted-foreground text-sm">{item.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function SummarySlide() {
  const highlights = [
    "6 Payment Gateways: Razorpay, Cashfree, Easebuzz, Paytm, PayU, NTT Atom",
    "4 POS Partners: Pine Labs, Razorpay Ezetap, Paytm POS & more",
    "Single KYC for ALL gateways and POS activation",
    "120+ payment modes in one dashboard",
    "T+1 settlements with full transparency",
    "Complete refund & chargeback management",
    "Split payments with per-beneficiary tracking",
    "Bank-grade security with 99.9% uptime",
  ]

  return (
    <div className="py-8">
      <div className="text-center mb-12">
        <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">Summary</Badge>
        <h2 className="text-4xl font-bold mb-4 text-foreground">Why Choose ClearN?</h2>
      </div>

      <div className="space-y-4 max-w-3xl mx-auto">
        {highlights.map((item, i) => (
          <motion.div
            key={i}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="bg-card border-border">
              <CardContent className="p-4 flex items-center gap-4">
                <Award className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-foreground">{item}</span>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

function ContactSlide() {
  return (
    <div className="py-16 text-center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <h2 className="text-5xl font-bold mb-4 text-primary">Get Started with ClearN</h2>
        <p className="text-xl text-muted-foreground mb-12">Contact our team for a personalized demo</p>

        <Card className="bg-card border-border max-w-lg mx-auto">
          <CardContent className="p-8 space-y-6">
            <div className="flex items-center gap-4 justify-center">
              <Globe className="w-5 h-5 text-primary" />
              <span className="text-foreground">www.edviron.com</span>
            </div>
            <div className="flex items-center gap-4 justify-center">
              <Mail className="w-5 h-5 text-primary" />
              <span className="text-foreground">sales@edviron.com</span>
            </div>
            <div className="flex items-center gap-4 justify-center">
              <Phone className="w-5 h-5 text-primary" />
              <span className="text-foreground">+91-XXXXXXXXXX</span>
            </div>
            <div className="flex items-center gap-4 justify-center">
              <MapPin className="w-5 h-5 text-primary" />
              <span className="text-foreground">India</span>
            </div>
          </CardContent>
        </Card>

        <Button size="lg" className="mt-8 gap-2">
          <Target className="w-5 h-5" />
          Schedule a Demo Today
        </Button>
      </motion.div>
    </div>
  )
}
