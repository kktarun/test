import { DashboardLayout } from "@/components/dashboard-layout"
import { PaymentFormsContent } from "@/components/payment-forms/payment-forms-content"

export default function PaymentFormsPage() {
  return (
    <DashboardLayout>
      <PaymentFormsContent />
    </DashboardLayout>
  )
}
