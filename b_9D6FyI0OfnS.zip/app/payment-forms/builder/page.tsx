import { DashboardLayout } from "@/components/dashboard-layout"
import { FormBuilderContent } from "@/components/payment-forms/form-builder-content"

export default function FormBuilderPage() {
  return (
    <DashboardLayout>
      <FormBuilderContent />
    </DashboardLayout>
  )
}
