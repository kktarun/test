import { DashboardLayout } from "@/components/dashboard-layout"
import { SettlementsContent } from "@/components/settlements/settlements-content"

export default function SettlementsPage() {
  return (
    <DashboardLayout>
      <SettlementsContent />
    </DashboardLayout>
  )
}
