"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Building2,
  Copy,
  CheckCircle2,
  XCircle,
  RefreshCcw,
  Wallet,
  Search,
  Minus,
  Eye,
  Clock,
  CreditCard,
  Download,
} from "lucide-react"


// Settlement Data with Gateway-wise breakdown showing Main Account vs Vendor Account
const settlementData: Record<string, any> = {
  "IST001": {
    id: "IST-DPS-2024-0311",
    settlementDate: "2024-03-11",
    settlementTime: "02:30 PM",
    institute: {
      name: "Delhi Public School",
      code: "DPS-RKP",
      id: "INST-DPS-001",
    },
    period: {
      from: "2024-03-10",
      to: "2024-03-10",
    },
    summary: {
      totalStudents: 100,
      totalOrderAmount: 1000000,
      totalMerchantAmount: 700000,
      totalVendorAmount: 300000,
      totalMDR: 20000,
      totalRefunds: 25000,
      totalChargebacks: 16500,
      netSettlement: 938500,
    },
    bankDetails: {
      mainAccount: {
        accountName: "Delhi Public School - Main",
        accountNumber: "XXXX XXXX 4521",
        ifsc: "HDFC0001234",
        bankName: "HDFC Bank",
      },
      vendorAccount: {
        accountName: "DPS Vendor Services",
        accountNumber: "XXXX XXXX 7890",
        ifsc: "ICIC0005678",
        bankName: "ICICI Bank",
      },
    },
    gateways: [
      {
        gateway: "Razorpay",
        totalAmount: 600000,
        totalStudents: 80,
        totalTransactions: 80,
        // Main Account (Merchant) Settlement
        mainAccount: {
          settlementId: "STL-RZP-MAIN-2024-0311",
          grossAmount: 400000,
          mdr: 8000,
          refunds: 25000,
          chargebacks: 15000,
          chargebackFees: 1500,
          netAmount: 350500,
          utr: "RAZP24031114301234",
          settlementTime: "02:30 PM",
          settlementDate: "2024-03-11",
          transactions: [
            { srNo: 1, id: "TXN-RZP-001", paymentId: "pay_RZP001234567", orderId: "ORD-DPS-001", instituteName: "Delhi Public School", studentName: "Rahul Sharma", studentId: "STU-001", class: "10-A", phone: "+91 98765 43210", orderAmount: 15000, transactionAmount: 15300, merchantAmount: 15000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "UPI", dateTime: "2024-03-10 09:15 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 2, id: "TXN-RZP-002", paymentId: "pay_RZP001234568", orderId: "ORD-DPS-002", instituteName: "Delhi Public School", studentName: "Priya Singh", studentId: "STU-002", class: "10-B", phone: "+91 98765 43211", orderAmount: 15000, transactionAmount: 15450, merchantAmount: 15000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Credit Card", dateTime: "2024-03-10 09:22 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 3, id: "TXN-RZP-003", paymentId: "pay_RZP001234569", orderId: "ORD-DPS-003", instituteName: "Delhi Public School", studentName: "Amit Kumar", studentId: "STU-003", class: "9-A", phone: "+91 98765 43212", orderAmount: 12000, transactionAmount: 12240, merchantAmount: 12000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Debit Card", dateTime: "2024-03-10 09:30 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 4, id: "TXN-RZP-004", paymentId: "pay_RZP001234570", orderId: "ORD-DPS-004", instituteName: "Delhi Public School", studentName: "Neha Gupta", studentId: "STU-004", class: "9-B", phone: "+91 98765 43213", orderAmount: 12000, transactionAmount: 12120, merchantAmount: 12000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "UPI", dateTime: "2024-03-10 09:45 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 5, id: "TXN-RZP-005", paymentId: "pay_RZP001234571", orderId: "ORD-DPS-005", instituteName: "Delhi Public School", studentName: "Vikram Patel", studentId: "STU-005", class: "11-A", phone: "+91 98765 43214", orderAmount: 18000, transactionAmount: 18360, merchantAmount: 18000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Net Banking", dateTime: "2024-03-10 10:00 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 6, id: "TXN-RZP-006", paymentId: "pay_RZP001234572", orderId: "ORD-DPS-006", instituteName: "Delhi Public School", studentName: "Ananya Reddy", studentId: "STU-006", class: "11-B", phone: "+91 98765 43215", orderAmount: 18000, transactionAmount: 18540, merchantAmount: 18000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Credit Card", dateTime: "2024-03-10 10:15 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 7, id: "TXN-RZP-007", paymentId: "pay_RZP001234573", orderId: "ORD-DPS-007", instituteName: "Delhi Public School", studentName: "Rohan Mehta", studentId: "STU-007", class: "12-A", phone: "+91 98765 43216", orderAmount: 20000, transactionAmount: 20200, merchantAmount: 20000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "UPI", dateTime: "2024-03-10 10:30 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 8, id: "TXN-RZP-008", paymentId: "pay_RZP001234574", orderId: "ORD-DPS-008", instituteName: "Delhi Public School", studentName: "Kavya Nair", studentId: "STU-008", class: "12-B", phone: "+91 98765 43217", orderAmount: 20000, transactionAmount: 20400, merchantAmount: 20000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Debit Card", dateTime: "2024-03-10 10:45 AM", settlementDate: "2024-03-11", status: "settled" },
          ],
refundTransactions: [
  { id: "RFD-RZP-001", refundId: "RFD-RZP-001", paymentId: "pay_RZP001234REF1", orderId: "ORD-DPS-REF-001", instituteName: "Delhi Public School", studentName: "Karan Malhotra", studentId: "STU-REF-001", class: "9-A", phone: "+91 98765 43218", orderAmount: 15000, refundAmount: 13500, pgCharges: 1000, erpCharges: 500, reason: "Student transferred", refundDate: "2024-03-10", settlementDate: "2024-03-11", status: "processed" },
  { id: "RFD-RZP-002", refundId: "RFD-RZP-002", paymentId: "pay_RZP001234REF2", orderId: "ORD-DPS-REF-002", instituteName: "Delhi Public School", studentName: "Simran Kaur", studentId: "STU-REF-002", class: "10-A", phone: "+91 98765 43219", orderAmount: 12000, refundAmount: 11500, pgCharges: 350, erpCharges: 150, reason: "Duplicate payment", refundDate: "2024-03-10", settlementDate: "2024-03-11", status: "processed" },
  { id: "RFD-RZP-003", refundId: "RFD-RZP-003", paymentId: "pay_RZP001234REF3", orderId: "ORD-DPS-REF-003", instituteName: "Delhi Public School", studentName: "Rahul Verma", studentId: "STU-REF-003", class: "8-B", phone: "+91 98765 43221", orderAmount: 18000, refundAmount: 16500, pgCharges: 1000, erpCharges: 500, reason: "Course cancellation", refundDate: "2024-03-11", settlementDate: null, status: "pending" },
  ],
          chargebackTransactions: [
            { id: "CB-RZP-001", paymentId: "pay_RZP001234CB01", orderId: "ORD-DPS-CB-001", instituteName: "Delhi Public School", studentName: "Aditya Saxena", studentId: "STU-CB-001", class: "11-A", phone: "+91 98765 43220", orderAmount: 15000, chargebackFee: 1500, totalDeduction: 16500, reason: "Unauthorized transaction", cbDate: "2024-03-10", settlementDate: "2024-03-11", status: "deducted" },
          ],
        },
        // Vendor Account Settlement (Split Payment)
        vendorAccount: {
          settlementId: "STL-RZP-VEND-2024-0311",
          grossAmount: 200000,
          mdr: 4000,
          refunds: 0,
          chargebacks: 0,
          chargebackFees: 0,
          netAmount: 196000,
          utr: "RAZP24031114307890",
          settlementTime: "02:35 PM",
          settlementDate: "2024-03-11",
          // Multiple vendors breakdown
          vendors: [
            { vendorName: "School Transport Services", vendorCode: "VND-STS-001", transactions: 25, grossAmount: 125000, platformFee: 2500, vendorShare: 122500, status: "settled", utr: "VNDR20240311RZP001" },
            { vendorName: "Uniform Supplier Co.", vendorCode: "VND-USC-002", transactions: 15, grossAmount: 45000, platformFee: 900, vendorShare: 44100, status: "settled", utr: "VNDR20240311RZP002" },
            { vendorName: "Books & Stationery Ltd", vendorCode: "VND-BSL-003", transactions: 10, grossAmount: 30000, platformFee: 600, vendorShare: 29400, status: "pending", utr: "-" },
          ],
          transactions: [
            { srNo: 1, id: "TXN-RZP-V001", paymentId: "pay_RZP001234V001", orderId: "ORD-DPS-V001", instituteName: "Delhi Public School", studentName: "Rahul Sharma", studentId: "STU-001", class: "10-A", phone: "+91 98765 43210", orderAmount: 5000, transactionAmount: 5050, merchantAmount: 0, vendorAmount: 5000, feeType: "Transport Fee", paymentMode: "UPI", dateTime: "2024-03-10 09:15 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 2, id: "TXN-RZP-V002", paymentId: "pay_RZP001234V002", orderId: "ORD-DPS-V002", instituteName: "Delhi Public School", studentName: "Priya Singh", studentId: "STU-002", class: "10-B", phone: "+91 98765 43211", orderAmount: 5000, transactionAmount: 5150, merchantAmount: 0, vendorAmount: 5000, feeType: "Transport Fee", paymentMode: "Credit Card", dateTime: "2024-03-10 09:22 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 3, id: "TXN-RZP-V003", paymentId: "pay_RZP001234V003", orderId: "ORD-DPS-V003", instituteName: "Delhi Public School", studentName: "Amit Kumar", studentId: "STU-003", class: "9-A", phone: "+91 98765 43212", orderAmount: 4000, transactionAmount: 4080, merchantAmount: 0, vendorAmount: 4000, feeType: "Transport Fee", paymentMode: "Debit Card", dateTime: "2024-03-10 09:30 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 4, id: "TXN-RZP-V004", paymentId: "pay_RZP001234V004", orderId: "ORD-DPS-V004", instituteName: "Delhi Public School", studentName: "Neha Gupta", studentId: "STU-004", class: "9-B", phone: "+91 98765 43213", orderAmount: 4000, transactionAmount: 4040, merchantAmount: 0, vendorAmount: 4000, feeType: "Transport Fee", paymentMode: "UPI", dateTime: "2024-03-10 09:45 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 5, id: "TXN-RZP-V005", paymentId: "pay_RZP001234V005", orderId: "ORD-DPS-V005", instituteName: "Delhi Public School", studentName: "Vikram Patel", studentId: "STU-005", class: "11-A", phone: "+91 98765 43214", orderAmount: 6000, transactionAmount: 6120, merchantAmount: 0, vendorAmount: 6000, feeType: "Transport Fee", paymentMode: "Net Banking", dateTime: "2024-03-10 10:00 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 6, id: "TXN-RZP-V006", paymentId: "pay_RZP001234V006", orderId: "ORD-DPS-V006", instituteName: "Delhi Public School", studentName: "Ananya Reddy", studentId: "STU-006", class: "11-B", phone: "+91 98765 43215", orderAmount: 6000, transactionAmount: 6180, merchantAmount: 0, vendorAmount: 6000, feeType: "Transport Fee", paymentMode: "Credit Card", dateTime: "2024-03-10 10:15 AM", settlementDate: "2024-03-11", status: "settled" },
          ],
          refundTransactions: [],
          chargebackTransactions: [],
        },
      },
      {
        gateway: "Cashfree",
        totalAmount: 400000,
        totalStudents: 20,
        totalTransactions: 20,
        // Main Account (Merchant) Settlement
        mainAccount: {
          settlementId: "STL-CF-MAIN-2024-0311",
          grossAmount: 300000,
          mdr: 6000,
          refunds: 0,
          chargebacks: 0,
          chargebackFees: 0,
          netAmount: 294000,
          utr: "CSHF24031114454521",
          settlementTime: "02:45 PM",
          settlementDate: "2024-03-11",
          transactions: [
            { srNo: 1, id: "TXN-CF-001", paymentId: "pay_CF001234567", orderId: "ORD-DPS-CF-001", instituteName: "Delhi Public School", studentName: "Sanjay Rao", studentId: "STU-CF-001", class: "7-A", phone: "+91 98765 43221", orderAmount: 15000, transactionAmount: 15150, merchantAmount: 15000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "UPI", dateTime: "2024-03-10 11:30 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 2, id: "TXN-CF-002", paymentId: "pay_CF001234568", orderId: "ORD-DPS-CF-002", instituteName: "Delhi Public School", studentName: "Meera Iyer", studentId: "STU-CF-002", class: "7-B", phone: "+91 98765 43222", orderAmount: 15000, transactionAmount: 15300, merchantAmount: 15000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Net Banking", dateTime: "2024-03-10 11:45 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 3, id: "TXN-CF-003", paymentId: "pay_CF001234569", orderId: "ORD-DPS-CF-003", instituteName: "Delhi Public School", studentName: "Rajesh Kumar", studentId: "STU-CF-003", class: "6-A", phone: "+91 98765 43223", orderAmount: 12000, transactionAmount: 12120, merchantAmount: 12000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "UPI", dateTime: "2024-03-10 12:00 PM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 4, id: "TXN-CF-004", paymentId: "pay_CF001234570", orderId: "ORD-DPS-CF-004", instituteName: "Delhi Public School", studentName: "Pooja Sharma", studentId: "STU-CF-004", class: "6-B", phone: "+91 98765 43224", orderAmount: 12000, transactionAmount: 12240, merchantAmount: 12000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Debit Card", dateTime: "2024-03-10 12:15 PM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 5, id: "TXN-CF-005", paymentId: "pay_CF001234571", orderId: "ORD-DPS-CF-005", instituteName: "Delhi Public School", studentName: "Vivek Singh", studentId: "STU-CF-005", class: "5-A", phone: "+91 98765 43225", orderAmount: 10000, transactionAmount: 10300, merchantAmount: 10000, vendorAmount: 0, feeType: "Tuition Fee", paymentMode: "Credit Card", dateTime: "2024-03-10 12:30 PM", settlementDate: "2024-03-11", status: "settled" },
          ],
          refundTransactions: [],
          chargebackTransactions: [],
        },
        // Vendor Account Settlement (Split Payment)
        vendorAccount: {
          settlementId: "STL-CF-VEND-2024-0311",
          grossAmount: 100000,
          mdr: 2000,
          refunds: 0,
          chargebacks: 0,
          chargebackFees: 0,
          netAmount: 98000,
          utr: "CSHF24031114457890",
          settlementTime: "02:50 PM",
          settlementDate: "2024-03-11",
          // Multiple vendors breakdown
          vendors: [
            { vendorName: "School Transport Services", vendorCode: "VND-STS-001", transactions: 20, grossAmount: 60000, platformFee: 1200, vendorShare: 58800, status: "settled", utr: "VNDR20240311CF001" },
            { vendorName: "Lab Equipment Pvt Ltd", vendorCode: "VND-LEP-004", transactions: 10, grossAmount: 40000, platformFee: 800, vendorShare: 39200, status: "settled", utr: "VNDR20240311CF002" },
          ],
          transactions: [
            { srNo: 1, id: "TXN-CF-V001", paymentId: "pay_CF001234V001", orderId: "ORD-DPS-CF-V001", instituteName: "Delhi Public School", studentName: "Sanjay Rao", studentId: "STU-CF-001", class: "7-A", phone: "+91 98765 43221", orderAmount: 5000, transactionAmount: 5050, merchantAmount: 0, vendorAmount: 5000, feeType: "Lab Fee", paymentMode: "UPI", dateTime: "2024-03-10 11:30 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 2, id: "TXN-CF-V002", paymentId: "pay_CF001234V002", orderId: "ORD-DPS-CF-V002", instituteName: "Delhi Public School", studentName: "Meera Iyer", studentId: "STU-CF-002", class: "7-B", phone: "+91 98765 43222", orderAmount: 5000, transactionAmount: 5100, merchantAmount: 0, vendorAmount: 5000, feeType: "Lab Fee", paymentMode: "Net Banking", dateTime: "2024-03-10 11:45 AM", settlementDate: "2024-03-11", status: "settled" },
            { srNo: 3, id: "TXN-CF-V003", paymentId: "pay_CF001234V003", orderId: "ORD-DPS-CF-V003", instituteName: "Delhi Public School", studentName: "Rajesh Kumar", studentId: "STU-CF-003", class: "6-A", phone: "+91 98765 43223", orderAmount: 4000, transactionAmount: 4040, merchantAmount: 0, vendorAmount: 4000, feeType: "Lab Fee", paymentMode: "UPI", dateTime: "2024-03-10 12:00 PM", settlementDate: "2024-03-11", status: "settled" },
          ],
          refundTransactions: [],
          chargebackTransactions: [],
        },
      },
    ],
  },
}

// Default settlement for any ID
const defaultSettlement = settlementData["IST001"]

export default function InstituteSettlementReceiptPage() {
  const params = useParams()
  const settlementId = params.id as string
  const settlement = settlementData[settlementId] || defaultSettlement
  
  const [activeTab, setActiveTab] = useState("gateway-breakdown")
  const [expandedGateways, setExpandedGateways] = useState<Record<string, boolean>>({
    "Razorpay": true,
    "Cashfree": true,
  })
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    "Razorpay-main": true,
    "Razorpay-vendor": true,
    "Cashfree-main": true,
    "Cashfree-vendor": true,
  })
  const [searchQuery, setSearchQuery] = useState("")
  const [rowsPerPage, setRowsPerPage] = useState("10")
  const [currentPage, setCurrentPage] = useState(1)
  const [gatewayFilter, setGatewayFilter] = useState("all")
  const [vendorFilter, setVendorFilter] = useState("all")
  const [refundSearch, setRefundSearch] = useState("")
  const [refundGatewayFilter, setRefundGatewayFilter] = useState("all")
  const [refundStatusFilter, setRefundStatusFilter] = useState("all")
  const [refundVendorFilter, setRefundVendorFilter] = useState("all")
  const [refundInstituteFilter, setRefundInstituteFilter] = useState("all")
  const [refundDateFilter, setRefundDateFilter] = useState("all")
  const [refundRowsPerPage, setRefundRowsPerPage] = useState("10")
  const [refundCurrentPage, setRefundCurrentPage] = useState(1)
  const [chargebackSearch, setChargebackSearch] = useState("")
  const [chargebackGatewayFilter, setChargebackGatewayFilter] = useState("all")

  const toggleGateway = (gateway: string) => {
    setExpandedGateways(prev => ({ ...prev, [gateway]: !prev[gateway] }))
  }

  const toggleSection = (key: string) => {
    setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }))
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const getGatewayColor = (gateway: string) => {
    const colors: Record<string, string> = {
      "Razorpay": "bg-blue-500",
      "Cashfree": "bg-purple-500",
      "Paytm": "bg-sky-500",
    }
    return colors[gateway] || "bg-primary"
  }

  // Get all transactions for All Transactions tab
  const getAllMerchantTransactions = () => {
    const transactions: any[] = []
    settlement.gateways.forEach((gw: any) => {
      gw.mainAccount.transactions.forEach((txn: any) => {
        transactions.push({ ...txn, gateway: gw.gateway })
      })
    })
    return transactions
  }

  const getAllVendorTransactions = () => {
    const transactions: any[] = []
    settlement.gateways.forEach((gw: any) => {
      gw.vendorAccount.transactions.forEach((txn: any) => {
        transactions.push({ ...txn, gateway: gw.gateway })
      })
    })
    return transactions
  }

  const filterTransactions = (transactions: any[]) => {
    let filtered = transactions
    if (gatewayFilter !== "all") {
      filtered = filtered.filter(txn => txn.gateway === gatewayFilter)
    }
    if (searchQuery) {
      filtered = filtered.filter(txn => 
        txn.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        txn.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        txn.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        txn.paymentId.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }
    return filtered
  }

  const paginateTransactions = (transactions: any[]) => {
    const limit = parseInt(rowsPerPage)
    const start = (currentPage - 1) * limit
    return transactions.slice(start, start + limit)
  }

  // Get all refund transactions
  const getAllRefundTransactions = () => {
    const refunds: any[] = []
    settlement.gateways.forEach((gw: any) => {
      gw.mainAccount.refundTransactions.forEach((txn: any) => {
        refunds.push({ ...txn, gateway: gw.gateway, accountType: "merchant" })
      })
      gw.vendorAccount.refundTransactions.forEach((txn: any) => {
        refunds.push({ ...txn, gateway: gw.gateway, accountType: "vendor" })
      })
    })
    return refunds
  }

  // Get all chargeback transactions
  const getAllChargebackTransactions = () => {
    const chargebacks: any[] = []
    settlement.gateways.forEach((gw: any) => {
      gw.mainAccount.chargebackTransactions.forEach((txn: any) => {
        chargebacks.push({ ...txn, gateway: gw.gateway, accountType: "merchant" })
      })
      gw.vendorAccount.chargebackTransactions.forEach((txn: any) => {
        chargebacks.push({ ...txn, gateway: gw.gateway, accountType: "vendor" })
      })
    })
    return chargebacks
  }

  const filterRefunds = (refunds: any[]) => {
    let filtered = refunds
    if (refundGatewayFilter !== "all") {
      filtered = filtered.filter(r => r.gateway === refundGatewayFilter)
    }
    if (refundStatusFilter !== "all") {
      filtered = filtered.filter(r => r.status.toLowerCase() === refundStatusFilter.toLowerCase())
    }
    if (refundVendorFilter !== "all") {
      filtered = filtered.filter(r => r.accountType === refundVendorFilter)
    }
    if (refundInstituteFilter !== "all") {
      filtered = filtered.filter(r => r.instituteName === refundInstituteFilter)
    }
    if (refundDateFilter !== "all") {
      const today = new Date()
      const filterDate = new Date()
      if (refundDateFilter === "today") {
        filtered = filtered.filter(r => r.refundDate === today.toISOString().split('T')[0])
      } else if (refundDateFilter === "7days") {
        filterDate.setDate(today.getDate() - 7)
        filtered = filtered.filter(r => new Date(r.refundDate) >= filterDate)
      } else if (refundDateFilter === "30days") {
        filterDate.setDate(today.getDate() - 30)
        filtered = filtered.filter(r => new Date(r.refundDate) >= filterDate)
      }
    }
    if (refundSearch) {
      const search = refundSearch.toLowerCase()
      filtered = filtered.filter(r =>
        r.studentName?.toLowerCase().includes(search) ||
        r.studentId?.toLowerCase().includes(search) ||
        r.orderId?.toLowerCase().includes(search) ||
        r.paymentId?.toLowerCase().includes(search) ||
        r.refundId?.toLowerCase().includes(search) ||
        r.instituteName?.toLowerCase().includes(search) ||
        r.reason?.toLowerCase().includes(search) ||
        r.phone?.toLowerCase().includes(search)
      )
    }
    return filtered
  }

  const paginateRefunds = (refunds: any[]) => {
    const limit = parseInt(refundRowsPerPage)
    const start = (refundCurrentPage - 1) * limit
    return refunds.slice(start, start + limit)
  }

  const handleCancelRefund = (refund: any) => {
    // In production, this would call an API to cancel the refund
    alert(`Cancel refund ${refund.refundId} - This would call an API in production`)
  }

  const filterChargebacks = (chargebacks: any[]) => {
    let filtered = chargebacks
    if (chargebackGatewayFilter !== "all") {
      filtered = filtered.filter(c => c.gateway === chargebackGatewayFilter)
    }
    if (chargebackSearch) {
      filtered = filtered.filter(c =>
        c.studentName.toLowerCase().includes(chargebackSearch.toLowerCase()) ||
        c.studentId.toLowerCase().includes(chargebackSearch.toLowerCase()) ||
        c.orderId.toLowerCase().includes(chargebackSearch.toLowerCase()) ||
        c.paymentId.toLowerCase().includes(chargebackSearch.toLowerCase())
      )
    }
    return filtered
  }

  // Navigation helpers
  const navigateToTransactionsWithGateway = (gateway: string) => {
    setGatewayFilter(gateway)
    setActiveTab("all-transactions")
  }

  const navigateToRefundsWithGateway = (gateway: string) => {
    setRefundGatewayFilter(gateway)
    setActiveTab("refunds")
  }

  const navigateToChargebacksWithGateway = (gateway: string) => {
    setChargebackGatewayFilter(gateway)
    setActiveTab("chargebacks")
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/settlements">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">Settlement Reconciliation Report</h1>
              <p className="text-sm text-muted-foreground">
                {settlement.institute.name} | {settlement.settlementDate}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <Printer className="h-4 w-4" />
              Print
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export PDF
            </Button>
          </div>
        </div>

        {/* Settlement Summary Card */}
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="grid grid-cols-2 lg:grid-cols-7 gap-6">
              <div>
                <p className="text-xs text-muted-foreground uppercase">Settlement ID</p>
                <div className="flex items-center gap-2">
                  <p className="font-mono text-sm font-semibold">{settlement.id}</p>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(settlement.id)}>
                    <Copy className="h-3 w-3" />
                  </Button>
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">Settlement Date</p>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <p className="font-medium">{settlement.settlementDate}</p>
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">Total Students</p>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <p className="font-semibold">{settlement.summary.totalStudents}</p>
                </div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">Total Collection</p>
                <p className="text-lg font-bold">₹{settlement.summary.totalOrderAmount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">Merchant Amount</p>
                <p className="text-lg font-bold text-primary">₹{settlement.summary.totalMerchantAmount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">Vendor Amount</p>
                <p className="text-lg font-bold text-emerald-500">₹{settlement.summary.totalVendorAmount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase">Net Settlement</p>
                <p className="text-lg font-bold text-success">₹{settlement.summary.netSettlement.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Institute & Bank Details */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Institute Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Name</span>
                <span className="font-medium">{settlement.institute.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Code</span>
                <span className="font-mono">{settlement.institute.code}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Collection Period</span>
                <span className="font-medium">{settlement.period.from}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border border-primary/30">
            <CardHeader className="pb-3 bg-primary/5">
              <CardTitle className="text-sm flex items-center gap-2">
                <Banknote className="h-4 w-4 text-primary" />
                Main (Merchant) Account
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm pt-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Account</span>
                <span className="font-mono">{settlement.bankDetails.mainAccount.accountNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Bank</span>
                <span className="font-medium">{settlement.bankDetails.mainAccount.bankName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">IFSC</span>
                <span className="font-mono">{settlement.bankDetails.mainAccount.ifsc}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border border-emerald-500/30">
            <CardHeader className="pb-3 bg-emerald-500/5">
              <CardTitle className="text-sm flex items-center gap-2">
                <Wallet className="h-4 w-4 text-emerald-500" />
                Vendor Account
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm pt-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Account</span>
                <span className="font-mono">{settlement.bankDetails.vendorAccount.accountNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Bank</span>
                <span className="font-medium">{settlement.bankDetails.vendorAccount.bankName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">IFSC</span>
                <span className="font-mono">{settlement.bankDetails.vendorAccount.ifsc}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs for different views */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
<TabsList className="bg-secondary/50">
            <TabsTrigger value="gateway-breakdown">Gateway Breakdown</TabsTrigger>
            <TabsTrigger value="all-transactions">All Transactions</TabsTrigger>
            <TabsTrigger value="refunds" className="flex items-center gap-2">
              Refunds
              {getAllRefundTransactions().length > 0 && (
                <Badge className="bg-warning/20 text-warning text-xs">{getAllRefundTransactions().length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="chargebacks" className="flex items-center gap-2">
              Chargebacks
              {getAllChargebackTransactions().length > 0 && (
                <Badge className="bg-destructive/20 text-destructive text-xs">{getAllChargebackTransactions().length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="summary">Summary</TabsTrigger>
            </TabsList>

          {/* Gateway Breakdown Tab */}
          <TabsContent value="gateway-breakdown" className="space-y-4">
            {settlement.gateways.map((gw: any) => (
              <Card key={gw.gateway} className="bg-card border-border overflow-hidden">
                {/* Gateway Header */}
                <div 
                  className="flex items-center justify-between p-4 bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors"
                  onClick={() => toggleGateway(gw.gateway)}
                >
                  <div className="flex items-center gap-4">
                    <div className={`h-10 w-10 rounded-lg ${getGatewayColor(gw.gateway)} flex items-center justify-center`}>
                      <CreditCard className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">{gw.gateway}</h3>
                      <p className="text-sm text-muted-foreground">
                        {gw.totalStudents} students | {gw.totalTransactions} transactions
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">Total Amount</p>
                      <p className="text-xl font-bold">₹{gw.totalAmount.toLocaleString()}</p>
                    </div>
                    {expandedGateways[gw.gateway] ? (
                      <ChevronDown className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                </div>

                {expandedGateways[gw.gateway] && (
                  <CardContent className="p-0">
                    {/* Main Account (Merchant) Section */}
                    <div className="border-b border-border">
                      <div 
                        className="flex items-center justify-between p-4 bg-primary/5 cursor-pointer hover:bg-primary/10 transition-colors"
                        onClick={() => toggleSection(`${gw.gateway}-main`)}
                      >
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                            <Banknote className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-semibold">Merchant Account Settlement</h4>
                            <p className="text-xs text-muted-foreground">
                              UTR: {gw.mainAccount.utr} | {settlement.bankDetails.mainAccount.accountNumber}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <button 
                            className="text-right hover:bg-primary/10 p-2 rounded-lg transition-colors cursor-pointer"
                            onClick={(e) => { e.stopPropagation(); navigateToTransactionsWithGateway(gw.gateway) }}
                            title="View all transactions"
                          >
                            <p className="text-xs text-muted-foreground">Gross</p>
                            <p className="font-semibold text-primary hover:underline">₹{gw.mainAccount.grossAmount.toLocaleString()}</p>
                            <p className="text-xs text-primary">View Txns</p>
                          </button>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">MDR</p>
                            <p className="font-semibold text-destructive">-₹{gw.mainAccount.mdr.toLocaleString()}</p>
                          </div>
                          {gw.mainAccount.refunds > 0 && (
                            <button 
                              className="text-right hover:bg-warning/10 p-2 rounded-lg transition-colors cursor-pointer"
                              onClick={(e) => { e.stopPropagation(); navigateToRefundsWithGateway(gw.gateway) }}
                              title="View refunds"
                            >
                              <p className="text-xs text-muted-foreground">Refunds</p>
                              <p className="font-semibold text-warning hover:underline">-₹{gw.mainAccount.refunds.toLocaleString()}</p>
                              <p className="text-xs text-warning">View</p>
                            </button>
                          )}
                          {gw.mainAccount.chargebacks > 0 && (
                            <button 
                              className="text-right hover:bg-destructive/10 p-2 rounded-lg transition-colors cursor-pointer"
                              onClick={(e) => { e.stopPropagation(); navigateToChargebacksWithGateway(gw.gateway) }}
                              title="View chargebacks"
                            >
                              <p className="text-xs text-muted-foreground">Chargebacks</p>
                              <p className="font-semibold text-destructive hover:underline">-₹{(gw.mainAccount.chargebacks + gw.mainAccount.chargebackFees).toLocaleString()}</p>
                              <p className="text-xs text-destructive">View</p>
                            </button>
                          )}
                          <div className="text-right bg-success/10 px-4 py-2 rounded-lg">
                            <p className="text-xs text-success">Net Settled</p>
                            <p className="font-bold text-success">₹{gw.mainAccount.netAmount.toLocaleString()}</p>
                          </div>
                          {expandedSections[`${gw.gateway}-main`] ? (
                            <ChevronDown className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                      </div>

                      {expandedSections[`${gw.gateway}-main`] && (
                        <div className="p-4 space-y-6">
                          {/* Settlement Details */}
                          <div className="grid grid-cols-5 gap-4 p-4 bg-secondary/30 rounded-lg">
                            <div>
                              <p className="text-xs text-muted-foreground">Settlement ID</p>
                              <p className="font-mono text-sm">{gw.mainAccount.settlementId}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">UTR Number</p>
                              <div className="flex items-center gap-2">
                                <p className="font-mono text-sm">{gw.mainAccount.utr}</p>
                                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(gw.mainAccount.utr)}>
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Settlement Date</p>
                              <p className="font-medium">{gw.mainAccount.settlementDate}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Settlement Time</p>
                              <p className="font-medium">{gw.mainAccount.settlementTime}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Transactions</p>
                              <p className="font-medium">{gw.mainAccount.transactions.length}</p>
                            </div>
                          </div>

                          {/* Transactions Table */}
                          <div>
                            <div className="flex items-center justify-between mb-4">
                              <h5 className="font-semibold flex items-center gap-2">
                                <CheckCircle2 className="h-4 w-4 text-success" />
                                Merchant Settlement Transactions
                              </h5>
                              <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input placeholder="Search..." className="pl-9 w-64 h-8" />
                              </div>
                            </div>
                            <div className="border rounded-lg overflow-x-auto">
                              <Table>
                                <TableHeader>
                                  <TableRow className="bg-secondary/50">
                                    <TableHead className="text-xs">Sr.No</TableHead>
                                    <TableHead className="text-xs">Institute Name</TableHead>
                                    <TableHead className="text-xs">Date & Time</TableHead>
                                    <TableHead className="text-xs">Order ID</TableHead>
                                    <TableHead className="text-xs">Payment ID</TableHead>
                                    <TableHead className="text-xs text-right">Order Amt</TableHead>
                                    <TableHead className="text-xs text-right">Txn Amt</TableHead>
                                    <TableHead className="text-xs">Payment Method</TableHead>
                                    <TableHead className="text-xs">Status</TableHead>
                                    <TableHead className="text-xs">Student Name</TableHead>
                                    <TableHead className="text-xs">Student ID</TableHead>
                                    <TableHead className="text-xs">Phone No.</TableHead>
                                    <TableHead className="text-xs">Settlement Date</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {gw.mainAccount.transactions.map((txn: any, idx: number) => (
                                    <TableRow key={txn.id} className="hover:bg-secondary/30">
                                      <TableCell className="text-sm">{idx + 1}</TableCell>
                                      <TableCell className="text-sm">{txn.instituteName}</TableCell>
                                      <TableCell className="text-sm whitespace-nowrap">{txn.dateTime}</TableCell>
                                      <TableCell className="font-mono text-xs">
                                        <Link href={`/transactions/${txn.id}`} className="text-primary hover:underline flex items-center gap-1">
                                          {txn.orderId}
                                          <ExternalLink className="h-3 w-3" />
                                        </Link>
                                      </TableCell>
                                      <TableCell className="font-mono text-xs">{txn.paymentId}</TableCell>
                                      <TableCell className="text-right font-semibold">₹{txn.orderAmount.toLocaleString()}</TableCell>
                                      <TableCell className="text-right">₹{txn.transactionAmount.toLocaleString()}</TableCell>
                                      <TableCell>
                                        <Badge variant="outline" className="text-xs">{txn.paymentMode}</Badge>
                                      </TableCell>
                                      <TableCell>
                                        <Badge className="text-xs bg-success/10 text-success">{txn.status}</Badge>
                                      </TableCell>
                                      <TableCell className="text-sm font-medium">{txn.studentName}</TableCell>
                                      <TableCell className="font-mono text-xs">{txn.studentId}</TableCell>
                                      <TableCell className="text-sm">{txn.phone}</TableCell>
                                      <TableCell className="text-sm">{txn.settlementDate}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                            <div className="flex justify-end mt-2">
                              <p className="text-sm">
                                <span className="text-muted-foreground">Total Merchant Order Amount: </span>
                                <span className="font-bold">₹{gw.mainAccount.transactions.reduce((sum: number, t: any) => sum + t.orderAmount, 0).toLocaleString()}</span>
                              </p>
                            </div>
                          </div>

                          {/* Refund Transactions */}
                          {gw.mainAccount.refundTransactions && gw.mainAccount.refundTransactions.length > 0 && (
                            <div>
                              <h5 className="font-semibold flex items-center gap-2 mb-4">
                                <RefreshCcw className="h-4 w-4 text-warning" />
                                Refund Deductions (ORDER AMOUNT Refunded)
                              </h5>
                              <div className="p-3 rounded-lg bg-warning/10 border border-warning/30 mb-4">
                                <p className="text-sm text-warning">
                                  Note: Refunds are processed on ORDER AMOUNT. PG charges and ERP commission are non-refundable and retained.
                                </p>
                              </div>
                              <div className="border rounded-lg overflow-x-auto border-warning/30">
                                <Table>
                                  <TableHeader>
                                    <TableRow className="bg-warning/10">
                                      <TableHead className="text-xs">Refund ID</TableHead>
                                      <TableHead className="text-xs">Payment ID</TableHead>
                                      <TableHead className="text-xs">Order ID</TableHead>
                                      <TableHead className="text-xs">Student Name</TableHead>
                                      <TableHead className="text-xs">Student ID</TableHead>
                                      <TableHead className="text-xs">Phone No.</TableHead>
                                      <TableHead className="text-xs text-right">Order Amount</TableHead>
                                      <TableHead className="text-xs text-right">PG Charges (Retained)</TableHead>
                                      <TableHead className="text-xs text-right">ERP Charges (Retained)</TableHead>
                                      <TableHead className="text-xs text-right">Refund Amount</TableHead>
                                      <TableHead className="text-xs">Reason</TableHead>
                                      <TableHead className="text-xs">Settlement Date</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {gw.mainAccount.refundTransactions.map((rfn: any) => (
                                      <TableRow key={rfn.id} className="hover:bg-warning/5">
                                        <TableCell className="font-mono text-xs">{rfn.id}</TableCell>
                                        <TableCell className="font-mono text-xs">{rfn.paymentId}</TableCell>
                                        <TableCell className="font-mono text-xs">{rfn.orderId}</TableCell>
                                        <TableCell className="text-sm font-medium">{rfn.studentName}</TableCell>
                                        <TableCell className="font-mono text-xs">{rfn.studentId}</TableCell>
                                        <TableCell className="text-sm">{rfn.phone}</TableCell>
                                        <TableCell className="text-right font-semibold">₹{rfn.orderAmount.toLocaleString()}</TableCell>
                                        <TableCell className="text-right text-muted-foreground">₹{rfn.pgCharges.toLocaleString()}</TableCell>
                                        <TableCell className="text-right text-muted-foreground">₹{rfn.erpCharges.toLocaleString()}</TableCell>
                                        <TableCell className="text-right font-semibold text-warning">-₹{rfn.refundAmount.toLocaleString()}</TableCell>
                                        <TableCell className="text-sm text-muted-foreground">{rfn.reason}</TableCell>
                                        <TableCell className="text-sm">{rfn.settlementDate}</TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                              <div className="flex justify-end mt-2">
                                <p className="text-sm">
                                  <span className="text-muted-foreground">Total Refund Deduction: </span>
                                  <span className="font-bold text-warning">-₹{gw.mainAccount.refundTransactions.reduce((sum: number, r: any) => sum + r.refundAmount, 0).toLocaleString()}</span>
                                </p>
                              </div>
                            </div>
                          )}

                          {/* Chargeback Transactions */}
                          {gw.mainAccount.chargebackTransactions && gw.mainAccount.chargebackTransactions.length > 0 && (
                            <div>
                              <h5 className="font-semibold flex items-center gap-2 mb-4">
                                <XCircle className="h-4 w-4 text-destructive" />
                                Chargeback Deductions (ORDER AMOUNT + Fee)
                              </h5>
                              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30 mb-4">
                                <p className="text-sm text-destructive">
                                  Note: Chargebacks deduct the full ORDER AMOUNT plus chargeback processing fee from merchant settlement.
                                </p>
                              </div>
                              <div className="border rounded-lg overflow-x-auto border-destructive/30">
                                <Table>
                                  <TableHeader>
                                    <TableRow className="bg-destructive/10">
                                      <TableHead className="text-xs">Chargeback ID</TableHead>
                                      <TableHead className="text-xs">Payment ID</TableHead>
                                      <TableHead className="text-xs">Order ID</TableHead>
                                      <TableHead className="text-xs">Student Name</TableHead>
                                      <TableHead className="text-xs">Student ID</TableHead>
                                      <TableHead className="text-xs">Phone No.</TableHead>
                                      <TableHead className="text-xs text-right">Order Amount</TableHead>
                                      <TableHead className="text-xs text-right">Chargeback Fee</TableHead>
                                      <TableHead className="text-xs text-right">Total Deduction</TableHead>
                                      <TableHead className="text-xs">Reason</TableHead>
                                      <TableHead className="text-xs">Settlement Date</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {gw.mainAccount.chargebackTransactions.map((cb: any) => (
                                      <TableRow key={cb.id} className="hover:bg-destructive/5">
                                        <TableCell className="font-mono text-xs">{cb.id}</TableCell>
                                        <TableCell className="font-mono text-xs">{cb.paymentId}</TableCell>
                                        <TableCell className="font-mono text-xs">{cb.orderId}</TableCell>
                                        <TableCell className="text-sm font-medium">{cb.studentName}</TableCell>
                                        <TableCell className="font-mono text-xs">{cb.studentId}</TableCell>
                                        <TableCell className="text-sm">{cb.phone}</TableCell>
                                        <TableCell className="text-right font-semibold">₹{cb.orderAmount.toLocaleString()}</TableCell>
                                        <TableCell className="text-right text-destructive">₹{cb.chargebackFee.toLocaleString()}</TableCell>
                                        <TableCell className="text-right font-bold text-destructive">-₹{cb.totalDeduction.toLocaleString()}</TableCell>
                                        <TableCell className="text-sm text-muted-foreground">{cb.reason}</TableCell>
                                        <TableCell className="text-sm">{cb.settlementDate}</TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                              <div className="flex justify-end mt-2">
                                <p className="text-sm">
                                  <span className="text-muted-foreground">Total Chargeback Deduction: </span>
                                  <span className="font-bold text-destructive">-₹{gw.mainAccount.chargebackTransactions.reduce((sum: number, c: any) => sum + c.totalDeduction, 0).toLocaleString()}</span>
                                </p>
                              </div>
                            </div>
                          )}

                          {/* Main Account Net Calculation */}
                          <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                            <h5 className="font-semibold mb-3">{gw.gateway} - Merchant Account Settlement Calculation</h5>
                            <div className="grid grid-cols-6 gap-4 text-center">
                              <div>
                                <p className="text-xs text-muted-foreground">Gross Amount</p>
                                <p className="font-bold">₹{gw.mainAccount.grossAmount.toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">MDR</p>
                                <p className="font-bold text-destructive">-₹{gw.mainAccount.mdr.toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Refunds</p>
                                <p className="font-bold text-warning">-₹{(gw.mainAccount.refunds || 0).toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Chargebacks</p>
                                <p className="font-bold text-destructive">-₹{((gw.mainAccount.chargebacks || 0) + (gw.mainAccount.chargebackFees || 0)).toLocaleString()}</p>
                              </div>
                              <div className="col-span-2 bg-success/10 rounded-lg p-2">
                                <p className="text-xs text-success">Net Settled to Merchant Account</p>
                                <p className="text-xl font-bold text-success">₹{gw.mainAccount.netAmount.toLocaleString()}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Vendor Account Section */}
                    <div>
                      <div 
                        className="flex items-center justify-between p-4 bg-emerald-500/5 cursor-pointer hover:bg-emerald-500/10 transition-colors"
                        onClick={() => toggleSection(`${gw.gateway}-vendor`)}
                      >
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                            <Wallet className="h-4 w-4 text-emerald-500" />
                          </div>
                          <div>
                            <h4 className="font-semibold">Vendor Account Settlement (Split Payment)</h4>
                            <p className="text-xs text-muted-foreground">
                              UTR: {gw.vendorAccount.utr} | {settlement.bankDetails.vendorAccount.accountNumber}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Gross</p>
                            <p className="font-semibold">₹{gw.vendorAccount.grossAmount.toLocaleString()}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">MDR</p>
                            <p className="font-semibold text-destructive">-₹{gw.vendorAccount.mdr.toLocaleString()}</p>
                          </div>
                          <div className="text-right bg-emerald-500/10 px-4 py-2 rounded-lg">
                            <p className="text-xs text-emerald-500">Net Settled</p>
                            <p className="font-bold text-emerald-500">₹{gw.vendorAccount.netAmount.toLocaleString()}</p>
                          </div>
                          {expandedSections[`${gw.gateway}-vendor`] ? (
                            <ChevronDown className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                      </div>

                      {expandedSections[`${gw.gateway}-vendor`] && (
                        <div className="p-4 space-y-6 bg-emerald-500/5">
                          {/* Settlement Details */}
                          <div className="grid grid-cols-4 gap-4 p-4 bg-secondary/30 rounded-lg">
                            <div>
                              <p className="text-xs text-muted-foreground">Settlement ID</p>
                              <p className="font-mono text-sm">{gw.vendorAccount.settlementId}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Master UTR</p>
                              <div className="flex items-center gap-2">
                                <p className="font-mono text-sm">{gw.vendorAccount.utr}</p>
                                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(gw.vendorAccount.utr)}>
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Settlement Date</p>
                              <p className="font-medium">{gw.vendorAccount.settlementDate}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Settlement Time</p>
                              <p className="font-medium">{gw.vendorAccount.settlementTime}</p>
                            </div>
                          </div>

                          {/* Vendor Settlement Breakdown Table */}
                          {gw.vendorAccount.vendors && gw.vendorAccount.vendors.length > 0 && (
                            <div>
                              <h5 className="font-semibold flex items-center gap-2 mb-4">
                                <Wallet className="h-4 w-4 text-emerald-500" />
                                Vendor Settlement Breakdown
                              </h5>
                              <div className="border rounded-lg overflow-hidden border-emerald-500/30">
                                <Table>
                                  <TableHeader>
                                    <TableRow className="bg-emerald-500/10">
                                      <TableHead className="text-xs uppercase text-muted-foreground">Vendor</TableHead>
                                      <TableHead className="text-xs uppercase text-muted-foreground">Vendor Code</TableHead>
                                      <TableHead className="text-xs uppercase text-muted-foreground text-center">Transactions</TableHead>
                                      <TableHead className="text-xs uppercase text-muted-foreground text-right">Gross Amount</TableHead>
                                      <TableHead className="text-xs uppercase text-muted-foreground text-right">Platform Fee</TableHead>
                                      <TableHead className="text-xs uppercase text-muted-foreground text-right">Vendor Share</TableHead>
                                      <TableHead className="text-xs uppercase text-muted-foreground text-center">Status</TableHead>
                                      <TableHead className="text-xs uppercase text-muted-foreground">UTR</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {gw.vendorAccount.vendors.map((vendor: any, idx: number) => (
                                      <TableRow key={idx} className="hover:bg-emerald-500/5">
                                        <TableCell className="font-semibold">{vendor.vendorName}</TableCell>
                                        <TableCell className="font-mono text-xs text-muted-foreground">{vendor.vendorCode}</TableCell>
                                        <TableCell className="text-center font-medium">{vendor.transactions}</TableCell>
                                        <TableCell className="text-right font-semibold">₹{vendor.grossAmount.toLocaleString()}</TableCell>
                                        <TableCell className="text-right text-orange-500">-₹{vendor.platformFee.toLocaleString()}</TableCell>
                                        <TableCell className="text-right font-bold text-emerald-500">₹{vendor.vendorShare.toLocaleString()}</TableCell>
                                        <TableCell className="text-center">
                                          <Badge className={`text-xs ${vendor.status === 'settled' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-orange-500/10 text-orange-500'}`}>
                                            {vendor.status.toUpperCase()}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="font-mono text-xs">{vendor.utr}</TableCell>
                                      </TableRow>
                                    ))}
                                    {/* Total Row */}
                                    <TableRow className="bg-emerald-500/10 font-semibold">
                                      <TableCell>Total</TableCell>
                                      <TableCell></TableCell>
                                      <TableCell className="text-center">{gw.vendorAccount.vendors.reduce((sum: number, v: any) => sum + v.transactions, 0)}</TableCell>
                                      <TableCell className="text-right">₹{gw.vendorAccount.vendors.reduce((sum: number, v: any) => sum + v.grossAmount, 0).toLocaleString()}</TableCell>
                                      <TableCell className="text-right text-orange-500">-₹{gw.vendorAccount.vendors.reduce((sum: number, v: any) => sum + v.platformFee, 0).toLocaleString()}</TableCell>
                                      <TableCell className="text-right text-emerald-500">₹{gw.vendorAccount.vendors.reduce((sum: number, v: any) => sum + v.vendorShare, 0).toLocaleString()}</TableCell>
                                      <TableCell></TableCell>
                                      <TableCell></TableCell>
                                    </TableRow>
                                  </TableBody>
                                </Table>
                              </div>
                            </div>
                          )}

                          {/* Vendor Transactions Table */}
                          <div>
                            <h5 className="font-semibold flex items-center gap-2 mb-4">
                              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                              All Vendor Transactions
                            </h5>
                            <div className="border rounded-lg overflow-x-auto border-emerald-500/30">
                              <Table>
                                <TableHeader>
                                  <TableRow className="bg-emerald-500/10">
                                    <TableHead className="text-xs">Sr.No</TableHead>
                                    <TableHead className="text-xs">Institute Name</TableHead>
                                    <TableHead className="text-xs">Date & Time</TableHead>
                                    <TableHead className="text-xs">Order ID</TableHead>
                                    <TableHead className="text-xs">Payment ID</TableHead>
                                    <TableHead className="text-xs text-right">Order Amt</TableHead>
                                    <TableHead className="text-xs text-right">Txn Amt</TableHead>
                                    <TableHead className="text-xs">Payment Method</TableHead>
                                    <TableHead className="text-xs">Status</TableHead>
                                    <TableHead className="text-xs">Student Name</TableHead>
                                    <TableHead className="text-xs">Student ID</TableHead>
                                    <TableHead className="text-xs">Phone No.</TableHead>
                                    <TableHead className="text-xs">Settlement Date</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {gw.vendorAccount.transactions.map((txn: any, idx: number) => (
                                    <TableRow key={txn.id} className="hover:bg-emerald-500/5">
                                      <TableCell className="text-sm">{idx + 1}</TableCell>
                                      <TableCell className="text-sm">{txn.instituteName}</TableCell>
                                      <TableCell className="text-sm whitespace-nowrap">{txn.dateTime}</TableCell>
                                      <TableCell className="font-mono text-xs">
                                        <Link href={`/transactions/${txn.id}`} className="text-primary hover:underline flex items-center gap-1">
                                          {txn.orderId}
                                          <ExternalLink className="h-3 w-3" />
                                        </Link>
                                      </TableCell>
                                      <TableCell className="font-mono text-xs">{txn.paymentId}</TableCell>
                                      <TableCell className="text-right font-semibold">₹{txn.orderAmount.toLocaleString()}</TableCell>
                                      <TableCell className="text-right">₹{txn.transactionAmount.toLocaleString()}</TableCell>
                                      <TableCell>
                                        <Badge variant="outline" className="text-xs">{txn.paymentMode}</Badge>
                                      </TableCell>
                                      <TableCell>
                                        <Badge className="text-xs bg-emerald-500/10 text-emerald-500">{txn.status}</Badge>
                                      </TableCell>
                                      <TableCell className="text-sm font-medium">{txn.studentName}</TableCell>
                                      <TableCell className="font-mono text-xs">{txn.studentId}</TableCell>
                                      <TableCell className="text-sm">{txn.phone}</TableCell>
                                      <TableCell className="text-sm">{txn.settlementDate}</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                            <div className="flex justify-end mt-2">
                              <p className="text-sm">
                                <span className="text-muted-foreground">Total Vendor Order Amount: </span>
                                <span className="font-bold">₹{gw.vendorAccount.transactions.reduce((sum: number, t: any) => sum + t.orderAmount, 0).toLocaleString()}</span>
                              </p>
                            </div>
                          </div>

                          {/* Vendor Account Net Calculation */}
                          <div className="p-4 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                            <h5 className="font-semibold mb-3">{gw.gateway} - Vendor Account Settlement Calculation</h5>
                            <p className="text-xs text-muted-foreground mb-3">Note: Refunds and Chargebacks are deducted from Merchant Account only, not from Vendor Account</p>
                            <div className="grid grid-cols-4 gap-4 text-center">
                              <div>
                                <p className="text-xs text-muted-foreground">Gross Amount</p>
                                <p className="font-bold">₹{gw.vendorAccount.grossAmount.toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">MDR</p>
                                <p className="font-bold text-destructive">-₹{gw.vendorAccount.mdr.toLocaleString()}</p>
                              </div>
                              <div className="col-span-2 bg-emerald-500/20 rounded-lg p-2">
                                <p className="text-xs text-emerald-600">Net Settled to Vendor Account</p>
                                <p className="text-xl font-bold text-emerald-500">₹{gw.vendorAccount.netAmount.toLocaleString()}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Gateway Total Summary */}
                    <div className="p-4 bg-secondary/50 border-t border-border">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`h-3 w-3 rounded-full ${getGatewayColor(gw.gateway)}`} />
                          <span className="font-semibold">{gw.gateway} Total Settlement</span>
                        </div>
                        <div className="flex items-center gap-8">
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Merchant Account</p>
                            <p className="font-semibold">₹{gw.mainAccount.netAmount.toLocaleString()}</p>
                          </div>
                          <span className="text-xl text-muted-foreground">+</span>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Vendor Account</p>
                            <p className="font-semibold text-emerald-500">₹{gw.vendorAccount.netAmount.toLocaleString()}</p>
                          </div>
                          <span className="text-xl text-muted-foreground">=</span>
                          <div className="text-right bg-primary/10 px-4 py-2 rounded-lg">
                            <p className="text-xs text-primary">Total via {gw.gateway}</p>
                            <p className="text-lg font-bold text-primary">₹{(gw.mainAccount.netAmount + gw.vendorAccount.netAmount).toLocaleString()}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </TabsContent>

          {/* All Transactions Tab */}
          <TabsContent value="all-transactions" className="space-y-6">
            {/* Merchant Transactions Table */}
            <Card className="bg-card border-border border-primary/30">
              <CardHeader className="bg-primary/5">
                <CardTitle className="text-base flex items-center gap-2">
                  <Banknote className="h-5 w-5 text-primary" />
                  All Merchant Account Transactions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    {filterTransactions(getAllMerchantTransactions()).length} transactions | Total: ₹{filterTransactions(getAllMerchantTransactions()).reduce((s, t) => s + t.orderAmount, 0).toLocaleString()}
                  </p>
                  <div className="flex items-center gap-2">
                    <Select value={gatewayFilter} onValueChange={setGatewayFilter}>
                      <SelectTrigger className="w-36 h-8">
                        <SelectValue placeholder="All Gateways" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Gateways</SelectItem>
                        <SelectItem value="Razorpay">Razorpay</SelectItem>
                        <SelectItem value="Cashfree">Cashfree</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search..." 
                        className="pl-9 w-64 h-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <Select value={rowsPerPage} onValueChange={(v) => { setRowsPerPage(v); setCurrentPage(1) }}>
                      <SelectTrigger className="w-24 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10 rows</SelectItem>
                        <SelectItem value="25">25 rows</SelectItem>
                        <SelectItem value="50">50 rows</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="border rounded-lg overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-primary/10">
                        <TableHead className="text-xs">Sr.No</TableHead>
                        <TableHead className="text-xs">Gateway</TableHead>
                        <TableHead className="text-xs">Institute Name</TableHead>
                        <TableHead className="text-xs">Date & Time</TableHead>
                        <TableHead className="text-xs">Order ID</TableHead>
                        <TableHead className="text-xs">Payment ID</TableHead>
                        <TableHead className="text-xs text-right">Order Amt</TableHead>
                        <TableHead className="text-xs text-right">Txn Amt</TableHead>
                        <TableHead className="text-xs text-right">Merchant Amt</TableHead>
                        <TableHead className="text-xs text-right">Vendor Amt</TableHead>
                        <TableHead className="text-xs">Payment Method</TableHead>
                        <TableHead className="text-xs">Status</TableHead>
                        <TableHead className="text-xs">Student Name</TableHead>
                        <TableHead className="text-xs">Student ID</TableHead>
                        <TableHead className="text-xs">Phone No.</TableHead>
                        <TableHead className="text-xs">Settlement Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginateTransactions(filterTransactions(getAllMerchantTransactions())).map((txn: any, idx: number) => (
                        <TableRow key={txn.id} className="hover:bg-primary/5">
                          <TableCell className="text-sm">{(currentPage - 1) * parseInt(rowsPerPage) + idx + 1}</TableCell>
                          <TableCell>
                            <Badge className={`text-xs ${txn.gateway === 'Razorpay' ? 'bg-blue-500/10 text-blue-500' : 'bg-purple-500/10 text-purple-500'}`}>
                              {txn.gateway}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{txn.instituteName}</TableCell>
                          <TableCell className="text-sm whitespace-nowrap">{txn.dateTime}</TableCell>
                          <TableCell className="font-mono text-xs">
                            <Link href={`/transactions/${txn.id}`} className="text-primary hover:underline flex items-center gap-1">
                              {txn.orderId}
                              <ExternalLink className="h-3 w-3" />
                            </Link>
                          </TableCell>
                          <TableCell className="font-mono text-xs">{txn.paymentId}</TableCell>
                          <TableCell className="text-right font-semibold">₹{txn.orderAmount.toLocaleString()}</TableCell>
                          <TableCell className="text-right">₹{txn.transactionAmount.toLocaleString()}</TableCell>
                          <TableCell className="text-right font-semibold text-primary">₹{txn.merchantAmount.toLocaleString()}</TableCell>
                          <TableCell className="text-right text-muted-foreground">₹{txn.vendorAmount.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">{txn.paymentMode}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className="text-xs bg-success/10 text-success">{txn.status}</Badge>
                          </TableCell>
                          <TableCell className="text-sm font-medium">{txn.studentName}</TableCell>
                          <TableCell className="font-mono text-xs">{txn.studentId}</TableCell>
                          <TableCell className="text-sm">{txn.phone}</TableCell>
                          <TableCell className="text-sm">{txn.settlementDate}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {/* Pagination */}
                <div className="flex items-center justify-between mt-4">
                  <p className="text-sm text-muted-foreground">
                    Showing {Math.min((currentPage - 1) * parseInt(rowsPerPage) + 1, filterTransactions(getAllMerchantTransactions()).length)} to {Math.min(currentPage * parseInt(rowsPerPage), filterTransactions(getAllMerchantTransactions()).length)} of {filterTransactions(getAllMerchantTransactions()).length} entries
                  </p>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage(p => p - 1)}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm">Page {currentPage}</span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      disabled={currentPage * parseInt(rowsPerPage) >= filterTransactions(getAllMerchantTransactions()).length}
                      onClick={() => setCurrentPage(p => p + 1)}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Vendor Transactions Table */}
            <Card className="bg-card border-border border-emerald-500/30">
              <CardHeader className="bg-emerald-500/5">
                <CardTitle className="text-base flex items-center gap-2">
                  <Wallet className="h-5 w-5 text-emerald-500" />
                  All Vendor Account Transactions
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    {getAllVendorTransactions().length} transactions | Total: ₹{getAllVendorTransactions().reduce((s, t) => s + t.orderAmount, 0).toLocaleString()}
                  </p>
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input placeholder="Search vendor transactions..." className="pl-9 w-64 h-8" />
                    </div>
                  </div>
                </div>
                <div className="border rounded-lg overflow-x-auto border-emerald-500/20">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-emerald-500/10">
                        <TableHead className="text-xs">Sr.No</TableHead>
                        <TableHead className="text-xs">Gateway</TableHead>
                        <TableHead className="text-xs">Institute Name</TableHead>
                        <TableHead className="text-xs">Date & Time</TableHead>
                        <TableHead className="text-xs">Order ID</TableHead>
                        <TableHead className="text-xs">Payment ID</TableHead>
                        <TableHead className="text-xs text-right">Order Amt</TableHead>
                        <TableHead className="text-xs text-right">Txn Amt</TableHead>
                        <TableHead className="text-xs text-right">Merchant Amt</TableHead>
                        <TableHead className="text-xs text-right">Vendor Amt</TableHead>
                        <TableHead className="text-xs">Payment Method</TableHead>
                        <TableHead className="text-xs">Status</TableHead>
                        <TableHead className="text-xs">Student Name</TableHead>
                        <TableHead className="text-xs">Student ID</TableHead>
                        <TableHead className="text-xs">Phone No.</TableHead>
                        <TableHead className="text-xs">Settlement Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getAllVendorTransactions().map((txn: any, idx: number) => (
                        <TableRow key={txn.id} className="hover:bg-emerald-500/5">
                          <TableCell className="text-sm">{idx + 1}</TableCell>
                          <TableCell>
                            <Badge className={`text-xs ${txn.gateway === 'Razorpay' ? 'bg-blue-500/10 text-blue-500' : 'bg-purple-500/10 text-purple-500'}`}>
                              {txn.gateway}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{txn.instituteName}</TableCell>
                          <TableCell className="text-sm whitespace-nowrap">{txn.dateTime}</TableCell>
                          <TableCell className="font-mono text-xs">
                            <Link href={`/transactions/${txn.id}`} className="text-primary hover:underline flex items-center gap-1">
                              {txn.orderId}
                              <ExternalLink className="h-3 w-3" />
                            </Link>
                          </TableCell>
                          <TableCell className="font-mono text-xs">{txn.paymentId}</TableCell>
                          <TableCell className="text-right font-semibold">₹{txn.orderAmount.toLocaleString()}</TableCell>
                          <TableCell className="text-right">₹{txn.transactionAmount.toLocaleString()}</TableCell>
                          <TableCell className="text-right text-muted-foreground">₹{txn.merchantAmount.toLocaleString()}</TableCell>
                          <TableCell className="text-right font-semibold text-emerald-500">₹{txn.vendorAmount.toLocaleString()}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">{txn.paymentMode}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className="text-xs bg-emerald-500/10 text-emerald-500">{txn.status}</Badge>
                          </TableCell>
                          <TableCell className="text-sm font-medium">{txn.studentName}</TableCell>
                          <TableCell className="font-mono text-xs">{txn.studentId}</TableCell>
                          <TableCell className="text-sm">{txn.phone}</TableCell>
                          <TableCell className="text-sm">{txn.settlementDate}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Refunds Tab */}
          <TabsContent value="refunds" className="space-y-4">
            {/* Total Refund Summary */}
            <div className="grid grid-cols-4 gap-4">
              <Card className="bg-warning/5 border-warning/30">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Total Refunds</p>
                  <p className="text-2xl font-bold text-warning">{getAllRefundTransactions().length}</p>
                </CardContent>
              </Card>
              <Card className="bg-warning/5 border-warning/30">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Total Refund Amount</p>
                  <p className="text-2xl font-bold text-warning">₹{getAllRefundTransactions().reduce((s, r) => s + r.refundAmount, 0).toLocaleString()}</p>
                </CardContent>
              </Card>
              <Card className="bg-emerald-500/5 border-emerald-500/30">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Processed</p>
                  <p className="text-2xl font-bold text-emerald-500">{getAllRefundTransactions().filter(r => r.status === 'processed').length}</p>
                </CardContent>
              </Card>
              <Card className="bg-orange-500/5 border-orange-500/30">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Pending</p>
                  <p className="text-2xl font-bold text-orange-500">{getAllRefundTransactions().filter(r => r.status === 'pending').length}</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-card border-border border-warning/30">
              <CardHeader className="bg-warning/5">
                <div className="flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      <RefreshCcw className="h-5 w-5 text-warning" />
                      All Refund Transactions
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" className="h-9">
                        <Download className="h-4 w-4 mr-2" />
                        Export
                      </Button>
                    </div>
                  </div>
                  {/* Filters Row */}
                  <div className="flex flex-wrap items-center gap-3">
                    <Select value={refundDateFilter} onValueChange={setRefundDateFilter}>
                      <SelectTrigger className="w-32 h-9">
                        <SelectValue placeholder="Date" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Time</SelectItem>
                        <SelectItem value="today">Today</SelectItem>
                        <SelectItem value="7days">Last 7 Days</SelectItem>
                        <SelectItem value="30days">Last 30 Days</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={refundInstituteFilter} onValueChange={setRefundInstituteFilter}>
                      <SelectTrigger className="w-40 h-9">
                        <SelectValue placeholder="Institute" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Institutes</SelectItem>
                        <SelectItem value="Delhi Public School">Delhi Public School</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={refundGatewayFilter} onValueChange={setRefundGatewayFilter}>
                      <SelectTrigger className="w-32 h-9">
                        <SelectValue placeholder="Gateway" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Gateways</SelectItem>
                        <SelectItem value="Razorpay">Razorpay</SelectItem>
                        <SelectItem value="Cashfree">Cashfree</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={refundStatusFilter} onValueChange={setRefundStatusFilter}>
                      <SelectTrigger className="w-32 h-9">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="processed">Processed</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="failed">Failed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={refundVendorFilter} onValueChange={setRefundVendorFilter}>
                      <SelectTrigger className="w-32 h-9">
                        <SelectValue placeholder="Account" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Accounts</SelectItem>
                        <SelectItem value="merchant">Merchant</SelectItem>
                        <SelectItem value="vendor">Vendor</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="relative flex-1 min-w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search by Refund ID, Order ID, Student Name, Phone..." 
                        className="pl-9 h-9"
                        value={refundSearch}
                        onChange={(e) => { setRefundSearch(e.target.value); setRefundCurrentPage(1) }}
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-muted-foreground">
                    Showing {paginateRefunds(filterRefunds(getAllRefundTransactions())).length} of {filterRefunds(getAllRefundTransactions()).length} refunds | 
                    Total: <span className="font-semibold text-warning">₹{filterRefunds(getAllRefundTransactions()).reduce((s, r) => s + r.refundAmount, 0).toLocaleString()}</span>
                  </p>
                  <Select value={refundRowsPerPage} onValueChange={(v) => { setRefundRowsPerPage(v); setRefundCurrentPage(1) }}>
                    <SelectTrigger className="w-28 h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10 rows</SelectItem>
                      <SelectItem value="25">25 rows</SelectItem>
                      <SelectItem value="50">50 rows</SelectItem>
                      <SelectItem value="100">100 rows</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="border rounded-lg overflow-x-auto border-warning/20">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-warning/10">
                        <TableHead className="text-xs">Sr.No</TableHead>
                        <TableHead className="text-xs">School Name</TableHead>
                        <TableHead className="text-xs">Refund ID</TableHead>
                        <TableHead className="text-xs">Order ID</TableHead>
                        <TableHead className="text-xs text-right">Refund Amount</TableHead>
                        <TableHead className="text-xs text-right">Order Amount</TableHead>
                        <TableHead className="text-xs text-right">Transaction Amt</TableHead>
                        <TableHead className="text-xs">Status</TableHead>
                        <TableHead className="text-xs">Created Date</TableHead>
                        <TableHead className="text-xs">Updated Date</TableHead>
                        <TableHead className="text-xs">Reason</TableHead>
                        <TableHead className="text-xs">Gateway</TableHead>
                        <TableHead className="text-xs">Account Type</TableHead>
                        <TableHead className="text-xs text-center">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paginateRefunds(filterRefunds(getAllRefundTransactions())).length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={14} className="text-center py-8 text-muted-foreground">
                            No refunds found
                          </TableCell>
                        </TableRow>
                      ) : (
                        paginateRefunds(filterRefunds(getAllRefundTransactions())).map((refund: any, idx: number) => (
                          <TableRow key={refund.id} className="hover:bg-warning/5">
                            <TableCell className="text-sm">{(refundCurrentPage - 1) * parseInt(refundRowsPerPage) + idx + 1}</TableCell>
                            <TableCell className="text-sm font-medium">{refund.instituteName}</TableCell>
                            <TableCell>
                              <Link href={`/settlements/refund/${refund.refundId}`} className="font-mono text-xs text-primary hover:underline">
                                {refund.refundId}
                              </Link>
                            </TableCell>
                            <TableCell className="font-mono text-xs">{refund.orderId}</TableCell>
                            <TableCell className="text-right font-bold text-warning">₹{refund.refundAmount.toLocaleString()}</TableCell>
                            <TableCell className="text-right font-semibold">₹{refund.orderAmount.toLocaleString()}</TableCell>
                            <TableCell className="text-right">₹{(refund.orderAmount - refund.pgCharges - refund.erpCharges).toLocaleString()}</TableCell>
                            <TableCell>
                              <Badge className={`text-xs ${
                                refund.status === 'processed' ? 'bg-emerald-500/10 text-emerald-500' : 
                                refund.status === 'pending' ? 'bg-orange-500/10 text-orange-500' : 
                                'bg-destructive/10 text-destructive'
                              }`}>
                                {refund.status.toUpperCase()}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">{refund.refundDate}</TableCell>
                            <TableCell className="text-sm">{refund.settlementDate || '-'}</TableCell>
                            <TableCell className="text-sm max-w-32 truncate" title={refund.reason}>{refund.reason}</TableCell>
                            <TableCell>
                              <Badge className={`text-xs ${refund.gateway === 'Razorpay' ? 'bg-blue-500/10 text-blue-500' : 'bg-purple-500/10 text-purple-500'}`}>
                                {refund.gateway}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {refund.accountType === 'vendor' ? 'Vendor' : 'Merchant'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-1">
                                <Link href={`/settlements/refund/${refund.refundId}`}>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-7 w-7"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                </Link>
                                {refund.status === 'pending' && (
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-7 w-7 text-destructive hover:text-destructive"
                                    onClick={() => handleCancelRefund(refund)}
                                  >
                                    <XCircle className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
                
                {/* Pagination */}
                {filterRefunds(getAllRefundTransactions()).length > parseInt(refundRowsPerPage) && (
                  <div className="flex items-center justify-between mt-4">
                    <p className="text-sm text-muted-foreground">
                      Page {refundCurrentPage} of {Math.ceil(filterRefunds(getAllRefundTransactions()).length / parseInt(refundRowsPerPage))}
                    </p>
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        disabled={refundCurrentPage === 1}
                        onClick={() => setRefundCurrentPage(p => p - 1)}
                      >
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        disabled={refundCurrentPage >= Math.ceil(filterRefunds(getAllRefundTransactions()).length / parseInt(refundRowsPerPage))}
                        onClick={() => setRefundCurrentPage(p => p + 1)}
                      >
                        Next
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}

                <div className="mt-4 p-3 bg-warning/10 rounded-lg border border-warning/20">
                  <p className="text-sm text-warning">
                    <strong>Note:</strong> Refund is on ORDER AMOUNT. PG Charges and ERP Commission are retained and not refunded.
                  </p>
                </div>
              </CardContent>
            </Card>

            </TabsContent>

          {/* Chargebacks Tab */}
          <TabsContent value="chargebacks" className="space-y-4">
            <Card className="bg-card border-border border-destructive/30">
              <CardHeader className="bg-destructive/5">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <XCircle className="h-5 w-5 text-destructive" />
                    All Chargeback Transactions
                  </CardTitle>
                  <div className="flex items-center gap-3">
                    <Select value={chargebackGatewayFilter} onValueChange={setChargebackGatewayFilter}>
                      <SelectTrigger className="w-36 h-9">
                        <SelectValue placeholder="All Gateways" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Gateways</SelectItem>
                        <SelectItem value="Razorpay">Razorpay</SelectItem>
                        <SelectItem value="Cashfree">Cashfree</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input 
                        placeholder="Search chargebacks..." 
                        className="pl-9 w-64 h-9"
                        value={chargebackSearch}
                        onChange={(e) => setChargebackSearch(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground mb-4">
                  {filterChargebacks(getAllChargebackTransactions()).length} chargebacks | Total Deducted: ₹{filterChargebacks(getAllChargebackTransactions()).reduce((s, c) => s + c.totalDeduction, 0).toLocaleString()}
                </p>
                <div className="border rounded-lg overflow-x-auto border-destructive/20">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-destructive/10">
                        <TableHead className="text-xs">Sr.No</TableHead>
                        <TableHead className="text-xs">Gateway</TableHead>
                        <TableHead className="text-xs">Institute Name</TableHead>
                        <TableHead className="text-xs">Order ID</TableHead>
                        <TableHead className="text-xs">Payment ID</TableHead>
                        <TableHead className="text-xs text-right">Order Amt</TableHead>
                        <TableHead className="text-xs text-right">CB Fee</TableHead>
                        <TableHead className="text-xs text-right">Total Deduction</TableHead>
                        <TableHead className="text-xs">Reason</TableHead>
                        <TableHead className="text-xs">Student Name</TableHead>
                        <TableHead className="text-xs">Student ID</TableHead>
                        <TableHead className="text-xs">Phone No.</TableHead>
                        <TableHead className="text-xs">CB Date</TableHead>
                        <TableHead className="text-xs">Settlement Date</TableHead>
                        <TableHead className="text-xs">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filterChargebacks(getAllChargebackTransactions()).length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={15} className="text-center py-8 text-muted-foreground">
                            No chargebacks found
                          </TableCell>
                        </TableRow>
                      ) : (
                        filterChargebacks(getAllChargebackTransactions()).map((cb: any, idx: number) => (
                          <TableRow key={cb.id} className="hover:bg-destructive/5">
                            <TableCell className="text-sm">{idx + 1}</TableCell>
                            <TableCell>
                              <Badge className={`text-xs ${cb.gateway === 'Razorpay' ? 'bg-blue-500/10 text-blue-500' : 'bg-purple-500/10 text-purple-500'}`}>
                                {cb.gateway}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">{cb.instituteName}</TableCell>
                            <TableCell className="font-mono text-xs text-primary">{cb.orderId}</TableCell>
                            <TableCell className="font-mono text-xs">{cb.paymentId}</TableCell>
                            <TableCell className="text-right font-semibold">₹{cb.orderAmount.toLocaleString()}</TableCell>
                            <TableCell className="text-right text-destructive">₹{cb.chargebackFee.toLocaleString()}</TableCell>
                            <TableCell className="text-right font-bold text-destructive">-₹{cb.totalDeduction.toLocaleString()}</TableCell>
                            <TableCell className="text-sm">{cb.reason}</TableCell>
                            <TableCell className="text-sm font-medium">{cb.studentName}</TableCell>
                            <TableCell className="font-mono text-xs">{cb.studentId}</TableCell>
                            <TableCell className="text-sm">{cb.phone}</TableCell>
                            <TableCell className="text-sm">{cb.cbDate}</TableCell>
                            <TableCell className="text-sm">{cb.settlementDate}</TableCell>
                            <TableCell>
                              <Badge className="text-xs bg-destructive/10 text-destructive">{cb.status}</Badge>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
                <div className="mt-4 p-3 bg-destructive/10 rounded-lg border border-destructive/20">
                  <p className="text-sm text-destructive">
                    <strong>Warning:</strong> Chargeback deducts ORDER AMOUNT + Chargeback Fee from settlement.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Summary Tab */}
          <TabsContent value="summary">
            <Card className="bg-card border-border border-success/30">
              <CardHeader className="bg-success/5">
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                  Final Settlement Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Overall Calculation */}
                  <div className="flex flex-wrap items-center justify-center gap-4 p-4 bg-secondary/30 rounded-lg">
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground uppercase">Gross Collection</p>
                      <p className="text-xl font-bold">₹{settlement.summary.totalOrderAmount.toLocaleString()}</p>
                    </div>
                    <span className="text-2xl text-muted-foreground">-</span>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground uppercase">MDR Charges</p>
                      <p className="text-xl font-bold text-destructive">₹{settlement.summary.totalMDR.toLocaleString()}</p>
                    </div>
                    <span className="text-2xl text-muted-foreground">-</span>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground uppercase">Refunds</p>
                      <p className="text-xl font-bold text-warning">₹{settlement.summary.totalRefunds.toLocaleString()}</p>
                    </div>
                    <span className="text-2xl text-muted-foreground">-</span>
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground uppercase">Chargebacks</p>
                      <p className="text-xl font-bold text-destructive">₹{settlement.summary.totalChargebacks.toLocaleString()}</p>
                    </div>
                    <span className="text-2xl text-muted-foreground">=</span>
                    <div className="text-center bg-success/10 px-6 py-3 rounded-lg border border-success/30">
                      <p className="text-xs text-success uppercase">Net Settlement</p>
                      <p className="text-2xl font-bold text-success">₹{settlement.summary.netSettlement.toLocaleString()}</p>
                    </div>
                  </div>

                  <Separator />

                  {/* By Gateway */}
                  <div className="space-y-2">
                    {settlement.gateways.map((gw: any) => (
                      <div key={gw.gateway} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className={`h-8 w-8 rounded-lg ${getGatewayColor(gw.gateway)} flex items-center justify-center`}>
                            <CreditCard className="h-4 w-4 text-white" />
                          </div>
                          <span className="font-medium">{gw.gateway}</span>
                        </div>
                        <div className="flex items-center gap-8">
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Merchant UTR</p>
                            <p className="font-mono text-xs">{gw.mainAccount.utr}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Vendor UTR</p>
                            <p className="font-mono text-xs">{gw.vendorAccount.utr}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Merchant Account</p>
                            <p className="font-semibold">₹{gw.mainAccount.netAmount.toLocaleString()}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Vendor Account</p>
                            <p className="font-semibold text-emerald-500">₹{gw.vendorAccount.netAmount.toLocaleString()}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">Total</p>
                            <p className="font-bold">₹{(gw.mainAccount.netAmount + gw.vendorAccount.netAmount).toLocaleString()}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Grand Total */}
                  <div className="flex items-center justify-between p-4 bg-success/10 rounded-lg border border-success/30">
                    <div>
                      <p className="text-lg font-semibold">Grand Total Settlement</p>
                      <p className="text-sm text-muted-foreground">{settlement.settlementDate} | {settlement.summary.totalStudents} students</p>
                    </div>
                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">To Merchant Account</p>
                        <p className="text-xl font-bold">₹{settlement.gateways.reduce((sum: number, gw: any) => sum + gw.mainAccount.netAmount, 0).toLocaleString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">To Vendor Account</p>
                        <p className="text-xl font-bold text-emerald-500">₹{settlement.gateways.reduce((sum: number, gw: any) => sum + gw.vendorAccount.netAmount, 0).toLocaleString()}</p>
                      </div>
                      <div className="text-right bg-success/20 px-6 py-3 rounded-lg">
                        <p className="text-xs text-success uppercase">Net Settlement</p>
                        <p className="text-2xl font-bold text-success">₹{settlement.summary.netSettlement.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
