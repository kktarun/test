"use client"

import { useParams } from "next/navigation"
import Link from "next/link"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  ChevronLeft,
  Copy,
  CheckCircle2,
  XCircle,
  RefreshCcw,
  Clock,
  CreditCard,
  Download,
  Building2,
  User,
  Phone,
  Mail,
  FileText,
  Wallet,
  AlertTriangle,
  Send,
  Banknote,
} from "lucide-react"

// Mock refund data - in production this would come from API
const refundData: Record<string, any> = {
  "RFD-RZP-001": {
    refundId: "RFD-RZP-001",
    paymentId: "pay_RZP001234REF1",
    orderId: "ORD-DPS-REF-001",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-RKP",
    studentName: "Karan Malhotra",
    studentId: "STU-REF-001",
    class: "9-A",
    phone: "+91 98765 43218",
    email: "karan.m@email.com",
    gateway: "Razorpay",
    accountType: "merchant",
    // Amount Breakup
    orderAmount: 15000,
    transactionAmount: 15300,
    pgCharges: 300,
    erpCharges: 500,
    gstOnCharges: 144,
    netToMerchant: 14356,
    refundAmount: 13500,
    refundPgCharges: 0,
    refundErpCharges: 0,
    reason: "Student transferred to another school. Parent requested full fee refund for remaining term.",
    status: "processed",
    // Timeline with actual timestamps
    timeline: [
      { event: "Refund Requested", status: "completed", timestamp: "2024-03-10 09:30:00 AM", description: "Refund request submitted by admin", user: "Admin User" },
      { event: "Request Approved", status: "completed", timestamp: "2024-03-10 10:15:00 AM", description: "Refund approved by finance manager", user: "Finance Manager" },
      { event: "Sent to Gateway", status: "completed", timestamp: "2024-03-10 10:16:00 AM", description: "Refund request sent to Razorpay", user: "System" },
      { event: "Gateway Processing", status: "completed", timestamp: "2024-03-10 10:20:00 AM", description: "Razorpay acknowledged refund request", user: "Razorpay" },
      { event: "Bank Processing", status: "completed", timestamp: "2024-03-10 02:30:00 PM", description: "Funds transferred to customer bank", user: "HDFC Bank" },
      { event: "Refund Completed", status: "completed", timestamp: "2024-03-11 09:00:00 AM", description: "Refund credited to customer account", user: "System" },
    ],
    createdDate: "2024-03-10",
    createdTime: "09:30:00 AM",
    updatedDate: "2024-03-11",
    updatedTime: "09:00:00 AM",
    settlementDate: "2024-03-11",
    settlementId: "STL-RZP-MAIN-2024-0311",
    bankDetails: {
      accountName: "Karan Malhotra",
      accountNumber: "XXXX XXXX 4521",
      ifsc: "HDFC0001234",
      bankName: "HDFC Bank",
    },
    feeType: "Tuition Fee",
    paymentMode: "UPI",
    originalPaymentDate: "2024-02-15",
  },
  "RFD-RZP-002": {
    refundId: "RFD-RZP-002",
    paymentId: "pay_RZP001234REF2",
    orderId: "ORD-DPS-REF-002",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-RKP",
    studentName: "Simran Kaur",
    studentId: "STU-REF-002",
    class: "10-A",
    phone: "+91 98765 43219",
    email: "simran.k@email.com",
    gateway: "Razorpay",
    accountType: "merchant",
    orderAmount: 12000,
    transactionAmount: 12240,
    pgCharges: 180,
    erpCharges: 150,
    gstOnCharges: 59,
    netToMerchant: 11611,
    refundAmount: 11500,
    refundPgCharges: 0,
    refundErpCharges: 0,
    reason: "Duplicate payment made by parent. Second payment needs to be refunded.",
    status: "processed",
    timeline: [
      { event: "Refund Requested", status: "completed", timestamp: "2024-03-10 11:00:00 AM", description: "Refund request submitted by admin", user: "Admin User" },
      { event: "Request Approved", status: "completed", timestamp: "2024-03-10 11:30:00 AM", description: "Refund approved by finance manager", user: "Finance Manager" },
      { event: "Sent to Gateway", status: "completed", timestamp: "2024-03-10 11:31:00 AM", description: "Refund request sent to Razorpay", user: "System" },
      { event: "Gateway Processing", status: "completed", timestamp: "2024-03-10 11:35:00 AM", description: "Razorpay acknowledged refund request", user: "Razorpay" },
      { event: "Bank Processing", status: "completed", timestamp: "2024-03-10 03:00:00 PM", description: "Funds transferred to customer bank", user: "ICICI Bank" },
      { event: "Refund Completed", status: "completed", timestamp: "2024-03-11 10:00:00 AM", description: "Refund credited to customer account", user: "System" },
    ],
    createdDate: "2024-03-10",
    createdTime: "11:00:00 AM",
    updatedDate: "2024-03-11",
    updatedTime: "10:00:00 AM",
    settlementDate: "2024-03-11",
    settlementId: "STL-RZP-MAIN-2024-0311",
    bankDetails: {
      accountName: "Simran Kaur",
      accountNumber: "XXXX XXXX 7890",
      ifsc: "ICIC0005678",
      bankName: "ICICI Bank",
    },
    feeType: "Tuition Fee",
    paymentMode: "Credit Card",
    originalPaymentDate: "2024-02-20",
  },
  "RFD-RZP-003": {
    refundId: "RFD-RZP-003",
    paymentId: "pay_RZP001234REF3",
    orderId: "ORD-DPS-REF-003",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-RKP",
    studentName: "Rahul Verma",
    studentId: "STU-REF-003",
    class: "8-B",
    phone: "+91 98765 43221",
    email: "rahul.v@email.com",
    gateway: "Razorpay",
    accountType: "merchant",
    orderAmount: 18000,
    transactionAmount: 18360,
    pgCharges: 270,
    erpCharges: 500,
    gstOnCharges: 139,
    netToMerchant: 17451,
    refundAmount: 16500,
    refundPgCharges: 0,
    refundErpCharges: 0,
    reason: "Course cancellation requested by parent due to schedule conflicts.",
    status: "pending",
    timeline: [
      { event: "Refund Requested", status: "completed", timestamp: "2024-03-11 09:00:00 AM", description: "Refund request submitted by admin", user: "Admin User" },
      { event: "Request Approved", status: "completed", timestamp: "2024-03-11 09:45:00 AM", description: "Refund approved by finance manager", user: "Finance Manager" },
      { event: "Sent to Gateway", status: "completed", timestamp: "2024-03-11 09:46:00 AM", description: "Refund request sent to Razorpay", user: "System" },
      { event: "Gateway Processing", status: "in-progress", timestamp: "2024-03-11 09:50:00 AM", description: "Awaiting Razorpay processing", user: "Razorpay" },
      { event: "Bank Processing", status: "pending", timestamp: null, description: "Waiting for gateway to process", user: null },
      { event: "Refund Completed", status: "pending", timestamp: null, description: "Estimated: 5-7 business days", user: null },
    ],
    createdDate: "2024-03-11",
    createdTime: "09:00:00 AM",
    updatedDate: "2024-03-11",
    updatedTime: "09:50:00 AM",
    settlementDate: null,
    settlementId: null,
    bankDetails: {
      accountName: "Rahul Verma",
      accountNumber: "XXXX XXXX 1234",
      ifsc: "SBIN0001234",
      bankName: "State Bank of India",
    },
    feeType: "Tuition Fee",
    paymentMode: "Debit Card",
    originalPaymentDate: "2024-03-01",
  },
}

// Default refund
const defaultRefund = refundData["RFD-RZP-001"]

export default function RefundDetailPage() {
  const params = useParams()
  const refundId = params.id as string
  const refund = refundData[refundId] || defaultRefund

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processed":
      case "completed":
        return "bg-emerald-500/10 text-emerald-500"
      case "pending":
      case "in-progress":
        return "bg-orange-500/10 text-orange-500"
      case "failed":
      case "rejected":
        return "bg-destructive/10 text-destructive"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getTimelineIcon = (event: string, status: string) => {
    if (status === "pending") return <Clock className="h-4 w-4 text-muted-foreground" />
    if (status === "in-progress") return <RefreshCcw className="h-4 w-4 text-orange-500 animate-spin" />
    
    switch (event) {
      case "Refund Requested":
        return <FileText className="h-4 w-4 text-blue-500" />
      case "Request Approved":
        return <CheckCircle2 className="h-4 w-4 text-emerald-500" />
      case "Sent to Gateway":
        return <Send className="h-4 w-4 text-purple-500" />
      case "Gateway Processing":
        return <CreditCard className="h-4 w-4 text-blue-500" />
      case "Bank Processing":
        return <Banknote className="h-4 w-4 text-cyan-500" />
      case "Refund Completed":
        return <CheckCircle2 className="h-4 w-4 text-emerald-500" />
      case "Request Rejected":
        return <XCircle className="h-4 w-4 text-destructive" />
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const handleCancelRefund = () => {
    alert(`Cancel refund ${refund.refundId} - This would call an API in production`)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/settlements">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold">Refund Receipt</h1>
                <Badge className={`${getStatusColor(refund.status)}`}>
                  {refund.status.toUpperCase()}
                </Badge>
              </div>
              <p className="text-muted-foreground">
                Refund ID: <span className="font-mono">{refund.refundId}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Download Receipt
            </Button>
            {refund.status === "pending" && (
              <Button variant="destructive" onClick={handleCancelRefund}>
                <XCircle className="h-4 w-4 mr-2" />
                Cancel Refund
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Left Column - Main Details */}
          <div className="col-span-2 space-y-6">
            {/* Refund Summary */}
            <Card className="border-warning/30">
              <CardHeader className="bg-warning/5">
                <CardTitle className="text-base flex items-center gap-2">
                  <RefreshCcw className="h-5 w-5 text-warning" />
                  Refund Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-4 gap-6">
                  <div className="text-center p-4 bg-secondary/30 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Order Amount</p>
                    <p className="text-2xl font-bold">₹{refund.orderAmount.toLocaleString()}</p>
                  </div>
                  <div className="text-center p-4 bg-secondary/30 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Transaction Amount</p>
                    <p className="text-2xl font-bold">₹{refund.transactionAmount.toLocaleString()}</p>
                  </div>
                  <div className="text-center p-4 bg-secondary/30 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Charges Retained</p>
                    <p className="text-2xl font-bold text-muted-foreground">₹{(refund.pgCharges + refund.erpCharges).toLocaleString()}</p>
                  </div>
                  <div className="text-center p-4 bg-warning/10 rounded-lg border border-warning/30">
                    <p className="text-xs text-warning mb-1">Refund Amount</p>
                    <p className="text-2xl font-bold text-warning">₹{refund.refundAmount.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Transaction Breakup */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Wallet className="h-5 w-5" />
                  Transaction Breakup
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Original Payment */}
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground mb-3">Original Payment</h4>
                    <div className="space-y-2 bg-secondary/20 p-4 rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Order Amount</span>
                        <span className="font-semibold">₹{refund.orderAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">PG Charges (2%)</span>
                        <span className="text-muted-foreground">+ ₹{refund.pgCharges.toLocaleString()}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="font-medium">Transaction Amount (Paid by Parent)</span>
                        <span className="font-bold">₹{refund.transactionAmount.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Deductions */}
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground mb-3">Deductions from Order Amount</h4>
                    <div className="space-y-2 bg-secondary/20 p-4 rounded-lg">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Order Amount</span>
                        <span className="font-semibold">₹{refund.orderAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">PG MDR Charges</span>
                        <span className="text-destructive">- ₹{refund.pgCharges.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ERP Commission</span>
                        <span className="text-destructive">- ₹{refund.erpCharges.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">GST on Charges (18%)</span>
                        <span className="text-destructive">- ₹{refund.gstOnCharges.toLocaleString()}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="font-medium">Net Settled to Merchant</span>
                        <span className="font-bold text-emerald-500">₹{refund.netToMerchant.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Refund Calculation */}
                  <div>
                    <h4 className="text-sm font-semibold text-muted-foreground mb-3">Refund Calculation</h4>
                    <div className="space-y-2 bg-warning/5 p-4 rounded-lg border border-warning/30">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Order Amount</span>
                        <span className="font-semibold">₹{refund.orderAmount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">PG Charges (Retained)</span>
                        <span className="text-destructive">- ₹{refund.pgCharges.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ERP Commission (Retained)</span>
                        <span className="text-destructive">- ₹{refund.erpCharges.toLocaleString()}</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="font-medium">Refund Amount to Customer</span>
                        <span className="font-bold text-warning text-lg">₹{refund.refundAmount.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/30">
                    <p className="text-sm text-blue-500">
                      <strong>Note:</strong> Refund is processed on the Order Amount. PG Convenience fee paid by parent (₹{(refund.transactionAmount - refund.orderAmount).toLocaleString()}) is non-refundable. PG MDR and ERP Commission are retained.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Order & Payment Details */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Order & Payment Details
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <p className="text-xs text-muted-foreground">Order ID</p>
                      <div className="flex items-center gap-2">
                        <p className="font-mono font-semibold">{refund.orderId}</p>
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(refund.orderId)}>
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Payment ID</p>
                      <div className="flex items-center gap-2">
                        <p className="font-mono">{refund.paymentId}</p>
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(refund.paymentId)}>
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Payment Gateway</p>
                      <Badge className={`${refund.gateway === 'Razorpay' ? 'bg-blue-500/10 text-blue-500' : 'bg-purple-500/10 text-purple-500'}`}>
                        {refund.gateway}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Payment Mode</p>
                      <p className="font-medium">{refund.paymentMode}</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <p className="text-xs text-muted-foreground">Fee Type</p>
                      <p className="font-medium">{refund.feeType}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Original Payment Date</p>
                      <p className="font-medium">{refund.originalPaymentDate}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Account Type</p>
                      <Badge variant="outline">{refund.accountType === 'vendor' ? 'Vendor' : 'Merchant'}</Badge>
                    </div>
                    {refund.settlementId && (
                      <div>
                        <p className="text-xs text-muted-foreground">Settlement ID</p>
                        <p className="font-mono text-sm">{refund.settlementId}</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Refund Reason */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                  Refund Reason
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <p className="text-sm">{refund.reason}</p>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Timeline & Info */}
          <div className="space-y-6">
            {/* Refund Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Refund Lifecycle
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-6">
                  {refund.timeline.map((item: any, idx: number) => (
                    <div key={idx} className="relative">
                      {idx < refund.timeline.length - 1 && (
                        <div className={`absolute left-4 top-8 w-0.5 h-full ${item.status === 'completed' ? 'bg-emerald-500/50' : 'bg-muted'}`} />
                      )}
                      <div className="flex items-start gap-4">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          item.status === 'completed' ? 'bg-emerald-500/20' : 
                          item.status === 'in-progress' ? 'bg-orange-500/20' : 
                          'bg-muted'
                        }`}>
                          {getTimelineIcon(item.event, item.status)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={`font-medium ${item.status === 'pending' ? 'text-muted-foreground' : ''}`}>
                            {item.event}
                          </p>
                          {item.timestamp && (
                            <p className="text-xs text-muted-foreground">{item.timestamp}</p>
                          )}
                          <p className={`text-sm mt-1 ${item.status === 'pending' ? 'text-muted-foreground italic' : ''}`}>
                            {item.description}
                          </p>
                          {item.user && item.status !== 'pending' && (
                            <p className="text-xs text-muted-foreground mt-1">By: {item.user}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Institute Details */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Institute Details
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Institute Name</p>
                  <p className="font-semibold">{refund.instituteName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Institute Code</p>
                  <p className="font-mono">{refund.instituteCode}</p>
                </div>
              </CardContent>
            </Card>

            {/* Student Details */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Student Details
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Student Name</p>
                  <p className="font-semibold">{refund.studentName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Student ID</p>
                  <p className="font-mono">{refund.studentId}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Class</p>
                  <p className="font-medium">{refund.class}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm">{refund.phone}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm">{refund.email}</p>
                </div>
              </CardContent>
            </Card>

            {/* Bank Details (for credit) */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Banknote className="h-5 w-5" />
                  Refund Credit To
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Account Holder</p>
                  <p className="font-semibold">{refund.bankDetails.accountName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Account Number</p>
                  <p className="font-mono">{refund.bankDetails.accountNumber}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Bank</p>
                  <p className="font-medium">{refund.bankDetails.bankName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">IFSC</p>
                  <p className="font-mono">{refund.bankDetails.ifsc}</p>
                </div>
              </CardContent>
            </Card>

            {/* Dates */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Important Dates
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground">Refund Initiated</p>
                  <p className="font-medium">{refund.createdDate} at {refund.createdTime}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Last Updated</p>
                  <p className="font-medium">{refund.updatedDate} at {refund.updatedTime}</p>
                </div>
                {refund.settlementDate && (
                  <div>
                    <p className="text-xs text-muted-foreground">Settlement Date</p>
                    <p className="font-medium">{refund.settlementDate}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
