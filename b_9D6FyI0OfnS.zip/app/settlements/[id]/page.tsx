"use client"

import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  ArrowLeft,
  Download,
  Building2,
  Wallet,
  CreditCard,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Minus,
  Split,
  FileText,
  BanknoteIcon,
  Calculator,
  Receipt,
  TrendingUp,
  Clock,
  RefreshCw,
  Percent,
  ExternalLink,
} from "lucide-react"
import Link from "next/link"

// Settlement data with ERP commission
interface Settlement {
  id: string
  settlementDate: string
  collectionPeriod: string
  instituteId: string
  instituteName: string
  instituteCode: string
  // Amounts
  grossOrderAmount: number
  totalMdrCharges: number
  totalErpCommission: number
  totalAdjustments: number
  netSettlementAmount: number
  // Counts
  transactionCount: number
  studentCount: number
  // Status
  status: "settled" | "pending" | "delayed" | "partial"
  expectedDate: string
  settledDate?: string
  // Bank Details
  bankAccount: string
  ifscCode: string
  utr?: string
  // Gateway Breakdown
  gatewaySettlements: Array<{
    gateway: string
    transactionCount: number
    grossAmount: number
    mdrCharges: number
    erpCommission: number
    adjustments: Array<{
      refundId: string
      originalTxnId: string
      studentName: string
      amount: number
      reason: string
      refundDate: string
      pgChargesDeducted: number
      erpCommissionDeducted: number
      netRefundAmount: number
    }>
    netAmount: number
    utr?: string
    status: "settled" | "pending" | "delayed"
    settledAt?: string
    splitDetails?: Array<{
      beneficiary: string
      accountNumber: string
      ifsc: string
      amount: number
      percentage: number
    }>
  }>
  // Transactions
  transactions: Array<{
    id: string
    orderId: string
    edvironOrderId: string
    gatewayTxnId: string
    studentName: string
    studentId: string
    amount: number
    paymentMode: string
    channel: string
    date: string
    mdrAmount: number
    mdrPercentage: number
    mdrBearing: "surcharge" | "merchant_bearing"
    erpCommission: number
    erpCommissionPercentage: number
    vendorAmount: number
    cardNetwork?: string
    upiPsp?: string
    isFinancing?: boolean
    financingType?: string
    financingCharges?: {
      parentCharge: number
      instituteCharge: number
      bankCharge: number
    }
  }>
}

const settlements: Record<string, Settlement> = {
  "STL001234": {
    id: "STL001234",
    settlementDate: "2024-01-16",
    collectionPeriod: "2024-01-15",
    instituteId: "INST-DPS-001",
    instituteName: "Delhi Public School",
    instituteCode: "DPS-DEL-001",
    grossOrderAmount: 4820000,
    totalMdrCharges: 72300,
    totalErpCommission: 48200,
    totalAdjustments: 25000,
    netSettlementAmount: 4674500,
    transactionCount: 156,
    studentCount: 142,
    status: "settled",
    expectedDate: "2024-01-16",
    settledDate: "2024-01-16 14:30:00",
    bankAccount: "HDFC ****4521",
    ifscCode: "HDFC0001234",
    utr: "RAZR2024011512345678",
    gatewaySettlements: [
      {
        gateway: "Razorpay",
        transactionCount: 98,
        grossAmount: 3200000,
        mdrCharges: 48000,
        erpCommission: 32000,
        adjustments: [
          {
            refundId: "RFD-2024-001",
            originalTxnId: "TXN001234500",
            studentName: "Rahul Kumar",
            amount: 15000,
            reason: "Student transferred",
            refundDate: "2024-01-14",
            pgChargesDeducted: 300,
            erpCommissionDeducted: 150,
            netRefundAmount: 14550,
          },
        ],
        netAmount: 3105000,
        utr: "RAZR2024011512345678",
        status: "settled",
        settledAt: "2024-01-16 14:30:00",
        splitDetails: [
          {
            beneficiary: "DPS Main Account",
            accountNumber: "HDFC ****4521",
            ifsc: "HDFC0001234",
            amount: 2800000,
            percentage: 90.2,
          },
          {
            beneficiary: "Transport Vendor",
            accountNumber: "ICICI ****8765",
            ifsc: "ICIC0005678",
            amount: 305000,
            percentage: 9.8,
          },
        ],
      },
      {
        gateway: "Cashfree",
        transactionCount: 58,
        grossAmount: 1620000,
        mdrCharges: 24300,
        erpCommission: 16200,
        adjustments: [
          {
            refundId: "RFD-2024-002",
            originalTxnId: "TXN001234510",
            studentName: "Priya Singh",
            amount: 10000,
            reason: "Duplicate payment",
            refundDate: "2024-01-14",
            pgChargesDeducted: 200,
            erpCommissionDeducted: 100,
            netRefundAmount: 9700,
          },
        ],
        netAmount: 1569500,
        utr: "CSHF2024011598765432",
        status: "settled",
        settledAt: "2024-01-16 15:00:00",
      },
    ],
    transactions: [
      {
        id: "TXN001234567",
        orderId: "ORD-DPS-2024-001",
        edvironOrderId: "EDV-2024-001234567",
        gatewayTxnId: "GTXN-RZP-001234567",
        studentName: "Aarav Sharma",
        studentId: "STU-DPS-001",
        amount: 45000,
        paymentMode: "Credit Card",
        channel: "Payment Form",
        date: "2024-01-15",
        mdrAmount: 900,
        mdrPercentage: 2.0,
        mdrBearing: "surcharge",
        erpCommission: 450,
        erpCommissionPercentage: 1.0,
        vendorAmount: 43650,
        cardNetwork: "Visa",
      },
      {
        id: "TXN001234568",
        orderId: "ORD-DPS-2024-002",
        edvironOrderId: "EDV-2024-001234568",
        gatewayTxnId: "GTXN-RZP-001234568",
        studentName: "Priya Singh",
        studentId: "STU-DPS-002",
        amount: 32500,
        paymentMode: "UPI",
        channel: "Payment Link",
        date: "2024-01-15",
        mdrAmount: 162,
        mdrPercentage: 0.5,
        mdrBearing: "merchant_bearing",
        erpCommission: 325,
        erpCommissionPercentage: 1.0,
        vendorAmount: 32013,
        upiPsp: "PhonePe",
      },
      {
        id: "TXN001234569",
        orderId: "ORD-DPS-2024-003",
        edvironOrderId: "EDV-2024-001234569",
        gatewayTxnId: "GTXN-CSF-001234569",
        studentName: "Kabir Mehta",
        studentId: "STU-DPS-003",
        amount: 125000,
        paymentMode: "Card EMI",
        channel: "Payment Form",
        date: "2024-01-15",
        mdrAmount: 2500,
        mdrPercentage: 2.0,
        mdrBearing: "merchant_bearing",
        erpCommission: 1250,
        erpCommissionPercentage: 1.0,
        vendorAmount: 121250,
        cardNetwork: "Mastercard",
        isFinancing: true,
        financingType: "No Cost EMI",
        financingCharges: {
          parentCharge: 0,
          instituteCharge: 6250,
          bankCharge: 0,
        },
      },
    ],
  },
  "STL001235": {
    id: "STL001235",
    settlementDate: "2024-01-16",
    collectionPeriod: "2024-01-15",
    instituteId: "INST-MOD-001",
    instituteName: "Modern School",
    instituteCode: "MOD-DEL-001",
    grossOrderAmount: 3150000,
    totalMdrCharges: 47250,
    totalErpCommission: 31500,
    totalAdjustments: 0,
    netSettlementAmount: 3071250,
    transactionCount: 98,
    studentCount: 92,
    status: "settled",
    expectedDate: "2024-01-16",
    settledDate: "2024-01-16 15:30:00",
    bankAccount: "ICICI ****8976",
    ifscCode: "ICIC0005678",
    utr: "CSHF2024011598765432",
    gatewaySettlements: [
      {
        gateway: "Cashfree",
        transactionCount: 98,
        grossAmount: 3150000,
        mdrCharges: 47250,
        erpCommission: 31500,
        adjustments: [],
        netAmount: 3071250,
        utr: "CSHF2024011598765432",
        status: "settled",
        settledAt: "2024-01-16 15:30:00",
      },
    ],
    transactions: [],
  },
  "STL001236": {
    id: "STL001236",
    settlementDate: "2024-01-17",
    collectionPeriod: "2024-01-16",
    instituteId: "INST-RYN-001",
    instituteName: "Ryan International",
    instituteCode: "RYN-DEL-001",
    grossOrderAmount: 2400000,
    totalMdrCharges: 36000,
    totalErpCommission: 24000,
    totalAdjustments: 0,
    netSettlementAmount: 2340000,
    transactionCount: 75,
    studentCount: 70,
    status: "pending",
    expectedDate: "2024-01-17",
    bankAccount: "HDFC ****4521",
    ifscCode: "HDFC0001234",
    gatewaySettlements: [
      {
        gateway: "Easebuzz",
        transactionCount: 75,
        grossAmount: 2400000,
        mdrCharges: 36000,
        erpCommission: 24000,
        adjustments: [],
        netAmount: 2340000,
        status: "pending",
      },
    ],
    transactions: [],
  },
}

const statusColors: Record<string, string> = {
  settled: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  delayed: "bg-destructive/10 text-destructive border-destructive/20",
  partial: "bg-info/10 text-info border-info/20",
}

export default function SettlementDetailPage() {
  const params = useParams()
  const router = useRouter()
  const settlementId = params.id as string

  const settlement = settlements[settlementId]

  if (!settlement) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-6xl mx-auto">
          <Button variant="ghost" onClick={() => router.back()} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <Card className="bg-card border-border">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="h-12 w-12 text-warning mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">Settlement Not Found</h2>
              <p className="text-muted-foreground">The settlement with ID "{settlementId}" was not found.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const allAdjustments = settlement.gatewaySettlements.flatMap((gw) =>
    gw.adjustments.map((adj) => ({ ...adj, gateway: gw.gateway }))
  )

  const hasSplitPayments = settlement.gatewaySettlements.some((gw) => gw.splitDetails && gw.splitDetails.length > 0)

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <FileText className="h-6 w-6 text-primary" />
                Settlement Details
              </h1>
              <p className="text-sm text-muted-foreground font-mono">{settlement.id}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className={statusColors[settlement.status]}>
              {settlement.status === "partial" ? "Partially Settled" : settlement.status}
            </Badge>
            <Link href={`/settlements/${settlementId}/recon`}>
              <Button variant="outline" size="sm" className="gap-2">
                <FileText className="h-4 w-4" />
                Recon Report
              </Button>
            </Link>
            <Link href={`/settlements/${settlementId}/receipt`}>
              <Button variant="outline" size="sm" className="gap-2">
                <Receipt className="h-4 w-4" />
                View Receipt
              </Button>
            </Link>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </div>

        {/* Institute Info */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" />
              Institute Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">Institute Name</p>
                <p className="font-medium">{settlement.instituteName}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Institute Code</p>
                <p className="font-mono">{settlement.instituteCode}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Bank Account</p>
                <p className="font-mono">{settlement.bankAccount}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">IFSC Code</p>
                <p className="font-mono">{settlement.ifscCode}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Settlement Date</p>
                <p className="font-medium">{settlement.settlementDate}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settlement Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <BanknoteIcon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-xl font-bold">₹{(settlement.grossOrderAmount / 100000).toFixed(2)} L</p>
                  <p className="text-xs text-muted-foreground">Gross Amount</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                  <CreditCard className="h-5 w-5 text-warning" />
                </div>
                <div>
                  <p className="text-xl font-bold text-warning">-₹{(settlement.totalMdrCharges / 1000).toFixed(1)}K</p>
                  <p className="text-xs text-muted-foreground">MDR / PG Charges</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10">
                  <TrendingUp className="h-5 w-5 text-emerald-500" />
                </div>
                <div>
                  <p className="text-xl font-bold text-emerald-500">₹{(settlement.totalErpCommission / 1000).toFixed(1)}K</p>
                  <p className="text-xs text-muted-foreground">ERP Commission</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                  <RefreshCw className="h-5 w-5 text-destructive" />
                </div>
                <div>
                  <p className="text-xl font-bold text-destructive">-₹{(settlement.totalAdjustments / 1000).toFixed(1)}K</p>
                  <p className="text-xs text-muted-foreground">Refund Adjustments</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border bg-success/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                  <Wallet className="h-5 w-5 text-success" />
                </div>
                <div>
                  <p className="text-xl font-bold text-success">₹{(settlement.netSettlementAmount / 100000).toFixed(2)} L</p>
                  <p className="text-xs text-muted-foreground">Net Settlement</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="calculation" className="space-y-4">
          <TabsList className="bg-secondary">
            <TabsTrigger value="calculation" className="gap-1">
              <Calculator className="h-3 w-3" />
              Calculation
            </TabsTrigger>
            <TabsTrigger value="gateways" className="gap-1">
              <Wallet className="h-3 w-3" />
              Gateways
            </TabsTrigger>
            <TabsTrigger value="transactions" className="gap-1">
              <Receipt className="h-3 w-3" />
              Transactions ({settlement.transactionCount})
            </TabsTrigger>
            <TabsTrigger value="adjustments" className="gap-1">
              <AlertTriangle className="h-3 w-3" />
              Refund Adjustments ({allAdjustments.length})
            </TabsTrigger>
            {hasSplitPayments && (
              <TabsTrigger value="splits" className="gap-1">
                <Split className="h-3 w-3" />
                Split Payments
              </TabsTrigger>
            )}
          </TabsList>

          {/* Calculation Tab */}
          <TabsContent value="calculation" className="space-y-4">
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Calculator className="h-4 w-4 text-primary" />
                  Settlement Calculation Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Step 1: Gross Collection */}
                  <div className="rounded-lg bg-secondary/30 border border-border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary font-bold">1</div>
                        <div>
                          <p className="font-semibold">Gross Order Amount Collected</p>
                          <p className="text-xs text-muted-foreground">
                            {settlement.transactionCount} transactions from {settlement.studentCount} students
                          </p>
                        </div>
                      </div>
                      <p className="text-xl font-bold">₹{(settlement.grossOrderAmount / 100000).toFixed(2)} L</p>
                    </div>
                  </div>

                  {/* Step 2: MDR Charges */}
                  <div className="flex items-center justify-center">
                    <Minus className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="rounded-lg bg-warning/5 border border-warning/20 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-warning/10 text-warning font-bold">2</div>
                        <div>
                          <p className="font-semibold">MDR / Payment Gateway Charges</p>
                          <p className="text-xs text-muted-foreground">
                            Avg {((settlement.totalMdrCharges / settlement.grossOrderAmount) * 100).toFixed(2)}% across all gateways
                          </p>
                        </div>
                      </div>
                      <p className="text-xl font-bold text-warning">-₹{(settlement.totalMdrCharges / 1000).toFixed(1)}K</p>
                    </div>
                    <div className="mt-3 pt-3 border-t border-warning/20 space-y-1">
                      {settlement.gatewaySettlements.map((gw, idx) => (
                        <div key={idx} className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">{gw.gateway}</span>
                          <span className="text-warning">-₹{(gw.mdrCharges / 1000).toFixed(1)}K</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Step 3: ERP Commission (Added) */}
                  <div className="flex items-center justify-center">
                    <Minus className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="rounded-lg bg-emerald-500/5 border border-emerald-500/20 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-500 font-bold">3</div>
                        <div>
                          <p className="font-semibold">ERP Commission</p>
                          <p className="text-xs text-muted-foreground">
                            Platform commission @ {((settlement.totalErpCommission / settlement.grossOrderAmount) * 100).toFixed(2)}%
                          </p>
                        </div>
                      </div>
                      <p className="text-xl font-bold text-emerald-500">₹{(settlement.totalErpCommission / 1000).toFixed(1)}K</p>
                    </div>
                    <div className="mt-3 pt-3 border-t border-emerald-500/20 space-y-1">
                      {settlement.gatewaySettlements.map((gw, idx) => (
                        <div key={idx} className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">{gw.gateway}</span>
                          <span className="text-emerald-500">₹{(gw.erpCommission / 1000).toFixed(1)}K</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Step 4: Refund Adjustments */}
                  <div className="flex items-center justify-center">
                    <Minus className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-destructive/10 text-destructive font-bold">4</div>
                        <div>
                          <p className="font-semibold">Refund Adjustments</p>
                          <p className="text-xs text-muted-foreground">
                            {allAdjustments.length} refund{allAdjustments.length !== 1 ? "s" : ""} deducted from this settlement
                          </p>
                        </div>
                      </div>
                      <p className="text-xl font-bold text-destructive">-₹{(settlement.totalAdjustments / 1000).toFixed(1)}K</p>
                    </div>
                    {allAdjustments.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-destructive/20 space-y-1">
                        {allAdjustments.map((adj, idx) => (
                          <div key={idx} className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">{adj.studentName} ({adj.gateway})</span>
                            <span className="text-destructive">-₹{adj.amount.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Result: Net Settlement */}
                  <div className="flex items-center justify-center">
                    <ArrowRight className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="rounded-lg bg-success/5 border border-success/20 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-success/10 text-success font-bold">=</div>
                        <div>
                          <p className="font-semibold">Net Settlement Amount</p>
                          <p className="text-xs text-muted-foreground">Amount credited to {settlement.bankAccount}</p>
                        </div>
                      </div>
                      <p className="text-2xl font-bold text-success">₹{(settlement.netSettlementAmount / 100000).toFixed(2)} L</p>
                    </div>
                    {settlement.utr && (
                      <div className="mt-3 pt-3 border-t border-success/20 flex items-center gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-success" />
                        <span className="text-muted-foreground">UTR:</span>
                        <span className="font-mono">{settlement.utr}</span>
                      </div>
                    )}
                  </div>

                  {/* Formula Summary */}
                  <div className="rounded-lg bg-secondary/50 p-4 text-center">
                    <p className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">Net Settlement</span> = Gross Amount (₹{(settlement.grossOrderAmount / 100000).toFixed(2)}L) 
                      - MDR (₹{(settlement.totalMdrCharges / 1000).toFixed(1)}K) 
                      - ERP Commission (₹{(settlement.totalErpCommission / 1000).toFixed(1)}K) 
                      - Adjustments (₹{(settlement.totalAdjustments / 1000).toFixed(1)}K) 
                      = <span className="font-bold text-success">₹{(settlement.netSettlementAmount / 100000).toFixed(2)}L</span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Gateways Tab */}
          <TabsContent value="gateways" className="space-y-4">
            {settlement.gatewaySettlements.map((gw, idx) => (
              <Card key={idx} className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <span className="font-semibold text-lg">{gw.gateway}</span>
                      <Badge variant="outline" className={statusColors[gw.status]}>
                        {gw.status}
                      </Badge>
                      {gw.adjustments.length > 0 && (
                        <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 text-xs">
                          {gw.adjustments.length} adjustment{gw.adjustments.length > 1 ? "s" : ""}
                        </Badge>
                      )}
                    </div>
                    {gw.utr && (
                      <span className="text-xs font-mono bg-secondary px-2 py-1 rounded">UTR: {gw.utr}</span>
                    )}
                  </div>

                  <div className="grid grid-cols-6 gap-4 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground">Transactions</p>
                      <p className="font-semibold">{gw.transactionCount}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Gross Amount</p>
                      <p className="font-semibold">₹{(gw.grossAmount / 100000).toFixed(2)}L</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">MDR</p>
                      <p className="font-semibold text-warning">-₹{(gw.mdrCharges / 1000).toFixed(1)}K</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">ERP Comm</p>
                      <p className="font-semibold text-emerald-500">₹{(gw.erpCommission / 1000).toFixed(1)}K</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Adjustments</p>
                      <p className={`font-semibold ${gw.adjustments.length > 0 ? "text-destructive" : "text-muted-foreground"}`}>
                        -₹{gw.adjustments.reduce((sum, adj) => sum + adj.amount, 0).toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Net Amount</p>
                      <p className="font-bold text-primary">₹{(gw.netAmount / 100000).toFixed(2)}L</p>
                    </div>
                  </div>

                  {gw.splitDetails && gw.splitDetails.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                        <Split className="h-3 w-3" />
                        Split Distribution
                      </p>
                      <div className="flex flex-wrap gap-3">
                        {gw.splitDetails.map((split, i) => (
                          <Badge key={i} variant="outline" className="bg-info/10 text-info border-info/20">
                            {split.beneficiary}: ₹{(split.amount / 100000).toFixed(2)}L ({split.percentage}%)
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Transactions Tab */}
          <TabsContent value="transactions" className="space-y-4">
            <Card className="bg-card border-border">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Transaction</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Student</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Payment Mode</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Amount</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">MDR</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">ERP Comm</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Net</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {settlement.transactions.map((txn) => (
                        <tr key={txn.id} className="border-b border-border hover:bg-secondary/30">
                          <td className="p-3">
                            <Link href={`/transactions/${txn.id}`} className="font-mono text-xs text-primary hover:underline">
                              {txn.id}
                            </Link>
                            <p className="text-[10px] text-muted-foreground">{txn.date}</p>
                          </td>
                          <td className="p-3">
                            <p className="text-sm font-medium">{txn.studentName}</p>
                            <p className="text-[10px] text-muted-foreground">{txn.studentId}</p>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm">{txn.paymentMode}</span>
                            </div>
                            {(txn.cardNetwork || txn.upiPsp || txn.isFinancing) && (
                              <div className="flex gap-1 mt-0.5">
                                {txn.cardNetwork && (
                                  <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">{txn.cardNetwork}</Badge>
                                )}
                                {txn.upiPsp && (
                                  <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">{txn.upiPsp}</Badge>
                                )}
                                {txn.isFinancing && (
                                  <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
                                    {txn.financingType}
                                  </Badge>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="p-3 text-right font-semibold">₹{txn.amount.toLocaleString()}</td>
                          <td className="p-3 text-right">
                            <span className="text-warning font-medium">₹{txn.mdrAmount.toLocaleString()}</span>
                            <Badge 
                              variant="outline" 
                              className={`text-[8px] px-1 py-0 h-4 ml-1 ${
                                txn.mdrBearing === "surcharge" 
                                  ? "bg-red-500/10 text-red-400 border-red-500/20" 
                                  : "bg-green-500/10 text-green-400 border-green-500/20"
                              }`}
                            >
                              {txn.mdrBearing === "surcharge" ? "S" : "M"}
                            </Badge>
                          </td>
                          <td className="p-3 text-right">
                            <span className="text-emerald-500 font-medium">₹{txn.erpCommission.toLocaleString()}</span>
                            <p className="text-[10px] text-muted-foreground">{txn.erpCommissionPercentage}%</p>
                          </td>
                          <td className="p-3 text-right font-bold text-primary">₹{txn.vendorAmount.toLocaleString()}</td>
                          <td className="p-3 text-right">
                            <Button variant="ghost" size="sm" asChild className="h-7 text-xs">
                              <Link href={`/transactions/${txn.id}`}>
                                View
                                <ExternalLink className="h-3 w-3 ml-1" />
                              </Link>
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {settlement.transactions.length === 0 && (
                  <div className="p-8 text-center text-muted-foreground">
                    <Receipt className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Transaction details are not available for this settlement.</p>
                    <p className="text-sm">This settlement contains {settlement.transactionCount} transactions.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Adjustments Tab */}
          <TabsContent value="adjustments" className="space-y-4">
            {allAdjustments.length > 0 ? (
              <Card className="bg-card border-border">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-destructive" />
                      Refund Adjustments Details
                    </CardTitle>
                    <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                      Total: -₹{settlement.totalAdjustments.toLocaleString()}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="p-3 rounded-lg bg-warning/5 border border-warning/20 mb-4">
                    <p className="text-sm text-muted-foreground">
                      <span className="text-warning font-medium">Note:</span> Refund amounts shown are the original order amounts. 
                      PG charges and ERP commission are non-refundable and have been deducted from the refund amount.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {allAdjustments.map((adj, idx) => (
                      <div key={idx} className="rounded-lg bg-secondary/30 border border-border p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                              {adj.refundId}
                            </Badge>
                            <span className="font-medium">{adj.studentName}</span>
                          </div>
                          <Badge variant="secondary">{adj.gateway}</Badge>
                        </div>
                        <div className="grid grid-cols-5 gap-4 text-sm">
                          <div>
                            <p className="text-xs text-muted-foreground">Original Txn</p>
                            <Link href={`/transactions/${adj.originalTxnId}`} className="font-mono text-xs text-primary hover:underline">
                              {adj.originalTxnId}
                            </Link>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Order Amount</p>
                            <p className="font-medium">₹{adj.amount.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">PG Charges (Non-refundable)</p>
                            <p className="font-medium text-warning">-₹{adj.pgChargesDeducted.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">ERP Comm (Non-refundable)</p>
                            <p className="font-medium text-warning">-₹{adj.erpCommissionDeducted.toLocaleString()}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Net Refund to Parent</p>
                            <p className="font-bold text-destructive">₹{adj.netRefundAmount.toLocaleString()}</p>
                          </div>
                        </div>
                        <div className="mt-3 pt-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
                          <span>Reason: {adj.reason}</span>
                          <span>Refund Date: {adj.refundDate}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-card border-border">
                <CardContent className="p-8 text-center">
                  <CheckCircle2 className="h-12 w-12 text-success mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">No Adjustments</h3>
                  <p className="text-muted-foreground">This settlement has no refund adjustments.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Splits Tab */}
          {hasSplitPayments && (
            <TabsContent value="splits" className="space-y-4">
              {settlement.gatewaySettlements
                .filter((gw) => gw.splitDetails && gw.splitDetails.length > 0)
                .map((gw, idx) => (
                  <Card key={idx} className="bg-card border-border">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Split className="h-4 w-4 text-info" />
                        {gw.gateway} - Split Distribution
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {gw.splitDetails?.map((split, i) => (
                          <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 border border-border">
                            <div>
                              <p className="font-medium">{split.beneficiary}</p>
                              <p className="text-xs text-muted-foreground font-mono">
                                {split.accountNumber} | {split.ifsc}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-primary">₹{(split.amount / 100000).toFixed(2)} L</p>
                              <p className="text-xs text-muted-foreground">{split.percentage}%</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  )
}
