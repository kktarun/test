"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  ArrowLeft,
  Download,
  Printer,
  Building2,
  Wallet,
  CreditCard,
  AlertTriangle,
  RefreshCw,
  Receipt,
  Store,
  Banknote,
  FileText,
  TrendingUp,
  ChevronDown,
  ChevronUp,
} from "lucide-react"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"

// Enhanced Transaction Record with all requested fields
interface TransactionRecord {
  srNo: number
  instituteName: string
  dateTime: string
  orderId: string
  paymentId: string
  orderAmount: number
  transactionAmount: number
  merchantOrderAmount: number
  vendorOrderAmount: number
  paymentMethod: string
  gateway: string
  status: "Success" | "Failed" | "Pending"
  studentName: string
  studentId: string
  phoneNo: string
  settlementDate: string
  additionalFields: {
  feeType?: string
  class?: string
  section?: string
  academicYear?: string
  }
  mdrCharges: number
  erpCommission: number
  netSettlement: number
  utr: string
  }

interface RefundRecord {
  refundId: string
  orderId: string
  paymentId: string
  studentName: string
  studentId: string
  phoneNo: string
  originalAmount: number
  refundAmount: number
  pgChargesDeducted: number
  erpCommissionDeducted: number
  netDeduction: number
  reason: string
  refundDate: string
  settlementDate: string
}

interface ChargebackRecord {
  chargebackId: string
  orderId: string
  paymentId: string
  studentName: string
  studentId: string
  chargebackAmount: number
  chargebackFee: number
  totalDeduction: number
  reason: string
  status: "Won" | "Lost" | "Pending"
  chargebackDate: string
}

interface MerchantSettlement {
  accountName: string
  accountNumber: string
  ifscCode: string
  bankName: string
  utr: string
  settlementDate: string
  settlementTime: string
  status: "settled" | "pending" | "processing"
  transactionCount: number
  grossAmount: number
  mdrCharges: number
  erpCommission: number
  refundDeductions: number
  chargebackDeductions: number
  netSettlement: number
  transactions: TransactionRecord[]
  refunds: RefundRecord[]
  chargebacks: ChargebackRecord[]
}

interface VendorSettlement {
  vendorName: string
  vendorCode: string
  accountNumber: string
  ifscCode: string
  bankName: string
  utr: string
  settlementDate: string
  settlementTime: string
  status: "settled" | "pending" | "processing"
  transactionCount: number
  grossAmount: number
  platformFee: number
  netSettlement: number
  transactions: TransactionRecord[]
  refunds: RefundRecord[]
  chargebacks: ChargebackRecord[]
}

interface GatewayRecon {
  gateway: string
  totalTransactions: number
  totalStudents: number
  grossCollection: number
  totalMdrCharges: number
  totalErpCommission: number
  totalRefundDeductions: number
  totalChargebackDeductions: number
  netSettlement: number
  merchantSettlement: MerchantSettlement
  vendorSettlements: VendorSettlement[]
}

const reconData = {
  id: "STL-DPS-20240311",
  instituteName: "Delhi Public School, R.K. Puram",
  instituteCode: "DPS-RKP-001",
  collectionDate: "2024-03-11",
  settlementDate: "2024-03-12",
  
  summary: {
    totalCollection: 1000000,
    totalStudents: 100,
    totalTransactions: 100,
    razorpayCollection: 600000,
    cashfreeCollection: 400000,
    totalMdrCharges: 4800,
    totalErpCommission: 10000,
    totalRefunds: 25000,
    totalChargebacks: 15000,
    netSettlement: 945200,
    merchantSettlement: 746700,
    vendorSettlement: 198500,
  },
  
  gateways: [
    {
      gateway: "Razorpay",
      totalTransactions: 80,
      totalStudents: 80,
      grossCollection: 600000,
      totalMdrCharges: 4800,
      totalErpCommission: 6000,
      totalRefundDeductions: 15000,
      totalChargebackDeductions: 10500,
      netSettlement: 563700,
      
      merchantSettlement: {
        accountName: "Delhi Public School Main Account",
        accountNumber: "HDFC ****4521",
        ifscCode: "HDFC0001234",
        bankName: "HDFC Bank",
        utr: "RAZR2024031200001234",
        settlementDate: "2024-03-12",
        settlementTime: "14:30:00",
        status: "settled" as const,
        transactionCount: 60,
        grossAmount: 400000,
        mdrCharges: 4800,
        erpCommission: 4000,
        refundDeductions: 15000,
        chargebackDeductions: 10500,
        netSettlement: 365700,
        transactions: [
          { srNo: 1, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:15:00", orderId: "ORD-DPS-001", paymentId: "TXN001234001", orderAmount: 10000, transactionAmount: 8500, merchantOrderAmount: 8500, vendorOrderAmount: 0, paymentMethod: "Credit Card", gateway: "Razorpay", status: "Success" as const, studentName: "Aarav Sharma", studentId: "STU001", phoneNo: "+91 98765 43210", settlementDate: "2024-03-12", additionalFields: { feeType: "Tuition Fee", class: "10", section: "A", academicYear: "2024-25" }, mdrCharges: 170, erpCommission: 85, netSettlement: 8245, utr: "RAZR2024031200001234" },
          { srNo: 2, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:22:00", orderId: "ORD-DPS-002", paymentId: "TXN001234002", orderAmount: 8500, transactionAmount: 7500, merchantOrderAmount: 7500, vendorOrderAmount: 0, paymentMethod: "UPI", gateway: "Razorpay", status: "Success" as const, studentName: "Priya Singh", studentId: "STU002", phoneNo: "+91 98765 43211", settlementDate: "2024-03-12", additionalFields: { feeType: "Tuition Fee", class: "9", section: "B", academicYear: "2024-25" }, mdrCharges: 37, erpCommission: 75, netSettlement: 7388, utr: "RAZR2024031200001234" },
          { srNo: 3, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:35:00", orderId: "ORD-DPS-003", paymentId: "TXN001234003", orderAmount: 14000, transactionAmount: 12000, merchantOrderAmount: 12000, vendorOrderAmount: 0, paymentMethod: "Debit Card", gateway: "Razorpay", status: "Success" as const, studentName: "Kabir Mehta", studentId: "STU003", phoneNo: "+91 98765 43212", settlementDate: "2024-03-12", additionalFields: { feeType: "Annual Fee", class: "11", section: "A", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 120, netSettlement: 11880, utr: "RAZR2024031200001234" },
          { srNo: 4, instituteName: "Delhi Public School", dateTime: "2024-03-11 10:05:00", orderId: "ORD-DPS-004", paymentId: "TXN001234004", orderAmount: 10500, transactionAmount: 9000, merchantOrderAmount: 9000, vendorOrderAmount: 0, paymentMethod: "Net Banking", gateway: "Razorpay", status: "Success" as const, studentName: "Ananya Verma", studentId: "STU004", phoneNo: "+91 98765 43213", settlementDate: "2024-03-12", additionalFields: { feeType: "Exam Fee", class: "12", section: "C", academicYear: "2024-25" }, mdrCharges: 135, erpCommission: 90, netSettlement: 8775, utr: "RAZR2024031200001234" },
          { srNo: 5, instituteName: "Delhi Public School", dateTime: "2024-03-11 10:30:00", orderId: "ORD-DPS-005", paymentId: "TXN001234005", orderAmount: 6000, transactionAmount: 5500, merchantOrderAmount: 5500, vendorOrderAmount: 0, paymentMethod: "UPI", gateway: "Razorpay", status: "Success" as const, studentName: "Rohan Gupta", studentId: "STU005", phoneNo: "+91 98765 43214", settlementDate: "2024-03-12", additionalFields: { feeType: "Lab Fee", class: "10", section: "B", academicYear: "2024-25" }, mdrCharges: 27, erpCommission: 55, netSettlement: 5418, utr: "RAZR2024031200001234" },
          { srNo: 6, instituteName: "Delhi Public School", dateTime: "2024-03-11 11:00:00", orderId: "ORD-DPS-006", paymentId: "TXN001234006", orderAmount: 7500, transactionAmount: 6500, merchantOrderAmount: 6500, vendorOrderAmount: 0, paymentMethod: "Credit Card", gateway: "Razorpay", status: "Success" as const, studentName: "Ishita Patel", studentId: "STU006", phoneNo: "+91 98765 43215", settlementDate: "2024-03-12", additionalFields: { feeType: "Sports Fee", class: "8", section: "A", academicYear: "2024-25" }, mdrCharges: 130, erpCommission: 65, netSettlement: 6305, utr: "RAZR2024031200001234" },
          { srNo: 7, instituteName: "Delhi Public School", dateTime: "2024-03-11 11:30:00", orderId: "ORD-DPS-007", paymentId: "TXN001234007", orderAmount: 8000, transactionAmount: 7000, merchantOrderAmount: 7000, vendorOrderAmount: 0, paymentMethod: "UPI", gateway: "Razorpay", status: "Success" as const, studentName: "Vihaan Reddy", studentId: "STU007", phoneNo: "+91 98765 43216", settlementDate: "2024-03-12", additionalFields: { feeType: "Library Fee", class: "7", section: "C", academicYear: "2024-25" }, mdrCharges: 35, erpCommission: 70, netSettlement: 6895, utr: "RAZR2024031200001234" },
          { srNo: 8, instituteName: "Delhi Public School", dateTime: "2024-03-11 12:00:00", orderId: "ORD-DPS-008", paymentId: "TXN001234008", orderAmount: 9000, transactionAmount: 8000, merchantOrderAmount: 8000, vendorOrderAmount: 0, paymentMethod: "Debit Card", gateway: "Razorpay", status: "Success" as const, studentName: "Diya Sharma", studentId: "STU008", phoneNo: "+91 98765 43217", settlementDate: "2024-03-12", additionalFields: { feeType: "Activity Fee", class: "6", section: "B", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 80, netSettlement: 7920, utr: "RAZR2024031200001234" },
        ],
        refunds: [
          { refundId: "RFD-001", orderId: "ORD-DPS-050", paymentId: "TXN001234050", studentName: "Arjun Kapoor", studentId: "STU050", phoneNo: "+91 98765 43250", originalAmount: 8000, refundAmount: 7700, pgChargesDeducted: 160, erpCommissionDeducted: 80, netDeduction: 8000, reason: "Student withdrawal", refundDate: "2024-03-11", settlementDate: "2024-03-12" },
          { refundId: "RFD-002", orderId: "ORD-DPS-055", paymentId: "TXN001234055", studentName: "Meera Joshi", studentId: "STU055", phoneNo: "+91 98765 43255", originalAmount: 7000, refundAmount: 6790, pgChargesDeducted: 140, erpCommissionDeducted: 70, netDeduction: 7000, reason: "Course change", refundDate: "2024-03-11", settlementDate: "2024-03-12" },
        ],
        chargebacks: [
          { chargebackId: "CB-001", orderId: "ORD-DPS-045", paymentId: "TXN001234045", studentName: "Unknown (Disputed)", studentId: "N/A", chargebackAmount: 9000, chargebackFee: 1500, totalDeduction: 10500, reason: "Unauthorized transaction", status: "Lost" as const, chargebackDate: "2024-03-10" },
        ],
      },
      
      vendorSettlements: [
        {
          vendorName: "School Transport Services",
          vendorCode: "VND-STS-001",
          accountNumber: "ICICI ****8765",
          ifscCode: "ICIC0005678",
          bankName: "ICICI Bank",
          utr: "RAZR2024031200005678",
          settlementDate: "2024-03-12",
          settlementTime: "15:00:00",
          status: "settled" as const,
          transactionCount: 20,
          grossAmount: 200000,
          platformFee: 2000,
          netSettlement: 198000,
          transactions: [
            { srNo: 1, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:15:00", orderId: "ORD-DPS-061", paymentId: "TXN001234061", orderAmount: 20000, transactionAmount: 10000, merchantOrderAmount: 10000, vendorOrderAmount: 10000, paymentMethod: "UPI", gateway: "Razorpay", status: "Success" as const, studentName: "Aarav Sharma", studentId: "STU001", phoneNo: "+91 98765 43210", settlementDate: "2024-03-12", additionalFields: { feeType: "Transport Fee", class: "10", section: "A", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 100, netSettlement: 9900, utr: "RAZR2024031200005678" },
            { srNo: 2, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:30:00", orderId: "ORD-DPS-062", paymentId: "TXN001234062", orderAmount: 18000, transactionAmount: 10000, merchantOrderAmount: 8000, vendorOrderAmount: 10000, paymentMethod: "Net Banking", gateway: "Razorpay", status: "Success" as const, studentName: "Priya Singh", studentId: "STU002", phoneNo: "+91 98765 43211", settlementDate: "2024-03-12", additionalFields: { feeType: "Transport Fee", class: "9", section: "B", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 100, netSettlement: 9900, utr: "RAZR2024031200005678" },
            { srNo: 3, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:45:00", orderId: "ORD-DPS-063", paymentId: "TXN001234063", orderAmount: 22000, transactionAmount: 10000, merchantOrderAmount: 12000, vendorOrderAmount: 10000, paymentMethod: "Credit Card", gateway: "Razorpay", status: "Success" as const, studentName: "Kabir Mehta", studentId: "STU003", phoneNo: "+91 98765 43212", settlementDate: "2024-03-12", additionalFields: { feeType: "Transport Fee", class: "11", section: "A", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 100, netSettlement: 9900, utr: "RAZR2024031200005678" },
            { srNo: 4, instituteName: "Delhi Public School", dateTime: "2024-03-11 10:00:00", orderId: "ORD-DPS-064", paymentId: "TXN001234064", orderAmount: 16000, transactionAmount: 10000, merchantOrderAmount: 6000, vendorOrderAmount: 10000, paymentMethod: "UPI", gateway: "Razorpay", status: "Success" as const, studentName: "Ananya Verma", studentId: "STU004", phoneNo: "+91 98765 43213", settlementDate: "2024-03-12", additionalFields: { feeType: "Transport Fee", class: "12", section: "C", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 100, netSettlement: 9900, utr: "RAZR2024031200005678" },
            { srNo: 5, instituteName: "Delhi Public School", dateTime: "2024-03-11 10:15:00", orderId: "ORD-DPS-065", paymentId: "TXN001234065", orderAmount: 18000, transactionAmount: 10000, merchantOrderAmount: 8000, vendorOrderAmount: 10000, paymentMethod: "Debit Card", gateway: "Razorpay", status: "Success" as const, studentName: "Rohan Gupta", studentId: "STU005", phoneNo: "+91 98765 43214", settlementDate: "2024-03-12", additionalFields: { feeType: "Transport Fee", class: "10", section: "B", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 100, netSettlement: 9900, utr: "RAZR2024031200005678" },
          ],
          refunds: [],
          chargebacks: [],
        },
      ],
    },
    {
      gateway: "Cashfree",
      totalTransactions: 20,
      totalStudents: 20,
      grossCollection: 400000,
      totalMdrCharges: 0,
      totalErpCommission: 4000,
      totalRefundDeductions: 10000,
      totalChargebackDeductions: 4500,
      netSettlement: 381500,
      
      merchantSettlement: {
        accountName: "Delhi Public School Main Account",
        accountNumber: "HDFC ****4521",
        ifscCode: "HDFC0001234",
        bankName: "HDFC Bank",
        utr: "CSHF2024031200009876",
        settlementDate: "2024-03-12",
        settlementTime: "15:30:00",
        status: "settled" as const,
        transactionCount: 20,
        grossAmount: 400000,
        mdrCharges: 4800,
        erpCommission: 4000,
        refundDeductions: 10000,
        chargebackDeductions: 4500,
        netSettlement: 376700,
        transactions: [
          { srNo: 1, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:20:00", orderId: "ORD-DPS-081", paymentId: "TXN002234001", orderAmount: 28000, transactionAmount: 25000, merchantOrderAmount: 25000, vendorOrderAmount: 0, paymentMethod: "Credit Card", gateway: "Cashfree", status: "Success" as const, studentName: "Neha Kumar", studentId: "STU081", phoneNo: "+91 98765 43281", settlementDate: "2024-03-12", additionalFields: { feeType: "Annual Fee", class: "10", section: "A", academicYear: "2024-25" }, mdrCharges: 500, erpCommission: 250, netSettlement: 24250, utr: "CSHF2024031200009876" },
          { srNo: 2, instituteName: "Delhi Public School", dateTime: "2024-03-11 09:40:00", orderId: "ORD-DPS-082", paymentId: "TXN002234002", orderAmount: 20000, transactionAmount: 18000, merchantOrderAmount: 18000, vendorOrderAmount: 0, paymentMethod: "UPI", gateway: "Cashfree", status: "Success" as const, studentName: "Rahul Verma", studentId: "STU082", phoneNo: "+91 98765 43282", settlementDate: "2024-03-12", additionalFields: { feeType: "Tuition Fee", class: "11", section: "B", academicYear: "2024-25" }, mdrCharges: 90, erpCommission: 180, netSettlement: 17730, utr: "CSHF2024031200009876" },
          { srNo: 3, instituteName: "Delhi Public School", dateTime: "2024-03-11 10:10:00", orderId: "ORD-DPS-083", paymentId: "TXN002234003", orderAmount: 25000, transactionAmount: 22000, merchantOrderAmount: 22000, vendorOrderAmount: 0, paymentMethod: "Net Banking", gateway: "Cashfree", status: "Success" as const, studentName: "Sneha Patel", studentId: "STU083", phoneNo: "+91 98765 43283", settlementDate: "2024-03-12", additionalFields: { feeType: "Exam Fee", class: "12", section: "A", academicYear: "2024-25" }, mdrCharges: 330, erpCommission: 220, netSettlement: 21450, utr: "CSHF2024031200009876" },
          { srNo: 4, instituteName: "Delhi Public School", dateTime: "2024-03-11 10:30:00", orderId: "ORD-DPS-084", paymentId: "TXN002234004", orderAmount: 17000, transactionAmount: 15000, merchantOrderAmount: 15000, vendorOrderAmount: 0, paymentMethod: "Debit Card", gateway: "Cashfree", status: "Success" as const, studentName: "Amit Singh", studentId: "STU084", phoneNo: "+91 98765 43284", settlementDate: "2024-03-12", additionalFields: { feeType: "Lab Fee", class: "9", section: "C", academicYear: "2024-25" }, mdrCharges: 0, erpCommission: 150, netSettlement: 14850, utr: "CSHF2024031200009876" },
          { srNo: 5, instituteName: "Delhi Public School", dateTime: "2024-03-11 11:00:00", orderId: "ORD-DPS-085", paymentId: "TXN002234005", orderAmount: 23000, transactionAmount: 20000, merchantOrderAmount: 20000, vendorOrderAmount: 0, paymentMethod: "Credit Card", gateway: "Cashfree", status: "Success" as const, studentName: "Pooja Sharma", studentId: "STU085", phoneNo: "+91 98765 43285", settlementDate: "2024-03-12", additionalFields: { feeType: "Sports Fee", class: "8", section: "B", academicYear: "2024-25" }, mdrCharges: 400, erpCommission: 200, netSettlement: 19400, utr: "CSHF2024031200009876" },
        ],
        refunds: [
          { refundId: "RFD-003", orderId: "ORD-DPS-090", paymentId: "TXN002234010", studentName: "Ravi Kumar", studentId: "STU090", phoneNo: "+91 98765 43290", originalAmount: 10000, refundAmount: 9700, pgChargesDeducted: 200, erpCommissionDeducted: 100, netDeduction: 10000, reason: "Duplicate payment", refundDate: "2024-03-11", settlementDate: "2024-03-12" },
        ],
        chargebacks: [
          { chargebackId: "CB-002", orderId: "ORD-DPS-088", paymentId: "TXN002234008", studentName: "Vikram Singh", studentId: "STU088", chargebackAmount: 3000, chargebackFee: 1500, totalDeduction: 4500, reason: "Services not rendered", status: "Lost" as const, chargebackDate: "2024-03-10" },
        ],
      },
      
      vendorSettlements: [],
    },
  ] as GatewayRecon[],
}

const statusColors: Record<string, string> = {
  settled: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  processing: "bg-blue-500/10 text-blue-500 border-blue-500/20",
}

const paymentStatusColors: Record<string, string> = {
  Success: "bg-success/10 text-success",
  Failed: "bg-destructive/10 text-destructive",
  Pending: "bg-warning/10 text-warning",
}

export default function SettlementReconPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("all-transactions")
  const [expandedGateways, setExpandedGateways] = useState<string[]>(["Razorpay"])
  const [expandedSections, setExpandedSections] = useState<Record<string, string[]>>({
    Razorpay: ["merchant", "vendors"],
    Cashfree: ["merchant"],
  })

  const toggleGateway = (gateway: string) => {
    setExpandedGateways(prev => 
      prev.includes(gateway) ? prev.filter(g => g !== gateway) : [...prev, gateway]
    )
  }

  const toggleSection = (gateway: string, section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [gateway]: prev[gateway]?.includes(section)
        ? prev[gateway].filter(s => s !== section)
        : [...(prev[gateway] || []), section]
    }))
  }

  const allMerchantTransactions = reconData.gateways.flatMap(g => 
    g.merchantSettlement.transactions.map(t => ({ ...t, gateway: g.gateway }))
  )
  const allVendorTransactions = reconData.gateways.flatMap(g => 
    g.vendorSettlements.flatMap(v => v.transactions.map(t => ({ ...t, gateway: g.gateway, vendorName: v.vendorName })))
  )

  const TransactionTable = ({ transactions, type }: { transactions: TransactionRecord[], type: "merchant" | "vendor" }) => (
    <div className="border border-border rounded-lg overflow-x-auto">
      <Table>
<TableHeader>
  <TableRow className={type === "merchant" ? "bg-primary/5" : "bg-orange-500/5"}>
  <TableHead className="text-xs whitespace-nowrap">Sr.No</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Institute Name</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Date & Time</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Order ID</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Payment ID</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Order Amt</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Transaction Amt</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Merchant Amt</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Vendor Amt</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Payment Method</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Payment Gateway</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Status</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Student Name</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Student ID</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Class</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Phone No.</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Settlement Date</TableHead>
  <TableHead className="text-xs whitespace-nowrap">Fee Type</TableHead>
  {type === "merchant" && <TableHead className="text-xs whitespace-nowrap">MDR</TableHead>}
  <TableHead className="text-xs whitespace-nowrap">Net Settlement</TableHead>
  </TableRow>
  </TableHeader>
<TableBody>
  {transactions.map((txn, idx) => (
  <TableRow key={txn.paymentId} className={`hover:${type === "merchant" ? "bg-primary/5" : "bg-orange-500/5"}`}>
  <TableCell className="font-mono text-xs">{idx + 1}</TableCell>
  <TableCell className="text-xs">{txn.instituteName}</TableCell>
  <TableCell className="text-xs whitespace-nowrap">{txn.dateTime}</TableCell>
  <TableCell className="font-mono text-xs">{txn.orderId}</TableCell>
  <TableCell className="font-mono text-xs text-primary">{txn.paymentId}</TableCell>
  <TableCell className="font-mono text-xs">₹{txn.orderAmount.toLocaleString()}</TableCell>
  <TableCell className="font-mono text-xs font-medium">₹{txn.transactionAmount.toLocaleString()}</TableCell>
  <TableCell className="font-mono text-xs text-primary">₹{txn.merchantOrderAmount.toLocaleString()}</TableCell>
  <TableCell className="font-mono text-xs text-orange-500">₹{txn.vendorOrderAmount.toLocaleString()}</TableCell>
  <TableCell className="text-xs">
  <Badge variant="outline" className="text-xs">{txn.paymentMethod}</Badge>
  </TableCell>
  <TableCell className="text-xs">
  <Badge variant="outline" className={txn.gateway === "Razorpay" ? "bg-blue-500/10 text-blue-500 border-blue-500/30" : "bg-purple-500/10 text-purple-500 border-purple-500/30"}>
    {txn.gateway}
  </Badge>
  </TableCell>
  <TableCell>
  <Badge className={`${paymentStatusColors[txn.status]} text-xs`}>{txn.status}</Badge>
  </TableCell>
  <TableCell className="text-xs">{txn.studentName}</TableCell>
  <TableCell className="font-mono text-xs">{txn.studentId}</TableCell>
  <TableCell className="text-xs">{txn.additionalFields?.class || "-"}</TableCell>
  <TableCell className="text-xs whitespace-nowrap">{txn.phoneNo}</TableCell>
  <TableCell className="text-xs">{txn.settlementDate}</TableCell>
  <TableCell className="text-xs">{txn.additionalFields?.feeType || "-"}</TableCell>
  {type === "merchant" && <TableCell className="font-mono text-xs text-warning">-₹{txn.mdrCharges}</TableCell>}
  <TableCell className="font-mono text-xs font-medium text-success">₹{txn.netSettlement.toLocaleString()}</TableCell>
  </TableRow>
  ))}
  </TableBody>
      </Table>
    </div>
  )

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between print:hidden">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Receipt className="h-6 w-6 text-primary" />
                Settlement Reconciliation Report
              </h1>
              <p className="text-sm text-muted-foreground">
                Collection Date: <span className="font-mono">{reconData.collectionDate}</span> | 
                Settlement Date: <span className="font-mono">{reconData.settlementDate}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" className="gap-2">
              <Printer className="h-4 w-4" />
              Print
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export PDF
            </Button>
          </div>
        </div>

        {/* Institute Info */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Building2 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-lg font-bold">{reconData.instituteName}</h2>
                  <p className="text-sm text-muted-foreground font-mono">{reconData.instituteCode}</p>
                </div>
              </div>
              <div className="flex items-center gap-8">
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Merchant Settlement</p>
                  <p className="text-xl font-bold text-primary">₹{(reconData.summary.merchantSettlement / 100000).toFixed(2)} L</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Vendor Settlement</p>
                  <p className="text-xl font-bold text-orange-500">₹{(reconData.summary.vendorSettlement / 100000).toFixed(2)} L</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Total Collection</p>
                  <p className="text-2xl font-bold text-success">₹{(reconData.summary.totalCollection / 100000).toFixed(2)} L</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-7 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Banknote className="h-4 w-4 text-primary" />
                <p className="text-xs text-muted-foreground">Razorpay</p>
              </div>
              <p className="text-lg font-bold">₹{(reconData.summary.razorpayCollection / 100000).toFixed(1)} L</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Banknote className="h-4 w-4 text-blue-500" />
                <p className="text-xs text-muted-foreground">Cashfree</p>
              </div>
              <p className="text-lg font-bold">₹{(reconData.summary.cashfreeCollection / 100000).toFixed(1)} L</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="h-4 w-4 text-warning" />
                <p className="text-xs text-muted-foreground">MDR (Merchant)</p>
              </div>
              <p className="text-lg font-bold text-warning">-₹{(reconData.summary.totalMdrCharges / 1000).toFixed(1)}K</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-emerald-500" />
                <p className="text-xs text-muted-foreground">ERP Commission</p>
              </div>
              <p className="text-lg font-bold text-emerald-500">₹{(reconData.summary.totalErpCommission / 1000).toFixed(1)}K</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <RefreshCw className="h-4 w-4 text-orange-500" />
                <p className="text-xs text-muted-foreground">Refunds</p>
              </div>
              <p className="text-lg font-bold text-orange-500">-₹{(reconData.summary.totalRefunds / 1000).toFixed(1)}K</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <p className="text-xs text-muted-foreground">Chargebacks</p>
              </div>
              <p className="text-lg font-bold text-destructive">-��{(reconData.summary.totalChargebacks / 1000).toFixed(1)}K</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border bg-success/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Wallet className="h-4 w-4 text-success" />
                <p className="text-xs text-muted-foreground">Net Settlement</p>
              </div>
              <p className="text-lg font-bold text-success">₹{(reconData.summary.netSettlement / 100000).toFixed(2)} L</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="all-transactions">All Transactions</TabsTrigger>
            <TabsTrigger value="gateway-recon">Gateway-wise Recon</TabsTrigger>
          </TabsList>

          {/* All Transactions Tab - Now First */}
          <TabsContent value="all-transactions" className="space-y-6">
            {/* All Merchant Transactions */}
            <Card className="bg-card border-border">
              <CardHeader className="bg-primary/5">
                <CardTitle className="text-base flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  All Merchant Transactions
                  <Badge className="ml-2 bg-primary/10 text-primary">
                    {reconData.gateways.reduce((acc, g) => acc + g.merchantSettlement.transactions.length, 0)} transactions
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <TransactionTable 
                    transactions={reconData.gateways.flatMap(g => g.merchantSettlement.transactions)} 
                    type="merchant"
                  />
                </div>
              </CardContent>
            </Card>

            {/* All Vendor Transactions */}
            <Card className="bg-card border-border">
              <CardHeader className="bg-orange-500/5">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="h-5 w-5 text-orange-500" />
                  All Vendor Transactions
                  <Badge className="ml-2 bg-orange-500/10 text-orange-500">
                    {reconData.gateways.reduce((acc, g) => acc + g.vendorSettlements.reduce((vacc, v) => vacc + v.transactions.length, 0), 0)} transactions
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <TransactionTable 
                    transactions={reconData.gateways.flatMap(g => g.vendorSettlements.flatMap(v => v.transactions))} 
                    type="vendor"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Gateway-wise Recon Tab */}
          <TabsContent value="gateway-recon" className="space-y-6">
            {reconData.gateways.map((gateway) => (
              <Card key={gateway.gateway} className="bg-card border-border overflow-hidden">
                <Collapsible open={expandedGateways.includes(gateway.gateway)} onOpenChange={() => toggleGateway(gateway.gateway)}>
                  <CollapsibleTrigger asChild>
                    <CardHeader className="bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <Wallet className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <CardTitle className="text-lg">{gateway.gateway} Settlement Recon</CardTitle>
                            <p className="text-sm text-muted-foreground">
                              {gateway.totalTransactions} Transactions | {gateway.totalStudents} Students
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="text-sm text-muted-foreground">Gross</p>
                            <p className="text-lg font-bold">₹{(gateway.grossCollection / 100000).toFixed(2)} L</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-muted-foreground">Net</p>
                            <p className="text-lg font-bold text-success">₹{(gateway.netSettlement / 100000).toFixed(2)} L</p>
                          </div>
                          {expandedGateways.includes(gateway.gateway) ? (
                            <ChevronUp className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>

                  <CollapsibleContent>
                    <CardContent className="p-6 space-y-6">
                      
                      {/* MERCHANT SETTLEMENT SECTION */}
                      <Collapsible 
                        open={expandedSections[gateway.gateway]?.includes("merchant")} 
                        onOpenChange={() => toggleSection(gateway.gateway, "merchant")}
                      >
                        <div className="border border-primary/30 rounded-lg overflow-hidden">
                          <CollapsibleTrigger asChild>
                            <div className="bg-primary/5 p-4 cursor-pointer hover:bg-primary/10 transition-colors">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                                    <Building2 className="h-5 w-5 text-primary" />
                                  </div>
                                  <div>
                                    <h3 className="font-semibold flex items-center gap-2">
                                      Merchant Account Settlement
                                      <Badge variant="outline" className={statusColors[gateway.merchantSettlement.status]}>
                                        {gateway.merchantSettlement.status.toUpperCase()}
                                      </Badge>
                                    </h3>
                                    <p className="text-sm text-muted-foreground">
                                      {gateway.merchantSettlement.accountName} | {gateway.merchantSettlement.accountNumber} | {gateway.merchantSettlement.bankName}
                                    </p>
                                    <p className="text-xs text-primary font-mono mt-1">
                                      UTR: {gateway.merchantSettlement.utr}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-6">
                                  <div className="text-right">
                                    <p className="text-sm text-muted-foreground">Gross</p>
                                    <p className="font-bold">₹{(gateway.merchantSettlement.grossAmount / 100000).toFixed(2)} L</p>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-sm text-warning">MDR Deducted</p>
                                    <p className="font-bold text-warning">-₹{gateway.merchantSettlement.mdrCharges.toLocaleString()}</p>
                                  </div>
                                  <div className="text-right">
                                    <p className="text-sm text-muted-foreground">Net Settlement</p>
                                    <p className="font-bold text-success">₹{(gateway.merchantSettlement.netSettlement / 100000).toFixed(2)} L</p>
                                  </div>
                                  {expandedSections[gateway.gateway]?.includes("merchant") ? (
                                    <ChevronUp className="h-5 w-5 text-muted-foreground" />
                                  ) : (
                                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                                  )}
                                </div>
                              </div>
                            </div>
                          </CollapsibleTrigger>

                          <CollapsibleContent>
                            <div className="p-4 space-y-4">
                              {/* Settlement Calculation */}
                              <div className="bg-secondary/20 rounded-lg p-4">
                                <h4 className="font-medium mb-3 flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-primary" />
                                  Merchant Settlement Calculation
                                </h4>
                                <div className="space-y-2 text-sm">
                                  <div className="flex justify-between">
                                    <span>Gross Collection ({gateway.merchantSettlement.transactionCount} transactions)</span>
                                    <span className="font-mono font-bold">₹{gateway.merchantSettlement.grossAmount.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between text-warning">
                                    <span>(-) MDR / PG Charges (Deducted from Merchant Only)</span>
                                    <span className="font-mono">-₹{gateway.merchantSettlement.mdrCharges.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between text-emerald-500">
                                    <span>(-) ERP Commission</span>
                                    <span className="font-mono">-₹{gateway.merchantSettlement.erpCommission.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between text-orange-500">
                                    <span>(-) Refund Deductions ({gateway.merchantSettlement.refunds.length} refunds)</span>
                                    <span className="font-mono">-₹{gateway.merchantSettlement.refundDeductions.toLocaleString()}</span>
                                  </div>
                                  <div className="flex justify-between text-destructive">
                                    <span>(-) Chargeback Deductions ({gateway.merchantSettlement.chargebacks.length} chargebacks)</span>
                                    <span className="font-mono">-₹{gateway.merchantSettlement.chargebackDeductions.toLocaleString()}</span>
                                  </div>
                                  <Separator className="my-2" />
                                  <div className="flex justify-between font-bold text-success">
                                    <span>Net Merchant Settlement</span>
                                    <span className="font-mono">₹{gateway.merchantSettlement.netSettlement.toLocaleString()}</span>
                                  </div>
                                </div>
                              </div>

                              {/* Merchant Transactions Table */}
                              <div>
                                <h4 className="font-medium mb-3 flex items-center gap-2">
                                  <Receipt className="h-4 w-4 text-primary" />
                                  Merchant Transactions
                                </h4>
                                <TransactionTable transactions={gateway.merchantSettlement.transactions} type="merchant" />
                              </div>

                              {/* Refunds Table */}
                              {gateway.merchantSettlement.refunds.length > 0 && (
                                <div>
                                  <h4 className="font-medium mb-3 flex items-center gap-2">
                                    <RefreshCw className="h-4 w-4 text-orange-500" />
                                    Refund Deductions (Merchant)
                                  </h4>
                                  <div className="border border-orange-500/30 rounded-lg overflow-hidden bg-orange-500/5">
                                    <Table>
                                      <TableHeader>
                                        <TableRow className="bg-orange-500/10">
                                          <TableHead className="text-xs">Refund ID</TableHead>
                                          <TableHead className="text-xs">Order ID</TableHead>
                                          <TableHead className="text-xs">Payment ID</TableHead>
                                          <TableHead className="text-xs">Student</TableHead>
                                          <TableHead className="text-xs">Student ID</TableHead>
                                          <TableHead className="text-xs">Phone</TableHead>
                                          <TableHead className="text-xs">Original Amt</TableHead>
                                          <TableHead className="text-xs">Refund Amt</TableHead>
                                          <TableHead className="text-xs">Net Deduction</TableHead>
                                          <TableHead className="text-xs">Reason</TableHead>
                                          <TableHead className="text-xs">Date</TableHead>
                                        </TableRow>
                                      </TableHeader>
                                      <TableBody>
                                        {gateway.merchantSettlement.refunds.map((refund) => (
                                          <TableRow key={refund.refundId} className="hover:bg-orange-500/10">
                                            <TableCell className="font-mono text-xs text-orange-500">{refund.refundId}</TableCell>
                                            <TableCell className="font-mono text-xs">{refund.orderId}</TableCell>
                                            <TableCell className="font-mono text-xs">{refund.paymentId}</TableCell>
                                            <TableCell className="text-xs">{refund.studentName}</TableCell>
                                            <TableCell className="font-mono text-xs">{refund.studentId}</TableCell>
                                            <TableCell className="text-xs">{refund.phoneNo}</TableCell>
                                            <TableCell className="font-mono text-xs">₹{refund.originalAmount.toLocaleString()}</TableCell>
                                            <TableCell className="font-mono text-xs">₹{refund.refundAmount.toLocaleString()}</TableCell>
                                            <TableCell className="font-mono text-xs font-medium text-destructive">-₹{refund.netDeduction.toLocaleString()}</TableCell>
                                            <TableCell className="text-xs">{refund.reason}</TableCell>
                                            <TableCell className="text-xs">{refund.refundDate}</TableCell>
                                          </TableRow>
                                        ))}
                                      </TableBody>
                                    </Table>
                                  </div>
                                </div>
                              )}

                              {/* Chargebacks Table */}
                              {gateway.merchantSettlement.chargebacks.length > 0 && (
                                <div>
                                  <h4 className="font-medium mb-3 flex items-center gap-2">
                                    <AlertTriangle className="h-4 w-4 text-destructive" />
                                    Chargeback Deductions (Merchant)
                                  </h4>
                                  <div className="border border-destructive/30 rounded-lg overflow-hidden bg-destructive/5">
                                    <Table>
                                      <TableHeader>
                                        <TableRow className="bg-destructive/10">
                                          <TableHead className="text-xs">Chargeback ID</TableHead>
                                          <TableHead className="text-xs">Order ID</TableHead>
                                          <TableHead className="text-xs">Payment ID</TableHead>
                                          <TableHead className="text-xs">Student</TableHead>
                                          <TableHead className="text-xs">CB Amount</TableHead>
                                          <TableHead className="text-xs">CB Fee</TableHead>
                                          <TableHead className="text-xs">Total Deduction</TableHead>
                                          <TableHead className="text-xs">Reason</TableHead>
                                          <TableHead className="text-xs">Status</TableHead>
                                          <TableHead className="text-xs">Date</TableHead>
                                        </TableRow>
                                      </TableHeader>
                                      <TableBody>
                                        {gateway.merchantSettlement.chargebacks.map((cb) => (
                                          <TableRow key={cb.chargebackId} className="hover:bg-destructive/10">
                                            <TableCell className="font-mono text-xs text-destructive">{cb.chargebackId}</TableCell>
                                            <TableCell className="font-mono text-xs">{cb.orderId}</TableCell>
                                            <TableCell className="font-mono text-xs">{cb.paymentId}</TableCell>
                                            <TableCell className="text-xs">{cb.studentName}</TableCell>
                                            <TableCell className="font-mono text-xs">₹{cb.chargebackAmount.toLocaleString()}</TableCell>
                                            <TableCell className="font-mono text-xs">₹{cb.chargebackFee.toLocaleString()}</TableCell>
                                            <TableCell className="font-mono text-xs font-medium text-destructive">-₹{cb.totalDeduction.toLocaleString()}</TableCell>
                                            <TableCell className="text-xs">{cb.reason}</TableCell>
                                            <TableCell>
                                              <Badge variant="outline" className={cb.status === "Lost" ? "bg-destructive/10 text-destructive" : cb.status === "Won" ? "bg-success/10 text-success" : "bg-warning/10 text-warning"}>
                                                {cb.status}
                                              </Badge>
                                            </TableCell>
                                            <TableCell className="text-xs">{cb.chargebackDate}</TableCell>
                                          </TableRow>
                                        ))}
                                      </TableBody>
                                    </Table>
                                  </div>
                                </div>
                              )}
                            </div>
                          </CollapsibleContent>
                        </div>
                      </Collapsible>

                      {/* VENDOR SETTLEMENTS SECTION */}
                      {gateway.vendorSettlements.length > 0 && (
                        <Collapsible 
                          open={expandedSections[gateway.gateway]?.includes("vendors")} 
                          onOpenChange={() => toggleSection(gateway.gateway, "vendors")}
                        >
                          <div className="border border-orange-500/30 rounded-lg overflow-hidden">
                            <CollapsibleTrigger asChild>
                              <div className="bg-orange-500/5 p-4 cursor-pointer hover:bg-orange-500/10 transition-colors">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-3">
                                    <div className="h-10 w-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
                                      <Store className="h-5 w-5 text-orange-500" />
                                    </div>
                                    <div>
                                      <h3 className="font-semibold flex items-center gap-2">
                                        Vendor Account Settlements
                                        <Badge variant="outline" className="bg-orange-500/10 text-orange-500 border-orange-500/20">
                                          {gateway.vendorSettlements.length} Vendors
                                        </Badge>
                                      </h3>
                                      <p className="text-sm text-muted-foreground">
                                        Separate UTRs | No MDR Deduction (Platform Fee Only)
                                      </p>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-6">
                                    <div className="text-right">
                                      <p className="text-sm text-muted-foreground">Total Vendor Settlement</p>
                                      <p className="font-bold text-orange-500">
                                        ₹{(gateway.vendorSettlements.reduce((sum, v) => sum + v.netSettlement, 0) / 100000).toFixed(2)} L
                                      </p>
                                    </div>
                                    {expandedSections[gateway.gateway]?.includes("vendors") ? (
                                      <ChevronUp className="h-5 w-5 text-muted-foreground" />
                                    ) : (
                                      <ChevronDown className="h-5 w-5 text-muted-foreground" />
                                    )}
                                  </div>
                                </div>
                              </div>
                            </CollapsibleTrigger>

                            <CollapsibleContent>
                              <div className="p-4 space-y-4">
                                {gateway.vendorSettlements.map((vendor) => (
                                  <div key={vendor.vendorCode} className="border border-border rounded-lg p-4 bg-orange-500/5">
                                    <div className="flex items-center justify-between mb-4">
                                      <div className="flex items-center gap-3">
                                        <div className="h-8 w-8 rounded-lg bg-orange-500/10 flex items-center justify-center">
                                          <Store className="h-4 w-4 text-orange-500" />
                                        </div>
                                        <div>
                                          <h4 className="font-medium">{vendor.vendorName}</h4>
                                          <p className="text-xs text-muted-foreground">
                                            {vendor.vendorCode} | {vendor.accountNumber} | {vendor.bankName}
                                          </p>
                                          <p className="text-xs text-orange-500 font-mono mt-1">
                                            UTR: {vendor.utr}
                                          </p>
                                        </div>
                                      </div>
                                      <Badge variant="outline" className={statusColors[vendor.status]}>
                                        {vendor.status.toUpperCase()}
                                      </Badge>
                                    </div>

                                    {/* Vendor Settlement Calculation */}
                                    <div className="bg-secondary/20 rounded-lg p-3 mb-4">
                                      <div className="grid grid-cols-4 gap-4 text-sm">
                                        <div>
                                          <p className="text-xs text-muted-foreground">Transactions</p>
                                          <p className="font-bold">{vendor.transactionCount}</p>
                                        </div>
                                        <div>
                                          <p className="text-xs text-muted-foreground">Gross Amount</p>
                                          <p className="font-bold">₹{vendor.grossAmount.toLocaleString()}</p>
                                        </div>
                                        <div>
                                          <p className="text-xs text-muted-foreground">Platform Fee (No MDR)</p>
                                          <p className="font-bold text-warning">-₹{vendor.platformFee.toLocaleString()}</p>
                                        </div>
                                        <div>
                                          <p className="text-xs text-muted-foreground">Net Settlement</p>
                                          <p className="font-bold text-success">₹{vendor.netSettlement.toLocaleString()}</p>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Vendor Transactions Table */}
                                    <TransactionTable transactions={vendor.transactions} type="vendor" />
                                  </div>
                                ))}
                              </div>
                            </CollapsibleContent>
                          </div>
                        </Collapsible>
                      )}
                    </CardContent>
                  </CollapsibleContent>
                </Collapsible>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
