"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  ArrowLeft,
  Download,
  Printer,
  Building2,
  FileText,
  Search,
  Columns3,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  ArrowRight,
  Wallet,
  TrendingUp,
  CreditCard,
  Banknote,
  AlertTriangle,
  XCircle,
  Minus,
  Plus,
  Receipt,
  Users,
  ArrowUpRight,
  Store,
  Info,
} from "lucide-react"
import Link from "next/link"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"

// Settlement Receipt Data Types
interface SettlementTransaction {
  srNo: number
  instituteName: string
  dateTime: string
  orderId: string
  paymentId: string
  orderAmount: number
  transactionAmount: number
  mdrAmount: number
  mdrPercentage: number
  erpCommission: number
  erpCommissionPercentage: number
  netSettlement: number
  paymentMethod: string
  gateway: string
  status: "success" | "failed" | "refunded" | "chargeback"
  studentName: string
  studentId: string
  phoneNo: string
  settlementDate: string
  settlementTime: string
  utr?: string
  cardNetwork?: string
  upiPsp?: string
  bankName?: string
  vendor?: string
}

interface RefundAdjustment {
  refundId: string
  orderId: string
  paymentId: string
  originalOrderAmount: number
  refundedAmount: number
  pgChargesNonRefundable: number
  erpCommissionNonRefundable: number
  netDeduction: number
  refundDate: string
  refundReason: string
  studentName: string
  gateway: string
}

interface ChargebackAdjustment {
  chargebackId: string
  orderId: string
  paymentId: string
  chargebackAmount: number
  chargebackFee: number
  totalDeduction: number
  chargebackDate: string
  chargebackReason: string
  chargebackStatus: string
  studentName: string
  gateway: string
}

interface GatewayBreakdown {
  gateway: string
  transactionCount: number
  grossOrderAmount: number
  grossTransactionAmount: number
  totalMdr: number
  avgMdrPercentage: number
  totalErpCommission: number
  refundCount: number
  refundAmount: number
  chargebackCount: number
  chargebackAmount: number
  chargebackFees: number
  netSettlement: number
  utr: string
  status: "settled" | "pending" | "processing"
}

interface VendorBreakdown {
  vendorName: string
  vendorCode: string
  transactionCount: number
  grossAmount: number
  platformFee: number
  vendorShare: number
  status: "settled" | "pending"
  utr?: string
}

// Sample comprehensive settlement data
const settlementData = {
  id: "STL001234",
  instituteName: "Delhi Public School, R.K. Puram",
  instituteCode: "DPS-RKP",
  settlementDate: "2024-01-16",
  settlementTime: "14:30:00",
  collectionDate: "2024-01-15",
  utr: "RAZR2024011512345678",
  bankAccount: "HDFC Bank ****4521",
  ifscCode: "HDFC0001234",
  status: "settled" as const,
  
  // High-level Summary
  summary: {
    totalTransactions: 156,
    successfulTransactions: 150,
    refundedTransactions: 4,
    chargebackTransactions: 2,
    grossOrderAmount: 4820000,
    grossTransactionAmount: 4892000,
    totalMdrCharges: 72300,
    totalErpCommission: 48200,
    totalRefundDeductions: 180000,
    totalChargebackDeductions: 76500,
    netSettlementAmount: 4515000,
  },
  
  // Gateway-wise breakdown
  gatewayBreakdown: [
    {
      gateway: "Razorpay",
      transactionCount: 85,
      grossOrderAmount: 2650000,
      grossTransactionAmount: 2703000,
      totalMdr: 40590,
      avgMdrPercentage: 1.5,
      totalErpCommission: 26500,
      refundCount: 2,
      refundAmount: 95000,
      chargebackCount: 1,
      chargebackAmount: 50000,
      chargebackFees: 1500,
      netSettlement: 2489410,
      utr: "RAZR2024011512345678",
      status: "settled" as const,
    },
    {
      gateway: "Cashfree",
      transactionCount: 45,
      grossOrderAmount: 1420000,
      grossTransactionAmount: 1434200,
      totalMdr: 21513,
      avgMdrPercentage: 1.5,
      totalErpCommission: 14200,
      refundCount: 1,
      refundAmount: 45000,
      chargebackCount: 1,
      chargebackAmount: 25000,
      chargebackFees: 1500,
      netSettlement: 1326987,
      utr: "CSHF2024011598765432",
      status: "settled" as const,
    },
    {
      gateway: "Paytm",
      transactionCount: 26,
      grossOrderAmount: 750000,
      grossTransactionAmount: 754800,
      totalMdr: 10197,
      avgMdrPercentage: 1.35,
      totalErpCommission: 7500,
      refundCount: 1,
      refundAmount: 40000,
      chargebackCount: 0,
      chargebackAmount: 0,
      chargebackFees: 0,
      netSettlement: 697103,
      utr: "PYTM2024011545678901",
      status: "settled" as const,
    },
  ],
  
  // Vendor breakdown (for split settlements)
  vendorBreakdown: [
    {
      vendorName: "School Transport Services",
      vendorCode: "VND-STS-001",
      transactionCount: 45,
      grossAmount: 450000,
      platformFee: 9000,
      vendorShare: 441000,
      status: "settled" as const,
      utr: "VNDR2024011600001",
    },
    {
      vendorName: "Uniform Supplier Co.",
      vendorCode: "VND-USC-002",
      transactionCount: 32,
      grossAmount: 320000,
      platformFee: 6400,
      vendorShare: 313600,
      status: "pending" as const,
    },
    {
      vendorName: "Books & Stationery Ltd",
      vendorCode: "VND-BSL-003",
      transactionCount: 28,
      grossAmount: 140000,
      platformFee: 2800,
      vendorShare: 137200,
      status: "settled" as const,
      utr: "VNDR2024011600003",
    },
  ],
  
  // Refund adjustments in this settlement
  refundAdjustments: [
    {
      refundId: "RFD-2024-001",
      orderId: "ORD-DPS-2024-089",
      paymentId: "TXN001234589",
      originalOrderAmount: 50000,
      refundedAmount: 47500,
      pgChargesNonRefundable: 1000,
      erpCommissionNonRefundable: 500,
      netDeduction: 50000,
      refundDate: "2024-01-15",
      refundReason: "Student withdrawal - Mid-term",
      studentName: "Arjun Kapoor",
      gateway: "Razorpay",
    },
    {
      refundId: "RFD-2024-002",
      orderId: "ORD-DPS-2024-092",
      paymentId: "TXN001234592",
      originalOrderAmount: 45000,
      refundedAmount: 43050,
      pgChargesNonRefundable: 900,
      erpCommissionNonRefundable: 450,
      netDeduction: 45000,
      refundDate: "2024-01-15",
      refundReason: "Course change request",
      studentName: "Meera Joshi",
      gateway: "Razorpay",
    },
    {
      refundId: "RFD-2024-003",
      orderId: "ORD-DPS-2024-105",
      paymentId: "TXN001234605",
      originalOrderAmount: 45000,
      refundedAmount: 42750,
      pgChargesNonRefundable: 900,
      erpCommissionNonRefundable: 450,
      netDeduction: 45000,
      refundDate: "2024-01-15",
      refundReason: "Duplicate payment",
      studentName: "Ravi Kumar",
      gateway: "Cashfree",
    },
    {
      refundId: "RFD-2024-004",
      orderId: "ORD-DPS-2024-118",
      paymentId: "TXN001234618",
      originalOrderAmount: 40000,
      refundedAmount: 37600,
      pgChargesNonRefundable: 800,
      erpCommissionNonRefundable: 400,
      netDeduction: 40000,
      refundDate: "2024-01-15",
      refundReason: "School transfer",
      studentName: "Neha Sharma",
      gateway: "Paytm",
    },
  ],
  
  // Chargeback adjustments in this settlement
  chargebackAdjustments: [
    {
      chargebackId: "CB-2024-001",
      orderId: "ORD-DPS-2024-076",
      paymentId: "TXN001234576",
      chargebackAmount: 50000,
      chargebackFee: 1500,
      totalDeduction: 51500,
      chargebackDate: "2024-01-14",
      chargebackReason: "Unauthorized transaction - Card holder dispute",
      chargebackStatus: "Lost",
      studentName: "Unknown (Disputed)",
      gateway: "Razorpay",
    },
    {
      chargebackId: "CB-2024-002",
      orderId: "ORD-DPS-2024-098",
      paymentId: "TXN001234598",
      chargebackAmount: 25000,
      chargebackFee: 1500,
      totalDeduction: 26500,
      chargebackDate: "2024-01-14",
      chargebackReason: "Services not rendered as described",
      chargebackStatus: "Lost",
      studentName: "Vikram Singh",
      gateway: "Cashfree",
    },
  ],
  
  // Timeline
  timeline: [
    { event: "Collection Complete", time: "2024-01-15 23:59:59", status: "success" as const, description: "All transactions for the day collected" },
    { event: "Settlement Initiated", time: "2024-01-16 06:00:00", status: "success" as const, description: "T+1 settlement cycle started" },
    { event: "Adjustments Applied", time: "2024-01-16 08:30:00", status: "success" as const, description: "4 refunds & 2 chargebacks deducted" },
    { event: "Gateway Processing", time: "2024-01-16 10:30:00", status: "success" as const, description: "3 gateways processing settlements" },
    { event: "Bank Transfer", time: "2024-01-16 12:00:00", status: "success" as const, description: "NEFT/RTGS initiated to bank" },
    { event: "Settlement Complete", time: "2024-01-16 14:30:00", status: "success" as const, description: "Funds credited to account" },
  ],
  
  // Transactions
  transactions: [
    {
      srNo: 1,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 09:15:00",
      orderId: "ORD-DPS-2024-001",
      paymentId: "TXN001234567",
      orderAmount: 45000,
      transactionAmount: 45900,
      mdrAmount: 918,
      mdrPercentage: 2.0,
      erpCommission: 450,
      erpCommissionPercentage: 1.0,
      netSettlement: 43632,
      paymentMethod: "Credit Card",
      gateway: "Razorpay",
      status: "success" as const,
      studentName: "Aarav Sharma",
      studentId: "STU-DPS-001",
      phoneNo: "+91 98765 43210",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "RAZR2024011512345678",
      cardNetwork: "Visa",
    },
    {
      srNo: 2,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 09:22:00",
      orderId: "ORD-DPS-2024-002",
      paymentId: "TXN001234568",
      orderAmount: 32500,
      transactionAmount: 32500,
      mdrAmount: 162,
      mdrPercentage: 0.5,
      erpCommission: 325,
      erpCommissionPercentage: 1.0,
      netSettlement: 32013,
      paymentMethod: "UPI",
      gateway: "Razorpay",
      status: "success" as const,
      studentName: "Priya Singh",
      studentId: "STU-DPS-002",
      phoneNo: "+91 98765 43211",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "RAZR2024011512345678",
      upiPsp: "PhonePe",
    },
    {
      srNo: 3,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 09:35:00",
      orderId: "ORD-DPS-2024-003",
      paymentId: "TXN001234569",
      orderAmount: 125000,
      transactionAmount: 125000,
      mdrAmount: 2500,
      mdrPercentage: 2.0,
      erpCommission: 1250,
      erpCommissionPercentage: 1.0,
      netSettlement: 121250,
      paymentMethod: "Card EMI",
      gateway: "Cashfree",
      status: "success" as const,
      studentName: "Kabir Mehta",
      studentId: "STU-DPS-003",
      phoneNo: "+91 98765 43212",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "CSHF2024011598765432",
      cardNetwork: "Mastercard",
    },
    {
      srNo: 4,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 10:05:00",
      orderId: "ORD-DPS-2024-004",
      paymentId: "TXN001234570",
      orderAmount: 28000,
      transactionAmount: 28000,
      mdrAmount: 0,
      mdrPercentage: 0,
      erpCommission: 280,
      erpCommissionPercentage: 1.0,
      netSettlement: 27720,
      paymentMethod: "Debit Card",
      gateway: "Paytm",
      status: "success" as const,
      studentName: "Ananya Verma",
      studentId: "STU-DPS-004",
      phoneNo: "+91 98765 43213",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "PYTM2024011545678901",
      cardNetwork: "RuPay",
    },
    {
      srNo: 5,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 10:30:00",
      orderId: "ORD-DPS-2024-005",
      paymentId: "TXN001234571",
      orderAmount: 55000,
      transactionAmount: 55000,
      mdrAmount: 825,
      mdrPercentage: 1.5,
      erpCommission: 550,
      erpCommissionPercentage: 1.0,
      netSettlement: 53625,
      paymentMethod: "Net Banking",
      gateway: "Razorpay",
      status: "success" as const,
      studentName: "Rohan Gupta",
      studentId: "STU-DPS-005",
      phoneNo: "+91 98765 43214",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "RAZR2024011512345678",
      bankName: "HDFC Bank",
    },
    {
      srNo: 6,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 11:00:00",
      orderId: "ORD-DPS-2024-006",
      paymentId: "TXN001234572",
      orderAmount: 15000,
      transactionAmount: 15000,
      mdrAmount: 225,
      mdrPercentage: 1.5,
      erpCommission: 150,
      erpCommissionPercentage: 1.0,
      netSettlement: 14625,
      paymentMethod: "Wallet",
      gateway: "Cashfree",
      status: "success" as const,
      studentName: "Ishita Patel",
      studentId: "STU-DPS-006",
      phoneNo: "+91 98765 43215",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "CSHF2024011598765432",
    },
    {
      srNo: 7,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 11:30:00",
      orderId: "ORD-DPS-2024-007",
      paymentId: "TXN001234573",
      orderAmount: 42000,
      transactionAmount: 42000,
      mdrAmount: 210,
      mdrPercentage: 0.5,
      erpCommission: 420,
      erpCommissionPercentage: 1.0,
      netSettlement: 41370,
      paymentMethod: "UPI",
      gateway: "Paytm",
      status: "success" as const,
      studentName: "Vihaan Reddy",
      studentId: "STU-DPS-007",
      phoneNo: "+91 98765 43216",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "PYTM2024011545678901",
      upiPsp: "Google Pay",
    },
    {
      srNo: 8,
      instituteName: "Delhi Public School",
      dateTime: "2024-01-15 12:00:00",
      orderId: "ORD-DPS-2024-008",
      paymentId: "TXN001234574",
      orderAmount: 38000,
      transactionAmount: 38760,
      mdrAmount: 775,
      mdrPercentage: 2.0,
      erpCommission: 380,
      erpCommissionPercentage: 1.0,
      netSettlement: 36845,
      paymentMethod: "Credit Card",
      gateway: "Razorpay",
      status: "success" as const,
      studentName: "Diya Sharma",
      studentId: "STU-DPS-008",
      phoneNo: "+91 98765 43217",
      settlementDate: "2024-01-16",
      settlementTime: "14:30:00",
      utr: "RAZR2024011512345678",
      cardNetwork: "Visa",
    },
  ],
}

// All possible columns for customization
const allColumns = [
  { id: "srNo", label: "Sr.No", default: true },
  { id: "instituteName", label: "Institute Name", default: false },
  { id: "dateTime", label: "Date & Time", default: true },
  { id: "orderId", label: "Order ID", default: true },
  { id: "paymentId", label: "Payment ID", default: true },
  { id: "orderAmount", label: "Order Amt", default: true },
  { id: "transactionAmount", label: "Transaction Amt", default: false },
  { id: "mdrAmount", label: "MDR/PG Charges", default: true },
  { id: "erpCommission", label: "ERP Commission", default: true },
  { id: "netSettlement", label: "Net Settlement", default: true },
  { id: "paymentMethod", label: "Payment Method", default: true },
  { id: "gateway", label: "Gateway", default: true },
  { id: "status", label: "Status", default: true },
  { id: "studentName", label: "Student Name", default: true },
  { id: "studentId", label: "Student ID", default: false },
  { id: "phoneNo", label: "Phone No.", default: false },
  { id: "settlementDate", label: "Settlement Date", default: false },
  { id: "settlementTime", label: "Settlement Time", default: false },
  { id: "utr", label: "UTR", default: false },
  { id: "cardNetwork", label: "Card Network", default: false },
  { id: "upiPsp", label: "UPI PSP", default: false },
  { id: "bankName", label: "Bank Name", default: false },
]

const statusColors = {
  success: "bg-success/10 text-success border-success/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
  refunded: "bg-warning/10 text-warning border-warning/20",
  chargeback: "bg-destructive/10 text-destructive border-destructive/20",
  settled: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  processing: "bg-info/10 text-info border-info/20",
}

export default function SettlementReceiptPage() {
  const params = useParams()
  const router = useRouter()
  const settlementId = params.id as string

  const [activeTab, setActiveTab] = useState("reconciliation")
  const [searchQuery, setSearchQuery] = useState("")
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)
  const [visibleColumns, setVisibleColumns] = useState<string[]>(
    allColumns.filter(c => c.default).map(c => c.id)
  )
  const [columnsOpen, setColumnsOpen] = useState(false)
  const [gatewayFilter, setGatewayFilter] = useState("all")

  // Filter transactions based on search and gateway
  const filteredTransactions = settlementData.transactions.filter(txn => {
    if (gatewayFilter !== "all" && txn.gateway !== gatewayFilter) return false
    if (!searchQuery) return true
    const query = searchQuery.toLowerCase()
    return (
      txn.orderId.toLowerCase().includes(query) ||
      txn.paymentId.toLowerCase().includes(query) ||
      txn.studentName.toLowerCase().includes(query) ||
      txn.studentId.toLowerCase().includes(query) ||
      txn.phoneNo.includes(query) ||
      txn.paymentMethod.toLowerCase().includes(query)
    )
  })

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / rowsPerPage)
  const startIndex = (currentPage - 1) * rowsPerPage
  const paginatedTransactions = filteredTransactions.slice(startIndex, startIndex + rowsPerPage)

  const handleColumnToggle = (columnId: string) => {
    setVisibleColumns(prev =>
      prev.includes(columnId)
        ? prev.filter(c => c !== columnId)
        : [...prev, columnId]
    )
  }

  const handleExport = (format: "csv" | "pdf" | "excel") => {
    console.log(`Exporting in ${format} format`)
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Receipt className="h-6 w-6 text-primary" />
                Settlement Reconciliation Receipt
              </h1>
              <p className="text-sm text-muted-foreground font-mono">{settlementData.id} | {settlementData.settlementDate}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className={statusColors[settlementData.status]}>
              {settlementData.status.toUpperCase()}
            </Badge>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Download className="h-4 w-4" />
                  Export
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-40" align="end">
                <div className="space-y-1">
                  <Button variant="ghost" size="sm" className="w-full justify-start" onClick={() => handleExport("csv")}>
                    Export as CSV
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start" onClick={() => handleExport("excel")}>
                    Export as Excel
                  </Button>
                  <Button variant="ghost" size="sm" className="w-full justify-start" onClick={() => handleExport("pdf")}>
                    Export as PDF
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => window.print()}>
              <Printer className="h-4 w-4" />
              Print
            </Button>
          </div>
        </div>

        {/* Institute & Settlement Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Building2 className="h-4 w-4 text-primary" />
                Institute Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Institute</span>
                  <span className="font-medium">{settlementData.instituteName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Code</span>
                  <span className="font-mono">{settlementData.instituteCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Bank Account</span>
                  <span className="font-mono">{settlementData.bankAccount}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">IFSC</span>
                  <span className="font-mono">{settlementData.ifscCode}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Clock className="h-4 w-4 text-primary" />
                Settlement Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-start gap-1 overflow-x-auto pb-2">
                {settlementData.timeline.map((event, index) => (
                  <div key={index} className="flex items-center">
                    <div className="flex flex-col items-center min-w-[120px]">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                        event.status === "success" ? "bg-success/20 text-success" : "bg-secondary text-muted-foreground"
                      }`}>
                        <CheckCircle2 className="h-4 w-4" />
                      </div>
                      <p className="text-[10px] font-medium mt-1 text-center">{event.event}</p>
                      <p className="text-[9px] text-muted-foreground">{event.time.split(" ")[1]}</p>
                      <p className="text-[8px] text-muted-foreground/70 text-center mt-0.5 max-w-[100px]">{event.description}</p>
                    </div>
                    {index < settlementData.timeline.length - 1 && (
                      <ArrowRight className="h-4 w-4 text-muted-foreground mx-1 flex-shrink-0" />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Reconciliation Section */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="reconciliation">Reconciliation</TabsTrigger>
            <TabsTrigger value="gateways">Gateway Breakdown</TabsTrigger>
            <TabsTrigger value="vendors">Vendor Settlement</TabsTrigger>
            <TabsTrigger value="refunds">Refunds ({settlementData.refundAdjustments.length})</TabsTrigger>
            <TabsTrigger value="chargebacks" className="text-destructive">
              Chargebacks ({settlementData.chargebackAdjustments.length})
            </TabsTrigger>
            <TabsTrigger value="transactions">All Transactions</TabsTrigger>
          </TabsList>

          {/* Reconciliation Tab - Main Net Calculation */}
          <TabsContent value="reconciliation" className="space-y-6">
            {/* Net Settlement Calculation Flow */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Wallet className="h-5 w-5 text-primary" />
                  Settlement Reconciliation - Net Calculation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Visual Flow */}
                <div className="p-6 rounded-lg bg-gradient-to-br from-secondary/50 to-background border border-border">
                  <div className="space-y-4">
                    {/* Gross Amount */}
                    <div className="flex items-center justify-between p-4 rounded-lg bg-primary/5 border border-primary/20">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Banknote className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">Gross Order Amount</p>
                          <p className="text-xs text-muted-foreground">{settlementData.summary.successfulTransactions} successful transactions</p>
                        </div>
                      </div>
                      <p className="text-2xl font-bold">₹{settlementData.summary.grossOrderAmount.toLocaleString()}</p>
                    </div>

                    {/* Minus MDR */}
                    <div className="flex items-center gap-4 pl-8">
                      <Minus className="h-5 w-5 text-warning" />
                      <div className="flex-1 flex items-center justify-between p-3 rounded-lg bg-warning/5 border border-warning/20">
                        <div className="flex items-center gap-3">
                          <CreditCard className="h-5 w-5 text-warning" />
                          <div>
                            <p className="font-medium text-warning">MDR / PG Charges</p>
                            <p className="text-xs text-muted-foreground">Payment gateway transaction fees</p>
                          </div>
                        </div>
                        <p className="text-lg font-semibold text-warning">-₹{settlementData.summary.totalMdrCharges.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Minus ERP (shown as revenue for ERP) */}
                    <div className="flex items-center gap-4 pl-8">
                      <Minus className="h-5 w-5 text-emerald-500" />
                      <div className="flex-1 flex items-center justify-between p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                        <div className="flex items-center gap-3">
                          <TrendingUp className="h-5 w-5 text-emerald-500" />
                          <div>
                            <p className="font-medium text-emerald-500">ERP Commission</p>
                            <p className="text-xs text-muted-foreground">Platform fee (1% of order amount)</p>
                          </div>
                        </div>
                        <p className="text-lg font-semibold text-emerald-500">₹{settlementData.summary.totalErpCommission.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Minus Refunds */}
                    <div className="flex items-center gap-4 pl-8">
                      <Minus className="h-5 w-5 text-orange-500" />
                      <div className="flex-1 flex items-center justify-between p-3 rounded-lg bg-orange-500/5 border border-orange-500/20">
                        <div className="flex items-center gap-3">
                          <RefreshCw className="h-5 w-5 text-orange-500" />
                          <div>
                            <p className="font-medium text-orange-500">Refund Deductions</p>
                            <p className="text-xs text-muted-foreground">{settlementData.summary.refundedTransactions} refunds (ORDER AMOUNT deducted)</p>
                          </div>
                        </div>
                        <p className="text-lg font-semibold text-orange-500">-₹{settlementData.summary.totalRefundDeductions.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Minus Chargebacks */}
                    <div className="flex items-center gap-4 pl-8">
                      <Minus className="h-5 w-5 text-destructive" />
                      <div className="flex-1 flex items-center justify-between p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                        <div className="flex items-center gap-3">
                          <AlertTriangle className="h-5 w-5 text-destructive" />
                          <div>
                            <p className="font-medium text-destructive">Chargeback Deductions</p>
                            <p className="text-xs text-muted-foreground">{settlementData.summary.chargebackTransactions} chargebacks (ORDER AMT + fees)</p>
                          </div>
                        </div>
                        <p className="text-lg font-semibold text-destructive">-₹{settlementData.summary.totalChargebackDeductions.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Separator */}
                    <Separator className="my-4" />

                    {/* Net Settlement */}
                    <div className="flex items-center justify-between p-5 rounded-lg bg-success/10 border-2 border-success/30">
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-12 rounded-lg bg-success/20 flex items-center justify-center">
                          <Wallet className="h-6 w-6 text-success" />
                        </div>
                        <div>
                          <p className="font-semibold text-success text-lg">Net Settlement Amount</p>
                          <p className="text-xs text-muted-foreground">Credited to {settlementData.bankAccount}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-bold text-success">₹{settlementData.summary.netSettlementAmount.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground font-mono">UTR: {settlementData.utr}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Summary Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 rounded-lg bg-secondary/50 border border-border text-center">
                    <p className="text-2xl font-bold">{settlementData.summary.totalTransactions}</p>
                    <p className="text-xs text-muted-foreground">Total Transactions</p>
                  </div>
                  <div className="p-4 rounded-lg bg-success/5 border border-success/20 text-center">
                    <p className="text-2xl font-bold text-success">{settlementData.summary.successfulTransactions}</p>
                    <p className="text-xs text-muted-foreground">Successful</p>
                  </div>
                  <div className="p-4 rounded-lg bg-orange-500/5 border border-orange-500/20 text-center">
                    <p className="text-2xl font-bold text-orange-500">{settlementData.summary.refundedTransactions}</p>
                    <p className="text-xs text-muted-foreground">Refunded</p>
                  </div>
                  <div className="p-4 rounded-lg bg-destructive/5 border border-destructive/20 text-center">
                    <p className="text-2xl font-bold text-destructive">{settlementData.summary.chargebackTransactions}</p>
                    <p className="text-xs text-muted-foreground">Chargebacks</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Gateway Breakdown Tab */}
          <TabsContent value="gateways" className="space-y-4">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base">Gateway-wise Settlement Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {settlementData.gatewayBreakdown.map((gw, index) => (
                    <div key={gw.gateway} className="space-y-4">
                      {index > 0 && <Separator />}
                      
                      {/* Gateway Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                            <CreditCard className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-semibold text-lg">{gw.gateway}</p>
                            <p className="text-xs text-muted-foreground">{gw.transactionCount} transactions</p>
                          </div>
                        </div>
                        <Badge variant="outline" className={statusColors[gw.status]}>
                          {gw.status.toUpperCase()}
                        </Badge>
                      </div>

                      {/* Gateway Calculation */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Left: Breakdown */}
                        <div className="p-4 rounded-lg bg-secondary/30 space-y-3">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Gross Order Amount</span>
                            <span className="font-medium">₹{gw.grossOrderAmount.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">MDR Charges ({gw.avgMdrPercentage}% avg)</span>
                            <span className="text-warning">-₹{gw.totalMdr.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">ERP Commission</span>
                            <span className="text-emerald-500">₹{gw.totalErpCommission.toLocaleString()}</span>
                          </div>
                          {gw.refundCount > 0 && (
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Refunds ({gw.refundCount})</span>
                              <span className="text-orange-500">-₹{gw.refundAmount.toLocaleString()}</span>
                            </div>
                          )}
                          {gw.chargebackCount > 0 && (
                            <div className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Chargebacks ({gw.chargebackCount})</span>
                              <span className="text-destructive">-₹{(gw.chargebackAmount + gw.chargebackFees).toLocaleString()}</span>
                            </div>
                          )}
                          <Separator />
                          <div className="flex justify-between font-semibold">
                            <span>Net Settlement</span>
                            <span className="text-success">₹{gw.netSettlement.toLocaleString()}</span>
                          </div>
                        </div>

                        {/* Right: UTR & Status */}
                        <div className="p-4 rounded-lg bg-success/5 border border-success/20 space-y-3">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Settlement UTR</span>
                            <span className="font-mono text-xs">{gw.utr}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Settlement Date</span>
                            <span>{settlementData.settlementDate}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Settlement Time</span>
                            <span>{settlementData.settlementTime}</span>
                          </div>
                          <div className="pt-2 border-t border-border">
                            <p className="text-2xl font-bold text-success text-center">
                              ₹{gw.netSettlement.toLocaleString()}
                            </p>
                            <p className="text-xs text-muted-foreground text-center mt-1">Settled to Merchant</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Total Across All Gateways */}
                  <Separator className="my-6" />
                  <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-lg">Total Across All Gateways</p>
                        <p className="text-xs text-muted-foreground">{settlementData.gatewayBreakdown.length} gateways</p>
                      </div>
                      <p className="text-3xl font-bold text-success">
                        ₹{settlementData.gatewayBreakdown.reduce((sum, gw) => sum + gw.netSettlement, 0).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vendor Settlement Tab */}
          <TabsContent value="vendors" className="space-y-4">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Store className="h-5 w-5" />
                  Vendor Settlement Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Vendor</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Vendor Code</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Transactions</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Gross Amount</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Platform Fee</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Vendor Share</th>
                        <th className="p-3 text-center text-xs font-medium uppercase text-muted-foreground">Status</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">UTR</th>
                      </tr>
                    </thead>
                    <tbody>
                      {settlementData.vendorBreakdown.map((vendor) => (
                        <tr key={vendor.vendorCode} className="border-b border-border hover:bg-secondary/30">
                          <td className="p-3 font-medium">{vendor.vendorName}</td>
                          <td className="p-3 font-mono text-xs text-muted-foreground">{vendor.vendorCode}</td>
                          <td className="p-3 text-right">{vendor.transactionCount}</td>
                          <td className="p-3 text-right font-medium">₹{vendor.grossAmount.toLocaleString()}</td>
                          <td className="p-3 text-right text-warning">-₹{vendor.platformFee.toLocaleString()}</td>
                          <td className="p-3 text-right font-semibold text-success">₹{vendor.vendorShare.toLocaleString()}</td>
                          <td className="p-3 text-center">
                            <Badge variant="outline" className={statusColors[vendor.status]}>
                              {vendor.status.toUpperCase()}
                            </Badge>
                          </td>
                          <td className="p-3 font-mono text-xs text-muted-foreground">{vendor.utr || "-"}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-secondary/50 font-semibold">
                        <td className="p-3" colSpan={2}>Total</td>
                        <td className="p-3 text-right">
                          {settlementData.vendorBreakdown.reduce((sum, v) => sum + v.transactionCount, 0)}
                        </td>
                        <td className="p-3 text-right">
                          ₹{settlementData.vendorBreakdown.reduce((sum, v) => sum + v.grossAmount, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-warning">
                          -₹{settlementData.vendorBreakdown.reduce((sum, v) => sum + v.platformFee, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-success">
                          ₹{settlementData.vendorBreakdown.reduce((sum, v) => sum + v.vendorShare, 0).toLocaleString()}
                        </td>
                        <td className="p-3" colSpan={2}></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Refunds Tab */}
          <TabsContent value="refunds" className="space-y-4">
            <Card className="bg-card border-border border-orange-500/30">
              <CardHeader className="bg-orange-500/5">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2 text-orange-500">
                    <RefreshCw className="h-5 w-5" />
                    Refund Adjustments in This Settlement
                  </CardTitle>
                  <Badge variant="outline" className="bg-orange-500/10 text-orange-500 border-orange-500/20">
                    {settlementData.refundAdjustments.length} Refunds
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {/* Important Note */}
                <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/20 mb-4">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 text-orange-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-orange-500">Refund Calculation Note</p>
                      <p className="text-xs text-muted-foreground">
                        Refund deductions are based on the ORDER AMOUNT (not transaction amount). 
                        PG charges and ERP commission are non-refundable and retained.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Refund ID</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Order ID</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Student</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Order Amt</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">PG Charges (NR)</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">ERP Comm (NR)</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Refund to Parent</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Net Deduction</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Reason</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Gateway</th>
                      </tr>
                    </thead>
                    <tbody>
                      {settlementData.refundAdjustments.map((refund) => (
                        <tr key={refund.refundId} className="border-b border-border hover:bg-secondary/30">
                          <td className="p-3 font-mono text-xs text-primary">{refund.refundId}</td>
                          <td className="p-3">
                            <Link href={`/transactions/${refund.paymentId}`} className="font-mono text-xs text-primary hover:underline">
                              {refund.orderId}
                            </Link>
                          </td>
                          <td className="p-3 text-sm">{refund.studentName}</td>
                          <td className="p-3 text-right font-medium">₹{refund.originalOrderAmount.toLocaleString()}</td>
                          <td className="p-3 text-right text-sm text-emerald-500">₹{refund.pgChargesNonRefundable.toLocaleString()}</td>
                          <td className="p-3 text-right text-sm text-emerald-500">₹{refund.erpCommissionNonRefundable.toLocaleString()}</td>
                          <td className="p-3 text-right text-sm">₹{refund.refundedAmount.toLocaleString()}</td>
                          <td className="p-3 text-right font-semibold text-orange-500">-₹{refund.netDeduction.toLocaleString()}</td>
                          <td className="p-3 text-xs text-muted-foreground max-w-[150px] truncate">{refund.refundReason}</td>
                          <td className="p-3">
                            <Badge variant="secondary" className="text-xs">{refund.gateway}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-orange-500/5 font-semibold">
                        <td className="p-3" colSpan={3}>Total Refund Adjustments</td>
                        <td className="p-3 text-right">
                          ₹{settlementData.refundAdjustments.reduce((sum, r) => sum + r.originalOrderAmount, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-emerald-500">
                          ₹{settlementData.refundAdjustments.reduce((sum, r) => sum + r.pgChargesNonRefundable, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-emerald-500">
                          ₹{settlementData.refundAdjustments.reduce((sum, r) => sum + r.erpCommissionNonRefundable, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right">
                          ₹{settlementData.refundAdjustments.reduce((sum, r) => sum + r.refundedAmount, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-orange-500">
                          -₹{settlementData.refundAdjustments.reduce((sum, r) => sum + r.netDeduction, 0).toLocaleString()}
                        </td>
                        <td className="p-3" colSpan={2}></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chargebacks Tab */}
          <TabsContent value="chargebacks" className="space-y-4">
            <Card className="bg-card border-border border-destructive/30">
              <CardHeader className="bg-destructive/5">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2 text-destructive">
                    <AlertTriangle className="h-5 w-5" />
                    Chargeback Adjustments in This Settlement
                  </CardTitle>
                  <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                    {settlementData.chargebackAdjustments.length} Chargebacks
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                {/* Important Note */}
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 mb-4">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 text-destructive flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-destructive">Chargeback Impact</p>
                      <p className="text-xs text-muted-foreground">
                        Chargebacks deduct the full ORDER AMOUNT plus chargeback processing fee (₹1,500). 
                        These are disputed transactions where the bank has ruled against the merchant.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Chargeback ID</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Order ID</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Student</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Chargeback Amt</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">CB Fee</th>
                        <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Total Deduction</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Date</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Reason</th>
                        <th className="p-3 text-center text-xs font-medium uppercase text-muted-foreground">Status</th>
                        <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Gateway</th>
                      </tr>
                    </thead>
                    <tbody>
                      {settlementData.chargebackAdjustments.map((cb) => (
                        <tr key={cb.chargebackId} className="border-b border-border hover:bg-secondary/30">
                          <td className="p-3 font-mono text-xs text-destructive">{cb.chargebackId}</td>
                          <td className="p-3">
                            <Link href={`/transactions/${cb.paymentId}`} className="font-mono text-xs text-primary hover:underline">
                              {cb.orderId}
                            </Link>
                          </td>
                          <td className="p-3 text-sm">{cb.studentName}</td>
                          <td className="p-3 text-right font-medium">₹{cb.chargebackAmount.toLocaleString()}</td>
                          <td className="p-3 text-right text-sm text-destructive">₹{cb.chargebackFee.toLocaleString()}</td>
                          <td className="p-3 text-right font-semibold text-destructive">-₹{cb.totalDeduction.toLocaleString()}</td>
                          <td className="p-3 text-sm">{cb.chargebackDate}</td>
                          <td className="p-3 text-xs text-muted-foreground max-w-[150px] truncate">{cb.chargebackReason}</td>
                          <td className="p-3 text-center">
                            <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 text-xs">
                              {cb.chargebackStatus}
                            </Badge>
                          </td>
                          <td className="p-3">
                            <Badge variant="secondary" className="text-xs">{cb.gateway}</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-destructive/5 font-semibold">
                        <td className="p-3" colSpan={3}>Total Chargeback Adjustments</td>
                        <td className="p-3 text-right">
                          ₹{settlementData.chargebackAdjustments.reduce((sum, cb) => sum + cb.chargebackAmount, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-destructive">
                          ₹{settlementData.chargebackAdjustments.reduce((sum, cb) => sum + cb.chargebackFee, 0).toLocaleString()}
                        </td>
                        <td className="p-3 text-right text-destructive">
                          -₹{settlementData.chargebackAdjustments.reduce((sum, cb) => sum + cb.totalDeduction, 0).toLocaleString()}
                        </td>
                        <td className="p-3" colSpan={4}></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* All Transactions Tab */}
          <TabsContent value="transactions" className="space-y-4">
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <CardTitle className="text-base">
                    All Transactions ({filteredTransactions.length})
                  </CardTitle>
                  <div className="flex items-center gap-3 flex-wrap">
                    {/* Gateway Filter */}
                    <Select value={gatewayFilter} onValueChange={setGatewayFilter}>
                      <SelectTrigger className="w-[140px] bg-secondary">
                        <SelectValue placeholder="All Gateways" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Gateways</SelectItem>
                        <SelectItem value="Razorpay">Razorpay</SelectItem>
                        <SelectItem value="Cashfree">Cashfree</SelectItem>
                        <SelectItem value="Paytm">Paytm</SelectItem>
                      </SelectContent>
                    </Select>

                    {/* Search */}
                    <div className="relative w-64">
                      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        placeholder="Search transactions..."
                        value={searchQuery}
                        onChange={(e) => {
                          setSearchQuery(e.target.value)
                          setCurrentPage(1)
                        }}
                        className="pl-9 bg-secondary"
                      />
                    </div>

                    {/* Column Customization */}
                    <Popover open={columnsOpen} onOpenChange={setColumnsOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-2">
                          <Columns3 className="h-4 w-4" />
                          Columns
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-64" align="end">
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-sm">Visible Columns</h4>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 text-xs"
                              onClick={() => setVisibleColumns(allColumns.filter(c => c.default).map(c => c.id))}
                            >
                              Reset
                            </Button>
                          </div>
                          <div className="space-y-2 max-h-[300px] overflow-y-auto">
                            {allColumns.map((column) => (
                              <div key={column.id} className="flex items-center space-x-2">
                                <Checkbox
                                  id={column.id}
                                  checked={visibleColumns.includes(column.id)}
                                  onCheckedChange={() => handleColumnToggle(column.id)}
                                />
                                <Label htmlFor={column.id} className="text-sm font-normal cursor-pointer">
                                  {column.label}
                                </Label>
                              </div>
                            ))}
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>

                    {/* Rows per page */}
                    <Select value={rowsPerPage.toString()} onValueChange={(v) => {
                      setRowsPerPage(parseInt(v))
                      setCurrentPage(1)
                    }}>
                      <SelectTrigger className="w-[100px] bg-secondary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">5 rows</SelectItem>
                        <SelectItem value="10">10 rows</SelectItem>
                        <SelectItem value="25">25 rows</SelectItem>
                        <SelectItem value="50">50 rows</SelectItem>
                        <SelectItem value="100">100 rows</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        {visibleColumns.includes("srNo") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Sr.No</th>
                        )}
                        {visibleColumns.includes("instituteName") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Institute</th>
                        )}
                        {visibleColumns.includes("dateTime") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Date & Time</th>
                        )}
                        {visibleColumns.includes("orderId") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Order ID</th>
                        )}
                        {visibleColumns.includes("paymentId") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Payment ID</th>
                        )}
                        {visibleColumns.includes("orderAmount") && (
                          <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Order Amt</th>
                        )}
                        {visibleColumns.includes("transactionAmount") && (
                          <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Txn Amt</th>
                        )}
                        {visibleColumns.includes("mdrAmount") && (
                          <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">MDR</th>
                        )}
                        {visibleColumns.includes("erpCommission") && (
                          <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">ERP Comm</th>
                        )}
                        {visibleColumns.includes("netSettlement") && (
                          <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Net Settle</th>
                        )}
                        {visibleColumns.includes("paymentMethod") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Method</th>
                        )}
                        {visibleColumns.includes("gateway") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Gateway</th>
                        )}
                        {visibleColumns.includes("status") && (
                          <th className="p-3 text-center text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Status</th>
                        )}
                        {visibleColumns.includes("studentName") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Student</th>
                        )}
                        {visibleColumns.includes("studentId") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Student ID</th>
                        )}
                        {visibleColumns.includes("phoneNo") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Phone</th>
                        )}
                        {visibleColumns.includes("settlementDate") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Settle Date</th>
                        )}
                        {visibleColumns.includes("settlementTime") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Settle Time</th>
                        )}
                        {visibleColumns.includes("utr") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">UTR</th>
                        )}
                        {visibleColumns.includes("cardNetwork") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Card</th>
                        )}
                        {visibleColumns.includes("upiPsp") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">PSP</th>
                        )}
                        {visibleColumns.includes("bankName") && (
                          <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground whitespace-nowrap">Bank</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedTransactions.map((txn) => (
                        <tr key={txn.paymentId} className="border-b border-border hover:bg-secondary/30 transition-colors">
                          {visibleColumns.includes("srNo") && (
                            <td className="p-3 text-sm">{txn.srNo}</td>
                          )}
                          {visibleColumns.includes("instituteName") && (
                            <td className="p-3 text-sm">{txn.instituteName}</td>
                          )}
                          {visibleColumns.includes("dateTime") && (
                            <td className="p-3 text-sm whitespace-nowrap">{txn.dateTime}</td>
                          )}
                          {visibleColumns.includes("orderId") && (
                            <td className="p-3">
                              <Link href={`/transactions/${txn.paymentId}`} className="font-mono text-sm text-primary hover:underline">
                                {txn.orderId}
                              </Link>
                            </td>
                          )}
                          {visibleColumns.includes("paymentId") && (
                            <td className="p-3 font-mono text-xs text-muted-foreground">{txn.paymentId}</td>
                          )}
                          {visibleColumns.includes("orderAmount") && (
                            <td className="p-3 text-right font-medium">₹{txn.orderAmount.toLocaleString()}</td>
                          )}
                          {visibleColumns.includes("transactionAmount") && (
                            <td className="p-3 text-right">₹{txn.transactionAmount.toLocaleString()}</td>
                          )}
                          {visibleColumns.includes("mdrAmount") && (
                            <td className="p-3 text-right text-sm text-warning">
                              {txn.mdrAmount > 0 ? `-₹${txn.mdrAmount.toLocaleString()}` : "-"}
                            </td>
                          )}
                          {visibleColumns.includes("erpCommission") && (
                            <td className="p-3 text-right text-sm text-emerald-500">₹{txn.erpCommission.toLocaleString()}</td>
                          )}
                          {visibleColumns.includes("netSettlement") && (
                            <td className="p-3 text-right font-medium text-success">₹{txn.netSettlement.toLocaleString()}</td>
                          )}
                          {visibleColumns.includes("paymentMethod") && (
                            <td className="p-3">
                              <Badge variant="secondary" className="text-xs">
                                {txn.paymentMethod}
                              </Badge>
                            </td>
                          )}
                          {visibleColumns.includes("gateway") && (
                            <td className="p-3">
                              <Badge variant="outline" className="text-xs">
                                {txn.gateway}
                              </Badge>
                            </td>
                          )}
                          {visibleColumns.includes("status") && (
                            <td className="p-3 text-center">
                              <Badge variant="outline" className={statusColors[txn.status]}>
                                {txn.status}
                              </Badge>
                            </td>
                          )}
                          {visibleColumns.includes("studentName") && (
                            <td className="p-3 text-sm">{txn.studentName}</td>
                          )}
                          {visibleColumns.includes("studentId") && (
                            <td className="p-3 font-mono text-xs text-muted-foreground">{txn.studentId}</td>
                          )}
                          {visibleColumns.includes("phoneNo") && (
                            <td className="p-3 text-sm">{txn.phoneNo}</td>
                          )}
                          {visibleColumns.includes("settlementDate") && (
                            <td className="p-3 text-sm">{txn.settlementDate}</td>
                          )}
                          {visibleColumns.includes("settlementTime") && (
                            <td className="p-3 text-sm">{txn.settlementTime}</td>
                          )}
                          {visibleColumns.includes("utr") && (
                            <td className="p-3 font-mono text-xs text-muted-foreground">{txn.utr || "-"}</td>
                          )}
                          {visibleColumns.includes("cardNetwork") && (
                            <td className="p-3 text-sm">{txn.cardNetwork || "-"}</td>
                          )}
                          {visibleColumns.includes("upiPsp") && (
                            <td className="p-3 text-sm">{txn.upiPsp || "-"}</td>
                          )}
                          {visibleColumns.includes("bankName") && (
                            <td className="p-3 text-sm">{txn.bankName || "-"}</td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                <div className="flex items-center justify-between border-t border-border p-4">
                  <p className="text-sm text-muted-foreground">
                    Showing {startIndex + 1} to {Math.min(startIndex + rowsPerPage, filteredTransactions.length)} of {filteredTransactions.length} transactions
                  </p>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(1)}
                      disabled={currentPage === 1}
                    >
                      <ChevronsLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm px-2">
                      Page {currentPage} of {totalPages || 1}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages || totalPages === 0}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(totalPages)}
                      disabled={currentPage === totalPages || totalPages === 0}
                    >
                      <ChevronsRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
