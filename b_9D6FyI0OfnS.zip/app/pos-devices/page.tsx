import { DashboardLayout } from "@/components/dashboard-layout"
import { PosDevicesContent } from "@/components/pos-devices/pos-devices-content"

export default function PosDevicesPage() {
  return (
    <DashboardLayout>
      <PosDevicesContent />
    </DashboardLayout>
  )
}
