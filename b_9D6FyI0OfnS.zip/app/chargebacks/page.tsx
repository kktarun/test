import { DashboardLayout } from "@/components/dashboard-layout"
import { ChargebacksContent } from "@/components/chargebacks/chargebacks-content"

export default function ChargebacksPage() {
  return (
    <DashboardLayout>
      <ChargebacksContent />
    </DashboardLayout>
  )
}
