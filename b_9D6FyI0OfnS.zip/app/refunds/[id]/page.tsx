"use client"

import { use } from "react"
import Link from "next/link"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  ChevronLeft,
  Download,
  Printer,
  CheckCircle2,
  XCircle,
  Clock,
  RefreshCcw,
  CreditCard,
  Building2,
  User,
  Wallet,
  AlertCircle,
  FileText,
  Send,
  Banknote,
  Receipt,
  ArrowRight,
  Landmark,
  Layers,
} from "lucide-react"

// Mock refund data with timeline
const refundData: Record<string, any> = {
  "RFD001234": {
    id: "RFD001234",
    orderId: "ORD-SMC-2024-007",
    paymentId: "pay_SMC001234567",
    institute: "St. Mary's College",
    instituteCode: "SMC-001",
    studentName: "Rohan Joshi",
    studentId: "STU-SMC-001",
    studentEmail: "rohan.joshi@gmail.com",
    studentPhone: "+91 32109 87654",
    class: "12-A",
    feeType: "Tuition Fee",
    orderAmount: 42000,
    pgCharges: 630,
    transactionAmount: 41370,
    erpCommission: 420,
    gst: 75.60,
    netSettlement: 40274.40,
    refundAmount: 42000,
    gateway: "NTT Atom",
    accountType: "merchant",
    paymentMode: "Credit Card",
    status: "processed",
    reason: "Course cancellation - Student opted out of course before semester started",
    requestedBy: "Admin - Priya Sharma",
    approvedBy: "Finance Manager - Rajesh Kumar",
    arn: "ARN2024011500012345",
    merchantAccount: {
      merchantName: "St. Mary's College",
      merchantId: "MID-SMC-NTT-001",
      accountNumber: "XXXX XXXX 4521",
      ifscCode: "HDFC0001234",
      bankName: "HDFC Bank",
    },
    sourcePayment: {
      paymentMode: "Credit Card",
      cardType: "Visa",
      cardNumber: "XXXX XXXX XXXX 4532",
      cardHolder: "Rohan Joshi",
      bankName: "HDFC Bank",
    },
    timeline: [
      { event: "Refund Requested", timestamp: "2024-01-15 11:30:00", description: "Refund request initiated by Admin - Priya Sharma", user: "Priya Sharma", status: "completed", icon: "request" },
      { event: "Request Approved", timestamp: "2024-01-15 12:15:00", description: "Refund request approved by Finance Manager", user: "Rajesh Kumar", status: "completed", icon: "approve" },
      { event: "Sent to Gateway", timestamp: "2024-01-15 12:20:00", description: "Refund request sent to NTT Atom for processing", user: "System", status: "completed", icon: "send" },
      { event: "Gateway Processing", timestamp: "2024-01-15 13:00:00", description: "NTT Atom is processing the refund", user: "NTT Atom", status: "completed", icon: "process" },
      { event: "Bank Processing", timestamp: "2024-01-15 14:00:00", description: "Bank is processing the credit to customer account", user: "HDFC Bank", status: "completed", icon: "bank" },
      { event: "Refund Completed", timestamp: "2024-01-15 14:45:00", description: "Amount credited to customer's account. ARN: ARN2024011500012345", user: "System", status: "completed", icon: "complete" },
    ],
    createdDate: "2024-01-15",
    updatedDate: "2024-01-15",
    completedDate: "2024-01-15",
    originalSettlement: {
      id: "SETTLE-085",
      date: "2024-01-10",
      amount: 40274.40,
      status: "settled",
    },
    adjustedFromSettlement: {
      id: "SETTLE-090",
      date: "2024-01-16",
      adjustedAmount: 42000,
      adjustmentDate: "2024-01-15",
      status: "adjusted",
    },
  },
  "RFD001235": {
    id: "RFD001235",
    orderId: "ORD-AMT-2024-011",
    paymentId: "pay_AMT001234580",
    institute: "Amity University",
    instituteCode: "AMT-001",
    studentName: "Pooja Reddy",
    studentId: "STU-AMT-002",
    studentEmail: "pooja.reddy@amity.edu",
    studentPhone: "+91 98765 12345",
    class: "MBA-1",
    feeType: "Hostel Fee",
    orderAmount: 125000,
    pgCharges: 1875,
    transactionAmount: 123125,
    erpCommission: 1250,
    gst: 225,
    netSettlement: 119775,
    refundAmount: 100000,
    gateway: "Razorpay",
    accountType: "merchant",
    paymentMode: "Net Banking",
    status: "pending",
    reason: "Partial refund - Hostel fee adjustment due to late joining",
    requestedBy: "Finance - Rahul Mehta",
    merchantAccount: {
      merchantName: "Amity University",
      merchantId: "MID-AMT-RZP-001",
      accountNumber: "XXXX XXXX 7823",
      ifscCode: "ICIC0002345",
      bankName: "ICICI Bank",
    },
    sourcePayment: {
      paymentMode: "Net Banking",
      bankName: "State Bank of India",
      accountNumber: "XXXX XXXX 7890",
      accountHolder: "Pooja Reddy",
    },
    timeline: [
      { event: "Refund Requested", timestamp: "2024-01-16 09:15:00", description: "Refund request initiated by Finance - Rahul Mehta", user: "Rahul Mehta", status: "completed", icon: "request" },
      { event: "Pending Approval", timestamp: "2024-01-16 09:15:00", description: "Awaiting approval from Finance Manager", user: "System", status: "pending", icon: "approve" },
    ],
    createdDate: "2024-01-16",
    updatedDate: "2024-01-16",
    originalSettlement: {
      id: "SETTLE-082",
      date: "2024-01-08",
      amount: 119775,
      status: "settled",
    },
    adjustedFromSettlement: null, // Not yet adjusted - will be deducted from next settlement
  },
  "RFD001236": {
    id: "RFD001236",
    orderId: "ORD-DPS-2024-001",
    paymentId: "pay_DPS001234567",
    institute: "Delhi Public School",
    instituteCode: "DPS-001",
    studentName: "Rahul Sharma",
    studentId: "STU-DPS-003",
    studentEmail: "rahul.sharma@gmail.com",
    studentPhone: "+91 98765 43210",
    class: "10-B",
    feeType: "Annual Fee",
    orderAmount: 45000,
    pgCharges: 675,
    transactionAmount: 44325,
    erpCommission: 450,
    gst: 81,
    netSettlement: 43119,
    refundAmount: 45000,
    gateway: "Razorpay",
    accountType: "vendor",
    paymentMode: "Credit Card",
    status: "initiated",
    reason: "Duplicate payment - Parent made payment twice by mistake",
    requestedBy: "Parent Request",
    approvedBy: "Admin - Neha Singh",
    vendorAccount: {
      vendorName: "DPS Transport Services",
      vendorCode: "VND-DPS-TRANS",
      vendorAccountId: "VA-RZP-DPS-001",
      accountNumber: "XXXX XXXX 3456",
      ifscCode: "SBIN0003456",
      bankName: "State Bank of India",
    },
    sourcePayment: {
      paymentMode: "Credit Card",
      cardType: "MasterCard",
      cardNumber: "XXXX XXXX XXXX 3456",
      cardHolder: "Rahul Sharma Sr",
      bankName: "ICICI Bank",
    },
    timeline: [
      { event: "Refund Requested", timestamp: "2024-01-16 10:30:00", description: "Refund request initiated by Parent", user: "Parent Portal", status: "completed", icon: "request" },
      { event: "Request Approved", timestamp: "2024-01-16 11:00:00", description: "Refund request approved by Admin", user: "Neha Singh", status: "completed", icon: "approve" },
      { event: "Sent to Gateway", timestamp: "2024-01-16 11:05:00", description: "Refund request sent to Razorpay for processing", user: "System", status: "completed", icon: "send" },
      { event: "Awaiting Gateway Response", timestamp: "2024-01-16 11:05:00", description: "Waiting for Razorpay to confirm refund processing", user: "Razorpay", status: "pending", icon: "process" },
    ],
    createdDate: "2024-01-16",
    updatedDate: "2024-01-16",
    originalSettlement: {
      id: "SETTLE-088",
      date: "2024-01-12",
      amount: 43119,
      status: "settled",
    },
    adjustedFromSettlement: null, // Will be deducted from next settlement
  },
  "RFD001240": {
    id: "RFD001240",
    orderId: "ORD-KV-2024-015",
    paymentId: "SPLIT-ORD-KV-2024-015",
    institute: "Kendriya Vidyalaya",
    instituteCode: "KV-001",
    studentName: "Aditya Verma",
    studentId: "STU-KV-007",
    studentEmail: "aditya.verma@gmail.com",
    studentPhone: "+91 99887 76655",
    class: "11-A",
    feeType: "Annual Fee + Transport",
    orderAmount: 85000,
    pgCharges: 1275,
    transactionAmount: 83725,
    erpCommission: 850,
    gst: 153,
    netSettlement: 82447,
    refundAmount: 85000,
    gateway: "Multiple",
    accountType: "merchant",
    paymentMode: "Split & Pay",
    status: "processed",
    reason: "Full refund - Admission cancelled (Split & Pay)",
    requestedBy: "Admin - Suresh Kumar",
    approvedBy: "Finance Manager - Vikram Singh",
    isSplitPayment: true,
    splitTransactions: [
      {
        transactionId: "TXN001234610",
        amount: 35000,
        paymentMode: "Credit Card",
        gateway: "Razorpay",
        status: "processed",
        arn: "ARN2024011700011111",
        sourceAccount: {
          type: "credit_card",
          cardType: "Visa",
          cardNumber: "XXXX XXXX XXXX 4532",
          cardHolder: "Aditya Verma",
          bankName: "HDFC Bank",
        },
      },
      {
        transactionId: "TXN001234611",
        amount: 30000,
        paymentMode: "Net Banking",
        gateway: "Razorpay",
        status: "processed",
        arn: "ARN2024011700022222",
        sourceAccount: {
          type: "net_banking",
          bankName: "State Bank of India",
          accountNumber: "XXXX XXXX 7890",
          accountHolder: "Aditya Verma",
        },
      },
      {
        transactionId: "TXN001234612",
        amount: 20000,
        paymentMode: "UPI",
        gateway: "Paytm",
        status: "processed",
        arn: "ARN2024011700033333",
        sourceAccount: {
          type: "upi",
          upiId: "aditya.verma@okicici",
          bankName: "ICICI Bank",
        },
      },
    ],
    merchantAccount: {
      merchantName: "Kendriya Vidyalaya Sangathan",
      merchantId: "MID-KV-RZP-001",
      accountNumber: "XXXX XXXX 1234",
      ifscCode: "SBIN0001234",
      bankName: "State Bank of India",
    },
    timeline: [
      { event: "Refund Requested", timestamp: "2024-01-17 10:00:00", description: "Full refund request initiated for Split & Pay order", user: "Suresh Kumar", status: "completed", icon: "request" },
      { event: "Request Approved", timestamp: "2024-01-17 10:30:00", description: "Refund request approved by Finance Manager", user: "Vikram Singh", status: "completed", icon: "approve" },
      { event: "Split Refund Initiated", timestamp: "2024-01-17 10:35:00", description: "3 separate refund requests initiated for each transaction", user: "System", status: "completed", icon: "send" },
      { event: "Refund 1 Processed", timestamp: "2024-01-17 14:00:00", description: "Rs. 35,000 credited to Visa Card ****4532", user: "Razorpay", status: "completed", icon: "complete" },
      { event: "Refund 2 Processed", timestamp: "2024-01-17 14:15:00", description: "Rs. 30,000 credited to SBI A/C ****7890", user: "Razorpay", status: "completed", icon: "complete" },
      { event: "Refund 3 Processed", timestamp: "2024-01-17 14:30:00", description: "Rs. 20,000 credited to UPI aditya.verma@okicici", user: "Paytm", status: "completed", icon: "complete" },
      { event: "All Refunds Completed", timestamp: "2024-01-17 15:00:00", description: "All 3 split refunds processed successfully", user: "System", status: "completed", icon: "complete" },
    ],
    createdDate: "2024-01-17",
    updatedDate: "2024-01-17",
    completedDate: "2024-01-17",
    originalSettlement: {
      id: "SETTLE-092",
      date: "2024-01-14",
      amount: 82447,
      status: "settled",
    },
    adjustedFromSettlement: {
      id: "SETTLE-095",
      date: "2024-01-18",
      adjustedAmount: 85000,
      adjustmentDate: "2024-01-17",
      status: "adjusted",
    },
  },
}

const statusConfig: Record<string, { color: string; bgColor: string; label: string }> = {
  processed: { color: "text-success", bgColor: "bg-success/10", label: "PROCESSED" },
  pending: { color: "text-warning", bgColor: "bg-warning/10", label: "PENDING APPROVAL" },
  initiated: { color: "text-blue-500", bgColor: "bg-blue-500/10", label: "INITIATED" },
  failed: { color: "text-destructive", bgColor: "bg-destructive/10", label: "FAILED" },
  rejected: { color: "text-muted-foreground", bgColor: "bg-muted", label: "REJECTED" },
}

const timelineIcons: Record<string, any> = {
  request: RefreshCcw,
  approve: CheckCircle2,
  send: Send,
  process: CreditCard,
  bank: Banknote,
  complete: CheckCircle2,
  reject: XCircle,
  fail: XCircle,
}

export default function RefundDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: refundId } = use(params)
  const refund = refundData[refundId] || refundData["RFD001234"]
  const statusInfo = statusConfig[refund.status]

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/refunds">
              <Button variant="ghost" size="icon">
                <ChevronLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold">Refund Receipt</h1>
                <Badge className={`${statusInfo.bgColor} ${statusInfo.color} border-transparent`}>
                  {statusInfo.label}
                </Badge>
              </div>
              <p className="text-muted-foreground font-mono">{refund.id}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
            {(refund.status === "pending" || refund.status === "initiated") && (
              <Button variant="destructive" size="sm">
                <XCircle className="h-4 w-4 mr-2" />
                Cancel Refund
              </Button>
            )}
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-4 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Order Amount</p>
              <p className="text-2xl font-bold">₹{refund.orderAmount.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Transaction Amount</p>
              <p className="text-2xl font-bold">₹{refund.transactionAmount.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">After PG charges</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground mb-1">Charges Retained</p>
              <p className="text-2xl font-bold text-destructive">₹{(refund.orderAmount - refund.refundAmount).toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">Non-refundable</p>
            </CardContent>
          </Card>
          <Card className="bg-warning/10 border-warning/30">
            <CardContent className="p-4">
              <p className="text-xs text-warning mb-1">Refund Amount</p>
              <p className="text-2xl font-bold text-warning">₹{refund.refundAmount.toLocaleString()}</p>
              <p className="text-xs text-warning">To Customer</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Left Column - Details */}
          <div className="col-span-2 space-y-6">
            {/* Transaction Breakup */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Receipt className="h-5 w-5 text-primary" />
                  Transaction Breakup
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-secondary/30 rounded-lg p-4">
                  <h4 className="font-semibold mb-3 text-sm">Original Payment</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Order Amount</span>
                      <span className="font-semibold">₹{refund.orderAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">PG Charges (1.5%)</span>
                      <span className="text-destructive">-₹{refund.pgCharges.toLocaleString()}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-sm font-semibold">
                      <span>Transaction Amount</span>
                      <span>₹{refund.transactionAmount.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-secondary/30 rounded-lg p-4">
                  <h4 className="font-semibold mb-3 text-sm">Deductions (Non-Refundable)</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">PG MDR</span>
                      <span>₹{refund.pgCharges.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">ERP Commission (1%)</span>
                      <span>₹{refund.erpCommission.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">GST (18%)</span>
                      <span>₹{refund.gst.toLocaleString()}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-sm font-semibold text-destructive">
                      <span>Total Retained</span>
                      <span>₹{(refund.orderAmount - refund.refundAmount).toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-warning/10 rounded-lg p-4 border border-warning/20">
                  <h4 className="font-semibold mb-3 text-sm text-warning">Refund Calculation</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Order Amount</span>
                      <span>₹{refund.orderAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Less: Retained Charges</span>
                      <span className="text-destructive">-₹{(refund.orderAmount - refund.refundAmount).toLocaleString()}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold text-warning">
                      <span>Refund to Customer</span>
                      <span className="text-lg">₹{refund.refundAmount.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Order & Payment Details */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" />
                  Order & Payment Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Order ID</p>
                    <p className="font-mono font-semibold">{refund.orderId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Payment ID</p>
                    <p className="font-mono">{refund.paymentId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Gateway</p>
                    <Badge variant="outline">{refund.gateway}</Badge>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Payment Mode</p>
                    <p className="text-sm">{refund.paymentMode}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Fee Type</p>
                    <p className="text-sm">{refund.feeType}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Account Type</p>
                    <Badge variant="outline" className={`${refund.accountType === 'vendor' ? 'bg-purple-500/10 text-purple-500' : 'bg-blue-500/10 text-blue-500'}`}>
                      {refund.accountType === 'vendor' ? 'Vendor' : 'Merchant'}
                    </Badge>
                  </div>
                  {refund.arn && !refund.isSplitPayment && (
                    <div className="col-span-2">
                      <p className="text-xs text-muted-foreground">ARN (Acquirer Reference Number)</p>
                      <p className="font-mono text-primary">{refund.arn}</p>
                    </div>
                  )}
                  {refund.isSplitPayment && (
                    <div className="col-span-2">
                      <Badge className="bg-indigo-500/10 text-indigo-500 border-transparent">
                        <Layers className="h-3 w-3 mr-1" />
                        Split & Pay - {refund.splitTransactions?.length} Transactions
                      </Badge>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Split Payment Refund Details - Multiple Source Accounts */}
            {refund.isSplitPayment && refund.splitTransactions && (
              <Card className="bg-card border-border border-indigo-500/30">
                <CardHeader className="bg-indigo-500/5">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Layers className="h-5 w-5 text-indigo-500" />
                    Split Payment Refund Details
                    <Badge className="bg-warning/20 text-warning border-transparent ml-2">Full Refund Only</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="bg-indigo-500/5 rounded-lg p-3 mb-4">
                    <p className="text-sm text-muted-foreground">
                      This order was paid using <span className="font-semibold text-indigo-500">{refund.splitTransactions.length} separate transactions</span>. 
                      Each refund will be credited back to its original payment source.
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    {refund.splitTransactions.map((txn: any, index: number) => (
                      <div key={txn.transactionId} className="bg-secondary/30 rounded-lg p-4 border border-border">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-500 font-semibold text-sm">
                              {index + 1}
                            </div>
                            <div>
                              <p className="font-mono text-sm text-primary">{txn.transactionId}</p>
                              <p className="text-xs text-muted-foreground">{txn.paymentMode} via {txn.gateway}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-lg">₹{txn.amount.toLocaleString()}</p>
                            <Badge variant="outline" className={`text-xs ${txn.status === 'processed' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'}`}>
                              {txn.status.toUpperCase()}
                            </Badge>
                          </div>
                        </div>
                        
                        {/* Refund Destination - Source Account */}
                        <div className="bg-background rounded-lg p-3 border border-border/50">
                          <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                            <Wallet className="h-3 w-3" />
                            Refund Credited To:
                          </p>
                          {txn.sourceAccount.type === 'credit_card' || txn.sourceAccount.type === 'debit_card' ? (
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <p className="text-xs text-muted-foreground">Card Type</p>
                                <p className="text-sm font-medium">{txn.sourceAccount.cardType} {txn.sourceAccount.type === 'credit_card' ? 'Credit Card' : 'Debit Card'}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Card Number</p>
                                <p className="font-mono text-sm">{txn.sourceAccount.cardNumber}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Card Holder</p>
                                <p className="text-sm">{txn.sourceAccount.cardHolder}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Bank</p>
                                <p className="text-sm">{txn.sourceAccount.bankName}</p>
                              </div>
                            </div>
                          ) : txn.sourceAccount.type === 'net_banking' ? (
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <p className="text-xs text-muted-foreground">Payment Method</p>
                                <p className="text-sm font-medium">Net Banking</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Bank</p>
                                <p className="text-sm">{txn.sourceAccount.bankName}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Account Number</p>
                                <p className="font-mono text-sm">{txn.sourceAccount.accountNumber}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Account Holder</p>
                                <p className="text-sm">{txn.sourceAccount.accountHolder}</p>
                              </div>
                            </div>
                          ) : txn.sourceAccount.type === 'upi' ? (
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <p className="text-xs text-muted-foreground">Payment Method</p>
                                <p className="text-sm font-medium">UPI</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">UPI ID</p>
                                <p className="font-mono text-sm">{txn.sourceAccount.upiId}</p>
                              </div>
                              <div className="col-span-2">
                                <p className="text-xs text-muted-foreground">Bank</p>
                                <p className="text-sm">{txn.sourceAccount.bankName}</p>
                              </div>
                            </div>
                          ) : txn.sourceAccount.type === 'wallet' ? (
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <p className="text-xs text-muted-foreground">Payment Method</p>
                                <p className="text-sm font-medium">Wallet</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Wallet Name</p>
                                <p className="text-sm">{txn.sourceAccount.walletName}</p>
                              </div>
                            </div>
                          ) : null}
                          
                          {txn.arn && (
                            <div className="mt-3 pt-3 border-t border-border/50">
                              <p className="text-xs text-muted-foreground">ARN</p>
                              <p className="font-mono text-xs text-primary">{txn.arn}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Total Summary */}
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Refund Amount</p>
                        <p className="text-xs text-muted-foreground">Across {refund.splitTransactions.length} transactions</p>
                      </div>
                      <p className="text-2xl font-bold text-success">₹{refund.refundAmount.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Refund Reason */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Refund Reason
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm bg-secondary/30 p-4 rounded-lg">{refund.reason}</p>
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Requested By</p>
                    <p className="text-sm font-medium">{refund.requestedBy}</p>
                  </div>
                  {refund.approvedBy && (
                    <div>
                      <p className="text-xs text-muted-foreground">Approved By</p>
                      <p className="text-sm font-medium">{refund.approvedBy}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Settlement Impact */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Landmark className="h-5 w-5 text-primary" />
                  Settlement Impact
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Original Settlement */}
                {refund.originalSettlement && (
                  <div className="bg-secondary/30 rounded-lg p-4">
                    <h4 className="font-semibold mb-3 text-sm flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">Original Payment</Badge>
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Settlement ID</p>
                        <Link href={`/settlements/institute/${refund.originalSettlement.id}`} className="font-mono text-sm text-primary hover:underline">
                          {refund.originalSettlement.id}
                        </Link>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Settlement Date</p>
                        <p className="text-sm">{refund.originalSettlement.date}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Settlement Amount</p>
                        <p className="font-semibold text-success">₹{refund.originalSettlement.amount.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Status</p>
                        <Badge className="bg-success/10 text-success border-transparent text-xs">
                          {refund.originalSettlement.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  </div>
                )}

                {/* Refund Adjustment */}
                {refund.adjustedFromSettlement ? (
                  <div className="bg-warning/10 rounded-lg p-4 border border-warning/20">
                    <h4 className="font-semibold mb-3 text-sm flex items-center gap-2">
                      <Badge className="bg-warning/20 text-warning border-transparent text-xs">Refund Adjusted</Badge>
                      <CheckCircle2 className="h-4 w-4 text-success" />
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Adjusted From Settlement</p>
                        <Link href={`/settlements/institute/${refund.adjustedFromSettlement.id}`} className="font-mono text-sm text-warning hover:underline">
                          {refund.adjustedFromSettlement.id}
                        </Link>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Settlement Date</p>
                        <p className="text-sm">{refund.adjustedFromSettlement.date}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Adjusted Amount</p>
                        <p className="font-semibold text-warning">-₹{refund.adjustedFromSettlement.adjustedAmount.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Adjustment Date</p>
                        <p className="text-sm">{refund.adjustedFromSettlement.adjustmentDate}</p>
                      </div>
                    </div>

                    {/* Visual Flow */}
                    <div className="mt-4 pt-4 border-t border-warning/20">
                      <div className="flex items-center justify-between text-xs">
                        <div className="text-center">
                          <p className="text-muted-foreground mb-1">Original Settlement</p>
                          <p className="font-mono text-success">{refund.originalSettlement?.id}</p>
                          <p className="text-muted-foreground">{refund.originalSettlement?.date}</p>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground" />
                        <div className="text-center">
                          <p className="text-muted-foreground mb-1">Refund Initiated</p>
                          <p className="font-mono">{refund.id}</p>
                          <p className="text-warning">-₹{refund.refundAmount.toLocaleString()}</p>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground" />
                        <div className="text-center">
                          <p className="text-muted-foreground mb-1">Adjusted From</p>
                          <p className="font-mono text-warning">{refund.adjustedFromSettlement.id}</p>
                          <p className="text-muted-foreground">{refund.adjustedFromSettlement.date}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-orange-500/10 rounded-lg p-4 border border-orange-500/20">
                    <h4 className="font-semibold mb-3 text-sm flex items-center gap-2">
                      <Badge className="bg-orange-500/20 text-orange-500 border-transparent text-xs">Pending Adjustment</Badge>
                      <Clock className="h-4 w-4 text-orange-500" />
                    </h4>
                    <div className="space-y-3">
                      <p className="text-sm text-muted-foreground">
                        This refund amount of <span className="font-semibold text-warning">₹{refund.refundAmount.toLocaleString()}</span> will be deducted from the next settlement for <span className="font-medium">{refund.institute}</span>.
                      </p>
                      <div className="flex items-center gap-2 text-xs text-orange-500">
                        <AlertCircle className="h-4 w-4" />
                        <span>Settlement adjustment pending - will be processed in next cycle</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Net Impact Summary */}
                <div className="bg-secondary/50 rounded-lg p-4">
                  <h4 className="font-semibold mb-3 text-sm">Net Settlement Impact</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Original Settlement Amount</span>
                      <span className="font-semibold text-success">+₹{refund.originalSettlement?.amount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Refund Deduction</span>
                      <span className="font-semibold text-destructive">-₹{refund.refundAmount.toLocaleString()}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-bold">
                      <span>Net Settled to Institute</span>
                      <span className={refund.originalSettlement ? 'text-success' : ''}>
                        ₹{((refund.originalSettlement?.amount || 0) - refund.refundAmount).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Timeline & Details */}
          <div className="space-y-6">
            {/* Refund Lifecycle Timeline */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  Refund Lifecycle
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  {refund.timeline.map((step: any, index: number) => {
                    const IconComponent = timelineIcons[step.icon] || Clock
                    const isLast = index === refund.timeline.length - 1
                    const isCompleted = step.status === "completed"
                    const isPending = step.status === "pending"

                    return (
                      <div key={index} className="relative pb-6 last:pb-0">
                        {!isLast && (
                          <div className={`absolute left-4 top-8 w-0.5 h-full ${isCompleted ? 'bg-success' : 'bg-border'}`} />
                        )}
                        <div className="flex gap-4">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            isCompleted ? 'bg-success/20' : isPending ? 'bg-warning/20' : 'bg-muted'
                          }`}>
                            <IconComponent className={`h-4 w-4 ${
                              isCompleted ? 'text-success' : isPending ? 'text-warning' : 'text-muted-foreground'
                            }`} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-sm">{step.event}</p>
                              {isPending && (
                                <Badge className="bg-warning/10 text-warning text-xs">Pending</Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground mt-0.5">{step.timestamp}</p>
                            <p className="text-xs text-muted-foreground mt-1">{step.description}</p>
                            <p className="text-xs text-primary mt-1">By: {step.user}</p>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Institute Details */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  Institute Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <p className="text-xs text-muted-foreground">Institute Name</p>
                  <p className="font-medium">{refund.institute}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Institute Code</p>
                  <p className="font-mono text-sm">{refund.instituteCode}</p>
                </div>
              </CardContent>
            </Card>

            {/* Student Details */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  Student Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <p className="text-xs text-muted-foreground">Name</p>
                  <p className="font-medium">{refund.studentName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Student ID</p>
                  <p className="font-mono text-sm">{refund.studentId}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Class</p>
                  <p className="text-sm">{refund.class}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Email</p>
                  <p className="text-sm">{refund.studentEmail}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Phone</p>
                  <p className="text-sm">{refund.studentPhone}</p>
                </div>
              </CardContent>
            </Card>

            {/* Refunded From - Merchant/Vendor Account */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
{refund.accountType === 'vendor' ? 'Vendor Account (Refunded From)' : 'Merchant Account (Refunded From)'}
  </CardTitle>
  </CardHeader>
  <CardContent className="space-y-2">
  {refund.accountType === 'vendor' && refund.vendorAccount ? (
  <>
  <div>
  <p className="text-xs text-muted-foreground">Vendor Name</p>
  <p className="font-medium text-purple-600">{refund.vendorAccount.vendorName}</p>
  </div>
  <div>
  <p className="text-xs text-muted-foreground">Vendor Code</p>
  <p className="font-mono text-sm">{refund.vendorAccount.vendorCode}</p>
  </div>
  <div>
  <p className="text-xs text-muted-foreground">Vendor Account ID</p>
  <p className="font-mono text-sm">{refund.vendorAccount.vendorAccountId}</p>
  </div>
  <Separator className="my-2" />
  <div>
  <p className="text-xs text-muted-foreground">Bank Name</p>
  <p className="font-medium">{refund.vendorAccount.bankName}</p>
  </div>
  <div>
  <p className="text-xs text-muted-foreground">Account Number</p>
  <p className="font-mono">{refund.vendorAccount.accountNumber}</p>
  </div>
  <div>
  <p className="text-xs text-muted-foreground">IFSC Code</p>
  <p className="font-mono text-sm">{refund.vendorAccount.ifscCode}</p>
  </div>
  </>
                ) : refund.merchantAccount ? (
                  <>
                    <div>
                      <p className="text-xs text-muted-foreground">Merchant Name</p>
                      <p className="font-medium text-blue-600">{refund.merchantAccount.merchantName}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Merchant ID</p>
                      <p className="font-mono text-sm">{refund.merchantAccount.merchantId}</p>
                    </div>
                    <Separator className="my-2" />
                    <div>
                      <p className="text-xs text-muted-foreground">Bank Name</p>
                      <p className="font-medium">{refund.merchantAccount.bankName}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Account Number</p>
                      <p className="font-mono">{refund.merchantAccount.accountNumber}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">IFSC Code</p>
                      <p className="font-mono text-sm">{refund.merchantAccount.ifscCode}</p>
                    </div>
                  </>
                ) : null}
              </CardContent>
            </Card>

            {/* Refund Destination - Source Payment */}
            <Card className="bg-warning/5 border-warning/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Wallet className="h-4 w-4 text-warning" />
                  Refund Destination (Source Payment)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="bg-warning/10 rounded-lg p-3 mb-3">
                  <p className="text-xs text-warning font-medium">Refund will be credited to the original payment source</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Payment Mode</p>
                  <p className="font-medium">{refund.sourcePayment?.paymentMode || refund.paymentMode}</p>
                </div>
                {refund.sourcePayment?.cardType && (
                  <>
                    <div>
                      <p className="text-xs text-muted-foreground">Card Type</p>
                      <p className="text-sm">{refund.sourcePayment.cardType}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Card Number</p>
                      <p className="font-mono">{refund.sourcePayment.cardNumber}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Card Holder</p>
                      <p className="text-sm">{refund.sourcePayment.cardHolder}</p>
                    </div>
                  </>
                )}
                {refund.sourcePayment?.accountNumber && !refund.sourcePayment?.cardType && (
                  <>
                    <div>
                      <p className="text-xs text-muted-foreground">Account Number</p>
                      <p className="font-mono">{refund.sourcePayment.accountNumber}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Account Holder</p>
                      <p className="text-sm">{refund.sourcePayment.accountHolder}</p>
                    </div>
                  </>
                )}
                <div>
                  <p className="text-xs text-muted-foreground">Bank</p>
                  <p className="font-medium">{refund.sourcePayment?.bankName}</p>
                </div>
              </CardContent>
            </Card>

            {/* Important Dates */}
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  Important Dates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <p className="text-xs text-muted-foreground">Created Date</p>
                  <p className="text-sm">{refund.createdDate}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Last Updated</p>
                  <p className="text-sm">{refund.updatedDate}</p>
                </div>
                {refund.completedDate && (
                  <div>
                    <p className="text-xs text-muted-foreground">Completed Date</p>
                    <p className="text-sm text-success">{refund.completedDate}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
