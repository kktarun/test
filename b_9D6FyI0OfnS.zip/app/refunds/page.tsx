import { DashboardLayout } from "@/components/dashboard-layout"
import { RefundsContent } from "@/components/refunds/refunds-content"

export default function RefundsPage() {
  return (
    <DashboardLayout>
      <RefundsContent />
    </DashboardLayout>
  )
}
