import { DashboardLayout } from "@/components/dashboard-layout"
import { InstitutesContent } from "@/components/institutes/institutes-content"

export default function InstitutesPage() {
  return (
    <DashboardLayout>
      <InstitutesContent />
    </DashboardLayout>
  )
}
