import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { ThemeProvider } from "@/components/theme-provider"
import { EnvironmentModeProvider } from "@/components/environment-mode-provider"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "ClearN by SparkIT - Payment Orchestration Platform",
  description:
    "Unified payment orchestration for Education - Multi-gateway analytics, settlements, and institute management by SparkIT",
  generator: "v0.app",
}

export const viewport = {
  themeColor: "#1a1a2e",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`font-sans antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <EnvironmentModeProvider>{children}</EnvironmentModeProvider>
        </ThemeProvider>
        <Analytics />
      </body>
    </html>
  )
}
