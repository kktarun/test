"use client"

import { StatsCards } from "./stats-cards"
import { RevenueChart } from "./charts/revenue-chart"
import { GatewayPerformance } from "./charts/gateway-performance"
import { TransactionVolume } from "./charts/transaction-volume"
import { RecentTransactions } from "./recent-transactions"
import { GatewayBreakdown } from "./gateway-breakdown"
import { TopInstitutes } from "./top-institutes"
import { DateRangePicker } from "./date-range-picker"
import { ChargebackSummary } from "./chargeback-summary"

export function DashboardContent() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Overview of your payment orchestration platform</p>
        </div>
        <DateRangePicker />
      </div>

      <StatsCards />

      <div className="grid gap-6 lg:grid-cols-2">
        <RevenueChart />
        <TransactionVolume />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <GatewayPerformance />
        </div>
        <GatewayBreakdown />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <RecentTransactions />
        </div>
        <div className="space-y-6">
          <TopInstitutes />
          <ChargebackSummary />
        </div>
      </div>
    </div>
  )
}
