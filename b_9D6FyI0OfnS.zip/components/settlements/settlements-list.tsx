"use client"

import { useState } from "react"
import React from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  ChevronsLeft,
  ChevronsRight,
  Search,
  Building2,
  Users,
  Eye,
  Split,
  RotateCcw,
  ShieldAlert,
  CheckCircle,
  ArrowDownRight,
  ArrowUpRight,
  FileText,
  ExternalLink,
  Clock,
  TrendingUp,
} from "lucide-react"
import { SettlementDetailDrawer } from "./settlement-detail-drawer"

interface SettlementsListProps {
  gateway: string
  status: string
  dateRange: string
  institute?: string
  searchQuery?: string
  visibleColumns?: string[]
}

const instituteSettlements = [
  {
    id: "SETTLE-001",
    settlementDate: "2025-01-10",
    settlementTime: "14:30:00",
    collectionDate: "2025-01-09",
    institute: {
      id: "INS001",
      name: "Delhi Public School, R.K. Puram",
      code: "DPS-RKP",
    },
    totalStudents: 145,
    totalTransactions: 145,
    orderAmount: 1450000,
    transactionFees: 29000,
    erpCommission: 14500,
    adjustments: {
      total: 60000,
      refunds: [
        {
          refundId: "REF-001",
          studentName: "Arjun Sharma",
          originalTxn: "TXN-8901",
          originalSettlement: "SETTLE-98",
          originalSettlementDate: "2025-01-05",
          amount: 10000,
          reason: "Course withdrawal",
          type: "refund",
        },
        {
          refundId: "REF-002",
          studentName: "Priya Patel",
          originalTxn: "TXN-8845",
          originalSettlement: "SETTLE-97",
          originalSettlementDate: "2025-01-04",
          amount: 5000,
          reason: "Partial refund",
          type: "refund",
        },
      ],
      chargebacks: [
        {
          chargebackId: "CHB-001",
          studentName: "Rahul Mehta",
          originalTxn: "TXN-8756",
          originalSettlement: "SETTLE-95",
          originalSettlementDate: "2025-01-02",
          amount: 45000,
          reason: "Fraudulent Transaction - 10.4",
          raisedBy: "HDFC Bank",
          status: "lost",
          raisedDate: "2025-01-08",
          type: "chargeback",
        },
      ],
    },
    recoveries: {
      total: 32000,
      chargebacksWon: [
        {
          chargebackId: "CHB-099",
          studentName: "Vikram Singh",
          originalTxn: "TXN-8500",
          deductedFromSettlement: "SETTLE-90",
          deductedDate: "2024-12-20",
          amount: 32000,
          reason: "Unauthorized Transaction - Won",
          wonDate: "2025-01-09",
          creditedDate: "2025-01-10",
          type: "chargeback_won",
        },
      ],
    },
    netSettlement: 1378500, // 1450000 - 29000 - 14500 - 60000 + 32000
    status: "settled",
    utr: "RAZP2501100001234",
    gatewayBreakdown: [
      {
        gateway: "Razorpay",
        transactions: 65,
        studentCount: 65,
        orderAmount: 650000,
        fees: 13000,
        refundAdjustments: 10000,
        chargebackAdjustments: 45000,
        recoveries: 32000,
        netAmount: 614000,
        utr: "RAZP2501100001234",
        status: "settled",
        hasSplit: true,
        splitDetails: {
          platformShare: 32500,
          vendorShare: 581500,
          beneficiaries: [
            { name: "Transport Vendor", share: 65000 },
            { name: "Canteen Services", share: 32500 },
          ],
        },
        students: [
          {
            id: "STU001",
            name: "Aarav Kumar",
            class: "X-A",
            rollNo: "2024001",
            amount: 10000,
            feeType: "Tuition",
            txnId: "TXN-9001",
            time: "09:15 AM",
          },
          {
            id: "STU002",
            name: "Diya Sharma",
            class: "X-B",
            rollNo: "2024002",
            amount: 10000,
            feeType: "Tuition",
            txnId: "TXN-9005",
            time: "09:22 AM",
          },
          {
            id: "STU003",
            name: "Vihaan Reddy",
            class: "XI-C",
            rollNo: "2024003",
            amount: 10000,
            feeType: "Tuition",
            txnId: "TXN-9008",
            time: "09:30 AM",
          },
        ],
      },
      {
        gateway: "Cashfree",
        transactions: 50,
        studentCount: 50,
        orderAmount: 500000,
        fees: 10000,
        refundAdjustments: 5000,
        chargebackAdjustments: 0,
        recoveries: 0,
        netAmount: 485000,
        utr: "CF2501100005678",
        status: "settled",
        hasSplit: false,
        students: [
          {
            id: "STU004",
            name: "Ananya Singh",
            class: "IX-B",
            rollNo: "2024004",
            amount: 10000,
            feeType: "Annual",
            txnId: "TXN-9002",
            time: "10:05 AM",
          },
          {
            id: "STU005",
            name: "Rohan Gupta",
            class: "IX-A",
            rollNo: "2024005",
            amount: 10000,
            feeType: "Annual",
            txnId: "TXN-9010",
            time: "10:12 AM",
          },
        ],
      },
      {
        gateway: "Paytm",
        transactions: 30,
        studentCount: 30,
        orderAmount: 300000,
        fees: 6000,
        refundAdjustments: 0,
        chargebackAdjustments: 0,
        recoveries: 0,
        netAmount: 294000,
        utr: "PTM2501100009012",
        status: "settled",
        hasSplit: true,
        splitDetails: {
          platformShare: 15000,
          vendorShare: 279000,
          beneficiaries: [{ name: "Sports Academy", share: 90000 }],
        },
        students: [
          {
            id: "STU006",
            name: "Ishaan Verma",
            class: "VIII-A",
            rollNo: "2024006",
            amount: 10000,
            feeType: "Sports",
            txnId: "TXN-9015",
            time: "11:00 AM",
          },
        ],
      },
    ],
    students: [
      {
        id: "STU001",
        name: "Aarav Kumar",
        class: "X-A",
        rollNo: "2024001",
        amount: 10000,
        gateway: "Razorpay",
        txnId: "TXN-9001",
        status: "settled",
        hasSplit: true,
        feeType: "Tuition",
      },
    ],
  },
  {
    id: "SETTLE-002",
    settlementDate: "2025-01-10",
    settlementTime: "15:30:00",
    collectionDate: "2025-01-09",
    institute: {
      id: "INS002",
      name: "St. Xavier's College",
      code: "SXC-MUM",
    },
    totalStudents: 230,
    totalTransactions: 230,
    orderAmount: 2300000,
    transactionFees: 46000,
    erpCommission: 23000,
    adjustments: {
      total: 103000,
      refunds: [
        {
          refundId: "REF-003",
          studentName: "Rahul Mehta",
          originalTxn: "TXN-7801",
          originalSettlement: "SETTLE-92",
          originalSettlementDate: "2024-12-28",
          amount: 25000,
          reason: "Admission cancelled",
          type: "refund",
        },
      ],
      chargebacks: [
        {
          chargebackId: "CHB-002",
          studentName: "Neha Kapoor",
          originalTxn: "TXN-7650",
          originalSettlement: "SETTLE-91",
          originalSettlementDate: "2024-12-27",
          amount: 78000,
          reason: "Product Not Received - 13.1",
          raisedBy: "ICICI Bank",
          status: "under_review",
          raisedDate: "2025-01-06",
          type: "chargeback",
        },
      ],
    },
    recoveries: {
      total: 0,
      chargebacksWon: [],
    },
    netSettlement: 2128000, // 2300000 - 46000 - 23000 - 103000
    status: "settled",
    utr: "HDFC2501100002345",
    gatewayBreakdown: [
      {
        gateway: "HDFC",
        transactions: 120,
        studentCount: 120,
        orderAmount: 1200000,
        fees: 24000,
        refundAdjustments: 25000,
        chargebackAdjustments: 78000,
        recoveries: 0,
        netAmount: 1073000,
        utr: "HDFC2501100002345",
        status: "settled",
        hasSplit: false,
        students: [],
      },
      {
        gateway: "Razorpay",
        transactions: 80,
        studentCount: 80,
        orderAmount: 800000,
        fees: 16000,
        refundAdjustments: 0,
        chargebackAdjustments: 0,
        recoveries: 0,
        netAmount: 784000,
        utr: "RAZP2501100003456",
        status: "settled",
        hasSplit: true,
        splitDetails: {
          platformShare: 40000,
          vendorShare: 744000,
          beneficiaries: [
            { name: "Library Services", share: 80000 },
            { name: "Lab Equipment", share: 160000 },
          ],
        },
        students: [],
      },
      {
        gateway: "PayU",
        transactions: 30,
        studentCount: 30,
        orderAmount: 300000,
        fees: 6000,
        refundAdjustments: 0,
        chargebackAdjustments: 0,
        recoveries: 0,
        netAmount: 294000,
        utr: "PAYU2501100004567",
        status: "settled",
        hasSplit: false,
        students: [],
      },
    ],
    students: [],
  },
  {
    id: "SETTLE-003",
    settlementDate: "2025-01-10",
    settlementTime: "",
    collectionDate: "2025-01-09",
    institute: {
      id: "INS003",
      name: "IIT Delhi",
      code: "IITD",
    },
    totalStudents: 85,
    totalTransactions: 85,
    orderAmount: 4250000,
    transactionFees: 85000,
    erpCommission: 42500,
    adjustments: {
      total: 0,
      refunds: [],
      chargebacks: [],
    },
    recoveries: {
      total: 125000,
      chargebacksWon: [
        {
          chargebackId: "CHB-050",
          studentName: "Aditya Jain",
          originalTxn: "TXN-5000",
          deductedFromSettlement: "SETTLE-80",
          deductedDate: "2024-12-10",
          amount: 125000,
          reason: "Duplicate Transaction - Won",
          wonDate: "2025-01-08",
          creditedDate: "2025-01-10",
          type: "chargeback_won",
        },
      ],
    },
    netSettlement: 4247500, // 4250000 - 85000 - 42500 + 125000
    status: "pending",
    utr: null,
    gatewayBreakdown: [
      {
        gateway: "Razorpay",
        transactions: 85,
        studentCount: 85,
        orderAmount: 4250000,
        fees: 85000,
        refundAdjustments: 0,
        chargebackAdjustments: 0,
        recoveries: 125000,
        netAmount: 4290000,
        utr: null,
        status: "pending",
        hasSplit: true,
        splitDetails: {
          platformShare: 212500,
          vendorShare: 4077500,
          beneficiaries: [
            { name: "Hostel Facility", share: 850000 },
            { name: "Mess Charges", share: 425000 },
          ],
        },
        students: [],
      },
    ],
    students: [],
  },
  {
    id: "SETTLE-004",
    settlementDate: "2025-01-10",
    settlementTime: "",
    collectionDate: "2025-01-09",
    institute: {
      id: "INS004",
      name: "Amity University",
      code: "AMITY-NOI",
    },
    totalStudents: 320,
    totalTransactions: 320,
    orderAmount: 3200000,
    transactionFees: 64000,
    erpCommission: 32000,
    adjustments: {
      total: 101000,
      refunds: [
        {
          refundId: "REF-004",
          studentName: "Sneha Gupta",
          originalTxn: "TXN-6701",
          originalSettlement: "SETTLE-88",
          originalSettlementDate: "2024-12-22",
          amount: 30000,
          reason: "Branch transfer",
          type: "refund",
        },
        {
          refundId: "REF-005",
          studentName: "Amit Verma",
          originalTxn: "TXN-6655",
          originalSettlement: "SETTLE-87",
          originalSettlementDate: "2024-12-21",
          amount: 15000,
          reason: "Duplicate payment",
          type: "refund",
        },
      ],
      chargebacks: [
        {
          chargebackId: "CHB-003",
          studentName: "Kavita Sharma",
          originalTxn: "TXN-6600",
          originalSettlement: "SETTLE-86",
          originalSettlementDate: "2024-12-20",
          amount: 56000,
          reason: "Refund Not Processed - 13.6",
          raisedBy: "Kotak Bank",
          status: "response_submitted",
          raisedDate: "2025-01-04",
          type: "chargeback",
        },
      ],
    },
    recoveries: {
      total: 0,
      chargebacksWon: [],
    },
    netSettlement: 3003000, // 3200000 - 64000 - 32000 - 101000
    status: "processing",
    utr: null,
    gatewayBreakdown: [
      {
        gateway: "Cashfree",
        transactions: 180,
        studentCount: 180,
        orderAmount: 1800000,
        fees: 36000,
        refundAdjustments: 30000,
        chargebackAdjustments: 0,
        recoveries: 0,
        netAmount: 1734000,
        utr: null,
        status: "processing",
        hasSplit: false,
        students: [],
      },
      {
        gateway: "Paytm",
        transactions: 140,
        studentCount: 140,
        orderAmount: 1400000,
        fees: 28000,
        refundAdjustments: 15000,
        chargebackAdjustments: 56000,
        recoveries: 0,
        netAmount: 1301000,
        utr: null,
        status: "processing",
        hasSplit: true,
        splitDetails: {
          platformShare: 70000,
          vendorShare: 1231000,
          beneficiaries: [{ name: "Bus Transport", share: 280000 }],
        },
        students: [],
      },
    ],
    students: [],
  },
]

const statusColors: Record<string, string> = {
  settled: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  pending: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  processing: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  failed: "bg-red-500/10 text-red-500 border-red-500/20",
  on_hold: "bg-red-500/10 text-red-500 border-red-500/20",
}

export function SettlementsList({ gateway, status, dateRange, institute = "all", searchQuery = "", visibleColumns = [] }: SettlementsListProps) {
  const [localSearchTerm, setLocalSearchTerm] = useState("")
  const [expandedRows, setExpandedRows] = useState<string[]>([])
  const [selectedSettlement, setSelectedSettlement] = useState<(typeof instituteSettlements)[0] | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [expandedGateways, setExpandedGateways] = useState<string[]>([])
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)

  const searchTerm = searchQuery || localSearchTerm

  const toggleRow = (id: string) => {
    setExpandedRows((prev) => (prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]))
  }

  const toggleGateway = (settlementId: string, gateway: string) => {
    const key = `${settlementId}-${gateway}`
    setExpandedGateways((prev) => (prev.includes(key) ? prev.filter((r) => r !== key) : [...prev, key]))
  }

  const filteredSettlements = instituteSettlements.filter((s) => {
    // Search filter
    if (searchTerm) {
      const query = searchTerm.toLowerCase()
      const matchesSearch = 
        s.institute.name.toLowerCase().includes(query) ||
        s.institute.code.toLowerCase().includes(query) ||
        s.id.toLowerCase().includes(query) ||
        (s.utr && s.utr.toLowerCase().includes(query))
      if (!matchesSearch) return false
    }
    // Institute filter
    if (institute !== "all" && s.institute.id !== institute) {
      return false
    }
    // Status filter
    if (status !== "all" && s.status !== status) {
      return false
    }
    return true
  })

  // Pagination
  const totalPages = Math.ceil(filteredSettlements.length / rowsPerPage)
  const startIndex = (currentPage - 1) * rowsPerPage
  const paginatedSettlements = filteredSettlements.slice(startIndex, startIndex + rowsPerPage)

  const openDetailDrawer = (settlement: (typeof instituteSettlements)[0]) => {
    setSelectedSettlement(settlement)
    setDrawerOpen(true)
  }

  // Check which columns to show
  const showColumn = (col: string) => visibleColumns.length === 0 || visibleColumns.includes(col)

  return (
    <>
      <Card className="bg-card border-border">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Institute Settlements ({filteredSettlements.length})
            </CardTitle>
            <div className="flex items-center gap-3">
              {/* Local Search (if not passed from parent) */}
              {!searchQuery && (
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search settlements..."
                    value={localSearchTerm}
                    onChange={(e) => {
                      setLocalSearchTerm(e.target.value)
                      setCurrentPage(1)
                    }}
                    className="pl-9 bg-secondary"
                  />
                </div>
              )}
              {/* Rows per page */}
              <Select value={rowsPerPage.toString()} onValueChange={(v) => {
                setRowsPerPage(parseInt(v))
                setCurrentPage(1)
              }}>
                <SelectTrigger className="w-[100px] bg-secondary">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 rows</SelectItem>
                  <SelectItem value="10">10 rows</SelectItem>
                  <SelectItem value="25">25 rows</SelectItem>
                  <SelectItem value="50">50 rows</SelectItem>
                  <SelectItem value="100">100 rows</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="w-8"></TableHead>
                  {showColumn("institute") && <TableHead>Institute</TableHead>}
                  {showColumn("settlementId") && <TableHead>Settlement ID</TableHead>}
                  {showColumn("settlementDate") && <TableHead>Settlement Date</TableHead>}
                  {showColumn("settlementTime") && <TableHead>Settlement Time</TableHead>}
                  {showColumn("students") && <TableHead className="text-center">Students</TableHead>}
                  {showColumn("gateways") && <TableHead className="text-center">Gateways</TableHead>}
                  {showColumn("orderAmount") && <TableHead className="text-right">Order Amount</TableHead>}
                  {showColumn("mdrCharges") && <TableHead className="text-right">MDR/Fees</TableHead>}
                  {showColumn("erpCommission") && <TableHead className="text-right">ERP Comm</TableHead>}
                  {showColumn("refundAdj") && <TableHead className="text-right">Refund Adj.</TableHead>}
                  {showColumn("chargebackAdj") && <TableHead className="text-right">CB Adj.</TableHead>}
                  {showColumn("recoveries") && <TableHead className="text-right">Recoveries</TableHead>}
                  {showColumn("netSettlement") && <TableHead className="text-right">Net Settlement</TableHead>}
                  {showColumn("utr") && <TableHead>UTR</TableHead>}
                  {showColumn("status") && <TableHead className="text-center">Status</TableHead>}
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedSettlements.map((settlement) => {
                  const refundTotal = settlement.adjustments.refunds?.reduce((sum, r) => sum + r.amount, 0) || 0
                  const chargebackTotal = settlement.adjustments.chargebacks?.reduce((sum, c) => sum + c.amount, 0) || 0
                  const recoveryTotal = settlement.recoveries?.total || 0

                  return (
                    <React.Fragment key={settlement.id}>
                      <TableRow className="border-border">
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => toggleRow(settlement.id)}
                          >
                            {expandedRows.includes(settlement.id) ? (
                              <ChevronDown className="h-4 w-4" />
                            ) : (
                              <ChevronRight className="h-4 w-4" />
                            )}
                          </Button>
                        </TableCell>
                        {showColumn("institute") && (
                          <TableCell>
                            <div>
                              <p className="font-medium">{settlement.institute.name}</p>
                              <p className="text-xs text-muted-foreground">{settlement.institute.code}</p>
                            </div>
                          </TableCell>
                        )}
                        {showColumn("settlementId") && (
                          <TableCell>
                            <Link 
                              href={`/settlements/${settlement.id}/recon`}
                              className="font-mono text-sm text-primary hover:underline flex items-center gap-1"
                            >
                              {settlement.id}
                              <ExternalLink className="h-3 w-3 opacity-60" />
                            </Link>
                          </TableCell>
                        )}
                        {showColumn("settlementDate") && (
                          <TableCell className="text-sm">{settlement.settlementDate}</TableCell>
                        )}
                        {showColumn("settlementTime") && (
                          <TableCell>
                            {settlement.settlementTime ? (
                              <span className="text-sm flex items-center gap-1">
                                <Clock className="h-3 w-3 text-muted-foreground" />
                                {settlement.settlementTime}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                        )}
                        {showColumn("students") && (
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center gap-1">
                              <Users className="h-3.5 w-3.5 text-muted-foreground" />
                              <span className="font-medium">{settlement.totalStudents}</span>
                            </div>
                          </TableCell>
                        )}
                        {showColumn("gateways") && (
                          <TableCell className="text-center">
                            <Badge variant="secondary" className="font-mono">
                              {settlement.gatewayBreakdown.length} PGs
                            </Badge>
                          </TableCell>
                        )}
                        {showColumn("orderAmount") && (
                          <TableCell className="text-right font-medium">
                            ₹{settlement.orderAmount.toLocaleString()}
                          </TableCell>
                        )}
                        {showColumn("mdrCharges") && (
                          <TableCell className="text-right text-muted-foreground">
                            - ₹{settlement.transactionFees.toLocaleString()}
                          </TableCell>
                        )}
                        {showColumn("erpCommission") && (
                          <TableCell className="text-right">
                            <span className="text-emerald-500 flex items-center justify-end gap-1">
                              <TrendingUp className="h-3 w-3" />
                              ₹{settlement.erpCommission.toLocaleString()}
                            </span>
                          </TableCell>
                        )}
                        {showColumn("refundAdj") && (
                          <TableCell className="text-right">
                            {refundTotal > 0 ? (
                              <span className="text-amber-500 flex items-center justify-end gap-1">
                                <RotateCcw className="h-3 w-3" />- ₹{refundTotal.toLocaleString()}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">₹0</span>
                            )}
                          </TableCell>
                        )}
                        {showColumn("chargebackAdj") && (
                          <TableCell className="text-right">
                            {chargebackTotal > 0 ? (
                              <span className="text-red-500 flex items-center justify-end gap-1">
                                <ShieldAlert className="h-3 w-3" />- ₹{chargebackTotal.toLocaleString()}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">₹0</span>
                            )}
                          </TableCell>
                        )}
                        {showColumn("recoveries") && (
                          <TableCell className="text-right">
                            {recoveryTotal > 0 ? (
                              <span className="text-emerald-500 flex items-center justify-end gap-1">
                                <CheckCircle className="h-3 w-3" />+ ₹{recoveryTotal.toLocaleString()}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">₹0</span>
                            )}
                          </TableCell>
                        )}
                        {showColumn("netSettlement") && (
                          <TableCell className="text-right font-semibold text-primary">
                            ₹{settlement.netSettlement.toLocaleString()}
                          </TableCell>
                        )}
                        {showColumn("utr") && (
                          <TableCell>
                            {settlement.utr ? (
                              <span className="font-mono text-xs text-muted-foreground">{settlement.utr}</span>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                        )}
                        {showColumn("status") && (
                          <TableCell className="text-center">
                            <Badge variant="outline" className={statusColors[settlement.status]}>
                              {settlement.status}
                            </Badge>
                          </TableCell>
                        )}
                        <TableCell className="text-center">
                          <Link href={`/settlements/${settlement.id}/recon`}>
                            <Button variant="ghost" size="sm">
                              <FileText className="h-4 w-4 mr-1" />
                              Recon
                            </Button>
                          </Link>
                        </TableCell>
                      </TableRow>

                      {/* Expanded Gateway Breakdown */}
                      {expandedRows.includes(settlement.id) && (
                        <TableRow className="bg-secondary/30 border-border">
                          <TableCell colSpan={17} className="p-0">
                            <div className="p-4 space-y-4">
                              <div className="bg-card rounded-lg border border-border p-4">
                                <div className="flex items-center gap-2 text-sm font-medium mb-3">
                                  Settlement Calculation for {settlement.totalStudents} Students
                                </div>
                                <div className="flex items-center gap-2 text-sm flex-wrap">
                                  <span className="font-mono">₹{settlement.orderAmount.toLocaleString()}</span>
                                  <span className="text-muted-foreground">-</span>
                                  <span className="font-mono text-muted-foreground">
                                    ₹{settlement.transactionFees.toLocaleString()} (MDR/fees)
                                  </span>
                                  <span className="text-muted-foreground">-</span>
                                  <span className="font-mono text-emerald-500">
                                    ₹{settlement.erpCommission.toLocaleString()} (ERP Commission)
                                  </span>
                                  {refundTotal > 0 && (
                                    <>
                                      <span className="text-muted-foreground">-</span>
                                      <span className="font-mono text-amber-500">
                                        ₹{refundTotal.toLocaleString()} (refunds)
                                      </span>
                                    </>
                                  )}
                                  {chargebackTotal > 0 && (
                                    <>
                                      <span className="text-muted-foreground">-</span>
                                      <span className="font-mono text-red-500">
                                        ₹{chargebackTotal.toLocaleString()} (chargebacks)
                                      </span>
                                    </>
                                  )}
                                  {recoveryTotal > 0 && (
                                    <>
                                      <span className="text-muted-foreground">+</span>
                                      <span className="font-mono text-emerald-500">
                                        ₹{recoveryTotal.toLocaleString()} (CB won)
                                      </span>
                                    </>
                                  )}
                                  <span className="text-muted-foreground">=</span>
                                  <span className="font-semibold text-primary">
                                    ₹{settlement.netSettlement.toLocaleString()}
                                  </span>
                                </div>
                              </div>

                              {(settlement.adjustments.refunds?.length > 0 ||
                                settlement.adjustments.chargebacks?.length > 0 ||
                                settlement.recoveries?.chargebacksWon?.length > 0) && (
                                <div className="space-y-3">
                                  <div className="text-sm font-medium text-muted-foreground">
                                    Adjustments & Recoveries
                                  </div>
                                  <div className="grid gap-2">
                                    {/* Refund Adjustments */}
                                    {settlement.adjustments.refunds?.map((refund, idx) => (
                                      <div
                                        key={`refund-${idx}`}
                                        className="flex items-center justify-between bg-card rounded-lg border border-border p-3"
                                      >
                                        <div className="flex items-center gap-3">
                                          <div className="h-8 w-8 rounded-full bg-amber-500/10 flex items-center justify-center">
                                            <ArrowDownRight className="h-4 w-4 text-amber-500" />
                                          </div>
                                          <div>
                                            <p className="text-sm font-medium">Refund: {refund.studentName}</p>
                                            <p className="text-xs text-muted-foreground">
                                              {refund.refundId} | TXN: {refund.originalTxn} | {refund.reason}
                                            </p>
                                          </div>
                                        </div>
                                        <div className="text-right">
                                          <p className="font-semibold text-amber-500">
                                            - ₹{refund.amount.toLocaleString()}
                                          </p>
                                          <p className="text-xs text-muted-foreground">
                                            From: {refund.originalSettlement} ({refund.originalSettlementDate})
                                          </p>
                                        </div>
                                      </div>
                                    ))}

                                    {/* Chargeback Adjustments */}
                                    {settlement.adjustments.chargebacks?.map((cb, idx) => (
                                      <div
                                        key={`cb-${idx}`}
                                        className="flex items-center justify-between bg-card rounded-lg border border-red-500/20 p-3"
                                      >
                                        <div className="flex items-center gap-3">
                                          <div className="h-8 w-8 rounded-full bg-red-500/10 flex items-center justify-center">
                                            <ShieldAlert className="h-4 w-4 text-red-500" />
                                          </div>
                                          <div>
                                            <p className="text-sm font-medium">Chargeback: {cb.studentName}</p>
                                            <p className="text-xs text-muted-foreground">
                                              {cb.chargebackId} | {cb.reason} | Raised by {cb.raisedBy}
                                            </p>
                                          </div>
                                        </div>
                                        <div className="text-right">
                                          <p className="font-semibold text-red-500">- ₹{cb.amount.toLocaleString()}</p>
                                          <p className="text-xs text-muted-foreground">
                                            From: {cb.originalSettlement} ({cb.originalSettlementDate})
                                          </p>
                                          <Badge
                                            variant="outline"
                                            className="text-xs mt-1 bg-red-500/10 text-red-500 border-red-500/20"
                                          >
                                            {cb.status}
                                          </Badge>
                                        </div>
                                      </div>
                                    ))}

                                    {/* Chargeback Won Recoveries */}
                                    {settlement.recoveries?.chargebacksWon?.map((cbWon, idx) => (
                                      <div
                                        key={`cb-won-${idx}`}
                                        className="flex items-center justify-between bg-card rounded-lg border border-emerald-500/20 p-3"
                                      >
                                        <div className="flex items-center gap-3">
                                          <div className="h-8 w-8 rounded-full bg-emerald-500/10 flex items-center justify-center">
                                            <ArrowUpRight className="h-4 w-4 text-emerald-500" />
                                          </div>
                                          <div>
                                            <p className="text-sm font-medium">Chargeback Won: {cbWon.studentName}</p>
                                            <p className="text-xs text-muted-foreground">
                                              {cbWon.chargebackId} | {cbWon.reason}
                                            </p>
                                          </div>
                                        </div>
                                        <div className="text-right">
                                          <p className="font-semibold text-emerald-500">
                                            + ₹{cbWon.amount.toLocaleString()}
                                          </p>
                                          <p className="text-xs text-muted-foreground">
                                            Deducted: {cbWon.deductedFromSettlement} ({cbWon.deductedDate})
                                          </p>
                                          <p className="text-xs text-emerald-600">
                                            Won: {cbWon.wonDate} | Credited: {cbWon.creditedDate}
                                          </p>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {/* Gateway Distribution Header */}
                              <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                                Gateway-wise Breakdown
                              </div>

                              {/* Gateway Cards */}
                              <div className="grid gap-3">
                                {settlement.gatewayBreakdown.map((gw, idx) => {
                                  const gwKey = `${settlement.id}-${gw.gateway}`
                                  const isGwExpanded = expandedGateways.includes(gwKey)
                                  const totalGwAdjustments = (gw.refundAdjustments || 0) + (gw.chargebackAdjustments || 0)

                                  return (
                                    <div key={idx} className="bg-card rounded-lg border border-border p-4">
                                      <div className="space-y-3 flex-1">
                                        {/* Gateway Header */}
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-3">
                                            <span className="font-semibold">{gw.gateway}</span>
                                            <Badge variant="outline" className={statusColors[gw.status]}>
                                              {gw.status}
                                            </Badge>
                                            {gw.hasSplit && (
                                              <Badge variant="outline" className="bg-info/10 text-info border-info/20">
                                                <Split className="h-3 w-3 mr-1" />
                                                Split
                                              </Badge>
                                            )}
                                            {gw.utr && (
                                              <span className="text-xs font-mono text-muted-foreground">
                                                UTR: {gw.utr}
                                              </span>
                                            )}
                                          </div>
                                          {gw.students && gw.students.length > 0 && (
                                            <Button
                                              variant="ghost"
                                              size="sm"
                                              onClick={() => toggleGateway(settlement.id, gw.gateway)}
                                              className="gap-1"
                                            >
                                              <Users className="h-3.5 w-3.5" />
                                              {gw.students.length} Students
                                              {isGwExpanded ? (
                                                <ChevronDown className="h-3.5 w-3.5" />
                                              ) : (
                                                <ChevronRight className="h-3.5 w-3.5" />
                                              )}
                                            </Button>
                                          )}
                                        </div>

                                        {/* Gateway Stats */}
                                        <div className="grid grid-cols-7 gap-4 text-sm">
                                          <div>
                                            <p className="text-xs text-muted-foreground">Students</p>
                                            <p className="font-medium">{gw.students?.length || gw.transactions}</p>
                                          </div>
                                          <div>
                                            <p className="text-xs text-muted-foreground">Order Amount</p>
                                            <p className="font-medium">₹{gw.orderAmount.toLocaleString()}</p>
                                          </div>
                                          <div>
                                            <p className="text-xs text-muted-foreground">Fees</p>
                                            <p className="font-medium text-muted-foreground">
                                              - ₹{gw.fees.toLocaleString()}
                                            </p>
                                          </div>
                                          <div>
                                            <p className="text-xs text-muted-foreground">Refund Adj.</p>
                                            <p
                                              className={`font-medium ${(gw.refundAdjustments || 0) > 0 ? "text-amber-500" : "text-muted-foreground"}`}
                                            >
                                              {(gw.refundAdjustments || 0) > 0
                                                ? `- ₹${gw.refundAdjustments?.toLocaleString()}`
                                                : "₹0"}
                                            </p>
                                          </div>
                                          <div>
                                            <p className="text-xs text-muted-foreground">CB Adj.</p>
                                            <p
                                              className={`font-medium ${(gw.chargebackAdjustments || 0) > 0 ? "text-red-500" : "text-muted-foreground"}`}
                                            >
                                              {(gw.chargebackAdjustments || 0) > 0
                                                ? `- ₹${gw.chargebackAdjustments?.toLocaleString()}`
                                                : "₹0"}
                                            </p>
                                          </div>
                                          <div>
                                            <p className="text-xs text-muted-foreground">Recoveries</p>
                                            <p
                                              className={`font-medium ${(gw.recoveries || 0) > 0 ? "text-emerald-500" : "text-muted-foreground"}`}
                                            >
                                              {(gw.recoveries || 0) > 0 ? `+ ₹${gw.recoveries?.toLocaleString()}` : "₹0"}
                                            </p>
                                          </div>
                                          <div>
                                            <p className="text-xs text-muted-foreground">Net Amount</p>
                                            <p className="font-semibold text-primary">₹{gw.netAmount.toLocaleString()}</p>
                                          </div>
                                        </div>

                                        {isGwExpanded && gw.students && gw.students.length > 0 && (
                                          <div className="mt-3 pt-3 border-t border-border">
                                            <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                                              <Users className="h-3 w-3" />
                                              Students who paid via {gw.gateway}
                                            </p>
                                            <div className="bg-secondary/50 rounded-lg overflow-hidden">
                                              <table className="w-full text-sm">
                                                <thead>
                                                  <tr className="border-b border-border">
                                                    <th className="text-left p-2 text-xs text-muted-foreground font-medium">
                                                      Student
                                                    </th>
                                                    <th className="text-left p-2 text-xs text-muted-foreground font-medium">
                                                      Class
                                                    </th>
                                                    <th className="text-left p-2 text-xs text-muted-foreground font-medium">
                                                      Fee Type
                                                    </th>
                                                    <th className="text-left p-2 text-xs text-muted-foreground font-medium">
                                                      TXN ID
                                                    </th>
                                                    <th className="text-left p-2 text-xs text-muted-foreground font-medium">
                                                      Time
                                                    </th>
                                                    <th className="text-right p-2 text-xs text-muted-foreground font-medium">
                                                      Amount
                                                    </th>
                                                  </tr>
                                                </thead>
                                                <tbody>
                                                  {gw.students.map((student, sIdx) => (
                                                    <tr key={sIdx} className="border-b border-border last:border-0">
                                                      <td className="p-2">
                                                        <div>
                                                          <p className="font-medium">{student.name}</p>
                                                          <p className="text-xs text-muted-foreground">
                                                            {student.rollNo}
                                                          </p>
                                                        </div>
                                                      </td>
                                                      <td className="p-2">{student.class}</td>
                                                      <td className="p-2">{student.feeType}</td>
                                                      <td className="p-2 font-mono text-xs">{student.txnId}</td>
                                                      <td className="p-2 text-muted-foreground">{student.time}</td>
                                                      <td className="p-2 text-right font-medium">
                                                        ₹{student.amount.toLocaleString()}
                                                      </td>
                                                    </tr>
                                                  ))}
                                                </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        )}

                                        {/* Split Details if applicable */}
                                        {gw.hasSplit && gw.splitDetails && (
                                          <div className="mt-3 pt-3 border-t border-border">
                                            <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                                              <Split className="h-3 w-3" />
                                              Split Distribution
                                            </p>
                                            <div className="flex items-center gap-6 text-sm flex-wrap">
                                              <div>
                                                <span className="text-muted-foreground">Platform: </span>
                                                <span className="font-medium">
                                                  ₹{gw.splitDetails.platformShare.toLocaleString()}
                                                </span>
                                              </div>
                                              <div>
                                                <span className="text-muted-foreground">Vendor: </span>
                                                <span className="font-medium">
                                                  ₹{gw.splitDetails.vendorShare.toLocaleString()}
                                                </span>
                                              </div>
                                              {gw.splitDetails.beneficiaries.map((b, bIdx) => (
                                                <div key={bIdx}>
                                                  <span className="text-muted-foreground">{b.name}: </span>
                                                  <span className="font-medium">₹{b.share.toLocaleString()}</span>
                                                </div>
                                              ))}
                                            </div>
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  )
                                })}
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </React.Fragment>
                  )
                })}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between border-t border-border p-4">
            <p className="text-sm text-muted-foreground">
              Showing {startIndex + 1} to {Math.min(startIndex + rowsPerPage, filteredSettlements.length)} of {filteredSettlements.length} settlements
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(1)}
                disabled={currentPage === 1}
              >
                <ChevronsLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm px-2">
                Page {currentPage} of {totalPages || 1}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages || totalPages === 0}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages || totalPages === 0}
              >
                <ChevronsRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <SettlementDetailDrawer settlement={selectedSettlement} open={drawerOpen} onOpenChange={setDrawerOpen} />
    </>
  )
}
