"use client"

import { useState } from "react"
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Building2,
  Users,
  Calendar,
  IndianRupee,
  Download,
  Search,
  Split,
  AlertTriangle,
  CheckCircle,
  Wallet,
  ArrowRight,
  FileText,
} from "lucide-react"

interface SettlementDetailDrawerProps {
  settlement: {
    id: string
    settlementDate: string
    collectionDate: string
    institute: { id: string; name: string; code: string }
    totalStudents: number
    totalTransactions: number
    orderAmount: number
    transactionFees: number
    adjustments: {
      total: number
      refunds: Array<{
        refundId: string
        studentName: string
        originalTxn: string
        amount: number
        reason: string
      }>
    }
    netSettlement: number
    status: string
    utr: string | null
    gatewayBreakdown: Array<{
      gateway: string
      transactions: number
      studentCount?: number
      orderAmount: number
      fees: number
      adjustments?: number
      refundAdjustments?: number
      chargebackAdjustments?: number
      recoveries?: number
      netAmount: number
      utr: string | null
      status: string
      hasSplit: boolean
      splitDetails?: {
        platformShare: number
        vendorShare: number
        beneficiaries: Array<{ name: string; share: number }>
      }
      students?: Array<{
        id: string
        name: string
        class: string
        rollNo: string
        amount: number
        feeType: string
        txnId: string
        time: string
      }>
    }>
    students: Array<{
      id: string
      name: string
      class: string
      amount: number
      gateway: string
      txnId: string
      status: string
      hasSplit: boolean
    }>
  } | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

const statusColors: Record<string, string> = {
  settled: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  pending: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  processing: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  failed: "bg-red-500/10 text-red-500 border-red-500/20",
}

// Extended student data for the drawer
const extendedStudents = [
  {
    id: "STU001",
    name: "Aarav Kumar",
    class: "X-A",
    amount: 10000,
    gateway: "Razorpay",
    txnId: "TXN-9001",
    status: "settled",
    hasSplit: true,
    feeType: "Tuition Fee",
    splitTo: "Transport Vendor - ₹1,000",
  },
  {
    id: "STU002",
    name: "Ananya Singh",
    class: "IX-B",
    amount: 10000,
    gateway: "Cashfree",
    txnId: "TXN-9002",
    status: "settled",
    hasSplit: false,
    feeType: "Tuition Fee",
    splitTo: null,
  },
  {
    id: "STU003",
    name: "Vihaan Reddy",
    class: "XI-C",
    amount: 10000,
    gateway: "Razorpay",
    txnId: "TXN-9003",
    status: "settled",
    hasSplit: true,
    feeType: "Annual Fee",
    splitTo: "Canteen Services - ₹500",
  },
  {
    id: "STU004",
    name: "Diya Sharma",
    class: "X-A",
    amount: 10000,
    gateway: "Paytm",
    txnId: "TXN-9004",
    status: "settled",
    hasSplit: false,
    feeType: "Tuition Fee",
    splitTo: null,
  },
  {
    id: "STU005",
    name: "Arjun Patel",
    class: "XII-B",
    amount: 10000,
    gateway: "Razorpay",
    txnId: "TXN-9005",
    status: "settled",
    hasSplit: true,
    feeType: "Exam Fee",
    splitTo: "Sports Academy - ₹2,000",
  },
  {
    id: "STU006",
    name: "Ishita Gupta",
    class: "IX-A",
    amount: 10000,
    gateway: "Cashfree",
    txnId: "TXN-9006",
    status: "settled",
    hasSplit: false,
    feeType: "Tuition Fee",
    splitTo: null,
  },
  {
    id: "STU007",
    name: "Rohan Mehta",
    class: "XI-A",
    amount: 10000,
    gateway: "Paytm",
    txnId: "TXN-9007",
    status: "settled",
    hasSplit: true,
    feeType: "Lab Fee",
    splitTo: "Lab Equipment - ₹3,000",
  },
  {
    id: "STU008",
    name: "Priya Verma",
    class: "X-C",
    amount: 10000,
    gateway: "Razorpay",
    txnId: "TXN-9008",
    status: "settled",
    hasSplit: false,
    feeType: "Tuition Fee",
    splitTo: null,
  },
  {
    id: "STU009",
    name: "Kabir Singh",
    class: "XII-A",
    amount: 10000,
    gateway: "Cashfree",
    txnId: "TXN-9009",
    status: "settled",
    hasSplit: false,
    feeType: "Tuition Fee",
    splitTo: null,
  },
  {
    id: "STU010",
    name: "Anika Das",
    class: "IX-C",
    amount: 10000,
    gateway: "Razorpay",
    txnId: "TXN-9010",
    status: "settled",
    hasSplit: true,
    feeType: "Activity Fee",
    splitTo: "Transport Vendor - ₹1,500",
  },
]

export function SettlementDetailDrawer({ settlement, open, onOpenChange }: SettlementDetailDrawerProps) {
  const [studentSearch, setStudentSearch] = useState("")
  const [gatewayFilter, setGatewayFilter] = useState("all")

  if (!settlement) return null

  const filteredStudents = extendedStudents.filter((s) => {
    if (studentSearch && !s.name.toLowerCase().includes(studentSearch.toLowerCase())) {
      return false
    }
    if (gatewayFilter !== "all" && s.gateway !== gatewayFilter) {
      return false
    }
    return true
  })

const gatewayStudentCounts = settlement.gatewayBreakdown.reduce(
    (acc, gw) => {
      acc[gw.gateway] = gw.studentCount || gw.students?.length || 0
      return acc
    },
    {} as Record<string, number>,
  )

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-3xl overflow-y-auto bg-background">
        <SheetHeader className="space-y-1">
          <div className="flex items-center justify-between">
            <SheetTitle className="text-xl font-bold flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Settlement Details
            </SheetTitle>
            <Badge variant="outline" className={statusColors[settlement.status]}>
              {settlement.status}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">{settlement.id}</p>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Institute Info */}
          <Card className="bg-secondary/30 border-border">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-lg">{settlement.institute.name}</p>
                  <p className="text-sm text-muted-foreground">{settlement.institute.code}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    Collection: {settlement.collectionDate}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                    <CheckCircle className="h-4 w-4" />
                    Settlement: {settlement.settlementDate}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Summary Stats */}
          <div className="grid grid-cols-4 gap-4">
            <Card className="bg-card border-border">
              <CardContent className="p-4 text-center">
                <Users className="h-5 w-5 mx-auto text-muted-foreground mb-1" />
                <p className="text-2xl font-bold">{settlement.totalStudents}</p>
                <p className="text-xs text-muted-foreground">Students</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4 text-center">
                <Wallet className="h-5 w-5 mx-auto text-muted-foreground mb-1" />
                <p className="text-2xl font-bold">{settlement.gatewayBreakdown.length}</p>
                <p className="text-xs text-muted-foreground">Gateways</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-border">
              <CardContent className="p-4 text-center">
                <IndianRupee className="h-5 w-5 mx-auto text-muted-foreground mb-1" />
                <p className="text-2xl font-bold">₹{(settlement.orderAmount / 100000).toFixed(2)}L</p>
                <p className="text-xs text-muted-foreground">Order Amount</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-border bg-primary/5">
              <CardContent className="p-4 text-center">
                <CheckCircle className="h-5 w-5 mx-auto text-primary mb-1" />
                <p className="text-2xl font-bold text-primary">₹{(settlement.netSettlement / 100000).toFixed(2)}L</p>
                <p className="text-xs text-muted-foreground">Net Settlement</p>
              </CardContent>
            </Card>
          </div>

          {/* Settlement Calculation */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Settlement Calculation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between py-2">
                <span className="text-muted-foreground">Gross Order Amount</span>
                <span className="font-semibold">₹{settlement.orderAmount.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between py-2 border-t border-border">
                <span className="text-muted-foreground">Transaction Fees (2%)</span>
                <span className="font-semibold text-muted-foreground">
                  - ₹{settlement.transactionFees.toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-t border-border">
                <span className="text-muted-foreground flex items-center gap-1">
                  <AlertTriangle className="h-3.5 w-3.5 text-warning" />
                  Refund Adjustments
                </span>
                <span
                  className={`font-semibold ${(settlement.adjustments?.total || 0) > 0 ? "text-warning" : "text-muted-foreground"}`}
                >
                  - ₹{(settlement.adjustments?.total || 0).toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between py-3 border-t-2 border-primary/20 mt-2 bg-primary/5 -mx-6 px-6">
                <span className="font-semibold">Net Settlement to Institute</span>
                <span className="font-bold text-xl text-primary">₹{settlement.netSettlement.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>

          {/* Tabs for Details */}
          <Tabs defaultValue="gateways" className="space-y-4">
            <TabsList className="bg-secondary w-full grid grid-cols-4">
              <TabsTrigger value="gateways">Gateways</TabsTrigger>
              <TabsTrigger value="students">Students</TabsTrigger>
              <TabsTrigger value="adjustments">Adjustments</TabsTrigger>
              <TabsTrigger value="splits">Split Payments</TabsTrigger>
            </TabsList>

            {/* Gateways Tab */}
            <TabsContent value="gateways" className="space-y-4">
              {settlement.gatewayBreakdown.map((gw, idx) => (
                <Card key={idx} className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <span className="font-semibold text-lg">{gw.gateway}</span>
                        <Badge variant="outline" className={statusColors[gw.status]}>
                          {gw.status}
                        </Badge>
                        {gw.hasSplit && (
                          <Badge variant="outline" className="bg-info/10 text-info border-info/20">
                            <Split className="h-3 w-3 mr-1" />
                            Split
                          </Badge>
                        )}
                      </div>
                      {gw.utr && (
                        <span className="text-xs font-mono bg-secondary px-2 py-1 rounded">UTR: {gw.utr}</span>
                      )}
                    </div>

                    <div className="grid grid-cols-5 gap-4 text-sm">
                      <div>
                        <p className="text-xs text-muted-foreground">Students</p>
                        <p className="font-semibold">{gw.studentCount || 0}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Order Amount</p>
                        <p className="font-semibold">₹{(gw.orderAmount || 0).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Fees</p>
                        <p className="font-semibold text-muted-foreground">₹{(gw.fees || 0).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Adjustments</p>
                        <p className={`font-semibold ${(gw.adjustments || 0) > 0 ? "text-warning" : "text-muted-foreground"}`}>
                          ₹{(gw.adjustments || 0).toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Net Amount</p>
                        <p className="font-bold text-primary">₹{(gw.netAmount || 0).toLocaleString()}</p>
                      </div>
                    </div>

                    {gw.hasSplit && gw.splitDetails && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <p className="text-xs text-muted-foreground mb-2">Split Distribution</p>
                        <div className="flex flex-wrap gap-3">
                          <Badge variant="secondary">Platform: ₹{gw.splitDetails.platformShare.toLocaleString()}</Badge>
                          {gw.splitDetails.beneficiaries.map((b, i) => (
                            <Badge key={i} variant="outline">
                              {b.name}: ₹{b.share.toLocaleString()}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            {/* Students Tab */}
            <TabsContent value="students" className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search students..."
                    value={studentSearch}
                    onChange={(e) => setStudentSearch(e.target.value)}
                    className="pl-9 bg-secondary"
                  />
                </div>
                <Select value={gatewayFilter} onValueChange={setGatewayFilter}>
                  <SelectTrigger className="w-40 bg-secondary">
                    <SelectValue placeholder="All Gateways" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Gateways</SelectItem>
                    {settlement.gatewayBreakdown.map((gw) => (
                      <SelectItem key={gw.gateway} value={gw.gateway}>
                        {gw.gateway} ({gw.studentCount || 0})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Card className="bg-card border-border">
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead>Student</TableHead>
                      <TableHead>Class</TableHead>
                      <TableHead>Fee Type</TableHead>
                      <TableHead>Gateway</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead>Split</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.map((student) => (
                      <TableRow key={student.id} className="border-border">
                        <TableCell>
                          <div>
                            <p className="font-medium">{student.name}</p>
                            <p className="text-xs text-muted-foreground font-mono">{student.txnId}</p>
                          </div>
                        </TableCell>
                        <TableCell>{student.class}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            {student.feeType}
                          </Badge>
                        </TableCell>
                        <TableCell>{student.gateway}</TableCell>
                        <TableCell className="text-right font-medium">₹{student.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          {student.hasSplit ? (
                            <span className="text-xs text-info">{student.splitTo}</span>
                          ) : (
                            <span className="text-xs text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={statusColors[student.status]}>
                            {student.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>

            {/* Adjustments Tab */}
            <TabsContent value="adjustments" className="space-y-4">
              {(settlement.adjustments?.total || 0) > 0 ? (
                <>
                  <div className="bg-warning/5 border border-warning/20 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-5 w-5 text-warning" />
                      <span className="font-semibold text-warning">
                        Total Adjustments: ₹{(settlement.adjustments?.total || 0).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      These refunds from previous transactions have been deducted from this settlement. Order amount
                      refunds are adjusted from future settlements.
                    </p>
                  </div>

                  <Card className="bg-card border-border">
                    <Table>
                      <TableHeader>
                        <TableRow className="border-border">
                          <TableHead>Refund ID</TableHead>
                          <TableHead>Student</TableHead>
                          <TableHead>Original Transaction</TableHead>
                          <TableHead>Reason</TableHead>
                          <TableHead className="text-right">Amount</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(settlement.adjustments?.refunds || []).map((refund, idx) => (
                          <TableRow key={idx} className="border-border">
                            <TableCell className="font-mono text-sm">{refund.refundId}</TableCell>
                            <TableCell className="font-medium">{refund.studentName}</TableCell>
                            <TableCell className="font-mono text-sm text-muted-foreground">
                              {refund.originalTxn}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">{refund.reason}</Badge>
                            </TableCell>
                            <TableCell className="text-right font-semibold text-warning">
                              - ₹{(refund.amount || 0).toLocaleString()}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </Card>
                </>
              ) : (
                <div className="text-center py-12">
                  <CheckCircle className="h-12 w-12 mx-auto text-emerald-500 mb-4" />
                  <p className="font-semibold">No Adjustments</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    There are no refund adjustments for this settlement.
                  </p>
                </div>
              )}
            </TabsContent>

            {/* Split Payments Tab */}
            <TabsContent value="splits" className="space-y-4">
              {settlement.gatewayBreakdown.some((gw) => gw.hasSplit) ? (
                <>
                  <div className="bg-info/5 border border-info/20 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Split className="h-5 w-5 text-info" />
                      <span className="font-semibold text-info">Split Payment Distribution</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Payments are split between the platform and various vendor beneficiaries as per configuration.
                    </p>
                  </div>

                  {settlement.gatewayBreakdown
                    .filter((gw) => gw.hasSplit && gw.splitDetails)
                    .map((gw, idx) => (
                      <Card key={idx} className="bg-card border-border">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm font-semibold flex items-center gap-2">
                            {gw.gateway}
                            <Badge variant="secondary" className="text-xs">
                              {gw.students} students
                            </Badge>
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex items-center gap-4">
                            <div className="flex-1 bg-secondary rounded-lg p-3 text-center">
                              <p className="text-xs text-muted-foreground">Total Split Amount</p>
                              <p className="text-lg font-bold">₹{gw.netAmount.toLocaleString()}</p>
                            </div>
                            <ArrowRight className="h-5 w-5 text-muted-foreground" />
                            <div className="flex-1 bg-primary/10 rounded-lg p-3 text-center">
                              <p className="text-xs text-muted-foreground">Platform Share</p>
                              <p className="text-lg font-bold text-primary">
                                ₹{gw.splitDetails!.platformShare.toLocaleString()}
                              </p>
                            </div>
                            <ArrowRight className="h-5 w-5 text-muted-foreground" />
                            <div className="flex-1 bg-emerald-500/10 rounded-lg p-3 text-center">
                              <p className="text-xs text-muted-foreground">Vendor Share</p>
                              <p className="text-lg font-bold text-emerald-500">
                                ₹{gw.splitDetails!.vendorShare.toLocaleString()}
                              </p>
                            </div>
                          </div>

                          <div className="border-t border-border pt-4">
                            <p className="text-xs text-muted-foreground mb-3">Beneficiary Breakdown</p>
                            <div className="space-y-2">
                              {gw.splitDetails!.beneficiaries.map((b, i) => (
                                <div
                                  key={i}
                                  className="flex items-center justify-between bg-secondary/50 rounded-lg p-3"
                                >
                                  <span className="font-medium">{b.name}</span>
                                  <span className="font-semibold">₹{b.share.toLocaleString()}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                </>
              ) : (
                <div className="text-center py-12">
                  <Split className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="font-semibold">No Split Payments</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    There are no split payment transactions in this settlement.
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>

          {/* Export Button */}
          <div className="flex justify-end gap-2 pt-4 border-t border-border">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export Settlement Report
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
