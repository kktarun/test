"use client"

import { useState } from "react"
import { SettlementDashboard } from "./settlement-dashboard"
import { SettlementFilters } from "./settlement-filters"
import { SettlementsList } from "./settlements-list"
import { BankHolidayCalendar } from "./bank-holiday-calendar"
import { SettlementExportModal } from "./settlement-export-modal"
import { Button } from "@/components/ui/button"
import { Calendar, Download, RefreshCw, CalendarDays, Info, Split } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SplitSettlementsTab } from "./split-settlements-tab"
import { SettlementCustomColumnsManager, type SettlementCustomColumnConfig } from "./settlement-custom-columns"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"

// FY 2024-25 Bank Holidays
const fyHolidays = [
  { date: "2024-04-11", name: "Idul Fitr", day: "Thursday" },
  { date: "2024-04-14", name: "Dr. Ambedkar Jayanti", day: "Sunday" },
  { date: "2024-04-17", name: "Ram Navami", day: "Wednesday" },
  { date: "2024-04-21", name: "Mahavir Jayanti", day: "Sunday" },
  { date: "2024-05-01", name: "May Day", day: "Wednesday" },
  { date: "2024-05-23", name: "Buddha Purnima", day: "Thursday" },
  { date: "2024-06-17", name: "Eid ul-Adha", day: "Monday" },
  { date: "2024-07-17", name: "Muharram", day: "Wednesday" },
  { date: "2024-08-15", name: "Independence Day", day: "Thursday" },
  { date: "2024-08-26", name: "Janmashtami", day: "Monday" },
  { date: "2024-09-16", name: "Milad un-Nabi", day: "Monday" },
  { date: "2024-10-02", name: "Gandhi Jayanti", day: "Wednesday" },
  { date: "2024-10-12", name: "Dussehra", day: "Saturday" },
  { date: "2024-10-31", name: "Diwali (Lakshmi Puja)", day: "Thursday" },
  { date: "2024-11-01", name: "Diwali (Govardhan Puja)", day: "Friday" },
  { date: "2024-11-15", name: "Guru Nanak Jayanti", day: "Friday" },
  { date: "2024-12-25", name: "Christmas", day: "Wednesday" },
  { date: "2025-01-26", name: "Republic Day", day: "Sunday" },
  { date: "2025-02-26", name: "Maha Shivaratri", day: "Wednesday" },
  { date: "2025-03-14", name: "Holi", day: "Friday" },
  { date: "2025-03-31", name: "Id-ul-Fitr", day: "Monday" },
]

export function SettlementsContent() {
  const [selectedGateway, setSelectedGateway] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedInstitute, setSelectedInstitute] = useState("all")
  const [dateRange, setDateRange] = useState("30d")
  const [searchQuery, setSearchQuery] = useState("")
  const [visibleColumns, setVisibleColumns] = useState<string[]>([
    "institute", "settlementId", "settlementDate", "settlementTime", "students", "gateways",
    "orderAmount", "mdrCharges", "erpCommission", "refundAdj", "netSettlement", "status"
  ])
  const [showHolidayCalendar, setShowHolidayCalendar] = useState(false)
  const [showExportModal, setShowExportModal] = useState(false)
  const [showFYHolidays, setShowFYHolidays] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const [showCustomColumnsManager, setShowCustomColumnsManager] = useState(false)
  const [customColumns, setCustomColumns] = useState<SettlementCustomColumnConfig[]>([
    {
      id: "custom-1",
      name: "invoice_number",
      apiField: "customFields.invoiceNumber",
      displayName: "Invoice No.",
      type: "text",
      visible: true,
      sortable: true,
      order: 0,
    },
    {
      id: "custom-2",
      name: "accounting_period",
      apiField: "customFields.accountingPeriod",
      displayName: "Accounting Period",
      type: "text",
      visible: true,
      sortable: true,
      order: 1,
    },
  ])

  // Get upcoming holidays (next 3)
  const today = new Date()
  const upcomingHolidays = fyHolidays
    .filter(h => new Date(h.date) > today)
    .slice(0, 3)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Settlements</h1>
          <p className="text-muted-foreground">
            Partner-level T+1 settlement orchestration across 100+ institutes and multiple gateways
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-2 bg-transparent"
            onClick={() => setShowFYHolidays(!showFYHolidays)}
          >
            <CalendarDays className="h-4 w-4" />
            FY Holidays
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="gap-2 bg-transparent"
            onClick={() => setShowHolidayCalendar(true)}
          >
            <Calendar className="h-4 w-4" />
            Bank Holidays
          </Button>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <RefreshCw className="h-4 w-4" />
            Sync
          </Button>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent" onClick={() => setShowExportModal(true)}>
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      {/* FY Holidays Panel */}
      {showFYHolidays && (
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2">
                <CalendarDays className="h-4 w-4 text-primary" />
                Financial Year 2024-25 Settlement Holidays
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setShowFYHolidays(false)}>
                Hide
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
              {fyHolidays.map((holiday, index) => {
                const isPast = new Date(holiday.date) < today
                return (
                  <div 
                    key={index}
                    className={`p-2 rounded-lg border text-center ${
                      isPast 
                        ? "bg-secondary/30 border-border/50 opacity-60" 
                        : "bg-destructive/5 border-destructive/20"
                    }`}
                  >
                    <p className="text-xs text-muted-foreground">{holiday.day}</p>
                    <p className="text-sm font-medium">{new Date(holiday.date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{holiday.name}</p>
                    {isPast && <Badge variant="outline" className="text-[8px] mt-1">Past</Badge>}
                  </div>
                )
              })}
            </div>
            <div className="mt-4 flex items-center gap-4 text-xs text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded bg-destructive/5 border border-destructive/20" />
                <span>Upcoming Holiday</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded bg-secondary/30 border border-border/50 opacity-60" />
                <span>Past Holiday</span>
              </div>
              <Tooltip>
                <TooltipTrigger>
                  <Info className="h-3.5 w-3.5" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Settlements are not processed on these bank holidays.</p>
                  <p>T+1 becomes T+2 or more around holidays.</p>
                </TooltipContent>
              </Tooltip>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upcoming Holidays Quick View */}
      {upcomingHolidays.length > 0 && !showFYHolidays && (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-warning/5 border border-warning/20">
          <CalendarDays className="h-5 w-5 text-warning" />
          <span className="text-sm text-muted-foreground">Upcoming Settlement Holidays:</span>
          {upcomingHolidays.map((h, i) => (
            <Badge key={i} variant="outline" className="bg-warning/10 text-warning border-warning/20">
              {new Date(h.date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })} - {h.name}
            </Badge>
          ))}
          <Button variant="ghost" size="sm" className="ml-auto text-xs" onClick={() => setShowFYHolidays(true)}>
            View All
          </Button>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-secondary/50">
          <TabsTrigger value="all" className="gap-2">
            All Settlements
          </TabsTrigger>
          <TabsTrigger value="split" className="gap-2">
            <Split className="h-4 w-4" />
            Split Payments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          {/* Settlement Dashboard - Partner Level Overview */}
          <SettlementDashboard />

          <div className="space-y-4">
            <SettlementFilters
              selectedGateway={selectedGateway}
              setSelectedGateway={setSelectedGateway}
              selectedStatus={selectedStatus}
              setSelectedStatus={setSelectedStatus}
              dateRange={dateRange}
              setDateRange={setDateRange}
              selectedInstitute={selectedInstitute}
              setSelectedInstitute={setSelectedInstitute}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              onOpenCustomColumns={() => setShowCustomColumnsManager(true)}
            />

        {/* Settlements List - Institute wise with drill down (includes split settlements) */}
        <SettlementsList 
          gateway={selectedGateway} 
          status={selectedStatus} 
          dateRange={dateRange}
          institute={selectedInstitute}
          searchQuery={searchQuery}
          visibleColumns={visibleColumns}
            />
          </div>
        </TabsContent>

        <TabsContent value="split" className="space-y-6">
          <SplitSettlementsTab />
        </TabsContent>
      </Tabs>

      <BankHolidayCalendar open={showHolidayCalendar} onOpenChange={setShowHolidayCalendar} />
      <SettlementExportModal open={showExportModal} onOpenChange={setShowExportModal} />
      <SettlementCustomColumnsManager
        open={showCustomColumnsManager}
        onClose={() => setShowCustomColumnsManager(false)}
        customColumns={customColumns}
        onColumnsChange={setCustomColumns}
      />
    </div>
  )
}
