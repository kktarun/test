"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Wallet, Clock, CheckCircle2, AlertCircle, TrendingDown, ArrowRight, Minus, Building2 } from "lucide-react"

const stats = [
  {
    name: "Total Settled",
    value: "₹11.8 Cr",
    subValue: "1,847 settlements",
    icon: Wallet,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    name: "Pending Settlement",
    value: "₹62.4 L",
    subValue: "Expected by tomorrow",
    icon: Clock,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    name: "Settled Today",
    value: "₹48.2 L",
    subValue: "12 settlements",
    icon: CheckCircle2,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    name: "Delayed",
    value: "₹8.5 L",
    subValue: "3 settlements",
    icon: AlertCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
]

const adjustmentStats = {
  totalAdjustments: 1245000, // ₹12.45 L
  pendingAdjustments: 285000, // ₹2.85 L
  adjustedThisMonth: 18,
  upcomingDeductions: 3,
}

const gatewayBreakdown = [
  { gateway: "Razorpay", settled: 48500000, pending: 3200000, adjustments: 450000, color: "bg-blue-500" },
  { gateway: "Cashfree", settled: 32400000, pending: 1800000, adjustments: 320000, color: "bg-purple-500" },
  { gateway: "Paytm", settled: 22100000, pending: 950000, adjustments: 280000, color: "bg-cyan-500" },
  { gateway: "Easebuzz", settled: 15000000, pending: 290000, adjustments: 195000, color: "bg-orange-500" },
]

export function SettlementStats() {
  const totalGross = gatewayBreakdown.reduce((sum, g) => sum + g.settled + g.pending, 0)
  const totalAdjustments = gatewayBreakdown.reduce((sum, g) => sum + g.adjustments, 0)

  return (
    <div className="space-y-6">
      {/* Primary Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.name} className="bg-card border-border">
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.name}</p>
                <p className={`text-xs ${stat.color}`}>{stat.subValue}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Adjustment Summary Card */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <TrendingDown className="h-5 w-5 text-destructive" />
              Refund Adjustments Overview
            </CardTitle>
            <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
              {adjustmentStats.upcomingDeductions} Upcoming Deductions
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Total Adjusted (All Time)</p>
              <p className="text-2xl font-bold text-destructive">
                ₹{(adjustmentStats.totalAdjustments / 100000).toFixed(2)} L
              </p>
              <p className="text-xs text-muted-foreground">Deducted from settlements</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Pending Adjustments</p>
              <p className="text-2xl font-bold text-warning">
                ₹{(adjustmentStats.pendingAdjustments / 100000).toFixed(2)} L
              </p>
              <p className="text-xs text-muted-foreground">To be deducted in next cycle</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Adjusted This Month</p>
              <p className="text-2xl font-bold text-foreground">{adjustmentStats.adjustedThisMonth}</p>
              <p className="text-xs text-muted-foreground">Refund adjustments</p>
            </div>
            <div className="rounded-lg bg-secondary/50 p-3 border border-border">
              <p className="text-xs text-muted-foreground mb-2">How Adjustments Work</p>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-foreground">Refund Amount</span>
                <ArrowRight className="h-3 w-3 text-muted-foreground" />
                <span className="text-destructive">Deducted from Next Settlement</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Gateway-wise Breakdown */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Building2 className="h-5 w-5 text-primary" />
            Gateway-wise Settlement Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Gateway</th>
                  <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Gross Settled</th>
                  <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Pending</th>
                  <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Adjustments</th>
                  <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Net Settled</th>
                  <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">Share</th>
                </tr>
              </thead>
              <tbody>
                {gatewayBreakdown.map((gateway) => {
                  const netSettled = gateway.settled - gateway.adjustments
                  const sharePercent = ((gateway.settled / totalGross) * 100).toFixed(1)
                  return (
                    <tr key={gateway.gateway} className="border-b border-border hover:bg-secondary/30">
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <div className={`h-3 w-3 rounded-full ${gateway.color}`} />
                          <span className="font-medium">{gateway.gateway}</span>
                        </div>
                      </td>
                      <td className="p-3 text-right font-medium">₹{(gateway.settled / 10000000).toFixed(2)} Cr</td>
                      <td className="p-3 text-right text-warning">₹{(gateway.pending / 100000).toFixed(2)} L</td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 text-destructive">
                          <Minus className="h-3 w-3" />₹{(gateway.adjustments / 100000).toFixed(2)} L
                        </div>
                      </td>
                      <td className="p-3 text-right font-semibold text-success">
                        ₹{(netSettled / 10000000).toFixed(2)} Cr
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <div className="w-16 h-2 rounded-full bg-secondary overflow-hidden">
                            <div className={`h-full ${gateway.color}`} style={{ width: `${sharePercent}%` }} />
                          </div>
                          <span className="text-xs text-muted-foreground w-10">{sharePercent}%</span>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
              <tfoot>
                <tr className="bg-secondary/30">
                  <td className="p-3 font-semibold">Total</td>
                  <td className="p-3 text-right font-semibold">
                    ₹{(gatewayBreakdown.reduce((s, g) => s + g.settled, 0) / 10000000).toFixed(2)} Cr
                  </td>
                  <td className="p-3 text-right font-semibold text-warning">
                    ₹{(gatewayBreakdown.reduce((s, g) => s + g.pending, 0) / 100000).toFixed(2)} L
                  </td>
                  <td className="p-3 text-right font-semibold text-destructive">
                    -₹{(totalAdjustments / 100000).toFixed(2)} L
                  </td>
                  <td className="p-3 text-right font-semibold text-success">
                    ₹{((gatewayBreakdown.reduce((s, g) => s + g.settled, 0) - totalAdjustments) / 10000000).toFixed(2)}{" "}
                    Cr
                  </td>
                  <td className="p-3 text-right font-semibold">100%</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
