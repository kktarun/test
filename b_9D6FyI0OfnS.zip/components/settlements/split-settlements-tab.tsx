"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  Search,
  Split,
  Building2,
  CheckCircle2,
  Clock,
  AlertCircle,
  Wallet,
  Users,
  IndianRupee,
  ChevronRight,
  FileText,
  TrendingUp,
  Filter,
  Copy,
  ExternalLink,
  CreditCard,
  Banknote,
} from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Split settlement data structure - simplified with account numbers, settlement IDs, students
const splitSettlementsData = [
  {
    id: "SPLIT-SET-001",
    parentTransactionId: "TXN-2025-001234",
    parentSettlementId: "SETTLE-001",
    collectionDate: "2025-01-09",
    settlementDate: "2025-01-10",
    institute: {
      name: "Delhi Public School, R.K. Puram",
      code: "DPS-RKP",
    },
    student: {
      name: "Rahul Sharma",
      id: "STU-001",
      class: "Class 10-A",
      phone: "+91 98765 43210",
    },
    totalOrderAmount: 150000,
    totalSettlementAmount: 150000,
    gateway: "Razorpay",
    splits: [
      {
        id: "SPL-001-A",
        settlementId: "SETTLE-001-A",
        beneficiary: "Delhi Public School, R.K. Puram",
        beneficiaryType: "Institute",
        accountNumber: "50100123456789",
        accountLast4: "6789",
        ifsc: "HDFC0001234",
        bank: "HDFC Bank",
        splitPercentage: 70,
        orderAmount: 105000,
        settlementAmount: 105000,
        status: "settled",
        settlementDate: "2025-01-10",
        utr: "HDFC0123456789",
        students: [
          { name: "Rahul Sharma", id: "STU-001", class: "Class 10-A", amount: 105000 },
        ],
      },
      {
        id: "SPL-001-B",
        settlementId: "SETTLE-001-B",
        beneficiary: "Education Trust Fund",
        beneficiaryType: "Trust",
        accountNumber: "91234567890123",
        accountLast4: "0123",
        ifsc: "ICIC0005678",
        bank: "ICICI Bank",
        splitPercentage: 20,
        orderAmount: 30000,
        settlementAmount: 30000,
        status: "settled",
        settlementDate: "2025-01-10",
        utr: "ICIC9876543210",
        students: [
          { name: "Rahul Sharma", id: "STU-001", class: "Class 10-A", amount: 30000 },
        ],
      },
      {
        id: "SPL-001-C",
        settlementId: "SETTLE-001-C",
        beneficiary: "Sports Academy",
        beneficiaryType: "Vendor",
        accountNumber: "33456789012345",
        accountLast4: "2345",
        ifsc: "SBIN0009012",
        bank: "SBI",
        splitPercentage: 10,
        orderAmount: 15000,
        settlementAmount: 15000,
        status: "pending",
        expectedSettlementDate: "2025-01-11",
        utr: null,
        students: [
          { name: "Rahul Sharma", id: "STU-001", class: "Class 10-A", amount: 15000 },
        ],
      },
    ],
  },
  {
    id: "SPLIT-SET-002",
    parentTransactionId: "TXN-2025-001235",
    parentSettlementId: "SETTLE-002",
    collectionDate: "2025-01-09",
    settlementDate: "2025-01-10",
    institute: {
      name: "St. Mary's Convent School",
      code: "SMCS-DEL",
    },
    student: {
      name: "Priya Patel",
      id: "STU-002",
      class: "Class 12-B",
      phone: "+91 87654 32109",
    },
    totalOrderAmount: 200000,
    totalSettlementAmount: 200000,
    gateway: "Cashfree",
    splits: [
      {
        id: "SPL-002-A",
        settlementId: "SETTLE-002-A",
        beneficiary: "St. Mary's Convent School",
        beneficiaryType: "Institute",
        accountNumber: "44567890123456",
        accountLast4: "3456",
        ifsc: "AXIS0003456",
        bank: "Axis Bank",
        splitPercentage: 80,
        orderAmount: 160000,
        settlementAmount: 160000,
        status: "settled",
        settlementDate: "2025-01-10",
        utr: "AXIS1122334455",
        students: [
          { name: "Priya Patel", id: "STU-002", class: "Class 12-B", amount: 160000 },
        ],
      },
      {
        id: "SPL-002-B",
        settlementId: "SETTLE-002-B",
        beneficiary: "Transport Services Ltd",
        beneficiaryType: "Vendor",
        accountNumber: "55678901234567",
        accountLast4: "4567",
        ifsc: "PUNB0007890",
        bank: "PNB",
        splitPercentage: 15,
        orderAmount: 30000,
        settlementAmount: 30000,
        status: "settled",
        settlementDate: "2025-01-10",
        utr: "PUNB5566778899",
        students: [
          { name: "Priya Patel", id: "STU-002", class: "Class 12-B", amount: 30000 },
        ],
      },
      {
        id: "SPL-002-C",
        settlementId: "SETTLE-002-C",
        beneficiary: "Canteen Vendor",
        beneficiaryType: "Vendor",
        accountNumber: "66789012345678",
        accountLast4: "5678",
        ifsc: "BARB0002345",
        bank: "Bank of Baroda",
        splitPercentage: 5,
        orderAmount: 10000,
        settlementAmount: 10000,
        status: "failed",
        failureReason: "Invalid account number",
        utr: null,
        students: [
          { name: "Priya Patel", id: "STU-002", class: "Class 12-B", amount: 10000 },
        ],
      },
    ],
  },
  {
    id: "SPLIT-SET-003",
    parentTransactionId: "TXN-2025-001236",
    parentSettlementId: "SETTLE-003",
    collectionDate: "2025-01-09",
    settlementDate: "2025-01-10",
    institute: {
      name: "Modern Public School",
      code: "MPS-GGN",
    },
    student: {
      name: "Amit Kumar",
      id: "STU-003",
      class: "Class 8-C",
      phone: "+91 76543 21098",
    },
    totalOrderAmount: 85000,
    totalSettlementAmount: 85000,
    gateway: "Paytm",
    splits: [
      {
        id: "SPL-003-A",
        settlementId: "SETTLE-003-A",
        beneficiary: "Modern Public School",
        beneficiaryType: "Institute",
        accountNumber: "77890123456789",
        accountLast4: "6789",
        ifsc: "HDFC0006789",
        bank: "HDFC Bank",
        splitPercentage: 75,
        orderAmount: 63750,
        settlementAmount: 63750,
        status: "settled",
        settlementDate: "2025-01-10",
        utr: "HDFC9988776655",
        students: [
          { name: "Amit Kumar", id: "STU-003", class: "Class 8-C", amount: 63750 },
        ],
      },
      {
        id: "SPL-003-B",
        settlementId: "SETTLE-003-B",
        beneficiary: "Uniform Supplier Co",
        beneficiaryType: "Vendor",
        accountNumber: "88901234567890",
        accountLast4: "7890",
        ifsc: "YESB0000123",
        bank: "Yes Bank",
        splitPercentage: 25,
        orderAmount: 21250,
        settlementAmount: 21250,
        status: "pending",
        expectedSettlementDate: "2025-01-11",
        utr: null,
        students: [
          { name: "Amit Kumar", id: "STU-003", class: "Class 8-C", amount: 21250 },
        ],
      },
    ],
  },
]

// Summary statistics
const splitSummaryStats = {
  totalSplitTransactions: 156,
  totalOrderAmount: 15600000,
  totalSettlementAmount: 15600000,
  totalBeneficiaries: 45,
  settledSplits: 420,
  settledAmount: 14200000,
  pendingSplits: 35,
  pendingAmount: 1200000,
  failedSplits: 8,
  failedAmount: 200000,
  byBeneficiaryType: {
    institute: { count: 156, amount: 10920000 },
    trust: { count: 45, amount: 2340000 },
    vendor: { count: 112, amount: 2340000 },
  },
  byGateway: {
    razorpay: { count: 180, amount: 7800000 },
    cashfree: { count: 150, amount: 5200000 },
    paytm: { count: 90, amount: 2600000 },
  },
}

export function SplitSettlementsTab() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedGateway, setSelectedGateway] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedBeneficiaryType, setSelectedBeneficiaryType] = useState("all")
  const [selectedVendor, setSelectedVendor] = useState("all")
  const [selectedSplit, setSelectedSplit] = useState<(typeof splitSettlementsData)[0] | null>(null)
  const [showDetailModal, setShowDetailModal] = useState(false)

  // Get unique vendors for filter
  const uniqueVendors = Array.from(new Set(
    splitSettlementsData.flatMap(t => 
      t.splits.filter(s => s.beneficiaryType === "Vendor").map(s => s.beneficiary)
    )
  ))

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "settled":
        return <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Settled</Badge>
      case "pending":
        return <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/30">Pending</Badge>
      case "failed":
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30">Failed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getBeneficiaryTypeBadge = (type: string) => {
    switch (type) {
      case "Institute":
        return (
          <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/30">
            Institute
          </Badge>
        )
      case "Trust":
        return (
          <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/30">
            Trust
          </Badge>
        )
      case "Vendor":
        return (
          <Badge variant="outline" className="bg-orange-500/10 text-orange-400 border-orange-500/30">
            Vendor
          </Badge>
        )
      default:
        return <Badge variant="outline">{type}</Badge>
    }
  }

  const getSplitSettlementProgress = (splits: (typeof splitSettlementsData)[0]["splits"]) => {
    const settled = splits.filter((s) => s.status === "settled").length
    return (settled / splits.length) * 100
  }

  const openDetailModal = (split: (typeof splitSettlementsData)[0]) => {
    setSelectedSplit(split)
    setShowDetailModal(true)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/20">
                <Split className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Split Transactions</p>
                <p className="text-xl font-bold text-foreground">{splitSummaryStats.totalSplitTransactions}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.totalOrderAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20">
                <CheckCircle2 className="h-5 w-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Settled Splits</p>
                <p className="text-xl font-bold text-emerald-400">{splitSummaryStats.settledSplits}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.settledAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20">
                <Clock className="h-5 w-5 text-amber-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending Splits</p>
                <p className="text-xl font-bold text-amber-400">{splitSummaryStats.pendingSplits}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.pendingAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-red-500/20">
                <AlertCircle className="h-5 w-5 text-red-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Failed Splits</p>
                <p className="text-xl font-bold text-red-400">{splitSummaryStats.failedSplits}</p>
                <p className="text-xs text-muted-foreground">{formatCurrency(splitSummaryStats.failedAmount)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by settlement ID, account number, student name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-background"
              />
            </div>
            <Select value={selectedGateway} onValueChange={setSelectedGateway}>
              <SelectTrigger className="w-[150px] bg-background">
                <SelectValue placeholder="Gateway" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Gateways</SelectItem>
                <SelectItem value="razorpay">Razorpay</SelectItem>
                <SelectItem value="cashfree">Cashfree</SelectItem>
                <SelectItem value="paytm">Paytm</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[150px] bg-background">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="settled">Settled</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedBeneficiaryType} onValueChange={setSelectedBeneficiaryType}>
              <SelectTrigger className="w-[180px] bg-background">
                <SelectValue placeholder="Beneficiary Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="institute">Institute</SelectItem>
                <SelectItem value="trust">Trust</SelectItem>
                <SelectItem value="vendor">Vendor</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedVendor} onValueChange={setSelectedVendor}>
              <SelectTrigger className="w-[200px] bg-background">
                <SelectValue placeholder="Vendor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Vendors</SelectItem>
                {uniqueVendors.map((vendor) => (
                  <SelectItem key={vendor} value={vendor}>{vendor}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Split Settlements Table - Simplified with Account, Settlement ID, Student */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Split Settlement Breakdown</CardTitle>
          <CardDescription>
            View split settlements with account details, settlement IDs, and student breakup
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-muted-foreground">Settlement ID</TableHead>
                <TableHead className="text-muted-foreground">Account Details</TableHead>
                <TableHead className="text-muted-foreground">Beneficiary</TableHead>
                <TableHead className="text-muted-foreground">Vendor Name</TableHead>
                <TableHead className="text-muted-foreground">Student(s)</TableHead>
                <TableHead className="text-muted-foreground text-right">Order Amount</TableHead>
                <TableHead className="text-muted-foreground text-right">Settlement</TableHead>
                <TableHead className="text-muted-foreground text-center">Status</TableHead>
                <TableHead className="text-muted-foreground text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {splitSettlementsData.flatMap((transaction) =>
                transaction.splits
                  .filter((split) => {
                    if (selectedVendor !== "all" && split.beneficiary !== selectedVendor) return false
                    if (selectedBeneficiaryType !== "all" && split.beneficiaryType.toLowerCase() !== selectedBeneficiaryType) return false
                    if (selectedStatus !== "all" && split.status !== selectedStatus) return false
                    if (selectedGateway !== "all" && transaction.gateway.toLowerCase() !== selectedGateway) return false
                    return true
                  })
                  .map((split) => (
                  <TableRow key={split.id} className="border-border">
                    <TableCell>
                      <div>
                        <div className="flex items-center gap-1">
                          <p className="font-mono text-sm text-primary">{split.settlementId}</p>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-5 w-5"
                            onClick={() => copyToClipboard(split.settlementId)}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                        <p className="text-xs text-muted-foreground">{split.settlementDate || split.expectedSettlementDate}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="flex items-center gap-2">
                          <Banknote className="h-3.5 w-3.5 text-muted-foreground" />
                          <span className="font-mono text-sm">****{split.accountLast4}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">{split.bank}</p>
                        <p className="text-xs text-muted-foreground font-mono">{split.ifsc}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm font-medium text-foreground">{split.beneficiary}</p>
                        {getBeneficiaryTypeBadge(split.beneficiaryType)}
                      </div>
                    </TableCell>
                    <TableCell>
                      {split.beneficiaryType === "Vendor" ? (
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="bg-orange-500/10 text-orange-400 border-orange-500/30">
                            {split.beneficiary}
                          </Badge>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {split.students.map((student, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            <Users className="h-3 w-3 text-muted-foreground" />
                            <div>
                              <p className="text-sm text-foreground">{student.name}</p>
                              <p className="text-xs text-muted-foreground">{student.id} | {student.class}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <p className="font-medium text-foreground">{formatCurrency(split.orderAmount)}</p>
                      <p className="text-xs text-muted-foreground">{split.splitPercentage}%</p>
                    </TableCell>
                    <TableCell className="text-right">
                      <p className="font-semibold text-emerald-500">{formatCurrency(split.settlementAmount)}</p>
                    </TableCell>
                    <TableCell className="text-center">
                      {getStatusBadge(split.status)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" className="gap-1" onClick={() => openDetailModal(transaction)}>
                        <ExternalLink className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Detail Modal - Simplified */}
      <Dialog open={showDetailModal} onOpenChange={setShowDetailModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          {selectedSplit && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Split className="h-5 w-5 text-primary" />
                  Split Settlement Details
                </DialogTitle>
              </DialogHeader>

              <Tabs defaultValue="overview" className="mt-4">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="beneficiaries">Beneficiaries</TabsTrigger>
                  <TabsTrigger value="students">Students</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4 mt-4">
                  {/* Transaction Info */}
                  <Card className="bg-muted/30 border-border">
                    <CardContent className="p-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <p className="text-xs text-muted-foreground">Transaction ID</p>
                          <p className="text-sm font-mono text-foreground">{selectedSplit.parentTransactionId}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Collection Date</p>
                          <p className="text-sm text-foreground">{selectedSplit.collectionDate}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Gateway</p>
                          <Badge variant="outline">{selectedSplit.gateway}</Badge>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Total Order Amount</p>
                          <p className="text-sm font-bold text-foreground">
                            {formatCurrency(selectedSplit.totalOrderAmount)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Student & Institute Info */}
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="bg-muted/30 border-border">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-blue-500/20">
                            <Users className="h-4 w-4 text-blue-400" />
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Student</p>
                            <p className="text-sm font-medium text-foreground">{selectedSplit.student.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {selectedSplit.student.class} | {selectedSplit.student.id}
                            </p>
                            <p className="text-xs text-muted-foreground">{selectedSplit.student.phone}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="bg-muted/30 border-border">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-emerald-500/20">
                            <Building2 className="h-4 w-4 text-emerald-400" />
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Institute</p>
                            <p className="text-sm font-medium text-foreground">{selectedSplit.institute.name}</p>
                            <p className="text-xs text-muted-foreground">{selectedSplit.institute.code}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Split Summary - Simplified showing Order Amount = Settlement */}
                  <Card className="bg-muted/30 border-border">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Split Distribution</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {selectedSplit.splits.map((split, index) => (
                          <div
                            key={split.id}
                            className="flex items-center justify-between p-4 rounded-lg bg-background border border-border"
                          >
                            <div className="flex items-center gap-4">
                              <div className="text-lg font-bold text-muted-foreground w-6">{index + 1}</div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <p className="text-sm font-medium text-foreground">{split.beneficiary}</p>
                                  {getBeneficiaryTypeBadge(split.beneficiaryType)}
                                </div>
                                <div className="flex items-center gap-2 mt-1">
                                  <Banknote className="h-3 w-3 text-muted-foreground" />
                                  <span className="text-xs font-mono text-muted-foreground">
                                    ****{split.accountLast4} | {split.bank}
                                  </span>
                                </div>
                                <p className="text-xs text-muted-foreground font-mono mt-0.5">
                                  Settlement ID: {split.settlementId}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="flex flex-col items-end gap-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-muted-foreground">Order:</span>
                                  <span className="text-sm font-medium text-foreground">
                                    {formatCurrency(split.orderAmount)}
                                  </span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-muted-foreground">Settlement:</span>
                                  <span className="text-sm font-bold text-emerald-500">
                                    {formatCurrency(split.settlementAmount)}
                                  </span>
                                </div>
                                <span className="text-xs text-muted-foreground">({split.splitPercentage}%)</span>
                              </div>
                              <div className="mt-2">{getStatusBadge(split.status)}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="beneficiaries" className="space-y-4 mt-4">
                  {selectedSplit.splits.map((split) => (
                    <Card key={split.id} className="bg-muted/30 border-border">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-base">{split.beneficiary}</CardTitle>
                            {getBeneficiaryTypeBadge(split.beneficiaryType)}
                          </div>
                          {getStatusBadge(split.status)}
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div>
                            <p className="text-xs text-muted-foreground">Account Number</p>
                            <div className="flex items-center gap-1">
                              <p className="text-sm font-mono text-foreground">{split.accountNumber}</p>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-5 w-5"
                                onClick={() => copyToClipboard(split.accountNumber)}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">IFSC Code</p>
                            <p className="text-sm font-mono text-foreground">{split.ifsc}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Bank</p>
                            <p className="text-sm text-foreground">{split.bank}</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Settlement ID</p>
                            <p className="text-sm font-mono text-primary">{split.settlementId}</p>
                          </div>
                        </div>

                        {/* Amount - Simplified: Order = Settlement */}
                        <div className="p-3 rounded-lg bg-background border border-border">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm text-muted-foreground">
                              Split ({split.splitPercentage}%)
                            </span>
                            <span className="text-sm font-medium text-foreground">
                              {formatCurrency(split.orderAmount)}
                            </span>
                          </div>
                          <div className="border-t border-border pt-2 flex items-center justify-between">
                            <span className="text-sm font-medium text-foreground">Settlement Amount</span>
                            <span className="text-sm font-bold text-emerald-400">
                              {formatCurrency(split.settlementAmount)}
                            </span>
                          </div>
                        </div>

                        {/* Settlement Details */}
                        {split.status === "settled" && split.utr && (
                          <div className="mt-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                            <div className="flex items-center gap-2 mb-2">
                              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                              <span className="text-sm font-medium text-emerald-400">Settlement Completed</span>
                            </div>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <p className="text-xs text-muted-foreground">Settlement Date</p>
                                <p className="text-foreground">{split.settlementDate}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">UTR Number</p>
                                <div className="flex items-center gap-1">
                                  <p className="font-mono text-foreground">{split.utr}</p>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-5 w-5"
                                    onClick={() => copyToClipboard(split.utr || "")}
                                  >
                                    <Copy className="h-3 w-3" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {split.status === "pending" && (
                          <div className="mt-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
                            <div className="flex items-center gap-2 mb-2">
                              <Clock className="h-4 w-4 text-amber-400" />
                              <span className="text-sm font-medium text-amber-400">Settlement Pending</span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Expected settlement date:{" "}
                              <span className="text-foreground font-medium">{split.expectedSettlementDate}</span>
                            </p>
                          </div>
                        )}

                        {split.status === "failed" && (
                          <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                            <div className="flex items-center gap-2 mb-2">
                              <AlertCircle className="h-4 w-4 text-red-400" />
                              <span className="text-sm font-medium text-red-400">Settlement Failed</span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Reason: <span className="text-foreground">{split.failureReason}</span>
                            </p>
                            <Button variant="outline" size="sm" className="mt-2 bg-transparent">
                              Retry Settlement
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="students" className="space-y-4 mt-4">
                  <Card className="bg-muted/30 border-border">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Student-wise Breakup</CardTitle>
                      <CardDescription>Breakdown of settlement by student contributions</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Table>
                        <TableHeader>
                          <TableRow className="border-border">
                            <TableHead className="text-muted-foreground">Student</TableHead>
                            <TableHead className="text-muted-foreground">Beneficiary</TableHead>
                            <TableHead className="text-muted-foreground">Account</TableHead>
                            <TableHead className="text-muted-foreground text-right">Order Amount</TableHead>
                            <TableHead className="text-muted-foreground text-right">Settlement</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {selectedSplit.splits.flatMap((split) =>
                            split.students.map((student, idx) => (
                              <TableRow key={`${split.id}-${idx}`} className="border-border">
                                <TableCell>
                                  <div>
                                    <p className="text-sm font-medium text-foreground">{student.name}</p>
                                    <p className="text-xs text-muted-foreground">{student.id} | {student.class}</p>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div>
                                    <p className="text-sm text-foreground">{split.beneficiary}</p>
                                    {getBeneficiaryTypeBadge(split.beneficiaryType)}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div>
                                    <p className="text-sm font-mono">****{split.accountLast4}</p>
                                    <p className="text-xs text-muted-foreground">{split.bank}</p>
                                  </div>
                                </TableCell>
                                <TableCell className="text-right">
                                  <p className="font-medium text-foreground">{formatCurrency(student.amount)}</p>
                                </TableCell>
                                <TableCell className="text-right">
                                  <p className="font-semibold text-emerald-500">{formatCurrency(student.amount)}</p>
                                </TableCell>
                              </TableRow>
                            ))
                          )}
                        </TableBody>
                      </Table>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
