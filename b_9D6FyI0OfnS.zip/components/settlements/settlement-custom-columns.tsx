"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import {
  Plus,
  GripVertical,
  Trash2,
  Settings2,
  ArrowUp,
  ArrowDown,
  Code,
  AlertCircle,
} from "lucide-react"

export interface SettlementCustomColumnConfig {
  id: string
  name: string
  apiField: string
  displayName: string
  type: "text" | "number" | "currency" | "date" | "badge" | "percentage"
  visible: boolean
  sortable: boolean
  order: number
}

interface SettlementCustomColumnsManagerProps {
  open: boolean
  onClose: () => void
  customColumns: SettlementCustomColumnConfig[]
  onColumnsChange: (columns: SettlementCustomColumnConfig[]) => void
}

// Sample ERP Partner API configuration for settlements
const erpApiExample = {
  endpoint: "/api/v1/settlements/:settlementId/custom-fields",
  method: "GET",
  response: {
    customFields: {
      bankAccountAlias: "Primary Collection A/C",
      settlementCycle: "T+1",
      partnerCode: "ERP-2024-001",
      invoiceNumber: "INV-2024-00123",
      taxDeducted: 14500,
      tdsPercentage: 1,
      gstOnCommission: 2610,
      reconciliationStatus: "Matched",
      accountingPeriod: "FY 2024-25 Q4",
    },
  },
}

export function SettlementCustomColumnsManager({
  open,
  onClose,
  customColumns,
  onColumnsChange,
}: SettlementCustomColumnsManagerProps) {
  const [newColumn, setNewColumn] = useState<Partial<SettlementCustomColumnConfig>>({
    name: "",
    apiField: "",
    displayName: "",
    type: "text",
    visible: true,
    sortable: true,
  })
  const [showApiDocs, setShowApiDocs] = useState(false)

  const handleAddColumn = () => {
    if (!newColumn.name || !newColumn.apiField || !newColumn.displayName) return

    const column: SettlementCustomColumnConfig = {
      id: `custom-${Date.now()}`,
      name: newColumn.name,
      apiField: newColumn.apiField,
      displayName: newColumn.displayName,
      type: newColumn.type || "text",
      visible: true,
      sortable: true,
      order: customColumns.length,
    }

    onColumnsChange([...customColumns, column])
    setNewColumn({
      name: "",
      apiField: "",
      displayName: "",
      type: "text",
      visible: true,
      sortable: true,
    })
  }

  const handleRemoveColumn = (columnId: string) => {
    onColumnsChange(customColumns.filter((c) => c.id !== columnId))
  }

  const handleToggleVisibility = (columnId: string) => {
    onColumnsChange(
      customColumns.map((c) => (c.id === columnId ? { ...c, visible: !c.visible } : c))
    )
  }

  const handleMoveColumn = (columnId: string, direction: "up" | "down") => {
    const idx = customColumns.findIndex((c) => c.id === columnId)
    if (idx === -1) return
    if (direction === "up" && idx === 0) return
    if (direction === "down" && idx === customColumns.length - 1) return

    const newColumns = [...customColumns]
    const swapIdx = direction === "up" ? idx - 1 : idx + 1
    ;[newColumns[idx], newColumns[swapIdx]] = [newColumns[swapIdx], newColumns[idx]]
    newColumns.forEach((c, i) => (c.order = i))
    onColumnsChange(newColumns)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="h-5 w-5" />
            Settlement Custom Columns Manager
          </DialogTitle>
          <DialogDescription>
            Add custom columns from your ERP API to extend the settlements table. Configure column visibility and order.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* ERP API Documentation */}
          <div className="rounded-lg border border-border p-4">
            <button
              onClick={() => setShowApiDocs(!showApiDocs)}
              className="flex items-center justify-between w-full text-left"
            >
              <div className="flex items-center gap-2">
                <Code className="h-4 w-4 text-primary" />
                <span className="font-medium">ERP API Integration Guide</span>
              </div>
              <Badge variant="outline" className="text-xs">
                {showApiDocs ? "Hide" : "Show"}
              </Badge>
            </button>

            {showApiDocs && (
              <div className="mt-4 space-y-4">
                <div className="rounded-lg bg-secondary/50 p-4">
                  <p className="text-sm text-muted-foreground mb-2">
                    To add custom columns for settlements, your ERP system needs to expose an API endpoint:
                  </p>
                  <div className="rounded bg-background p-3 font-mono text-xs overflow-x-auto">
                    <p className="text-primary">GET {erpApiExample.endpoint}</p>
                    <p className="text-muted-foreground mt-2">Response:</p>
                    <pre className="text-foreground mt-1">
                      {JSON.stringify(erpApiExample.response, null, 2)}
                    </pre>
                  </div>
                </div>

                <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-amber-400">Important</p>
                    <p className="text-muted-foreground">
                      The API field name must match exactly with the field returned by your ERP API. 
                      Column data will be fetched in real-time for each settlement record.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Add New Column Form */}
          <div className="rounded-lg border border-border p-4 space-y-4">
            <h4 className="font-semibold flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add New Custom Column
            </h4>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="columnName">Column Internal Name</Label>
                <Input
                  id="columnName"
                  placeholder="e.g., invoice_number"
                  value={newColumn.name}
                  onChange={(e) => setNewColumn({ ...newColumn, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="displayName">Display Name (Header)</Label>
                <Input
                  id="displayName"
                  placeholder="e.g., Invoice Number"
                  value={newColumn.displayName}
                  onChange={(e) => setNewColumn({ ...newColumn, displayName: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="apiField">API Field Name</Label>
                <Input
                  id="apiField"
                  placeholder="e.g., customFields.invoiceNumber"
                  value={newColumn.apiField}
                  onChange={(e) => setNewColumn({ ...newColumn, apiField: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">
                  The field path in your ERP API response
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="columnType">Data Type</Label>
                <Select
                  value={newColumn.type}
                  onValueChange={(value) =>
                    setNewColumn({ ...newColumn, type: value as SettlementCustomColumnConfig["type"] })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="text">Text</SelectItem>
                    <SelectItem value="number">Number</SelectItem>
                    <SelectItem value="currency">Currency (Rs.)</SelectItem>
                    <SelectItem value="date">Date</SelectItem>
                    <SelectItem value="badge">Badge/Tag</SelectItem>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={handleAddColumn}
              disabled={!newColumn.name || !newColumn.apiField || !newColumn.displayName}
              className="w-full"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Column
            </Button>
          </div>

          <Separator />

          {/* Existing Custom Columns */}
          <div className="space-y-4">
            <h4 className="font-semibold">Custom Columns ({customColumns.length})</h4>

            {customColumns.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Settings2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No custom columns configured</p>
                <p className="text-xs mt-1">Add columns from your ERP API to extend the settlements table</p>
              </div>
            ) : (
              <div className="space-y-2">
                {customColumns.map((column, idx) => (
                  <div
                    key={column.id}
                    className={`rounded-lg border p-4 ${
                      column.visible ? "border-border bg-secondary/30" : "border-border/50 bg-secondary/10 opacity-60"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab" />

                      <div className="flex-1 grid grid-cols-4 gap-4 items-center">
                        <div>
                          <p className="font-medium text-sm">{column.displayName}</p>
                          <p className="text-xs text-muted-foreground font-mono">{column.name}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">API Field</p>
                          <p className="text-sm font-mono">{column.apiField}</p>
                        </div>
                        <div>
                          <Badge variant="secondary" className="text-xs">
                            {column.type}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={column.visible}
                            onCheckedChange={() => handleToggleVisibility(column.id)}
                          />
                          <span className="text-xs text-muted-foreground">
                            {column.visible ? "Visible" : "Hidden"}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleMoveColumn(column.id, "up")}
                          disabled={idx === 0}
                        >
                          <ArrowUp className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleMoveColumn(column.id, "down")}
                          disabled={idx === customColumns.length - 1}
                        >
                          <ArrowDown className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => handleRemoveColumn(column.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Column Order Info */}
          <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-4">
            <div className="flex items-start gap-2">
              <GripVertical className="h-4 w-4 text-blue-400 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-blue-400">Column Arrangement</p>
                <p className="text-muted-foreground">
                  Use the up/down arrows to rearrange column order. Custom columns will appear after the default columns in the settlements table.
                  Toggle visibility to show/hide columns without deleting them.
                </p>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={onClose}>
            Save Configuration
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
