"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Calendar, Info, AlertTriangle } from "lucide-react"

interface BankHolidayCalendarProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

interface Holiday {
  date: string
  name: string
  type: "national" | "bank" | "regional"
  affectsSettlement: boolean
}

const holidays2024: Holiday[] = [
  { date: "2024-01-26", name: "Republic Day", type: "national", affectsSettlement: true },
  { date: "2024-03-08", name: "Maha Shivaratri", type: "bank", affectsSettlement: true },
  { date: "2024-03-25", name: "Holi", type: "national", affectsSettlement: true },
  { date: "2024-03-29", name: "Good Friday", type: "bank", affectsSettlement: true },
  { date: "2024-04-11", name: "Ugadi", type: "regional", affectsSettlement: true },
  { date: "2024-04-14", name: "Ambedkar Jayanti", type: "national", affectsSettlement: true },
  { date: "2024-04-17", name: "Ram Navami", type: "bank", affectsSettlement: true },
  { date: "2024-04-21", name: "Mahavir Jayanti", type: "bank", affectsSettlement: true },
  { date: "2024-05-01", name: "May Day", type: "national", affectsSettlement: true },
  { date: "2024-05-23", name: "Buddha Purnima", type: "bank", affectsSettlement: true },
  { date: "2024-06-17", name: "Eid ul-Adha", type: "bank", affectsSettlement: true },
  { date: "2024-07-17", name: "Muharram", type: "bank", affectsSettlement: true },
  { date: "2024-08-15", name: "Independence Day", type: "national", affectsSettlement: true },
  { date: "2024-08-26", name: "Janmashtami", type: "bank", affectsSettlement: true },
  { date: "2024-09-16", name: "Milad un-Nabi", type: "bank", affectsSettlement: true },
  { date: "2024-10-02", name: "Gandhi Jayanti", type: "national", affectsSettlement: true },
  { date: "2024-10-12", name: "Dussehra", type: "national", affectsSettlement: true },
  { date: "2024-10-31", name: "Diwali (Lakshmi Puja)", type: "national", affectsSettlement: true },
  { date: "2024-11-01", name: "Diwali (Govardhan Puja)", type: "national", affectsSettlement: true },
  { date: "2024-11-15", name: "Guru Nanak Jayanti", type: "bank", affectsSettlement: true },
  { date: "2024-12-25", name: "Christmas", type: "national", affectsSettlement: true },
]

const holidays2025: Holiday[] = [
  { date: "2025-01-14", name: "Makar Sankranti", type: "regional", affectsSettlement: true },
  { date: "2025-01-26", name: "Republic Day", type: "national", affectsSettlement: true },
  { date: "2025-02-26", name: "Maha Shivaratri", type: "bank", affectsSettlement: true },
  { date: "2025-03-14", name: "Holi", type: "national", affectsSettlement: true },
  { date: "2025-03-30", name: "Eid ul-Fitr", type: "bank", affectsSettlement: true },
  { date: "2025-04-06", name: "Ram Navami", type: "bank", affectsSettlement: true },
  { date: "2025-04-10", name: "Mahavir Jayanti", type: "bank", affectsSettlement: true },
  { date: "2025-04-14", name: "Ambedkar Jayanti", type: "national", affectsSettlement: true },
  { date: "2025-04-18", name: "Good Friday", type: "bank", affectsSettlement: true },
  { date: "2025-05-01", name: "May Day", type: "national", affectsSettlement: true },
  { date: "2025-05-12", name: "Buddha Purnima", type: "bank", affectsSettlement: true },
  { date: "2025-06-07", name: "Eid ul-Adha", type: "bank", affectsSettlement: true },
  { date: "2025-07-06", name: "Muharram", type: "bank", affectsSettlement: true },
  { date: "2025-08-15", name: "Independence Day", type: "national", affectsSettlement: true },
  { date: "2025-08-16", name: "Janmashtami", type: "bank", affectsSettlement: true },
  { date: "2025-09-05", name: "Milad un-Nabi", type: "bank", affectsSettlement: true },
  { date: "2025-10-02", name: "Gandhi Jayanti / Dussehra", type: "national", affectsSettlement: true },
  { date: "2025-10-20", name: "Diwali (Lakshmi Puja)", type: "national", affectsSettlement: true },
  { date: "2025-11-05", name: "Guru Nanak Jayanti", type: "bank", affectsSettlement: true },
  { date: "2025-12-25", name: "Christmas", type: "national", affectsSettlement: true },
]

const typeColors = {
  national: "bg-destructive/10 text-destructive border-destructive/20",
  bank: "bg-warning/10 text-warning border-warning/20",
  regional: "bg-info/10 text-info border-info/20",
}

export function BankHolidayCalendar({ open, onOpenChange }: BankHolidayCalendarProps) {
  const [selectedYear, setSelectedYear] = useState("2025")
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth())

  const holidays = selectedYear === "2024" ? holidays2024 : holidays2025

  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  const getHolidaysForMonth = (month: number) => {
    return holidays.filter((h) => {
      const holidayMonth = new Date(h.date).getMonth()
      return holidayMonth === month
    })
  }

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay()
  }

  const isHoliday = (day: number, month: number) => {
    const dateStr = `${selectedYear}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    return holidays.find((h) => h.date === dateStr)
  }

  const isWeekend = (day: number, month: number) => {
    const date = new Date(Number.parseInt(selectedYear), month, day)
    const dayOfWeek = date.getDay()
    return dayOfWeek === 0 || dayOfWeek === 6
  }

  const year = Number.parseInt(selectedYear)
  const daysInMonth = getDaysInMonth(currentMonth, year)
  const firstDay = getFirstDayOfMonth(currentMonth, year)
  const monthHolidays = getHolidaysForMonth(currentMonth)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl bg-card border-border max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Bank Holiday Calendar
            </DialogTitle>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="w-24 bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2025">2025</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Settlement Info Banner */}
          <div className="rounded-lg bg-info/10 border border-info/20 p-4 flex items-start gap-3">
            <Info className="h-5 w-5 text-info shrink-0 mt-0.5" />
            <div>
              <p className="font-medium text-info">T+1 Settlement Policy</p>
              <p className="text-sm text-muted-foreground mt-1">
                Institutes receive settlements on T+1 basis (next business day). On bank holidays and weekends,
                settlements are processed on the next working day. Funds collected on Friday will be settled on Monday.
              </p>
            </div>
          </div>

          {/* Calendar Grid */}
          <Card className="bg-secondary/30 border-border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <Button variant="ghost" size="icon" onClick={() => setCurrentMonth((m) => (m === 0 ? 11 : m - 1))}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <CardTitle className="text-lg">
                  {months[currentMonth]} {selectedYear}
                </CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setCurrentMonth((m) => (m === 11 ? 0 : m + 1))}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 mb-2">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                  <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2">
                    {day}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: firstDay }).map((_, i) => (
                  <div key={`empty-${i}`} className="aspect-square" />
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = i + 1
                  const holiday = isHoliday(day, currentMonth)
                  const weekend = isWeekend(day, currentMonth)

                  return (
                    <div
                      key={day}
                      className={`aspect-square flex items-center justify-center rounded-md text-sm relative
                        ${holiday ? "bg-destructive/20 text-destructive font-semibold" : ""}
                        ${weekend && !holiday ? "bg-muted text-muted-foreground" : ""}
                        ${!holiday && !weekend ? "hover:bg-secondary" : ""}
                      `}
                      title={holiday?.name || (weekend ? "Weekend - No Settlement" : "")}
                    >
                      {day}
                      {holiday && <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-destructive" />}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Holidays for Selected Month */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-warning" />
                Holidays in {months[currentMonth]} {selectedYear}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {monthHolidays.length > 0 ? (
                <div className="space-y-2">
                  {monthHolidays.map((holiday) => (
                    <div
                      key={holiday.date}
                      className="flex items-center justify-between rounded-lg bg-secondary/50 p-3"
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-sm text-muted-foreground">
                          {new Date(holiday.date).toLocaleDateString("en-IN", { day: "2-digit", month: "short" })}
                        </span>
                        <span className="font-medium">{holiday.name}</span>
                      </div>
                      <Badge variant="outline" className={typeColors[holiday.type]}>
                        {holiday.type}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-muted-foreground py-4">No bank holidays this month</p>
              )}
            </CardContent>
          </Card>

          {/* Legend */}
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded bg-destructive/20 border border-destructive/40" />
              <span className="text-muted-foreground">Bank Holiday</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded bg-muted border border-border" />
              <span className="text-muted-foreground">Weekend</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={typeColors.national}>
                National
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={typeColors.bank}>
                Bank
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={typeColors.regional}>
                Regional
              </Badge>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
