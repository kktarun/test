"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Download,
  ChevronDown,
  ChevronRight,
  User,
  CreditCard,
  CheckCircle2,
  Clock,
  IndianRupee,
  AlertTriangle,
  RotateCcw,
  Split,
} from "lucide-react"

interface InstituteStudentListProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  instituteId: string
  instituteName: string
  settlementId: string
}

interface StudentTransaction {
  id: string
  orderId: string
  orderAmount: number
  transactionAmount: number
  transactionFee: number
  feeType: string
  gateway: string
  paymentMode: string
  date: string
  time: string
  status: "success" | "pending" | "failed"
  isSettled: boolean
  settlementUtr?: string
  hasSplit?: boolean
  splitDetails?: Array<{
    beneficiary: string
    amount: number
    percentage: number
  }>
}

interface RefundAdjustment {
  refundId: string
  originalTxnId: string
  amount: number
  reason: string
  refundDate: string
  adjustedInSettlement: string
  status: "adjusted" | "pending"
}

interface Student {
  id: string
  name: string
  enrollmentNumber: string
  class: string
  division: string
  email: string
  mobile: string
  totalPaid: number
  totalSettled: number
  transactions: StudentTransaction[]
  refundAdjustments: RefundAdjustment[]
}

const studentsData: Record<string, Student[]> = {
  DPS001: [
    {
      id: "STU001",
      name: "Rahul Sharma",
      enrollmentNumber: "DPS/2024/10A/045",
      class: "Class 10",
      division: "A",
      email: "rahul.sharma@gmail.com",
      mobile: "+91 98765 43210",
      totalPaid: 83000,
      totalSettled: 81174,
      transactions: [
        {
          id: "TXN001234567",
          orderId: "ORD-DPS-2024-001",
          orderAmount: 45000,
          transactionAmount: 45990,
          transactionFee: 990,
          feeType: "Tuition Fee - Q4",
          gateway: "Razorpay",
          paymentMode: "Credit Card",
          date: "2024-01-15",
          time: "10:30 AM",
          status: "success",
          isSettled: true,
          settlementUtr: "RAZP24011600001234",
          hasSplit: true,
          splitDetails: [
            { beneficiary: "DPS Main Account", amount: 40500, percentage: 90 },
            { beneficiary: "DPS Transport Fund", amount: 4500, percentage: 10 },
          ],
        },
        {
          id: "TXN001234590",
          orderId: "ORD-DPS-2024-015",
          orderAmount: 38000,
          transactionAmount: 38836,
          transactionFee: 836,
          feeType: "Tuition Fee - Q3",
          gateway: "Cashfree",
          paymentMode: "UPI",
          date: "2024-01-10",
          time: "02:15 PM",
          status: "success",
          isSettled: true,
          settlementUtr: "CSHF24011100003456",
        },
      ],
      refundAdjustments: [],
    },
    {
      id: "STU002",
      name: "Amit Kumar",
      enrollmentNumber: "DPS/2024/09D/089",
      class: "Class 9",
      division: "D",
      email: "amit.kumar@gmail.com",
      mobile: "+91 43210 98765",
      totalPaid: 45000,
      totalSettled: 0,
      transactions: [
        {
          id: "TXN001234500",
          orderId: "ORD-DPS-2024-050",
          orderAmount: 45000,
          transactionAmount: 45990,
          transactionFee: 990,
          feeType: "Tuition Fee - Q4",
          gateway: "Razorpay",
          paymentMode: "UPI",
          date: "2024-01-12",
          time: "10:05 AM",
          status: "success",
          isSettled: false,
        },
      ],
      refundAdjustments: [
        {
          refundId: "REF001234",
          originalTxnId: "TXN001234500",
          amount: 45000,
          reason: "Course cancellation - Full refund requested by parent",
          refundDate: "2024-01-14",
          adjustedInSettlement: "IST001",
          status: "adjusted",
        },
      ],
    },
    {
      id: "STU003",
      name: "Priya Sharma",
      enrollmentNumber: "DPS/2024/08B/034",
      class: "Class 8",
      division: "B",
      email: "priya.sharma@yahoo.com",
      mobile: "+91 87654 32100",
      totalPaid: 75000,
      totalSettled: 48180,
      transactions: [
        {
          id: "TXN001234520",
          orderId: "ORD-DPS-2024-008",
          orderAmount: 50000,
          transactionAmount: 51100,
          transactionFee: 1100,
          feeType: "Annual Fee",
          gateway: "Cashfree",
          paymentMode: "Net Banking",
          date: "2024-01-14",
          time: "11:30 AM",
          status: "success",
          isSettled: true,
          settlementUtr: "CSHF24011500005678",
        },
        {
          id: "TXN001234525",
          orderId: "ORD-DPS-2024-009",
          orderAmount: 25000,
          transactionAmount: 25000,
          transactionFee: 0,
          feeType: "Duplicate Payment",
          gateway: "Cashfree",
          paymentMode: "UPI",
          date: "2024-01-14",
          time: "11:32 AM",
          status: "success",
          isSettled: false,
        },
      ],
      refundAdjustments: [
        {
          refundId: "REF001235",
          originalTxnId: "TXN001234525",
          amount: 25000,
          reason: "Duplicate payment - Refund processed automatically",
          refundDate: "2024-01-15",
          adjustedInSettlement: "IST001",
          status: "adjusted",
        },
      ],
    },
    {
      id: "STU004",
      name: "Rahul Verma",
      enrollmentNumber: "DPS/2024/11A/012",
      class: "Class 11",
      division: "A",
      email: "rahul.verma@outlook.com",
      mobile: "+91 76543 21098",
      totalPaid: 67000,
      totalSettled: 50820,
      transactions: [
        {
          id: "TXN001234540",
          orderId: "ORD-DPS-2024-018",
          orderAmount: 67000,
          transactionAmount: 68474,
          transactionFee: 1474,
          feeType: "Annual Fee",
          gateway: "Paytm",
          paymentMode: "Credit Card",
          date: "2024-01-15",
          time: "03:20 PM",
          status: "success",
          isSettled: true,
          settlementUtr: "PYTM24011600009012",
        },
      ],
      refundAdjustments: [
        {
          refundId: "REF001236",
          originalTxnId: "TXN001234540",
          amount: 15000,
          reason: "Partial fee waiver approved by management",
          refundDate: "2024-01-13",
          adjustedInSettlement: "IST001",
          status: "adjusted",
        },
      ],
    },
  ],
}

const statusColors = {
  success: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
}

export function InstituteStudentList({
  open,
  onOpenChange,
  instituteId,
  instituteName,
  settlementId,
}: InstituteStudentListProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [expandedStudent, setExpandedStudent] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("all")

  const students = studentsData[instituteId] || []

  const filteredStudents = students
    .filter((s) => {
      if (!searchQuery) return true
      const query = searchQuery.toLowerCase()
      return (
        s.name.toLowerCase().includes(query) ||
        s.enrollmentNumber.toLowerCase().includes(query) ||
        s.email.toLowerCase().includes(query)
      )
    })
    .filter((s) => {
      if (activeTab === "all") return true
      if (activeTab === "with-adjustments") return s.refundAdjustments.length > 0
      if (activeTab === "with-splits") return s.transactions.some((t) => t.hasSplit)
      return true
    })

  const totalOrderAmount = filteredStudents.reduce((sum, s) => sum + s.totalPaid, 0)
  const totalTransactions = filteredStudents.reduce((sum, s) => sum + s.transactions.length, 0)
  const totalAdjustments = filteredStudents.reduce(
    (sum, s) => sum + s.refundAdjustments.reduce((a, r) => a + r.amount, 0),
    0,
  )
  const studentsWithAdjustments = filteredStudents.filter((s) => s.refundAdjustments.length > 0).length

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl bg-card border-border max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl font-bold">{instituteName}</DialogTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Settlement ID: <span className="font-mono">{settlementId}</span> - Student Transaction Details
              </p>
            </div>
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Summary Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-secondary/50 border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{filteredStudents.length}</p>
                    <p className="text-xs text-muted-foreground">Students</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-secondary/50 border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-info/10">
                    <CreditCard className="h-5 w-5 text-info" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{totalTransactions}</p>
                    <p className="text-xs text-muted-foreground">Transactions</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-secondary/50 border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                    <IndianRupee className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">₹{(totalOrderAmount / 1000).toFixed(1)}K</p>
                    <p className="text-xs text-muted-foreground">Total Amount</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-secondary/50 border-border">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                    <RotateCcw className="h-5 w-5 text-destructive" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-destructive">₹{(totalAdjustments / 1000).toFixed(1)}K</p>
                    <p className="text-xs text-muted-foreground">{studentsWithAdjustments} Adjustments</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs and Search */}
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-auto">
              <TabsList className="bg-secondary">
                <TabsTrigger value="all">All Students</TabsTrigger>
                <TabsTrigger value="with-adjustments" className="gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  With Adjustments
                </TabsTrigger>
                <TabsTrigger value="with-splits" className="gap-1">
                  <Split className="h-3 w-3" />
                  Split Payments
                </TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by name, enrollment..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-secondary pl-10"
              />
            </div>
          </div>

          {/* Student List */}
          <div className="space-y-3">
            {filteredStudents.map((student) => {
              const hasAdjustments = student.refundAdjustments.length > 0
              const hasSplits = student.transactions.some((t) => t.hasSplit)

              return (
                <Card key={student.id} className="bg-secondary/30 border-border overflow-hidden">
                  <CardHeader
                    className="pb-3 cursor-pointer hover:bg-secondary/50 transition-colors"
                    onClick={() => setExpandedStudent(expandedStudent === student.id ? null : student.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Button variant="ghost" size="icon" className="h-6 w-6">
                          {expandedStudent === student.id ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </Button>
                        <div>
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-base font-semibold">{student.name}</CardTitle>
                            {hasAdjustments && (
                              <Badge
                                variant="outline"
                                className="bg-destructive/10 text-destructive border-destructive/20 text-xs"
                              >
                                <AlertTriangle className="h-3 w-3 mr-1" />
                                Refund Adjusted
                              </Badge>
                            )}
                            {hasSplits && (
                              <Badge variant="outline" className="bg-info/10 text-info border-info/20 text-xs">
                                <Split className="h-3 w-3 mr-1" />
                                Split
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-3 mt-1">
                            <span className="text-xs text-muted-foreground font-mono">{student.enrollmentNumber}</span>
                            <Badge variant="outline" className="text-xs">
                              {student.class} - {student.division}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-primary">₹{student.totalPaid.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">{student.transactions.length} transactions</p>
                        {hasAdjustments && (
                          <p className="text-xs text-destructive">
                            -₹{student.refundAdjustments.reduce((s, r) => s + r.amount, 0).toLocaleString()} adjusted
                          </p>
                        )}
                      </div>
                    </div>
                  </CardHeader>

                  {expandedStudent === student.id && (
                    <CardContent className="pt-0">
                      <div className="border-t border-border pt-4 space-y-4">
                        {/* Contact Info */}
                        <div className="flex items-center gap-6 text-sm">
                          <span className="text-muted-foreground">Email: {student.email}</span>
                          <span className="text-muted-foreground">Mobile: {student.mobile}</span>
                        </div>

                        {/* Refund Adjustments */}
                        {hasAdjustments && (
                          <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-4">
                            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2 text-destructive">
                              <RotateCcw className="h-4 w-4" />
                              Refund Adjustments (Deducted from Settlement)
                            </h4>
                            <div className="space-y-2">
                              {student.refundAdjustments.map((adj, idx) => (
                                <div key={idx} className="rounded-lg bg-card border border-border p-3">
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <div className="flex items-center gap-2">
                                        <span className="font-mono text-xs text-destructive">{adj.refundId}</span>
                                        <span className="text-muted-foreground">→</span>
                                        <span className="font-mono text-xs text-muted-foreground">
                                          {adj.originalTxnId}
                                        </span>
                                      </div>
                                      <p className="text-sm mt-1">{adj.reason}</p>
                                    </div>
                                    <div className="text-right">
                                      <p className="font-bold text-destructive">-₹{adj.amount.toLocaleString()}</p>
                                      <p className="text-xs text-muted-foreground">
                                        {adj.status === "adjusted" ? "Adjusted" : "Pending"} • {adj.refundDate}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Transactions */}
                        <div className="space-y-2">
                          <h4 className="text-sm font-semibold text-muted-foreground">Transaction Details</h4>
                          {student.transactions.map((txn) => (
                            <div key={txn.id} className="rounded-lg bg-card border border-border p-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                  <div>
                                    <div className="flex items-center gap-2">
                                      <span className="font-mono text-sm text-primary">{txn.id}</span>
                                      {txn.hasSplit && (
                                        <Badge
                                          variant="outline"
                                          className="bg-info/10 text-info border-info/20 text-xs"
                                        >
                                          <Split className="h-3 w-3 mr-1" />
                                          Split
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-xs text-muted-foreground">{txn.orderId}</p>
                                  </div>
                                  <Badge variant="outline" className="text-xs">
                                    {txn.feeType}
                                  </Badge>
                                </div>
                                <div className="flex items-center gap-4">
                                  <div className="text-right">
                                    <div className="flex items-center gap-2">
                                      <span className="text-xs text-muted-foreground">Order:</span>
                                      <span className="font-semibold">₹{txn.orderAmount.toLocaleString()}</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      {txn.gateway} • {txn.paymentMode}
                                    </p>
                                  </div>
                                  <Badge variant="outline" className={statusColors[txn.status]}>
                                    {txn.status}
                                  </Badge>
                                </div>
                              </div>

                              {/* Split Details */}
                              {txn.hasSplit && txn.splitDetails && (
                                <div className="mt-3 pt-3 border-t border-border">
                                  <p className="text-xs text-muted-foreground mb-2">Split Breakdown:</p>
                                  <div className="flex flex-wrap gap-2">
                                    {txn.splitDetails.map((split, idx) => (
                                      <div key={idx} className="text-xs bg-info/10 text-info px-2 py-1 rounded">
                                        {split.beneficiary}: ₹{split.amount.toLocaleString()} ({split.percentage}%)
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
                                <span className="text-xs text-muted-foreground">
                                  {txn.date} at {txn.time}
                                </span>
                                {txn.isSettled ? (
                                  <div className="flex items-center gap-1.5">
                                    <CheckCircle2 className="h-3.5 w-3.5 text-success" />
                                    <span className="text-xs text-success">Settled</span>
                                    <span className="text-xs text-muted-foreground font-mono ml-2">
                                      {txn.settlementUtr}
                                    </span>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-1.5">
                                    <Clock className="h-3.5 w-3.5 text-warning" />
                                    <span className="text-xs text-warning">Settlement Pending</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  )}
                </Card>
              )
            })}

            {filteredStudents.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No students found matching your search criteria.
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
