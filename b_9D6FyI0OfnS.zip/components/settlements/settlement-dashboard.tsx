"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Building2,
  Users,
  CreditCard,
  IndianRupee,
  TrendingUp,
  Wallet,
  RefreshCcw,
  AlertTriangle,
  Split,
  Landmark,
} from "lucide-react"

// Partner-level settlement data
const dashboardData = {
  overview: {
    totalSettlements: 847,
    totalInstitutes: 112,
    totalStudents: 15420,
    totalOrderAmount: 15420000,
    totalTransactionFees: 308400,
    totalAdjustments: 125000,
    netSettled: 14986600,
  },
  todaySettlement: {
    institutes: 45,
    students: 1250,
    orderAmount: 1250000,
    fees: 25000,
    adjustments: 8500,
    netAmount: 1216500,
    pendingCount: 12,
    pendingAmount: 450000,
  },
  gatewayDistribution: [
    {
      gateway: "Razorpay",
      color: "#528FF0",
      transactions: 5820,
      students: 5820,
      orderAmount: 5820000,
      fees: 116400,
      adjustments: 45000,
      netAmount: 5658600,
      percentage: 37.8,
    },
    {
      gateway: "Cashfree",
      color: "#00D09C",
      transactions: 4250,
      students: 4250,
      orderAmount: 4250000,
      fees: 85000,
      adjustments: 32000,
      netAmount: 4133000,
      percentage: 27.6,
    },
    {
      gateway: "Paytm",
      color: "#00B9F1",
      transactions: 3100,
      students: 3100,
      orderAmount: 3100000,
      fees: 62000,
      adjustments: 28000,
      netAmount: 3010000,
      percentage: 20.1,
    },
    {
      gateway: "PayU",
      color: "#54B848",
      transactions: 1450,
      students: 1450,
      orderAmount: 1450000,
      fees: 29000,
      adjustments: 12000,
      netAmount: 1409000,
      percentage: 9.4,
    },
    {
      gateway: "HDFC",
      color: "#004C8F",
      transactions: 800,
      students: 800,
      orderAmount: 800000,
      fees: 16000,
      adjustments: 8000,
      netAmount: 776000,
      percentage: 5.1,
    },
  ],
  statusBreakdown: {
    settled: { count: 720, amount: 14200000 },
    pending: { count: 85, amount: 950000 },
    processing: { count: 32, amount: 220000 },
    onHold: { count: 10, amount: 50000 },
  },
  adjustments: {
    totalRefundsAdjusted: 125000,
    refundTransactions: 42,
    pendingAdjustments: 35000,
    upcomingDeductions: 18500,
  },
  splitPayments: {
    totalSplitTransactions: 2450,
    totalBeneficiaries: 156,
    splitAmount: 4850000,
    platformShare: 485000,
    vendorShare: 4365000,
  },
}

export function SettlementDashboard() {
  const { overview, todaySettlement, gatewayDistribution, statusBreakdown, adjustments, splitPayments } = dashboardData

  return (
    <div className="space-y-6">
      {/* Today's Settlement Summary */}
      <Card className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-primary/20">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              Today's Settlement (T+1 from Yesterday)
            </CardTitle>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              {todaySettlement.institutes} Institutes
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
            <div>
              <p className="text-xs text-muted-foreground">Students Paid</p>
              <p className="text-lg font-semibold">{todaySettlement.students.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Order Amount</p>
              <p className="text-lg font-semibold">₹{(todaySettlement.orderAmount / 100000).toFixed(2)}L</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Transaction Fees</p>
              <p className="text-lg font-semibold text-muted-foreground">
                - ₹{(todaySettlement.fees / 1000).toFixed(1)}K
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Adjustments</p>
              <p className="text-lg font-semibold text-warning">
                - ₹{(todaySettlement.adjustments / 1000).toFixed(1)}K
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Net Settlement</p>
              <p className="text-lg font-semibold text-primary">₹{(todaySettlement.netAmount / 100000).toFixed(2)}L</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Pending</p>
              <p className="text-lg font-semibold text-amber-500">{todaySettlement.pendingCount}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Pending Amount</p>
              <p className="text-lg font-semibold text-amber-500">
                ₹{(todaySettlement.pendingAmount / 100000).toFixed(2)}L
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      
    </div>
  )
}
