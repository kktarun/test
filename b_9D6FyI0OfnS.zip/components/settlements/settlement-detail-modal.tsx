"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Download,
  Building2,
  Wallet,
  CreditCard,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Minus,
  Split,
  FileText,
  BanknoteIcon,
  Calculator,
} from "lucide-react"

interface SettlementDetailModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  settlement: {
    id: string
    settlementDate: string
    instituteId: string
    instituteName: string
    instituteCode: string
    grossOrderAmount: number
    totalTransactionFees: number
    totalAdjustments: number
    netSettlementAmount: number
    transactionCount: number
    studentCount: number
    status: "settled" | "pending" | "delayed" | "partial"
    expectedDate: string
    bankAccount: string
    ifscCode: string
    gatewaySettlements: Array<{
      gateway: string
      grossAmount: number
      transactionFees: number
      adjustments: Array<{
        refundId: string
        originalTxnId: string
        studentName: string
        amount: number
        reason: string
        refundDate: string
      }>
      netAmount: number
      transactionCount: number
      utr?: string
      status: "settled" | "pending" | "delayed"
      settledAt?: string
      splitDetails?: Array<{
        beneficiary: string
        accountNumber: string
        ifsc: string
        amount: number
        percentage: number
      }>
    }>
  }
}

const statusColors = {
  settled: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  delayed: "bg-destructive/10 text-destructive border-destructive/20",
  partial: "bg-info/10 text-info border-info/20",
}

export function SettlementDetailModal({ open, onOpenChange, settlement }: SettlementDetailModalProps) {
  const totalAdjustmentAmount = settlement.gatewaySettlements.reduce(
    (sum, gw) => sum + gw.adjustments.reduce((a, adj) => a + adj.amount, 0),
    0,
  )

  const allAdjustments = settlement.gatewaySettlements.flatMap((gw) =>
    gw.adjustments.map((adj) => ({ ...adj, gateway: gw.gateway })),
  )

  const hasSplitPayments = settlement.gatewaySettlements.some((gw) => gw.splitDetails && gw.splitDetails.length > 0)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl bg-card border-border max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl font-bold flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Settlement Details
              </DialogTitle>
              <p className="text-sm text-muted-foreground mt-1">
                Settlement ID: <span className="font-mono">{settlement.id}</span>
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={statusColors[settlement.status]}>
                {settlement.status === "partial" ? "Partially Settled" : settlement.status}
              </Badge>
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="bg-secondary">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="calculation">Calculation</TabsTrigger>
            <TabsTrigger value="adjustments" className="gap-1">
              <AlertTriangle className="h-3 w-3" />
              Adjustments ({allAdjustments.length})
            </TabsTrigger>
            {hasSplitPayments && (
              <TabsTrigger value="splits" className="gap-1">
                <Split className="h-3 w-3" />
                Split Payments
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {/* Institute Info */}
            <Card className="bg-secondary/30 border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-primary" />
                  Institute Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Institute Name</p>
                    <p className="font-medium">{settlement.instituteName}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Institute Code</p>
                    <p className="font-mono">{settlement.instituteCode}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Bank Account</p>
                    <p className="font-mono">{settlement.bankAccount}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">IFSC Code</p>
                    <p className="font-mono">{settlement.ifscCode}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Settlement Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="bg-secondary/30 border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <BanknoteIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xl font-bold">₹{(settlement.grossOrderAmount / 100000).toFixed(2)} L</p>
                      <p className="text-xs text-muted-foreground">Gross Amount</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-secondary/30 border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                      <CreditCard className="h-5 w-5 text-warning" />
                    </div>
                    <div>
                      <p className="text-xl font-bold text-warning">
                        -₹{(settlement.totalTransactionFees / 1000).toFixed(1)}K
                      </p>
                      <p className="text-xs text-muted-foreground">Transaction Fees</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-secondary/30 border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
                      <AlertTriangle className="h-5 w-5 text-destructive" />
                    </div>
                    <div>
                      <p className="text-xl font-bold text-destructive">
                        -₹{(settlement.totalAdjustments / 1000).toFixed(1)}K
                      </p>
                      <p className="text-xs text-muted-foreground">Adjustments</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-secondary/30 border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/10">
                      <Wallet className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <p className="text-xl font-bold text-success">
                        ₹{(settlement.netSettlementAmount / 100000).toFixed(2)} L
                      </p>
                      <p className="text-xs text-muted-foreground">Net Settlement</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Gateway Breakdown */}
            <Card className="bg-secondary/30 border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Wallet className="h-4 w-4 text-primary" />
                  Gateway-wise Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {settlement.gatewaySettlements.map((gw, idx) => (
                    <div key={idx} className="rounded-lg bg-card border border-border p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="font-semibold">{gw.gateway}</span>
                          <Badge variant="outline" className={statusColors[gw.status]}>
                            {gw.status}
                          </Badge>
                          {gw.adjustments.length > 0 && (
                            <Badge
                              variant="outline"
                              className="bg-destructive/10 text-destructive border-destructive/20 text-xs"
                            >
                              {gw.adjustments.length} adjustment{gw.adjustments.length > 1 ? "s" : ""}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-6 text-sm">
                          <div className="text-right">
                            <p className="text-muted-foreground">Gross</p>
                            <p className="font-medium">₹{(gw.grossAmount / 100000).toFixed(2)} L</p>
                          </div>
                          <div className="text-right">
                            <p className="text-muted-foreground">Net</p>
                            <p className="font-bold text-success">₹{(gw.netAmount / 100000).toFixed(2)} L</p>
                          </div>
                        </div>
                      </div>
                      {gw.utr && (
                        <div className="mt-2 pt-2 border-t border-border flex items-center gap-4 text-xs text-muted-foreground">
                          <span className="font-mono">UTR: {gw.utr}</span>
                          {gw.settledAt && (
                            <>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <CheckCircle2 className="h-3 w-3 text-success" />
                                {gw.settledAt}
                              </span>
                            </>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="calculation" className="space-y-4">
            <Card className="bg-secondary/30 border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Calculator className="h-4 w-4 text-primary" />
                  Settlement Calculation Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Step 1: Gross Collection */}
                  <div className="rounded-lg bg-card border border-border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary font-bold">
                          1
                        </div>
                        <div>
                          <p className="font-semibold">Gross Order Amount Collected</p>
                          <p className="text-xs text-muted-foreground">
                            {settlement.transactionCount} transactions from {settlement.studentCount} students
                          </p>
                        </div>
                      </div>
                      <p className="text-xl font-bold">₹{(settlement.grossOrderAmount / 100000).toFixed(2)} L</p>
                    </div>
                  </div>

                  {/* Step 2: Transaction Fees */}
                  <div className="flex items-center justify-center">
                    <Minus className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="rounded-lg bg-warning/5 border border-warning/20 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-warning/10 text-warning font-bold">
                          2
                        </div>
                        <div>
                          <p className="font-semibold">Payment Gateway Transaction Fees</p>
                          <p className="text-xs text-muted-foreground">
                            Avg {((settlement.totalTransactionFees / settlement.grossOrderAmount) * 100).toFixed(2)}%
                            across all gateways
                          </p>
                        </div>
                      </div>
                      <p className="text-xl font-bold text-warning">
                        -₹{(settlement.totalTransactionFees / 1000).toFixed(1)}K
                      </p>
                    </div>
                    <div className="mt-3 pt-3 border-t border-warning/20 space-y-1">
                      {settlement.gatewaySettlements.map((gw, idx) => (
                        <div key={idx} className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">{gw.gateway}</span>
                          <span className="text-warning">-₹{(gw.transactionFees / 1000).toFixed(1)}K</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Step 3: Refund Adjustments */}
                  <div className="flex items-center justify-center">
                    <Minus className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-destructive/10 text-destructive font-bold">
                          3
                        </div>
                        <div>
                          <p className="font-semibold">Refund Adjustments</p>
                          <p className="text-xs text-muted-foreground">
                            {allAdjustments.length} refund{allAdjustments.length !== 1 ? "s" : ""} deducted from this
                            settlement
                          </p>
                        </div>
                      </div>
                      <p className="text-xl font-bold text-destructive">
                        -₹{(settlement.totalAdjustments / 1000).toFixed(1)}K
                      </p>
                    </div>
                    {allAdjustments.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-destructive/20 space-y-1">
                        {allAdjustments.map((adj, idx) => (
                          <div key={idx} className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">
                              {adj.studentName} ({adj.gateway})
                            </span>
                            <span className="text-destructive">-₹{adj.amount.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Result: Net Settlement */}
                  <div className="flex items-center justify-center">
                    <ArrowRight className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <div className="rounded-lg bg-success/5 border border-success/20 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-success/10 text-success font-bold">
                          =
                        </div>
                        <div>
                          <p className="font-semibold">Net Settlement Amount</p>
                          <p className="text-xs text-muted-foreground">Amount credited to {settlement.bankAccount}</p>
                        </div>
                      </div>
                      <p className="text-2xl font-bold text-success">
                        ₹{(settlement.netSettlementAmount / 100000).toFixed(2)} L
                      </p>
                    </div>
                  </div>

                  {/* Formula Summary */}
                  <div className="rounded-lg bg-secondary/50 p-4 text-center">
                    <p className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">Net Settlement</span> = Gross Amount (₹
                      {(settlement.grossOrderAmount / 100000).toFixed(2)}L) - Transaction Fees (₹
                      {(settlement.totalTransactionFees / 1000).toFixed(1)}K) - Adjustments (₹
                      {(settlement.totalAdjustments / 1000).toFixed(1)}K) ={" "}
                      <span className="font-bold text-success">
                        ₹{(settlement.netSettlementAmount / 100000).toFixed(2)}L
                      </span>
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="adjustments" className="space-y-4">
            <Card className="bg-secondary/30 border-border">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-destructive" />
                    Refund Adjustments Details
                  </CardTitle>
                  <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
                    Total: -₹{totalAdjustmentAmount.toLocaleString()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {allAdjustments.length > 0 ? (
                  <div className="space-y-3">
                    <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-3 mb-4">
                      <p className="text-sm text-destructive">
                        <strong>Note:</strong> These refunds were processed earlier and their order amounts are being
                        deducted from this settlement cycle. The institute will receive the net amount after these
                        adjustments.
                      </p>
                    </div>
                    {allAdjustments.map((adj, idx) => (
                      <div key={idx} className="rounded-lg bg-card border border-border p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className="text-xs">
                                {adj.gateway}
                              </Badge>
                              <span className="font-mono text-xs text-destructive">{adj.refundId}</span>
                            </div>
                            <p className="font-semibold">{adj.studentName}</p>
                            <p className="text-sm text-muted-foreground">{adj.reason}</p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                              <span>
                                Original Txn: <span className="font-mono">{adj.originalTxnId}</span>
                              </span>
                              <span>•</span>
                              <span>Refund Date: {adj.refundDate}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold text-destructive">-₹{adj.amount.toLocaleString()}</p>
                            <p className="text-xs text-muted-foreground">Deducted</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle2 className="h-12 w-12 mx-auto mb-3 text-success" />
                    <p>No refund adjustments for this settlement.</p>
                    <p className="text-sm">Full gross amount (minus transaction fees) was settled.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {hasSplitPayments && (
            <TabsContent value="splits" className="space-y-4">
              <Card className="bg-secondary/30 border-border">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Split className="h-4 w-4 text-info" />
                    Split Payment Beneficiaries
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {settlement.gatewaySettlements
                      .filter((gw) => gw.splitDetails && gw.splitDetails.length > 0)
                      .map((gw, gwIdx) => (
                        <div key={gwIdx} className="rounded-lg bg-card border border-border p-4">
                          <div className="flex items-center gap-2 mb-3">
                            <span className="font-semibold">{gw.gateway}</span>
                            <Badge variant="outline" className="text-xs">
                              ₹{(gw.netAmount / 100000).toFixed(2)} L split
                            </Badge>
                          </div>
                          <div className="grid gap-3 md:grid-cols-2">
                            {gw.splitDetails!.map((split, splitIdx) => (
                              <div key={splitIdx} className="rounded-lg bg-info/5 border border-info/20 p-3">
                                <div className="flex items-center justify-between mb-2">
                                  <p className="font-medium">{split.beneficiary}</p>
                                  <Badge variant="outline" className="bg-info/10 text-info border-info/20">
                                    {split.percentage}%
                                  </Badge>
                                </div>
                                <p className="text-xl font-bold text-info">₹{(split.amount / 100000).toFixed(2)} L</p>
                                <p className="text-xs text-muted-foreground font-mono mt-1">
                                  A/C: {split.accountNumber} | IFSC: {split.ifsc}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
