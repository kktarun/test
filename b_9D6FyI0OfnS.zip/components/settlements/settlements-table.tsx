"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronRight, ChevronLeft, ExternalLink } from "lucide-react"
import { SettlementTransactions } from "./settlement-transactions"
import Link from "next/link"

interface Settlement {
  id: string
  utr: string
  gateway: string
  amount: number
  transactionCount: number
  status: "settled" | "pending" | "delayed"
  settlementDate: string
  bankAccount: string
}

const settlements: Settlement[] = [
  {
    id: "STL001234",
    utr: "RAZR2024011512345678",
    gateway: "Razorpay",
    amount: 4820000,
    transactionCount: 156,
    status: "settled",
    settlementDate: "2024-01-16",
    bankAccount: "HDFC ****4521",
  },
  {
    id: "STL001235",
    utr: "CSHF2024011598765432",
    gateway: "Cashfree",
    amount: 3150000,
    transactionCount: 98,
    status: "settled",
    settlementDate: "2024-01-16",
    bankAccount: "ICICI ****8976",
  },
  {
    id: "STL001236",
    utr: "EZBZ2024011545678901",
    gateway: "Easebuzz",
    amount: 2400000,
    transactionCount: 75,
    status: "pending",
    settlementDate: "2024-01-17",
    bankAccount: "HDFC ****4521",
  },
  {
    id: "STL001237",
    utr: "PYTM2024011523456789",
    gateway: "Paytm",
    amount: 1850000,
    transactionCount: 62,
    status: "settled",
    settlementDate: "2024-01-16",
    bankAccount: "AXIS ****3214",
  },
  {
    id: "STL001238",
    utr: "RAZR2024011587654321",
    gateway: "Razorpay",
    amount: 850000,
    transactionCount: 28,
    status: "delayed",
    settlementDate: "2024-01-15",
    bankAccount: "HDFC ****4521",
  },
]

const statusColors = {
  settled: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  delayed: "bg-destructive/10 text-destructive border-destructive/20",
}

interface SettlementsTableProps {
  gateway: string
  status: string
}

export function SettlementsTable({ gateway, status }: SettlementsTableProps) {
  const [expandedSettlement, setExpandedSettlement] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)

  const filteredSettlements = settlements.filter((s) => {
    if (gateway !== "all" && !s.gateway.toLowerCase().includes(gateway)) return false
    if (status !== "all" && s.status !== status) return false
    return true
  })

  const toggleExpand = (id: string) => {
    setExpandedSettlement(expandedSettlement === id ? null : id)
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">{filteredSettlements.length} Settlements</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                <th className="p-4 text-left w-10"></th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Settlement ID</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">UTR</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Gateway</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Amount</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Transactions</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Bank Account</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Settlement Date</th>
              </tr>
            </thead>
            <tbody>
              {filteredSettlements.map((settlement) => (
                <>
                  <tr
                    key={settlement.id}
                    className="border-b border-border hover:bg-secondary/30 transition-colors cursor-pointer"
                    onClick={() => toggleExpand(settlement.id)}
                  >
                    <td className="p-4">
                      <Button variant="ghost" size="icon" className="h-6 w-6">
                        {expandedSettlement === settlement.id ? (
                          <ChevronDown className="h-4 w-4" />
                        ) : (
                          <ChevronRight className="h-4 w-4" />
                        )}
                      </Button>
                    </td>
                    <td className="p-4">
                      <Link 
                        href={`/settlements/${settlement.id}`}
                        className="font-mono text-sm font-medium text-primary hover:underline flex items-center gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {settlement.id}
                        <ExternalLink className="h-3 w-3 opacity-60" />
                      </Link>
                    </td>
                    <td className="p-4">
                      <span className="font-mono text-xs text-muted-foreground">{settlement.utr}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{settlement.gateway}</span>
                    </td>
                    <td className="p-4">
                      <span className="font-semibold">₹{(settlement.amount / 100000).toFixed(2)} L</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-muted-foreground">{settlement.transactionCount} txns</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm text-muted-foreground">{settlement.bankAccount}</span>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline" className={statusColors[settlement.status]}>
                        {settlement.status}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{settlement.settlementDate}</span>
                    </td>
                  </tr>
                  {expandedSettlement === settlement.id && (
                    <tr key={`${settlement.id}-expanded`}>
                      <td colSpan={9} className="p-0">
                        <SettlementTransactions settlementId={settlement.id} />
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-border p-4">
          <p className="text-sm text-muted-foreground">
            Showing 1 to {filteredSettlements.length} of {filteredSettlements.length} settlements
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">Page 1 of 1</span>
            <Button variant="outline" size="sm" disabled>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
