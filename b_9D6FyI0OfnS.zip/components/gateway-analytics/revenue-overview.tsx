"use client"

import { Card, CardContent } from "@/components/ui/card"
import { IndianRupee, TrendingUp, PiggyBank, Percent, ArrowUpRight } from "lucide-react"

const stats = [
  {
    name: "Total Collections",
    value: "₹12.4 Cr",
    change: "+12.5%",
    icon: IndianRupee,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    name: "ERP Revenue",
    value: "₹6.2 L",
    change: "+18.3%",
    description: "Platform fee earnings",
    icon: PiggyBank,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    name: "Avg. Transaction",
    value: "₹9,950",
    change: "+5.2%",
    icon: TrendingUp,
    color: "text-info",
    bgColor: "bg-info/10",
  },
  {
    name: "Revenue Rate",
    value: "0.50%",
    change: "Flat rate",
    description: "Per transaction",
    icon: Percent,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
]

export function RevenueOverview() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.name} className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div className="flex items-center gap-1 text-sm font-medium text-success">
                {stat.change}
                {stat.change.includes("+") && <ArrowUpRight className="h-4 w-4" />}
              </div>
            </div>
            <div className="mt-4">
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm font-medium text-foreground/90">{stat.name}</p>
              {stat.description && <p className="text-xs text-muted-foreground">{stat.description}</p>}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
