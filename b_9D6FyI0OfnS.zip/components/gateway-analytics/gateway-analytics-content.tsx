"use client"

import { useState } from "react"
import { RevenueOverview } from "./revenue-overview"
import { EarningsBreakdown } from "./earnings-breakdown"
import { GatewayComparison } from "./gateway-comparison"
import { RevenueByInstitute } from "./revenue-by-institute"
import { FeeAnalytics } from "./fee-analytics"
import { DateRangePicker } from "@/components/date-range-picker"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function GatewayAnalyticsContent() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Revenue & Gateway Analytics</h1>
          <p className="text-muted-foreground">ERP earnings breakdown and gateway performance metrics</p>
        </div>
        <DateRangePicker />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-secondary">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="earnings">ERP Earnings</TabsTrigger>
          <TabsTrigger value="gateways">Gateway Performance</TabsTrigger>
          <TabsTrigger value="institutes">By Institute</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6 space-y-6">
          <RevenueOverview />
          <div className="grid gap-6 lg:grid-cols-2">
            <EarningsBreakdown />
            <FeeAnalytics />
          </div>
        </TabsContent>

        <TabsContent value="earnings" className="mt-6 space-y-6">
          <EarningsBreakdown fullWidth />
          <FeeAnalytics fullWidth />
        </TabsContent>

        <TabsContent value="gateways" className="mt-6 space-y-6">
          <GatewayComparison />
        </TabsContent>

        <TabsContent value="institutes" className="mt-6 space-y-6">
          <RevenueByInstitute />
        </TabsContent>
      </Tabs>
    </div>
  )
}
