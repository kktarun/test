"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"

const earningsData = [
  { name: "Platform Fee (0.5%)", value: 620000, color: "#22c55e" },
  { name: "Gateway Markup", value: 185000, color: "#3b82f6" },
  { name: "Convenience Fee", value: 124000, color: "#eab308" },
  { name: "Late Payment Charges", value: 45000, color: "#a855f7" },
]

const monthlyEarnings = [
  { month: "Oct", platformFee: 480000, markup: 145000, convenience: 98000 },
  { month: "Nov", platformFee: 520000, markup: 158000, convenience: 105000 },
  { month: "Dec", platformFee: 580000, markup: 172000, convenience: 118000 },
  { month: "Jan", platformFee: 620000, markup: 185000, convenience: 124000 },
]

interface EarningsBreakdownProps {
  fullWidth?: boolean
}

export function EarningsBreakdown({ fullWidth }: EarningsBreakdownProps) {
  const totalEarnings = earningsData.reduce((sum, item) => sum + item.value, 0)

  return (
    <Card className={`bg-card border-border ${fullWidth ? "" : ""}`}>
      <CardHeader>
        <CardTitle className="text-lg font-semibold">ERP Earnings Breakdown</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={earningsData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {earningsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#1e1e2e",
                    border: "1px solid #2a2a3e",
                    borderRadius: "8px",
                  }}
                  formatter={(value: number) => [`₹${(value / 1000).toFixed(1)}K`, ""]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-4">
            <div className="text-center lg:text-left">
              <p className="text-sm text-muted-foreground">Total ERP Earnings</p>
              <p className="text-3xl font-bold text-primary">₹{(totalEarnings / 100000).toFixed(2)} L</p>
            </div>

            <div className="space-y-3">
              {earningsData.map((item) => (
                <div key={item.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-sm">{item.name}</span>
                  </div>
                  <span className="font-medium">₹{(item.value / 1000).toFixed(1)}K</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
