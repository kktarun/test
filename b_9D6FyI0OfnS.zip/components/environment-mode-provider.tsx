"use client"

import * as React from "react"

type EnvironmentMode = "live" | "test"

interface EnvironmentModeContextType {
  mode: EnvironmentMode
  setMode: (mode: EnvironmentMode) => void
}

const EnvironmentModeContext = React.createContext<EnvironmentModeContextType | undefined>(undefined)

export function EnvironmentModeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = React.useState<EnvironmentMode>("live")

  return <EnvironmentModeContext.Provider value={{ mode, setMode }}>{children}</EnvironmentModeContext.Provider>
}

export function useEnvironmentMode() {
  const context = React.useContext(EnvironmentModeContext)
  if (context === undefined) {
    throw new Error("useEnvironmentMode must be used within an EnvironmentModeProvider")
  }
  return context
}
