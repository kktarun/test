"use client"

import { Card, CardContent } from "@/components/ui/card"
import { CreditCard, CheckCircle, AlertTriangle, Wrench, IndianRupee, TrendingUp } from "lucide-react"

const stats = [
  {
    title: "Total Devices",
    value: "156",
    change: "+12 this month",
    changeType: "positive",
    icon: CreditCard,
  },
  {
    title: "Active Devices",
    value: "142",
    change: "91% of total",
    changeType: "neutral",
    icon: CheckCircle,
  },
  {
    title: "In Maintenance",
    value: "8",
    change: "3 returning soon",
    changeType: "warning",
    icon: Wrench,
  },
  {
    title: "Faulty / Inactive",
    value: "6",
    change: "2 pending replacement",
    changeType: "negative",
    icon: AlertTriangle,
  },
  {
    title: "Today's POS Collections",
    value: "₹4.2L",
    change: "+18% vs yesterday",
    changeType: "positive",
    icon: IndianRupee,
  },
  {
    title: "Avg. Txn per Device",
    value: "24",
    change: "Today",
    changeType: "neutral",
    icon: TrendingUp,
  },
]

export function PosDeviceStats() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {stats.map((stat) => (
        <Card key={stat.title} className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <stat.icon className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div className="mt-3">
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.title}</p>
            </div>
            <p
              className={`mt-1 text-xs ${
                stat.changeType === "positive"
                  ? "text-success"
                  : stat.changeType === "negative"
                    ? "text-destructive"
                    : stat.changeType === "warning"
                      ? "text-warning"
                      : "text-muted-foreground"
              }`}
            >
              {stat.change}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
