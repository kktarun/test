"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Download, ChevronLeft, ChevronRight, CreditCard, Smartphone, QrCode } from "lucide-react"

interface PosDevice {
  id: string
  serialNumber: string
  model: string
  manufacturer: string
  institute: {
    id: string
    name: string
  }
  location: string
  status: "active" | "inactive" | "maintenance" | "faulty"
  lastOnline: string
  todayTxnCount: number
  todayCollection: number
  assignedDate: string
  firmwareVersion: string
  connectivity: "online" | "offline"
}

interface PosTransactionHistoryModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  device: PosDevice
}

interface Transaction {
  id: string
  timestamp: string
  studentName: string
  studentId: string
  amount: number
  feeType: string
  paymentMethod: "card" | "upi" | "qr"
  status: "success" | "failed" | "pending"
  cardLast4?: string
  upiId?: string
}

const mockTransactions: Transaction[] = [
  {
    id: "TXN001",
    timestamp: "2024-01-15T10:30:00",
    studentName: "Rahul Sharma",
    studentId: "STU2024001",
    amount: 15000,
    feeType: "Tuition Fee",
    paymentMethod: "card",
    status: "success",
    cardLast4: "4521",
  },
  {
    id: "TXN002",
    timestamp: "2024-01-15T10:15:00",
    studentName: "Priya Patel",
    studentId: "STU2024002",
    amount: 5000,
    feeType: "Library Fee",
    paymentMethod: "upi",
    status: "success",
    upiId: "priya@paytm",
  },
  {
    id: "TXN003",
    timestamp: "2024-01-15T09:45:00",
    studentName: "Amit Kumar",
    studentId: "STU2024003",
    amount: 25000,
    feeType: "Semester Fee",
    paymentMethod: "card",
    status: "success",
    cardLast4: "8976",
  },
  {
    id: "TXN004",
    timestamp: "2024-01-15T09:30:00",
    studentName: "Sneha Singh",
    studentId: "STU2024004",
    amount: 3500,
    feeType: "Exam Fee",
    paymentMethod: "qr",
    status: "success",
  },
  {
    id: "TXN005",
    timestamp: "2024-01-15T09:15:00",
    studentName: "Vikram Reddy",
    studentId: "STU2024005",
    amount: 12000,
    feeType: "Hostel Fee",
    paymentMethod: "card",
    status: "failed",
    cardLast4: "3345",
  },
  {
    id: "TXN006",
    timestamp: "2024-01-15T09:00:00",
    studentName: "Ananya Gupta",
    studentId: "STU2024006",
    amount: 8000,
    feeType: "Transport Fee",
    paymentMethod: "upi",
    status: "success",
    upiId: "ananya@gpay",
  },
]

const statusColors = {
  success: "bg-success/10 text-success border-success/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
  pending: "bg-warning/10 text-warning border-warning/20",
}

const paymentMethodIcons = {
  card: CreditCard,
  upi: Smartphone,
  qr: QrCode,
}

export function PosTransactionHistoryModal({ open, onOpenChange, device }: PosTransactionHistoryModalProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("today")

  const filteredTransactions = mockTransactions.filter((txn) => {
    if (statusFilter !== "all" && txn.status !== statusFilter) return false
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        txn.studentName.toLowerCase().includes(query) ||
        txn.studentId.toLowerCase().includes(query) ||
        txn.id.toLowerCase().includes(query)
      )
    }
    return true
  })

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Transaction History - {device.id}</DialogTitle>
          <p className="text-sm text-muted-foreground">
            {device.model} at {device.location}, {device.institute.name}
          </p>
        </DialogHeader>

        <div className="flex flex-wrap items-center gap-3 py-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by student name or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-secondary pl-10"
            />
          </div>
          <Select value={dateFilter} onValueChange={setDateFilter}>
            <SelectTrigger className="w-32 bg-secondary">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-32 bg-secondary">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="success">Success</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>

        <div className="rounded-lg border border-border overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Transaction</th>
                <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Student</th>
                <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Fee Type</th>
                <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Amount</th>
                <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Method</th>
                <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map((txn) => {
                const PaymentIcon = paymentMethodIcons[txn.paymentMethod]
                return (
                  <tr key={txn.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                    <td className="p-3">
                      <div>
                        <p className="font-medium text-sm">{txn.id}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(txn.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </td>
                    <td className="p-3">
                      <div>
                        <p className="font-medium text-sm">{txn.studentName}</p>
                        <p className="text-xs text-muted-foreground">{txn.studentId}</p>
                      </div>
                    </td>
                    <td className="p-3">
                      <span className="text-sm">{txn.feeType}</span>
                    </td>
                    <td className="p-3">
                      <span className="font-semibold">₹{txn.amount.toLocaleString()}</span>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <PaymentIcon className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm capitalize">{txn.paymentMethod}</p>
                          <p className="text-xs text-muted-foreground">
                            {txn.cardLast4 ? `****${txn.cardLast4}` : txn.upiId || "QR Scan"}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3">
                      <Badge variant="outline" className={statusColors[txn.status]}>
                        {txn.status}
                      </Badge>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between pt-2">
          <p className="text-sm text-muted-foreground">Showing {filteredTransactions.length} transactions</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">Page 1 of 1</span>
            <Button variant="outline" size="sm" disabled>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
