"use client"

import { useState } from "react"
import { PosDeviceStats } from "./pos-device-stats"
import { PosDevicesTable } from "./pos-devices-table"
import { AddPosDeviceModal } from "./add-pos-device-modal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Search, Download, Upload } from "lucide-react"

export function PosDevicesContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [instituteFilter, setInstituteFilter] = useState("all")
  const [showAddModal, setShowAddModal] = useState(false)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">POS Devices</h1>
          <p className="text-muted-foreground">Manage point of sale machines across institutes</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <Upload className="h-4 w-4" />
            Bulk Import
          </Button>
          <Button className="gap-2" onClick={() => setShowAddModal(true)}>
            <Plus className="h-4 w-4" />
            Add POS Device
          </Button>
        </div>
      </div>

      <PosDeviceStats />

      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[250px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by device ID, serial number, or institute..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-secondary pl-10"
          />
        </div>
        <Select value={instituteFilter} onValueChange={setInstituteFilter}>
          <SelectTrigger className="w-48 bg-secondary">
            <SelectValue placeholder="All Institutes" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Institutes</SelectItem>
            <SelectItem value="INST001">Delhi Public School</SelectItem>
            <SelectItem value="INST002">Amity University</SelectItem>
            <SelectItem value="INST003">St. Mary's College</SelectItem>
            <SelectItem value="INST004">Ryan International</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36 bg-secondary">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
            <SelectItem value="maintenance">Maintenance</SelectItem>
            <SelectItem value="faulty">Faulty</SelectItem>
          </SelectContent>
        </Select>
        <Button variant="outline" className="gap-2 bg-transparent">
          <Download className="h-4 w-4" />
          Export
        </Button>
      </div>

      <PosDevicesTable searchQuery={searchQuery} statusFilter={statusFilter} instituteFilter={instituteFilter} />

      <AddPosDeviceModal open={showAddModal} onOpenChange={setShowAddModal} />
    </div>
  )
}
