"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { CreditCard, Building2, MapPin, Settings, Check } from "lucide-react"

interface AddPosDeviceModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const institutes = [
  { id: "INST001", name: "Delhi Public School" },
  { id: "INST002", name: "Amity University" },
  { id: "INST003", name: "St. Mary's College" },
  { id: "INST004", name: "Ryan International" },
  { id: "INST005", name: "Modern School" },
]

const manufacturers = [
  { id: "paytm", name: "Paytm", models: ["Soundbox 2.0", "EDC Machine", "All-in-One"] },
  { id: "pinelabs", name: "Pine Labs", models: ["P1000", "P2000", "Plutus Smart"] },
  { id: "razorpay", name: "Razorpay", models: ["POS Terminal", "QR Stand"] },
  { id: "mswipe", name: "Mswipe", models: ["WisePOS", "WisePad 3"] },
  { id: "bharatpe", name: "BharatPe", models: ["Swipe Machine", "Soundbox"] },
  { id: "phonepe", name: "PhonePe", models: ["SmartSpeaker", "POS Device"] },
]

export function AddPosDeviceModal({ open, onOpenChange }: AddPosDeviceModalProps) {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    serialNumber: "",
    manufacturer: "",
    model: "",
    institute: "",
    location: "",
    simNumber: "",
    notes: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const selectedManufacturer = manufacturers.find((m) => m.id === formData.manufacturer)

  const handleSubmit = async () => {
    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setIsSuccess(true)
    setTimeout(() => {
      setIsSuccess(false)
      setStep(1)
      setFormData({
        serialNumber: "",
        manufacturer: "",
        model: "",
        institute: "",
        location: "",
        simNumber: "",
        notes: "",
      })
      onOpenChange(false)
    }, 2000)
  }

  const canProceedToStep2 = formData.serialNumber && formData.manufacturer && formData.model
  const canProceedToStep3 = formData.institute && formData.location

  if (isSuccess) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <div className="flex flex-col items-center justify-center py-8">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-success/10">
              <Check className="h-8 w-8 text-success" />
            </div>
            <h3 className="mt-4 text-lg font-semibold">Device Added Successfully</h3>
            <p className="mt-2 text-center text-sm text-muted-foreground">
              The POS device has been registered and assigned to the institute.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Add New POS Device</DialogTitle>
          <DialogDescription>Register a new point of sale device and assign it to an institute</DialogDescription>
        </DialogHeader>

        {/* Steps Indicator */}
        <div className="flex items-center gap-2 py-4">
          {[
            { num: 1, label: "Device Info", icon: CreditCard },
            { num: 2, label: "Assignment", icon: Building2 },
            { num: 3, label: "Configuration", icon: Settings },
          ].map((s, i) => (
            <div key={s.num} className="flex items-center">
              <div
                className={`flex items-center gap-2 rounded-lg px-3 py-2 ${
                  step === s.num
                    ? "bg-primary text-primary-foreground"
                    : step > s.num
                      ? "bg-success/10 text-success"
                      : "bg-secondary text-muted-foreground"
                }`}
              >
                <s.icon className="h-4 w-4" />
                <span className="text-sm font-medium">{s.label}</span>
              </div>
              {i < 2 && <div className="mx-2 h-px w-8 bg-border" />}
            </div>
          ))}
        </div>

        {/* Step 1: Device Info */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="serialNumber">Serial Number *</Label>
                <Input
                  id="serialNumber"
                  placeholder="SN-2024-XXXXXX"
                  value={formData.serialNumber}
                  onChange={(e) => setFormData({ ...formData, serialNumber: e.target.value })}
                  className="bg-secondary"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="simNumber">SIM/IMEI Number</Label>
                <Input
                  id="simNumber"
                  placeholder="Optional"
                  value={formData.simNumber}
                  onChange={(e) => setFormData({ ...formData, simNumber: e.target.value })}
                  className="bg-secondary"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Manufacturer *</Label>
              <div className="grid grid-cols-3 gap-2">
                {manufacturers.map((mfr) => (
                  <Card
                    key={mfr.id}
                    className={`cursor-pointer transition-all ${
                      formData.manufacturer === mfr.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => setFormData({ ...formData, manufacturer: mfr.id, model: "" })}
                  >
                    <CardContent className="flex items-center justify-center p-3">
                      <span className="text-sm font-medium">{mfr.name}</span>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {selectedManufacturer && (
              <div className="space-y-2">
                <Label htmlFor="model">Model *</Label>
                <Select value={formData.model} onValueChange={(value) => setFormData({ ...formData, model: value })}>
                  <SelectTrigger className="bg-secondary">
                    <SelectValue placeholder="Select model" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedManufacturer.models.map((model) => (
                      <SelectItem key={model} value={model}>
                        {model}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        )}

        {/* Step 2: Assignment */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="institute">Assign to Institute *</Label>
              <Select
                value={formData.institute}
                onValueChange={(value) => setFormData({ ...formData, institute: value })}
              >
                <SelectTrigger className="bg-secondary">
                  <SelectValue placeholder="Select institute" />
                </SelectTrigger>
                <SelectContent>
                  {institutes.map((inst) => (
                    <SelectItem key={inst.id} value={inst.id}>
                      <div className="flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-muted-foreground" />
                        {inst.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Device Location *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="location"
                  placeholder="e.g., Main Reception, Accounts Office, Canteen"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="bg-secondary pl-10"
                />
              </div>
              <p className="text-xs text-muted-foreground">Specify where this device will be physically placed</p>
            </div>

            <Card className="border-border bg-secondary/30">
              <CardContent className="p-4">
                <h4 className="text-sm font-medium">Selected Device</h4>
                <p className="mt-1 text-sm text-muted-foreground">
                  {selectedManufacturer?.name} {formData.model}
                </p>
                <p className="text-xs text-muted-foreground">SN: {formData.serialNumber}</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Step 3: Configuration */}
        {step === 3 && (
          <div className="space-y-4">
            <Card className="border-border bg-secondary/30">
              <CardContent className="p-4 space-y-3">
                <h4 className="text-sm font-medium">Device Summary</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-muted-foreground">Device</p>
                    <p className="font-medium">
                      {selectedManufacturer?.name} {formData.model}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Serial Number</p>
                    <p className="font-medium">{formData.serialNumber}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Institute</p>
                    <p className="font-medium">{institutes.find((i) => i.id === formData.institute)?.name}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Location</p>
                    <p className="font-medium">{formData.location}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                placeholder="Any special configuration notes or instructions..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="bg-secondary min-h-[100px]"
              />
            </div>

            <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
              <h4 className="text-sm font-medium text-primary">Auto Configuration</h4>
              <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                <li>- Device will be registered with the payment gateway</li>
                <li>- Settlement account will be linked automatically</li>
                <li>- Firmware updates will be pushed OTA</li>
              </ul>
            </div>
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-0">
          {step > 1 && (
            <Button variant="outline" onClick={() => setStep(step - 1)}>
              Back
            </Button>
          )}
          {step < 3 ? (
            <Button onClick={() => setStep(step + 1)} disabled={step === 1 ? !canProceedToStep2 : !canProceedToStep3}>
              Continue
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? "Registering..." : "Register Device"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
