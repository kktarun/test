"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CreditCard,
  Building2,
  MapPin,
  Calendar,
  Wifi,
  WifiOff,
  Cpu,
  RefreshCw,
  IndianRupee,
  TrendingUp,
  Clock,
} from "lucide-react"

interface PosDevice {
  id: string
  serialNumber: string
  model: string
  manufacturer: string
  institute: {
    id: string
    name: string
  }
  location: string
  status: "active" | "inactive" | "maintenance" | "faulty"
  lastOnline: string
  todayTxnCount: number
  todayCollection: number
  assignedDate: string
  firmwareVersion: string
  connectivity: "online" | "offline"
}

interface PosDeviceDetailModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  device: PosDevice
}

const statusColors = {
  active: "bg-success/10 text-success border-success/20",
  inactive: "bg-muted text-muted-foreground border-border",
  maintenance: "bg-warning/10 text-warning border-warning/20",
  faulty: "bg-destructive/10 text-destructive border-destructive/20",
}

// Mock performance data
const performanceData = {
  thisWeek: { txns: 234, amount: 567000 },
  thisMonth: { txns: 892, amount: 2340000 },
  avgTxnValue: 2625,
  uptime: "99.2%",
  lastMaintenance: "2024-01-05",
}

export function PosDeviceDetailModal({ open, onOpenChange, device }: PosDeviceDetailModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              {device.model}
            </DialogTitle>
            <Badge variant="outline" className={statusColors[device.status]}>
              {device.status}
            </Badge>
          </div>
        </DialogHeader>

        <Tabs defaultValue="overview" className="mt-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="configuration">Configuration</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            {/* Device Info */}
            <Card className="border-border">
              <CardContent className="p-4">
                <h4 className="text-sm font-semibold mb-3">Device Information</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-start gap-2">
                    <CreditCard className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-muted-foreground">Device ID</p>
                      <p className="font-medium">{device.id}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Cpu className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-muted-foreground">Serial Number</p>
                      <p className="font-medium">{device.serialNumber}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Building2 className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-muted-foreground">Institute</p>
                      <p className="font-medium">{device.institute.name}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-muted-foreground">Location</p>
                      <p className="font-medium">{device.location}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-muted-foreground">Assigned Date</p>
                      <p className="font-medium">{new Date(device.assignedDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    {device.connectivity === "online" ? (
                      <Wifi className="h-4 w-4 text-success mt-0.5" />
                    ) : (
                      <WifiOff className="h-4 w-4 text-muted-foreground mt-0.5" />
                    )}
                    <div>
                      <p className="text-muted-foreground">Connectivity</p>
                      <p className={`font-medium ${device.connectivity === "online" ? "text-success" : ""}`}>
                        {device.connectivity === "online" ? "Online" : "Offline"}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Today's Stats */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <TrendingUp className="h-4 w-4" />
                    <span className="text-sm">Today's Transactions</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold">{device.todayTxnCount}</p>
                </CardContent>
              </Card>
              <Card className="border-border">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <IndianRupee className="h-4 w-4" />
                    <span className="text-sm">Today's Collection</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold">₹{(device.todayCollection / 1000).toFixed(1)}K</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <Card className="border-border">
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">This Week</p>
                  <p className="text-xl font-bold mt-1">{performanceData.thisWeek.txns} txns</p>
                  <p className="text-sm text-muted-foreground">
                    ₹{(performanceData.thisWeek.amount / 100000).toFixed(2)}L collected
                  </p>
                </CardContent>
              </Card>
              <Card className="border-border">
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">This Month</p>
                  <p className="text-xl font-bold mt-1">{performanceData.thisMonth.txns} txns</p>
                  <p className="text-sm text-muted-foreground">
                    ₹{(performanceData.thisMonth.amount / 100000).toFixed(2)}L collected
                  </p>
                </CardContent>
              </Card>
              <Card className="border-border">
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Avg. Transaction Value</p>
                  <p className="text-xl font-bold mt-1">₹{performanceData.avgTxnValue.toLocaleString()}</p>
                </CardContent>
              </Card>
              <Card className="border-border">
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground">Uptime (30 days)</p>
                  <p className="text-xl font-bold mt-1 text-success">{performanceData.uptime}</p>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Last Maintenance</span>
                  </div>
                  <span className="text-sm font-medium">
                    {new Date(performanceData.lastMaintenance).toLocaleDateString()}
                  </span>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="configuration" className="space-y-4 mt-4">
            <Card className="border-border">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Firmware Version</p>
                    <p className="text-sm text-muted-foreground">{device.firmwareVersion}</p>
                  </div>
                  <Button size="sm" variant="outline" className="gap-2 bg-transparent">
                    <RefreshCw className="h-4 w-4" />
                    Check Update
                  </Button>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="font-medium">Manufacturer</p>
                  <p className="text-sm text-muted-foreground">{device.manufacturer}</p>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="font-medium">Model</p>
                  <p className="text-sm text-muted-foreground">{device.model}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-secondary/30">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">Settlement Configuration</h4>
                <p className="text-sm text-muted-foreground">
                  This device is linked to the settlement account of <strong>{device.institute.name}</strong>. All
                  transactions are settled T+1 (next business day).
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
