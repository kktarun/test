"use client"

import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  ArrowLeftRight,
  Wallet,
  RotateCcw,
  AlertTriangle,
  SplitSquareHorizontal,
  Building2,
  FileText,
  CreditCard,
  Settings,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  Repeat,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Transactions", href: "/transactions", icon: ArrowLeftRight },
  { name: "Settlements", href: "/settlements", icon: Wallet },
  { name: "Refunds", href: "/refunds", icon: RotateCcw },
  { name: "Chargebacks", href: "/chargebacks", icon: AlertTriangle },
  { name: "Split Payments", href: "/split-payments", icon: SplitSquareHorizontal },
  { name: "Institutes", href: "/institutes", icon: Building2 },
  { name: "Payment Forms", href: "/payment-forms", icon: FileText },
  { name: "Auto Debit", href: "/auto-debit", icon: Repeat },
  { name: "Gateway Analytics", href: "/gateway-analytics", icon: BarChart3 },
  { name: "POS Devices", href: "/pos-devices", icon: CreditCard },
  { name: "Settings", href: "/settings", icon: Settings },
  { name: "Brochure", href: "/brochure", icon: FileText },
]

interface SidebarProps {
  collapsed: boolean
  onToggle: () => void
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const pathname = usePathname()

  return (
    <aside
      className={cn(
        "flex flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-4">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <span className="text-sm font-bold text-primary-foreground">CN</span>
          </div>
            <span className="font-semibold text-sidebar-foreground">ClearN</span>
          </div>
        )}
        <button
          onClick={onToggle}
          className="flex h-8 w-8 items-center justify-center rounded-md text-sidebar-foreground hover:bg-sidebar-accent"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      <nav className="flex-1 space-y-1 p-2">
        {navigation.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
              )}
            >
              <item.icon className="h-5 w-5 shrink-0" />
              {!collapsed && <span>{item.name}</span>}
            </Link>
          )
        })}
      </nav>

      {!collapsed && (
        <div className="border-t border-sidebar-border p-4">
          <div className="rounded-lg bg-sidebar-accent p-3">
            <p className="text-xs font-medium text-sidebar-foreground">Partner Dashboard</p>
            <p className="text-sm font-semibold text-sidebar-primary">SparkIT</p>
            <p className="mt-1 text-xs text-sidebar-foreground/60">127 Institutes Connected</p>
          </div>
        </div>
      )}
    </aside>
  )
}
