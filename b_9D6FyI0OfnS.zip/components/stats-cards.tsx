"use client"

import { Card, CardContent } from "@/components/ui/card"
import { ArrowUpRight, ArrowDownRight, IndianRupee, ArrowLeftRight, Building2, Percent } from "lucide-react"

const stats = [
  {
    name: "Total Collections",
    value: "₹12.4 Cr",
    change: "+12.5%",
    trend: "up",
    icon: IndianRupee,
    subtitle: "This month",
  },
  {
    name: "Transactions",
    value: "1,24,567",
    change: "+8.2%",
    trend: "up",
    icon: ArrowLeftRight,
    subtitle: "This month",
  },
  {
    name: "Active Institutes",
    value: "127",
    change: "+3",
    trend: "up",
    icon: Building2,
    subtitle: "New this month",
  },
  {
    name: "Success Rate",
    value: "98.7%",
    change: "-0.2%",
    trend: "down",
    icon: Percent,
    subtitle: "Across all gateways",
  },
]

export function StatsCards() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.name} className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <stat.icon className="h-5 w-5 text-primary" />
              </div>
              <div
                className={`flex items-center gap-1 text-sm font-medium ${
                  stat.trend === "up" ? "text-success" : "text-destructive"
                }`}
              >
                {stat.change}
                {stat.trend === "up" ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
              </div>
            </div>
            <div className="mt-4">
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm font-medium text-foreground/90">{stat.name}</p>
              <p className="text-xs text-muted-foreground">{stat.subtitle}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
