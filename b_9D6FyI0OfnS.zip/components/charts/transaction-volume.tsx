"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { name: "Mon", online: 4200, pos: 1800, upi: 3200 },
  { name: "Tue", online: 3800, pos: 2100, upi: 2900 },
  { name: "Wed", online: 5100, pos: 1900, upi: 3800 },
  { name: "Thu", online: 4700, pos: 2300, upi: 3400 },
  { name: "Fri", online: 6200, pos: 2600, upi: 4100 },
  { name: "Sat", online: 3200, pos: 1200, upi: 2100 },
  { name: "Sun", online: 2800, pos: 900, upi: 1800 },
]

export function TransactionVolume() {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Transaction Volume by Channel</CardTitle>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-chart-1" />
              <span className="text-muted-foreground">Online</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-chart-2" />
              <span className="text-muted-foreground">POS</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-chart-3" />
              <span className="text-muted-foreground">UPI</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full min-w-0">
          <ResponsiveContainer width="100%" height="100%" minWidth={0}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
              <XAxis dataKey="name" stroke="#6b7280" fontSize={12} />
              <YAxis stroke="#6b7280" fontSize={12} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1e1e2e",
                  border: "1px solid #2a2a3e",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="online" fill="#22c55e" radius={[4, 4, 0, 0]} />
              <Bar dataKey="pos" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="upi" fill="#eab308" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
