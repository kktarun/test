"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const gateways = [
  { name: "Razorpay", volume: "₹4.2 Cr", percentage: 34, transactions: "42,156", color: "bg-chart-1" },
  { name: "Cashfree", volume: "₹3.1 Cr", percentage: 25, transactions: "31,245", color: "bg-chart-2" },
  { name: "Easebuzz", volume: "₹2.4 Cr", percentage: 19, transactions: "24,891", color: "bg-chart-3" },
  { name: "Paytm", volume: "₹1.5 Cr", percentage: 12, transactions: "15,234", color: "bg-chart-4" },
  { name: "Others", volume: "₹1.2 Cr", percentage: 10, transactions: "11,041", color: "bg-chart-5" },
]

export function GatewayBreakdown() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Gateway Distribution</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {gateways.map((gateway) => (
          <div key={gateway.name} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">{gateway.name}</span>
              <span className="text-muted-foreground">{gateway.volume}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative h-2 flex-1 rounded-full bg-secondary">
                <div
                  className={`absolute h-2 rounded-full ${gateway.color}`}
                  style={{ width: `${gateway.percentage}%` }}
                />
              </div>
              <span className="text-xs text-muted-foreground w-10">{gateway.percentage}%</span>
            </div>
            <p className="text-xs text-muted-foreground">{gateway.transactions} transactions</p>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
