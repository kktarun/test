"use client"

import { useState } from "react"
import { CalendarIcon } from "lucide-react"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const ranges = [
  { label: "Today", value: "today" },
  { label: "Yesterday", value: "yesterday" },
  { label: "Last 7 days", value: "7d" },
  { label: "Last 30 days", value: "30d" },
  { label: "This month", value: "month" },
  { label: "Last month", value: "last-month" },
  { label: "Custom range", value: "custom" },
]

export function DateRangePicker() {
  const [selected, setSelected] = useState("30d")
  const selectedRange = ranges.find((r) => r.value === selected)

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2 bg-transparent">
          <CalendarIcon className="h-4 w-4" />
          {selectedRange?.label}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {ranges.map((range) => (
          <DropdownMenuItem key={range.value} onClick={() => setSelected(range.value)}>
            {range.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
