"use client"

import { Card, CardContent } from "@/components/ui/card"
import { SplitSquareHorizontal, Users, Building, TrendingUp } from "lucide-react"

const stats = [
  {
    title: "Total Split Amount",
    value: "₹4.25Cr",
    subtext: "This Month",
    icon: SplitSquareHorizontal,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    title: "Split Transactions",
    value: "12,456",
    subtext: "Across 127 Institutes",
    icon: TrendingUp,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    title: "Active Vendors",
    value: "342",
    subtext: "Receiving Splits",
    icon: Users,
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
  },
  {
    title: "Institutes with Splits",
    value: "89",
    subtext: "Using Split Feature",
    icon: Building,
    color: "text-orange-500",
    bgColor: "bg-orange-500/10",
  },
]

export function SplitPaymentStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <Card key={stat.title} className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
            </div>
            <div className="mt-3">
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.title}</p>
              <p className="text-xs text-muted-foreground mt-1">{stat.subtext}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
