"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Copy, Download, Building, Users, Truck, CreditCard } from "lucide-react"

interface SplitVendor {
  vendorId: string
  vendorName: string
  vendorType: string
  accountNumber: string
  ifsc: string
  amount: number
  percentage: number
  status: "settled" | "pending" | "processing"
  settlementDate?: string
  utr?: string
}

interface SplitTransaction {
  id: string
  transactionId: string
  institute: string
  studentName: string
  feeType: string
  totalAmount: number
  gateway: string
  date: string
  status: "completed" | "pending" | "partial"
  splits: SplitVendor[]
}

interface SplitDetailModalProps {
  transaction: SplitTransaction | null
  onClose: () => void
}

const statusColors = {
  completed: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  partial: "bg-blue-500/10 text-blue-500 border-blue-500/20",
}

const vendorTypeIcons: Record<string, any> = {
  Institute: Building,
  Transport: Truck,
  Vendor: Users,
  Platform: CreditCard,
  Hostel: Building,
}

const vendorStatusColors = {
  settled: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  processing: "bg-blue-500/10 text-blue-500 border-blue-500/20",
}

export function SplitDetailModal({ transaction, onClose }: SplitDetailModalProps) {
  if (!transaction) return null

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const settledAmount = transaction.splits.filter((s) => s.status === "settled").reduce((sum, s) => sum + s.amount, 0)

  const pendingAmount = transaction.totalAmount - settledAmount

  return (
    <Dialog open={!!transaction} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl bg-card max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-3">
              <span className="font-mono">{transaction.id}</span>
              <Badge variant="outline" className={statusColors[transaction.status]}>
                {transaction.status}
              </Badge>
            </DialogTitle>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          <div className="grid grid-cols-3 gap-4">
            <div className="rounded-lg bg-secondary/50 p-4 text-center">
              <p className="text-sm text-muted-foreground">Total Amount</p>
              <p className="text-2xl font-bold">₹{transaction.totalAmount.toLocaleString()}</p>
            </div>
            <div className="rounded-lg bg-success/10 p-4 text-center">
              <p className="text-sm text-success">Settled</p>
              <p className="text-2xl font-bold text-success">₹{settledAmount.toLocaleString()}</p>
            </div>
            <div className="rounded-lg bg-warning/10 p-4 text-center">
              <p className="text-sm text-warning">Pending</p>
              <p className="text-2xl font-bold text-warning">₹{pendingAmount.toLocaleString()}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase">Transaction Details</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Transaction ID</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm">{transaction.transactionId}</span>
                    <button onClick={() => copyToClipboard(transaction.transactionId)}>
                      <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                    </button>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gateway</span>
                  <span>{transaction.gateway}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Date</span>
                  <span>{transaction.date}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase">Payer Details</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Institute</span>
                  <span>{transaction.institute}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Student</span>
                  <span>{transaction.studentName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Fee Type</span>
                  <span>{transaction.feeType}</span>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase">
              Split Breakdown ({transaction.splits.length} Vendors)
            </h3>

            <div className="space-y-3">
              {transaction.splits.map((split, index) => {
                const Icon = vendorTypeIcons[split.vendorType] || Users
                const colors = ["bg-primary", "bg-blue-500", "bg-orange-500", "bg-purple-500", "bg-teal-500"]

                return (
                  <div key={split.vendorId} className="rounded-lg bg-secondary/30 p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-1 h-12 rounded-full ${colors[index % colors.length]}`} />
                        <div>
                          <div className="flex items-center gap-2">
                            <Icon className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{split.vendorName}</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {split.vendorType} • A/C: {split.accountNumber} • IFSC: {split.ifsc}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline" className={vendorStatusColors[split.status]}>
                        {split.status}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex-1 mr-4">
                        <Progress value={split.percentage} className="h-2" />
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">₹{split.amount.toLocaleString()}</p>
                        <p className="text-xs text-muted-foreground">{split.percentage.toFixed(2)}%</p>
                      </div>
                    </div>

                    {split.status === "settled" && (
                      <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t border-border">
                        <span>Settled on {split.settlementDate}</span>
                        {split.utr && (
                          <div className="flex items-center gap-2">
                            <span className="font-mono">UTR: {split.utr}</span>
                            <button onClick={() => copyToClipboard(split.utr!)}>
                              <Copy className="h-3 w-3 hover:text-foreground" />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>

          <div className="flex justify-end">
            <Button variant="outline" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Download Split Report
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
