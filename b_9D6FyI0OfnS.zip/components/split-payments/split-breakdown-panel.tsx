"use client"

import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Building, Users, Truck, CreditCard, CheckCircle, Clock, Loader2 } from "lucide-react"

interface SplitVendor {
  vendorId: string
  vendorName: string
  vendorType: string
  accountNumber: string
  ifsc: string
  amount: number
  percentage: number
  status: "settled" | "pending" | "processing"
  settlementDate?: string
  utr?: string
}

interface SplitBreakdownPanelProps {
  splits: SplitVendor[]
  totalAmount: number
}

const vendorTypeIcons: Record<string, any> = {
  Institute: Building,
  Transport: Truck,
  Vendor: Users,
  Platform: CreditCard,
  Hostel: Building,
}

const vendorTypeColors: Record<string, string> = {
  Institute: "bg-primary/10 text-primary",
  Transport: "bg-blue-500/10 text-blue-500",
  Vendor: "bg-orange-500/10 text-orange-500",
  Platform: "bg-purple-500/10 text-purple-500",
  Hostel: "bg-teal-500/10 text-teal-500",
}

const statusIcons = {
  settled: CheckCircle,
  pending: Clock,
  processing: Loader2,
}

const statusColors = {
  settled: "text-success",
  pending: "text-warning",
  processing: "text-blue-500",
}

export function SplitBreakdownPanel({ splits, totalAmount }: SplitBreakdownPanelProps) {
  return (
    <div className="bg-secondary/20 border-t border-border p-6">
      <div className="mb-4">
        <h4 className="text-sm font-semibold mb-2">Split Distribution</h4>
        <div className="flex h-3 rounded-full overflow-hidden">
          {splits.map((split, index) => {
            const colors = ["bg-primary", "bg-blue-500", "bg-orange-500", "bg-purple-500", "bg-teal-500"]
            return (
              <div
                key={split.vendorId}
                className={`${colors[index % colors.length]} transition-all`}
                style={{ width: `${split.percentage}%` }}
              />
            )
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {splits.map((split) => {
          const Icon = vendorTypeIcons[split.vendorType] || Users
          const StatusIcon = statusIcons[split.status]

          return (
            <div key={split.vendorId} className="rounded-lg bg-card border border-border p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-lg ${vendorTypeColors[split.vendorType]}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <StatusIcon
                  className={`h-4 w-4 ${statusColors[split.status]} ${split.status === "processing" ? "animate-spin" : ""}`}
                />
              </div>

              <div>
                <p className="text-sm font-medium line-clamp-1">{split.vendorName}</p>
                <Badge variant="outline" className="mt-1 text-xs">
                  {split.vendorType}
                </Badge>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Amount</span>
                  <span className="font-semibold">₹{split.amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Share</span>
                  <span>{split.percentage.toFixed(2)}%</span>
                </div>
              </div>

              <Progress value={split.percentage} className="h-1.5" />

              <div className="pt-2 border-t border-border space-y-1">
                <p className="text-xs text-muted-foreground">
                  A/C: {split.accountNumber} • {split.ifsc}
                </p>
                {split.status === "settled" && split.utr && (
                  <p className="text-xs text-muted-foreground truncate">UTR: {split.utr}</p>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
