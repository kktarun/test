"use client"

// Split payments table component with vendor filtering
import React, { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronRight, ChevronLeft, Eye } from "lucide-react"
import { SplitBreakdownPanel } from "./split-breakdown-panel"
import { SplitDetailModal } from "./split-detail-modal"

interface SplitVendor {
  vendorId: string
  vendorName: string
  vendorType: string
  accountNumber: string
  ifsc: string
  amount: number
  percentage: number
  status: "settled" | "pending" | "processing"
  settlementDate?: string
  utr?: string
}

interface SplitTransaction {
  id: string
  transactionId: string
  institute: string
  studentName: string
  feeType: string
  totalAmount: number
  gateway: string
  date: string
  status: "completed" | "pending" | "partial"
  splits: SplitVendor[]
}

const splitTransactions: SplitTransaction[] = [
  {
    id: "SPL001234",
    transactionId: "TXN789456123",
    institute: "Delhi Public School",
    studentName: "Rahul Sharma",
    feeType: "Admission Fee",
    totalAmount: 150000,
    gateway: "Razorpay",
    date: "2024-01-15",
    status: "completed",
    splits: [
      {
        vendorId: "VND001",
        vendorName: "Delhi Public School - Main",
        vendorType: "Institute",
        accountNumber: "****4521",
        ifsc: "HDFC0001234",
        amount: 120000,
        percentage: 80,
        status: "settled",
        settlementDate: "2024-01-16",
        utr: "RAZR2024011512345678",
      },
      {
        vendorId: "VND002",
        vendorName: "Transport Services Pvt Ltd",
        vendorType: "Transport",
        accountNumber: "****8976",
        ifsc: "ICIC0005678",
        amount: 15000,
        percentage: 10,
        status: "settled",
        settlementDate: "2024-01-16",
        utr: "RAZR2024011512345679",
      },
      {
        vendorId: "VND003",
        vendorName: "Uniform Suppliers Co",
        vendorType: "Vendor",
        accountNumber: "****3214",
        ifsc: "SBIN0009012",
        amount: 10000,
        percentage: 6.67,
        status: "settled",
        settlementDate: "2024-01-16",
        utr: "RAZR2024011512345680",
      },
      {
        vendorId: "VND004",
        vendorName: "SparkIT (Platform)",
        vendorType: "Platform",
        accountNumber: "****6543",
        ifsc: "AXIS0003456",
        amount: 5000,
        percentage: 3.33,
        status: "settled",
        settlementDate: "2024-01-16",
        utr: "RAZR2024011512345681",
      },
    ],
  },
  {
    id: "SPL001235",
    transactionId: "TXN789456124",
    institute: "St. Joseph's College",
    studentName: "Priya Patel",
    feeType: "Tuition Fee",
    totalAmount: 85000,
    gateway: "Cashfree",
    date: "2024-01-15",
    status: "partial",
    splits: [
      {
        vendorId: "VND005",
        vendorName: "St. Joseph's College - Main",
        vendorType: "Institute",
        accountNumber: "****7890",
        ifsc: "HDFC0002345",
        amount: 70000,
        percentage: 82.35,
        status: "settled",
        settlementDate: "2024-01-16",
        utr: "CSHF2024011598765432",
      },
      {
        vendorId: "VND006",
        vendorName: "Lab Equipment Suppliers",
        vendorType: "Vendor",
        accountNumber: "****1234",
        ifsc: "ICIC0006789",
        amount: 8000,
        percentage: 9.41,
        status: "pending",
      },
      {
        vendorId: "VND007",
        vendorName: "SparkIT (Platform)",
        vendorType: "Platform",
        accountNumber: "****6543",
        ifsc: "AXIS0003456",
        amount: 7000,
        percentage: 8.24,
        status: "processing",
      },
    ],
  },
  {
    id: "SPL001236",
    transactionId: "TXN789456125",
    institute: "VJTI Mumbai",
    studentName: "Amit Kumar",
    feeType: "Semester Fee",
    totalAmount: 125000,
    gateway: "Paytm",
    date: "2024-01-14",
    status: "completed",
    splits: [
      {
        vendorId: "VND008",
        vendorName: "VJTI Mumbai - Main",
        vendorType: "Institute",
        accountNumber: "****5678",
        ifsc: "SBIN0003456",
        amount: 100000,
        percentage: 80,
        status: "settled",
        settlementDate: "2024-01-15",
        utr: "PYTM2024011423456789",
      },
      {
        vendorId: "VND009",
        vendorName: "Hostel Management",
        vendorType: "Hostel",
        accountNumber: "****9012",
        ifsc: "HDFC0004567",
        amount: 20000,
        percentage: 16,
        status: "settled",
        settlementDate: "2024-01-15",
        utr: "PYTM2024011423456790",
      },
      {
        vendorId: "VND010",
        vendorName: "SparkIT (Platform)",
        vendorType: "Platform",
        accountNumber: "****6543",
        ifsc: "AXIS0003456",
        amount: 5000,
        percentage: 4,
        status: "settled",
        settlementDate: "2024-01-15",
        utr: "PYTM2024011423456791",
      },
    ],
  },
  {
    id: "SPL001237",
    transactionId: "TXN789456126",
    institute: "Modern Academy",
    studentName: "Sneha Reddy",
    feeType: "Annual Fee",
    totalAmount: 200000,
    gateway: "Easebuzz",
    date: "2024-01-14",
    status: "pending",
    splits: [
      {
        vendorId: "VND011",
        vendorName: "Modern Academy - Main",
        vendorType: "Institute",
        accountNumber: "****3456",
        ifsc: "ICIC0007890",
        amount: 160000,
        percentage: 80,
        status: "pending",
      },
      {
        vendorId: "VND012",
        vendorName: "Sports Equipment Vendor",
        vendorType: "Vendor",
        accountNumber: "****7890",
        ifsc: "HDFC0005678",
        amount: 25000,
        percentage: 12.5,
        status: "pending",
      },
      {
        vendorId: "VND013",
        vendorName: "Library Services",
        vendorType: "Vendor",
        accountNumber: "****1234",
        ifsc: "SBIN0006789",
        amount: 10000,
        percentage: 5,
        status: "pending",
      },
      {
        vendorId: "VND014",
        vendorName: "SparkIT (Platform)",
        vendorType: "Platform",
        accountNumber: "****6543",
        ifsc: "AXIS0003456",
        amount: 5000,
        percentage: 2.5,
        status: "pending",
      },
    ],
  },
]

const statusColors = {
  completed: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  partial: "bg-blue-500/10 text-blue-500 border-blue-500/20",
}

interface SplitPaymentsTableProps {
  filters: {
    institute: string
    gateway: string
    status: string
    vendor: string
  }
}

export function SplitPaymentsTable({ filters }: SplitPaymentsTableProps) {
  const [expandedSplit, setExpandedSplit] = useState<string | null>(null)
  const [detailTransaction, setDetailTransaction] = useState<SplitTransaction | null>(null)

  const filteredTransactions = splitTransactions.filter((t) => {
    if (filters.gateway !== "all" && !t.gateway.toLowerCase().includes(filters.gateway)) return false
    if (filters.status !== "all" && t.status !== filters.status) return false
    if (filters.vendor !== "all") {
      const hasVendor = t.splits.some((s) => s.vendorName.toLowerCase().includes(filters.vendor.toLowerCase()))
      if (!hasVendor) return false
    }
    return true
  })

  // Helper to get vendor names for display
  const getVendorNames = (splits: SplitVendor[]) => {
    const vendors = splits.filter(s => s.vendorType === "Vendor" || s.vendorType === "Transport")
    return vendors.map(v => v.vendorName)
  }

  const toggleExpand = (id: string) => {
    setExpandedSplit(expandedSplit === id ? null : id)
  }

  return (
    <>
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold">{filteredTransactions.length} Split Transactions</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="p-4 text-left w-10"></th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Transaction</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institute</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Vendor Name</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Fee Type</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Total Amount</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Splits</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Gateway</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((transaction) => (
                  <React.Fragment key={transaction.id}>
                    <tr
                      className="border-b border-border hover:bg-secondary/30 transition-colors cursor-pointer"
                      onClick={() => toggleExpand(transaction.id)}
                    >
                      <td className="p-4">
                        <Button variant="ghost" size="icon" className="h-6 w-6">
                          {expandedSplit === transaction.id ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                        </Button>
                      </td>
                      <td className="p-4">
                        <div>
                          <span className="font-mono text-sm font-medium text-primary">{transaction.id}</span>
                          <p className="text-xs text-muted-foreground">{transaction.transactionId}</p>
                        </div>
                      </td>
                      <td className="p-4">
                        <div>
                          <span className="text-sm font-medium">{transaction.institute}</span>
                          <p className="text-xs text-muted-foreground">{transaction.studentName}</p>
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex flex-wrap gap-1 max-w-[200px]">
                          {getVendorNames(transaction.splits).length > 0 ? (
                            getVendorNames(transaction.splits).slice(0, 2).map((vendor, idx) => (
                              <Badge key={idx} variant="outline" className="bg-orange-500/10 text-orange-400 border-orange-500/30 text-xs truncate max-w-[150px]">
                                {vendor}
                              </Badge>
                            ))
                          ) : (
                            <span className="text-muted-foreground text-xs">-</span>
                          )}
                          {getVendorNames(transaction.splits).length > 2 && (
                            <Badge variant="outline" className="bg-secondary text-muted-foreground text-xs">
                              +{getVendorNames(transaction.splits).length - 2}
                            </Badge>
                          )}
                        </div>
                      </td>
                      <td className="p-4">
                        <span className="text-sm">{transaction.feeType}</span>
                      </td>
                      <td className="p-4">
                        <span className="font-semibold">₹{transaction.totalAmount.toLocaleString()}</span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{transaction.splits.length} vendors</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className="text-sm">{transaction.gateway}</span>
                      </td>
                      <td className="p-4">
                        <Badge variant="outline" className={statusColors[transaction.status]}>
                          {transaction.status}
                        </Badge>
                      </td>
                      <td className="p-4">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation()
                            setDetailTransaction(transaction)
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                    {expandedSplit === transaction.id && (
                      <tr>
                        <td colSpan={10} className="p-0">
                          <SplitBreakdownPanel splits={transaction.splits} totalAmount={transaction.totalAmount} />
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-border p-4">
            <p className="text-sm text-muted-foreground">
              Showing 1 to {filteredTransactions.length} of {filteredTransactions.length} transactions
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm">Page 1 of 1</span>
              <Button variant="outline" size="sm" disabled>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <SplitDetailModal transaction={detailTransaction} onClose={() => setDetailTransaction(null)} />
    </>
  )
}
