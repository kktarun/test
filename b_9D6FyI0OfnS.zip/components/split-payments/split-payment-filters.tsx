"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, Download } from "lucide-react"
import { DateRangePicker } from "@/components/date-range-picker"

interface SplitPaymentFiltersProps {
  filters: {
    institute: string
    gateway: string
    status: string
    vendor: string
  }
  onFilterChange: (filters: any) => void
}

const vendors = [
  { value: "all", label: "All Vendors" },
  { value: "transport", label: "Transport Services Pvt Ltd" },
  { value: "uniform", label: "Uniform Suppliers Co" },
  { value: "books", label: "Books & Stationery Store" },
  { value: "sports", label: "Sports Academy" },
  { value: "canteen", label: "Campus Canteen Services" },
  { value: "hostel", label: "Hostel Management Co" },
]

export function SplitPaymentFilters({ filters, onFilterChange }: SplitPaymentFiltersProps) {
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search by Transaction ID, Vendor..." className="pl-9 bg-secondary/50 border-border" />
          </div>

          <Select value={filters.institute} onValueChange={(value) => onFilterChange({ ...filters, institute: value })}>
            <SelectTrigger className="w-[180px] bg-secondary/50 border-border">
              <SelectValue placeholder="All Institutes" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Institutes</SelectItem>
              <SelectItem value="dps">Delhi Public School</SelectItem>
              <SelectItem value="sjc">St. Joseph's College</SelectItem>
              <SelectItem value="vjti">VJTI Mumbai</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.gateway} onValueChange={(value) => onFilterChange({ ...filters, gateway: value })}>
            <SelectTrigger className="w-[150px] bg-secondary/50 border-border">
              <SelectValue placeholder="All Gateways" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Gateways</SelectItem>
              <SelectItem value="razorpay">Razorpay</SelectItem>
              <SelectItem value="cashfree">Cashfree</SelectItem>
              <SelectItem value="paytm">Paytm</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.status} onValueChange={(value) => onFilterChange({ ...filters, status: value })}>
            <SelectTrigger className="w-[150px] bg-secondary/50 border-border">
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="partial">Partial</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.vendor} onValueChange={(value) => onFilterChange({ ...filters, vendor: value })}>
            <SelectTrigger className="w-[200px] bg-secondary/50 border-border">
              <SelectValue placeholder="All Vendors" />
            </SelectTrigger>
            <SelectContent>
              {vendors.map((vendor) => (
                <SelectItem key={vendor.value} value={vendor.value}>{vendor.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <DateRangePicker />

          <Button variant="outline" className="gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
