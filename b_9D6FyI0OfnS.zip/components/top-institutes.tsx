"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp } from "lucide-react"

const institutes = [
  { name: "Delhi Public School", collections: "₹1.2 Cr", growth: "+15%", transactions: 12450 },
  { name: "Amity University", collections: "₹98 L", growth: "+8%", transactions: 8920 },
  { name: "St. Mary's College", collections: "₹76 L", growth: "+22%", transactions: 7650 },
  { name: "Ryan International", collections: "₹65 L", growth: "+5%", transactions: 6540 },
  { name: "Modern School", collections: "₹54 L", growth: "+12%", transactions: 5430 },
]

export function TopInstitutes() {
  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Top Performing Institutes</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {institutes.map((institute, index) => (
          <div
            key={institute.name}
            className="flex items-center gap-3 rounded-lg border border-border bg-secondary/30 p-3"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-sm font-bold text-primary">
              {index + 1}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{institute.name}</p>
              <p className="text-xs text-muted-foreground">{institute.transactions.toLocaleString()} txns</p>
            </div>
            <div className="text-right">
              <p className="font-semibold">{institute.collections}</p>
              <div className="flex items-center justify-end gap-1 text-xs text-success">
                <TrendingUp className="h-3 w-3" />
                {institute.growth}
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
