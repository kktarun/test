"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Copy,
  Download,
  Upload,
  FileText,
  ImageIcon,
  File,
  X,
  CheckCircle,
  Landmark,
  ArrowRight,
  ArrowUpRight,
  AlertCircle,
} from "lucide-react"

interface Chargeback {
  id: string
  transactionId: string
  arn: string
  institute: string
  studentName: string
  amount: number
  gateway: string
  reason: string
  reasonCode: string
  status: "open" | "under_review" | "response_submitted" | "won" | "lost" | "expired"
  raisedBy: string
  raisedDate: string
  dueDate: string
  cardType: string
  cardLast4: string
  originalSettlement?: {
    id: string
    date: string
  }
  deductedFromSettlement?: {
    id: string
    date: string
    deductionDate: string
  }
  recoveryInfo?: {
    creditedToSettlement: string
    creditedDate: string
    wonDate: string
  }
}

interface ChargebackDetailModalProps {
  chargeback: Chargeback | null
  onClose: () => void
}

const statusColors = {
  open: "bg-warning/10 text-warning border-warning/20",
  under_review: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  response_submitted: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  won: "bg-success/10 text-success border-success/20",
  lost: "bg-destructive/10 text-destructive border-destructive/20",
  expired: "bg-muted text-muted-foreground border-muted",
}

const statusLabels = {
  open: "Open",
  under_review: "Under Review",
  response_submitted: "Response Submitted",
  won: "Won",
  lost: "Lost",
  expired: "Expired",
}

const existingDocuments = [
  { name: "Transaction Receipt.pdf", type: "pdf", size: "245 KB", uploadedAt: "2024-01-14" },
  { name: "Student ID Proof.jpg", type: "image", size: "1.2 MB", uploadedAt: "2024-01-15" },
  { name: "Fee Payment Confirmation.pdf", type: "pdf", size: "89 KB", uploadedAt: "2024-01-15" },
]

export function ChargebackDetailModal({ chargeback, onClose }: ChargebackDetailModalProps) {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [responseNote, setResponseNote] = useState("")

  if (!chargeback) return null

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setUploadedFiles([...uploadedFiles, ...Array.from(e.target.files)])
    }
  }

  const removeFile = (index: number) => {
    setUploadedFiles(uploadedFiles.filter((_, i) => i !== index))
  }

  const getFileIcon = (type: string) => {
    if (type === "pdf") return <FileText className="h-4 w-4 text-red-500" />
    if (type === "image") return <ImageIcon className="h-4 w-4 text-blue-500" />
    return <File className="h-4 w-4 text-muted-foreground" />
  }

  return (
    <Dialog open={!!chargeback} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-card max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-3">
              <span className="font-mono">{chargeback.id}</span>
              <Badge variant="outline" className={statusColors[chargeback.status]}>
                {statusLabels[chargeback.status]}
              </Badge>
            </DialogTitle>
          </div>
        </DialogHeader>

        <Tabs defaultValue="details" className="mt-4">
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="settlement">Settlement Impact</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="response">Submit Response</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-6 mt-4">
            <div className="rounded-lg bg-destructive/10 border border-destructive/20 p-4 text-center">
              <p className="text-sm text-destructive">Disputed Amount</p>
              <p className="text-3xl font-bold text-destructive">₹{chargeback.amount.toLocaleString()}</p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase">Chargeback Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Transaction ID</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm">{chargeback.transactionId}</span>
                      <button onClick={() => copyToClipboard(chargeback.transactionId)}>
                        <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">ARN</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs">{chargeback.arn}</span>
                      <button onClick={() => copyToClipboard(chargeback.arn)}>
                        <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Gateway</span>
                    <span>{chargeback.gateway}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Reason</span>
                    <span className="text-right max-w-[200px]">{chargeback.reason}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Reason Code</span>
                    <span className="font-mono">{chargeback.reasonCode}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase">Raised By</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Issuing Bank</span>
                    <span>{chargeback.raisedBy}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Card Type</span>
                    <span>{chargeback.cardType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Card Number</span>
                    <span>****{chargeback.cardLast4}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Raised Date</span>
                    <span>{chargeback.raisedDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Response Due</span>
                    <span className="text-destructive font-medium">{chargeback.dueDate}</span>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase">Payer Information</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg bg-secondary/30 p-4">
                  <p className="text-sm text-muted-foreground">Institute</p>
                  <p className="font-medium">{chargeback.institute}</p>
                </div>
                <div className="rounded-lg bg-secondary/30 p-4">
                  <p className="text-sm text-muted-foreground">Student Name</p>
                  <p className="font-medium">{chargeback.studentName}</p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settlement" className="space-y-6 mt-4">
            <div className="rounded-lg border border-border p-4">
              <div className="flex items-center gap-2 mb-4">
                <Landmark className="h-5 w-5 text-muted-foreground" />
                <h3 className="font-semibold">Settlement Impact Timeline</h3>
              </div>

              <div className="space-y-6">
                {chargeback.originalSettlement && (
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                        <CheckCircle className="h-5 w-5 text-success" />
                      </div>
                      <div className="w-0.5 h-16 bg-border mt-2" />
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="font-medium">Original Payment Settled</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Transaction was part of settlement{" "}
                        <span className="font-mono text-primary">{chargeback.originalSettlement.id}</span>
                      </p>
                      <div className="mt-2 bg-secondary/50 rounded-lg p-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Settlement Date</span>
                          <span>{chargeback.originalSettlement.date}</span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Amount Settled</span>
                          <span className="text-success">₹{chargeback.amount.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-4">
                  <div className="flex flex-col items-center">
                    <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
                      <AlertCircle className="h-5 w-5 text-destructive" />
                    </div>
                    <div className="w-0.5 h-16 bg-border mt-2" />
                  </div>
                  <div className="flex-1 pt-1">
                    <p className="font-medium">Chargeback Raised</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {chargeback.raisedBy} raised chargeback for {chargeback.reason}
                    </p>
                    <div className="mt-2 bg-destructive/5 border border-destructive/20 rounded-lg p-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Raised Date</span>
                        <span>{chargeback.raisedDate}</span>
                      </div>
                      <div className="flex justify-between text-sm mt-1">
                        <span className="text-muted-foreground">Response Due</span>
                        <span className="text-destructive font-medium">{chargeback.dueDate}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {chargeback.deductedFromSettlement && (
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                        <ArrowRight className="h-5 w-5 text-amber-500" />
                      </div>
                      {(chargeback.status === "won" || chargeback.status === "lost") && (
                        <div className="w-0.5 h-16 bg-border mt-2" />
                      )}
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="font-medium">Amount Deducted from Institute Settlement</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        ₹{chargeback.amount.toLocaleString()} was held back from settlement{" "}
                        <span className="font-mono text-amber-600">{chargeback.deductedFromSettlement.id}</span>
                      </p>
                      <div className="mt-2 bg-amber-500/5 border border-amber-500/20 rounded-lg p-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Deduction Date</span>
                          <span>{chargeback.deductedFromSettlement.deductionDate}</span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Settlement ID</span>
                          <span className="font-mono">{chargeback.deductedFromSettlement.id}</span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Amount Held</span>
                          <span className="text-amber-600 font-medium">₹{chargeback.amount.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {chargeback.status === "won" && chargeback.recoveryInfo && (
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                        <ArrowUpRight className="h-5 w-5 text-emerald-500" />
                      </div>
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="font-medium text-emerald-600">Chargeback Won - Amount Recovered</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Dispute resolved in favor. Amount credited back to settlement{" "}
                        <span className="font-mono text-emerald-600">
                          {chargeback.recoveryInfo.creditedToSettlement}
                        </span>
                      </p>
                      <div className="mt-2 bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Won Date</span>
                          <span>{chargeback.recoveryInfo.wonDate}</span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Credited Date</span>
                          <span>{chargeback.recoveryInfo.creditedDate}</span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Credited To</span>
                          <span className="font-mono text-emerald-600">
                            {chargeback.recoveryInfo.creditedToSettlement}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Amount Recovered</span>
                          <span className="text-emerald-600 font-medium">₹{chargeback.amount.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {chargeback.status === "lost" && (
                  <div className="flex items-start gap-4">
                    <div className="flex flex-col items-center">
                      <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
                        <X className="h-5 w-5 text-destructive" />
                      </div>
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="font-medium text-destructive">Chargeback Lost - Permanent Deduction</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Dispute was not resolved in favor. The deducted amount is a permanent loss.
                      </p>
                      <div className="mt-2 bg-destructive/5 border border-destructive/20 rounded-lg p-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Final Status</span>
                          <span className="text-destructive font-medium">Lost</span>
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span className="text-muted-foreground">Permanent Loss</span>
                          <span className="text-destructive font-medium">₹{chargeback.amount.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-lg bg-secondary/50 p-4 text-center">
                <p className="text-xs text-muted-foreground mb-1">Original Settlement</p>
                <p className="font-mono font-semibold">{chargeback.originalSettlement?.id || "-"}</p>
                <p className="text-xs text-muted-foreground mt-1">{chargeback.originalSettlement?.date}</p>
              </div>
              <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-4 text-center">
                <p className="text-xs text-muted-foreground mb-1">Deducted From</p>
                <p className="font-mono font-semibold text-amber-600">{chargeback.deductedFromSettlement?.id || "-"}</p>
                <p className="text-xs text-muted-foreground mt-1">{chargeback.deductedFromSettlement?.deductionDate}</p>
              </div>
              <div
                className={`rounded-lg p-4 text-center ${
                  chargeback.status === "won"
                    ? "bg-emerald-500/10 border border-emerald-500/20"
                    : chargeback.status === "lost"
                      ? "bg-destructive/10 border border-destructive/20"
                      : "bg-secondary/50"
                }`}
              >
                <p className="text-xs text-muted-foreground mb-1">
                  {chargeback.status === "won" ? "Recovered To" : chargeback.status === "lost" ? "Status" : "Pending"}
                </p>
                <p
                  className={`font-mono font-semibold ${
                    chargeback.status === "won"
                      ? "text-emerald-600"
                      : chargeback.status === "lost"
                        ? "text-destructive"
                        : ""
                  }`}
                >
                  {chargeback.status === "won"
                    ? chargeback.recoveryInfo?.creditedToSettlement
                    : chargeback.status === "lost"
                      ? "Lost"
                      : "In Progress"}
                </p>
                {chargeback.status === "won" && (
                  <p className="text-xs text-muted-foreground mt-1">{chargeback.recoveryInfo?.creditedDate}</p>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="documents" className="space-y-6 mt-4">
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Uploaded Documents</h3>
              <div className="space-y-2">
                {existingDocuments.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between rounded-lg bg-secondary/30 p-3">
                    <div className="flex items-center gap-3">
                      {getFileIcon(doc.type)}
                      <div>
                        <p className="text-sm font-medium">{doc.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {doc.size} - Uploaded {doc.uploadedAt}
                        </p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" className="gap-2">
                      <Download className="h-4 w-4" />
                      Download
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Upload New Documents</h3>
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                <input
                  type="file"
                  id="file-upload"
                  multiple
                  className="hidden"
                  onChange={handleFileUpload}
                  accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Upload className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-sm font-medium">Click to upload or drag and drop</p>
                  <p className="text-xs text-muted-foreground mt-1">PDF, Images, Word documents (Max 10MB each)</p>
                </label>
              </div>

              {uploadedFiles.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Files to upload</h4>
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="flex items-center justify-between rounded-lg bg-secondary/30 p-3">
                      <div className="flex items-center gap-3">
                        <File className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">{file.name}</p>
                          <p className="text-xs text-muted-foreground">{(file.size / 1024).toFixed(1)} KB</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => removeFile(index)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button className="w-full mt-4 gap-2">
                    <Upload className="h-4 w-4" />
                    Upload {uploadedFiles.length} File(s)
                  </Button>
                </div>
              )}
            </div>

            <div className="rounded-lg bg-blue-500/10 border border-blue-500/20 p-4">
              <h4 className="text-sm font-semibold text-blue-500 mb-2">Recommended Documents</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>- Transaction receipt or confirmation</li>
                <li>- Proof of service delivery (fee receipt)</li>
                <li>- Communication with cardholder</li>
                <li>- Student ID or enrollment proof</li>
                <li>- Institute acknowledgment letter</li>
              </ul>
            </div>
          </TabsContent>

          <TabsContent value="response" className="space-y-6 mt-4">
            {chargeback.status === "open" || chargeback.status === "under_review" ? (
              <>
                <div className="space-y-4">
                  <Label htmlFor="response">Response Note</Label>
                  <Textarea
                    id="response"
                    placeholder="Provide detailed response explaining why this chargeback should be reversed..."
                    className="min-h-[150px] bg-secondary/50"
                    value={responseNote}
                    onChange={(e) => setResponseNote(e.target.value)}
                  />
                </div>

                <div className="rounded-lg bg-warning/10 border border-warning/20 p-4">
                  <h4 className="text-sm font-semibold text-warning mb-2">Before Submitting</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>- Ensure all supporting documents are uploaded</li>
                    <li>- Verify transaction details are accurate</li>
                    <li>- Response deadline: {chargeback.dueDate}</li>
                  </ul>
                </div>

                <div className="flex justify-end gap-3">
                  <Button variant="outline" className="bg-transparent">
                    Save Draft
                  </Button>
                  <Button className="gap-2">
                    <CheckCircle className="h-4 w-4" />
                    Submit Response
                  </Button>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg font-medium">Response Already Submitted</p>
                <p className="text-sm text-muted-foreground mt-1">
                  This chargeback has been{" "}
                  {chargeback.status === "won"
                    ? "resolved in your favor"
                    : chargeback.status === "lost"
                      ? "resolved against you"
                      : "processed"}
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
