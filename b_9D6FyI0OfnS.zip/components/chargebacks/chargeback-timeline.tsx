"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Clock, FileText, CheckCircle, Upload, MessageSquare, Send } from "lucide-react"

interface TimelineEvent {
  id: string
  type: "raised" | "document" | "response" | "review" | "resolved" | "message"
  title: string
  description: string
  date: string
  time: string
  actor: string
}

const timelineData: Record<string, TimelineEvent[]> = {
  CHB001234: [
    {
      id: "1",
      type: "raised",
      title: "Chargeback Initiated",
      description: "Chargeback raised by HDFC Bank for Reason Code 10.4 - Fraudulent Transaction",
      date: "2024-01-14",
      time: "09:30 AM",
      actor: "HDFC Bank",
    },
    {
      id: "2",
      type: "message",
      title: "Notification Sent",
      description: "Chargeback notification sent to merchant and ERP partner",
      date: "2024-01-14",
      time: "09:35 AM",
      actor: "System",
    },
  ],
  CHB001235: [
    {
      id: "1",
      type: "raised",
      title: "Chargeback Initiated",
      description: "Chargeback raised by ICICI Bank for Reason Code 13.1 - Product Not Received",
      date: "2024-01-12",
      time: "11:20 AM",
      actor: "ICICI Bank",
    },
    {
      id: "2",
      type: "document",
      title: "Documents Uploaded",
      description: "Transaction receipt and fee confirmation uploaded",
      date: "2024-01-13",
      time: "02:45 PM",
      actor: "SparkIT",
    },
    {
      id: "3",
      type: "review",
      title: "Under Review",
      description: "Documents submitted for bank review",
      date: "2024-01-14",
      time: "10:00 AM",
      actor: "Cashfree",
    },
  ],
  CHB001236: [
    {
      id: "1",
      type: "raised",
      title: "Chargeback Initiated",
      description: "Chargeback raised by SBI Card for Reason Code 12.6 - Duplicate Transaction",
      date: "2024-01-10",
      time: "03:15 PM",
      actor: "SBI Card",
    },
    {
      id: "2",
      type: "document",
      title: "Documents Uploaded",
      description: "Transaction logs and unique order IDs uploaded as proof",
      date: "2024-01-11",
      time: "11:30 AM",
      actor: "SparkIT",
    },
    {
      id: "3",
      type: "response",
      title: "Response Submitted",
      description: "Detailed response with evidence submitted to issuing bank",
      date: "2024-01-12",
      time: "04:00 PM",
      actor: "SparkIT",
    },
    {
      id: "4",
      type: "review",
      title: "Bank Processing",
      description: "Response under review by SBI Card dispute team",
      date: "2024-01-13",
      time: "09:00 AM",
      actor: "SBI Card",
    },
  ],
  CHB001237: [
    {
      id: "1",
      type: "raised",
      title: "Chargeback Initiated",
      description: "Chargeback raised by Axis Bank for Reason Code 10.1 - Unauthorized Transaction",
      date: "2024-01-05",
      time: "10:45 AM",
      actor: "Axis Bank",
    },
    {
      id: "2",
      type: "document",
      title: "Documents Uploaded",
      description: "3DS authentication proof and IP logs uploaded",
      date: "2024-01-06",
      time: "02:30 PM",
      actor: "SparkIT",
    },
    {
      id: "3",
      type: "response",
      title: "Response Submitted",
      description: "Compelling evidence submitted showing valid authorization",
      date: "2024-01-07",
      time: "11:00 AM",
      actor: "SparkIT",
    },
    {
      id: "4",
      type: "resolved",
      title: "Dispute Won",
      description: "Bank accepted the evidence. Chargeback reversed in merchant's favor",
      date: "2024-01-10",
      time: "03:30 PM",
      actor: "Axis Bank",
    },
  ],
}

const getEventIcon = (type: string) => {
  switch (type) {
    case "raised":
      return <AlertTriangle className="h-4 w-4 text-warning" />
    case "document":
      return <Upload className="h-4 w-4 text-blue-500" />
    case "response":
      return <Send className="h-4 w-4 text-purple-500" />
    case "review":
      return <Clock className="h-4 w-4 text-orange-500" />
    case "resolved":
      return <CheckCircle className="h-4 w-4 text-success" />
    case "message":
      return <MessageSquare className="h-4 w-4 text-muted-foreground" />
    default:
      return <FileText className="h-4 w-4 text-muted-foreground" />
  }
}

interface ChargebackTimelineProps {
  chargebackId: string | null
}

export function ChargebackTimeline({ chargebackId }: ChargebackTimelineProps) {
  const timeline = chargebackId ? timelineData[chargebackId] : null

  return (
    <Card className="bg-card border-border h-fit">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">Chargeback Timeline</CardTitle>
      </CardHeader>
      <CardContent>
        {timeline ? (
          <div className="relative">
            <div className="absolute left-[11px] top-2 bottom-2 w-px bg-border" />
            <div className="space-y-6">
              {timeline.map((event, index) => (
                <div key={event.id} className="relative flex gap-4">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-secondary border border-border z-10">
                    {getEventIcon(event.type)}
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium">{event.title}</p>
                    <p className="text-xs text-muted-foreground">{event.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className="text-xs">
                        {event.actor}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {event.date} • {event.time}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <Clock className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Select a chargeback to view its timeline</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
