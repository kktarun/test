"use client"

import { Card, CardContent } from "@/components/ui/card"
import { AlertTriangle, Clock, CheckCircle, XCircle, TrendingUp, TrendingDown } from "lucide-react"

const stats = [
  {
    title: "Total Chargebacks",
    value: "₹12.45L",
    count: "156",
    trend: "+12%",
    trendUp: true,
    icon: AlertTriangle,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    title: "Pending Response",
    value: "₹3.20L",
    count: "28",
    trend: "-8%",
    trendUp: false,
    icon: Clock,
    color: "text-orange-500",
    bgColor: "bg-orange-500/10",
  },
  {
    title: "Won Disputes",
    value: "₹5.80L",
    count: "67",
    trend: "+18%",
    trendUp: true,
    icon: CheckCircle,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    title: "Lost Disputes",
    value: "₹3.45L",
    count: "61",
    trend: "-5%",
    trendUp: false,
    icon: XCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
]

export function ChargebackStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <Card key={stat.title} className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div className={`flex items-center gap-1 text-xs ${stat.trendUp ? "text-success" : "text-destructive"}`}>
                {stat.trendUp ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                {stat.trend}
              </div>
            </div>
            <div className="mt-3">
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-sm text-muted-foreground">
                {stat.title} ({stat.count})
              </p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
