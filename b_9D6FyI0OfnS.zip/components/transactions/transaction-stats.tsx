"use client"

import { Card, CardContent } from "@/components/ui/card"
import { ArrowUpRight, CheckCircle2, Clock, XCircle } from "lucide-react"

const stats = [
  {
    name: "Total Transactions",
    value: "1,24,567",
    subValue: "₹12.4 Cr",
    icon: ArrowUpRight,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    name: "Successful",
    value: "1,22,891",
    subValue: "98.7%",
    icon: CheckCircle2,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    name: "Pending",
    value: "1,234",
    subValue: "0.9%",
    icon: Clock,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    name: "Failed",
    value: "442",
    subValue: "0.4%",
    icon: XCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
]

export function TransactionStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.name} className="bg-card border-border">
          <CardContent className="flex items-center gap-4 p-4">
            <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-6 w-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.name}</p>
              <p className={`text-xs font-medium ${stat.color}`}>{stat.subValue}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
