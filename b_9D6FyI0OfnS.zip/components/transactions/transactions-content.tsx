"use client"

import { useState } from "react"
import { TransactionFilters } from "./transaction-filters"
import { TransactionsTable, type CustomColumnConfig } from "./transactions-table"
import { TransactionDashboard } from "./transaction-dashboard"
import { ExportModal } from "./export-modal"
import { Button } from "@/components/ui/button"
import { Download, RefreshCw, ChevronDown, Save, Bookmark, Settings2 } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu"
import { ChannelModeFilter } from "./channel-mode-filter"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { CustomColumnsManager } from "./custom-columns-manager"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SplitTransactionsTab } from "./split-transactions-tab"
import { Split } from "lucide-react"

export interface FilterState {
  institute: string
  gateway: string
  paymentMode: string
  channel: string
  status: string
  dateRange: string
  searchQuery: string
  selectedChannels: string[]
  selectedModes: string[]
  vendor: string
  captureStatus: string
  searchType: string
  // Network/Provider filters
  cardNetwork: string
  upiPsp: string
  bank: string
  wallet: string
  bankTransferType: string
  // Financing filters
  financingCategory: string
  financingType: string
  financingCollectionType: string
  nbfcPartner: string
  emiCostBearing: string
  partialCostSharing: string
  cardIssuingBank: string
  // Financing charge percentage filters
  parentChargePercentage: string
  instituteChargePercentage: string
  bankChargePercentage: string
  // International payment filters
  internationalMethod: string
  internationalCardNetwork: string
  internationalPricingType: string
  currency: string
  // Transaction fee bearing
  transactionFeeBearing: string
  partialFeeSharing: string
}

export interface SavedFilter {
  id: string
  name: string
  filters: FilterState
  createdAt: string
}

// Default saved filters
const defaultSavedFilters: SavedFilter[] = [
  {
    id: "sf1",
    name: "Today's Successful Payments",
    filters: {
      institute: "all",
      gateway: "all",
      paymentMode: "all",
      channel: "all",
      status: "success",
      dateRange: "today",
      searchQuery: "",
      selectedChannels: [],
      selectedModes: [],
      vendor: "all",
      captureStatus: "all",
      searchType: "all",
      cardNetwork: "all",
      upiPsp: "all",
      bank: "all",
      wallet: "all",
      bankTransferType: "all",
      financingCategory: "all",
      financingType: "all",
      financingCollectionType: "all",
      nbfcPartner: "all",
      emiCostBearing: "all",
      partialCostSharing: "all",
      cardIssuingBank: "all",
      parentChargePercentage: "all",
      instituteChargePercentage: "all",
      bankChargePercentage: "all",
      internationalMethod: "all",
      internationalCardNetwork: "all",
      internationalPricingType: "all",
      currency: "all",
      transactionFeeBearing: "all",
      partialFeeSharing: "all",
    },
    createdAt: "2024-01-15",
  },
  {
    id: "sf2",
    name: "Pending Captures",
    filters: {
      institute: "all",
      gateway: "all",
      paymentMode: "all",
      channel: "all",
      status: "pending",
      dateRange: "7d",
      searchQuery: "",
      selectedChannels: [],
      selectedModes: [],
      vendor: "all",
      captureStatus: "authorized",
      searchType: "all",
      cardNetwork: "all",
      upiPsp: "all",
      bank: "all",
      wallet: "all",
      bankTransferType: "all",
      financingCategory: "all",
      financingType: "all",
      financingCollectionType: "all",
      nbfcPartner: "all",
      emiCostBearing: "all",
      partialCostSharing: "all",
      cardIssuingBank: "all",
      parentChargePercentage: "all",
      instituteChargePercentage: "all",
      bankChargePercentage: "all",
      internationalMethod: "all",
      internationalCardNetwork: "all",
      internationalPricingType: "all",
      currency: "all",
      transactionFeeBearing: "all",
      partialFeeSharing: "all",
    },
    createdAt: "2024-01-14",
  },
]

export function TransactionsContent() {
  const [filters, setFilters] = useState<FilterState>({
    institute: "all",
    gateway: "all",
    paymentMode: "all",
    channel: "all",
    status: "all",
    dateRange: "all",
    searchQuery: "",
    selectedChannels: [],
    selectedModes: [],
    vendor: "all",
    captureStatus: "all",
    searchType: "all",
    cardNetwork: "all",
    upiPsp: "all",
    bank: "all",
    wallet: "all",
    bankTransferType: "all",
    financingCategory: "all",
    financingType: "all",
    financingCollectionType: "all",
    nbfcPartner: "all",
    emiCostBearing: "all",
    partialCostSharing: "all",
    cardIssuingBank: "all",
    parentChargePercentage: "all",
    instituteChargePercentage: "all",
    bankChargePercentage: "all",
    internationalMethod: "all",
    internationalCardNetwork: "all",
    internationalPricingType: "all",
    currency: "all",
    transactionFeeBearing: "all",
    partialFeeSharing: "all",
  })
  const [selectedCount, setSelectedCount] = useState(0)
  const [showExportModal, setShowExportModal] = useState(false)
  const [savedFilters, setSavedFilters] = useState<SavedFilter[]>(defaultSavedFilters)
  const [showSaveFilterModal, setShowSaveFilterModal] = useState(false)
  const [newFilterName, setNewFilterName] = useState("")
  const [rowsPerPage, setRowsPerPage] = useState(10)
  const [showCustomColumnsManager, setShowCustomColumnsManager] = useState(false)
  const [customColumns, setCustomColumns] = useState<CustomColumnConfig[]>([
    // Sample pre-configured custom columns from ERP
    {
      id: "custom-1",
      name: "academic_year",
      apiField: "customFields.academicYear",
      displayName: "Academic Year",
      type: "text",
      visible: true,
      sortable: true,
      order: 0,
    },
    {
      id: "custom-2",
      name: "fee_category",
      apiField: "customFields.feeCategory",
      displayName: "Fee Category",
      type: "badge",
      visible: true,
      sortable: true,
      order: 1,
    },
    {
      id: "custom-3",
      name: "installment_no",
      apiField: "customFields.installmentNo",
      displayName: "Installment #",
      type: "number",
      visible: true,
      sortable: true,
      order: 2,
    },
  ])
  const [visibleCustomColumns, setVisibleCustomColumns] = useState<string[]>(["academic_year", "fee_category", "installment_no"])

  const handleFilterChange = (key: keyof FilterState, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const handleReset = () => {
    setFilters({
      institute: "all",
      gateway: "all",
      paymentMode: "all",
      channel: "all",
      status: "all",
      dateRange: "all",
      searchQuery: "",
      selectedChannels: [],
      selectedModes: [],
      vendor: "all",
      captureStatus: "all",
      searchType: "all",
      cardNetwork: "all",
      upiPsp: "all",
      bank: "all",
      wallet: "all",
      bankTransferType: "all",
      financingCategory: "all",
      financingType: "all",
      financingCollectionType: "all",
      nbfcPartner: "all",
      emiCostBearing: "all",
      partialCostSharing: "all",
      cardIssuingBank: "all",
      parentChargePercentage: "all",
      instituteChargePercentage: "all",
      bankChargePercentage: "all",
      internationalMethod: "all",
      internationalCardNetwork: "all",
      internationalPricingType: "all",
      currency: "all",
      transactionFeeBearing: "all",
      partialFeeSharing: "all",
    })
  }

  const handleSaveFilter = () => {
    if (!newFilterName.trim()) {
      toast.error("Please enter a filter name")
      return
    }
    const newFilter: SavedFilter = {
      id: `sf${Date.now()}`,
      name: newFilterName,
      filters: { ...filters },
      createdAt: new Date().toISOString().split("T")[0],
    }
    setSavedFilters((prev) => [...prev, newFilter])
    setNewFilterName("")
    setShowSaveFilterModal(false)
    toast.success("Filter saved successfully")
  }

  const handleApplySavedFilter = (savedFilter: SavedFilter) => {
    setFilters(savedFilter.filters)
    toast.success(`Applied filter: ${savedFilter.name}`)
  }

  const handleDeleteSavedFilter = (filterId: string) => {
    setSavedFilters((prev) => prev.filter((f) => f.id !== filterId))
    toast.success("Filter deleted")
  }

  const handleSelectionChange = (selected: string[]) => {
    setSelectedCount(selected.length)
  }

  const [activeTab, setActiveTab] = useState("all")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Transactions</h1>
          <p className="text-muted-foreground">View and manage all transactions across institutes</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Saved Filters Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <Bookmark className="h-4 w-4" />
                Saved Filters
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              {savedFilters.length === 0 ? (
                <div className="p-3 text-sm text-muted-foreground text-center">No saved filters</div>
              ) : (
                savedFilters.map((sf) => (
                  <DropdownMenuItem
                    key={sf.id}
                    onClick={() => handleApplySavedFilter(sf)}
                    className="flex items-center justify-between"
                  >
                    <span className="truncate">{sf.name}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 opacity-50 hover:opacity-100"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDeleteSavedFilter(sf.id)
                      }}
                    >
                      &times;
                    </Button>
                  </DropdownMenuItem>
                ))
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setShowSaveFilterModal(true)}>
                <Save className="mr-2 h-4 w-4" />
                Save Current Filter
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button 
            variant="outline" 
            size="sm" 
            className="gap-2 bg-transparent"
            onClick={() => setShowCustomColumnsManager(true)}
          >
            <Settings2 className="h-4 w-4" />
            Custom Columns
          </Button>
          <Button variant="outline" size="sm" className="gap-2 bg-transparent">
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <Download className="h-4 w-4" />
                Export
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowExportModal(true)}>Advanced Export...</DropdownMenuItem>
              <DropdownMenuItem>Quick Export as Excel</DropdownMenuItem>
              <DropdownMenuItem>Quick Export as CSV</DropdownMenuItem>
              <DropdownMenuItem>Quick Export as PDF</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-secondary/50">
          <TabsTrigger value="all" className="gap-2">
            All Transactions
          </TabsTrigger>
          <TabsTrigger value="split" className="gap-2">
            <Split className="h-4 w-4" />
            Split Payments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          <TransactionDashboard filters={filters} />

          <div className="flex gap-2 flex-wrap">
            <TransactionFilters filters={filters} onFilterChange={handleFilterChange} onReset={handleReset} />
            <ChannelModeFilter
              selectedChannels={filters.selectedChannels}
              selectedModes={filters.selectedModes}
              onChannelsChange={(channels) => setFilters({ ...filters, selectedChannels: channels })}
              onModesChange={(modes) => setFilters({ ...filters, selectedModes: modes })}
            />
          </div>

          <TransactionsTable 
        filters={filters} 
        onSelectionChange={handleSelectionChange} 
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={setRowsPerPage}
        customColumns={customColumns.filter(c => c.visible)}
      />

      <ExportModal
            open={showExportModal}
            onClose={() => setShowExportModal(false)}
            totalRecords={12456}
            selectedRecords={selectedCount}
            filters={{
              dateRange: filters.dateRange,
              status: filters.status,
              gateway: filters.gateway,
            }}
          />
        </TabsContent>

        <TabsContent value="split" className="space-y-6">
          <SplitTransactionsTab />
        </TabsContent>
      </Tabs>

      {/* Save Filter Modal */}
      <Dialog open={showSaveFilterModal} onOpenChange={setShowSaveFilterModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Save Current Filter</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="filterName">Filter Name</Label>
              <Input
                id="filterName"
                placeholder="e.g., Today's UPI Transactions"
                value={newFilterName}
                onChange={(e) => setNewFilterName(e.target.value)}
              />
            </div>
            <div className="text-sm text-muted-foreground">
              <p className="font-medium mb-2">Current filter settings:</p>
              <ul className="space-y-1">
                {filters.status !== "all" && <li>Status: {filters.status}</li>}
                {filters.gateway !== "all" && <li>Gateway: {filters.gateway}</li>}
                {filters.institute !== "all" && <li>Institute: {filters.institute}</li>}
                {filters.vendor !== "all" && <li>Vendor: {filters.vendor}</li>}
                {filters.captureStatus !== "all" && <li>Capture Status: {filters.captureStatus}</li>}
                {filters.dateRange && <li>Date Range: {filters.dateRange}</li>}
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSaveFilterModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveFilter}>Save Filter</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Custom Columns Manager */}
      <CustomColumnsManager
        open={showCustomColumnsManager}
        onClose={() => setShowCustomColumnsManager(false)}
        customColumns={customColumns}
        onColumnsChange={setCustomColumns}
        visibleColumns={visibleCustomColumns}
        onVisibleColumnsChange={setVisibleCustomColumns}
      />
    </div>
  )
}
