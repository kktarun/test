"use client"

import { useMemo } from "react"
import { Card, CardContent } from "@/components/ui/card"
import {
  IndianRupee,
  TrendingUp,
  CheckCircle2,
  CreditCard,
} from "lucide-react"
import type { FilterState } from "./transactions-content"
import { useTransactionsData } from "@/hooks/use-transactions-data"

interface TransactionDashboardProps {
  filters: FilterState
}

export function TransactionDashboard({ filters }: TransactionDashboardProps) {
  const { transactions: rawTransactions, isLoading } = useTransactionsData()

  // Filter transactions based on current filters
  const filteredData = useMemo(() => {
    return rawTransactions.filter((txn) => {
      // Institute filter
      if (filters.institute !== "all" && filters.institute) {
        const instituteMatch = txn.institute?.toLowerCase().includes(filters.institute.toLowerCase())
        if (!instituteMatch) return false
      }
      
      // Date range filter
      if (filters.dateRange && filters.dateRange !== "all") {
        const txnDate = new Date(txn.date)
        const today = new Date()
        today.setHours(0, 0, 0, 0)
        
        // Check for custom date range format (startDate_endDate)
        if (filters.dateRange.includes("_")) {
          const [startStr, endStr] = filters.dateRange.split("_")
          const startDate = new Date(startStr)
          const endDate = new Date(endStr)
          endDate.setHours(23, 59, 59, 999)
          if (txnDate < startDate || txnDate > endDate) return false
        } else {
          let startDate: Date
          switch (filters.dateRange) {
            case "today":
              startDate = today
              if (txnDate < startDate) return false
              break
            case "yesterday":
              startDate = new Date(today)
              startDate.setDate(startDate.getDate() - 1)
              const endOfYesterday = new Date(startDate)
              endOfYesterday.setHours(23, 59, 59, 999)
              if (txnDate < startDate || txnDate > endOfYesterday) return false
              break
            case "7d":
              startDate = new Date(today)
              startDate.setDate(startDate.getDate() - 7)
              if (txnDate < startDate) return false
              break
            case "30d":
              startDate = new Date(today)
              startDate.setDate(startDate.getDate() - 30)
              if (txnDate < startDate) return false
              break
            case "90d":
              startDate = new Date(today)
              startDate.setDate(startDate.getDate() - 90)
              if (txnDate < startDate) return false
              break
            case "this_month":
              startDate = new Date(today.getFullYear(), today.getMonth(), 1)
              if (txnDate < startDate) return false
              break
            case "last_month":
              startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1)
              const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0, 23, 59, 59, 999)
              if (txnDate < startDate || txnDate > endOfLastMonth) return false
              break
            case "this_year":
              startDate = new Date(today.getFullYear(), 0, 1)
              if (txnDate < startDate) return false
              break
            default:
              break
          }
        }
      }
      
      if (filters.status !== "all" && txn.status?.toLowerCase() !== filters.status.toLowerCase()) return false
      if (filters.gateway !== "all" && !txn.gateway?.toLowerCase().includes(filters.gateway.toLowerCase())) return false
      if (filters.paymentMode !== "all") {
        const modeMatch = txn.payment_mode?.toLowerCase().includes(filters.paymentMode.replace("_", " ").toLowerCase())
        if (!modeMatch) return false
      }
      return true
    })
  }, [rawTransactions, filters])

  // Calculate dynamic stats based on filtered data
  const summaryStats = useMemo(() => {
    const totalOrderAmount = filteredData.reduce((sum, txn) => sum + (txn.order_amount || 0), 0)
    const totalTransactionAmount = filteredData.reduce((sum, txn) => sum + (txn.transaction_amount || 0), 0)
    const totalTransactions = filteredData.length
    const successfulTxns = filteredData.filter((txn) => txn.status?.toLowerCase() === "success")
    const successRate = totalTransactions > 0 ? (successfulTxns.length / totalTransactions) * 100 : 0
    const avgTransactionValue = totalTransactions > 0 ? Math.round(totalTransactionAmount / totalTransactions) : 0

    return {
      totalOrderAmount,
      totalTransactionAmount,
      totalTransactions,
      avgTransactionValue,
      successRate: Math.round(successRate * 10) / 10,
    }
  }, [filteredData])

  // Get date range label for display
  const getDateRangeLabel = () => {
    if (filters.dateRange?.includes("_")) {
      const [start, end] = filters.dateRange.split("_")
      return `${new Date(start).toLocaleDateString()} - ${new Date(end).toLocaleDateString()}`
    }
    switch (filters.dateRange) {
      case "today": return "Today"
      case "yesterday": return "Yesterday"
      case "7d": return "Last 7 Days"
      case "30d": return "Last 30 Days"
      case "90d": return "Last 90 Days"
      case "this_month": return "This Month"
      case "last_month": return "Last Month"
      case "this_year": return "This Year"
      case "all": return "All Time"
      default: return "Selected Period"
    }
  }

  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="bg-muted/50 animate-pulse">
            <CardContent className="p-4">
              <div className="h-20" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats - Dynamic based on filters */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Order Amount</p>
                <p className="text-2xl font-bold text-foreground">
                  ₹{summaryStats.totalOrderAmount >= 100000 
                    ? `${(summaryStats.totalOrderAmount / 100000).toFixed(2)} L`
                    : summaryStats.totalOrderAmount.toLocaleString()
                  }
                </p>
                <p className="text-xs text-muted-foreground mt-1">{getDateRangeLabel()}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
                <IndianRupee className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-success/10 to-success/5 border-success/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Transaction Amount</p>
                <p className="text-2xl font-bold text-foreground">
                  ₹{summaryStats.totalTransactionAmount >= 100000 
                    ? `${(summaryStats.totalTransactionAmount / 100000).toFixed(2)} L`
                    : summaryStats.totalTransactionAmount.toLocaleString()
                  }
                </p>
                <p className="text-xs text-muted-foreground mt-1">{getDateRangeLabel()}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-success/20">
                <TrendingUp className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-info/10 to-info/5 border-info/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Transaction Count</p>
                <p className="text-2xl font-bold text-foreground">{summaryStats.totalTransactions.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Avg ₹{summaryStats.avgTransactionValue.toLocaleString()}/txn
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-info/20">
                <CreditCard className="h-6 w-6 text-info" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500/10 to-amber-500/5 border-amber-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground font-medium">Success Rate</p>
                <p className="text-2xl font-bold text-foreground">{summaryStats.successRate}%</p>
                <p className="text-xs text-muted-foreground mt-1">{getDateRangeLabel()}</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-amber-500/20">
                <CheckCircle2 className="h-6 w-6 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
