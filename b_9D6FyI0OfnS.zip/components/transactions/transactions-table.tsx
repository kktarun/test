"use client"

import { useState, useMemo } from "react"
import { useTransactionsData, type RawTransaction } from "@/hooks/use-transactions-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
  RotateCcw,
  FileText,
  CheckCircle2,
  Clock,
  SplitSquareVertical,
  Building2,
  Info,
  ArrowRight,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import type { FilterState } from "./transactions-content"
import { ColumnFilter } from "./column-filter"
import { TransactionDetailModal } from "./transaction-detail-modal" // ADDED: Import for TransactionDetailModal

export interface Transaction {
  id: string
  orderId: string
  edvironOrderId: string
  gatewayTransactionId?: string
  bankReferenceNumber?: string
  institute: string
  studentName: string
  studentId: string
  orderAmount: number
  transactionAmount: number
  vendorAmount: number
  amount: number
  gateway: string
  paymentMode: string
  channel: string
  status: "success" | "pending" | "failed" | "refunded" | "partially_refunded" | "chargeback" | "user_dropped"
  statusReason: string
  date: string
  time: string
  // Payer Details
  payerEmail: string
  payerMobile: string
  studentClass: string
  studentDivision: string
  enrollmentNumber: string
  rollNumber: string
  feeType: string
  // Payment Instrument Details
  instrumentType: string
  instrumentDetails: string
  psp?: string
  cardBrand?: string
  cardType?: string
  cardIssuer?: string
  bankName?: string
  bankReferenceNumber?: string
  upiId?: string
  walletName?: string
  // Settlement Details
  isSettled: boolean
  settlementId?: string
  settlementUtr?: string
  settlementDate?: string
  // Capture API Details
  captureApiUsed: boolean
  captureStatus: "authorized" | "captured" | "void" | "not_applicable"
  authorizedAt?: string
  capturedAt?: string
  captureDelay?: string
  isSplitPayment: boolean
  splitDetails?: {
    totalSplits: number
    splits: Array<{
      beneficiary: string
      account: string
      ifsc: string
      amount: number
      percentage: number
      status: "settled" | "pending"
    }>
  }
  bankTransferDetails?: {
    type: "vpa" | "challan" | "neft" | "rtgs" | "imps"
    vpa?: string
    challanNumber?: string
    bankName?: string
    accountNumber?: string
    ifscCode?: string
    utrNumber?: string
    depositDate?: string
    branchName?: string
    referenceNumber?: string
  }
  vendor: string
  // Financing Details
  financingCategory?: "card_emi" | "nbfc_financing" | "none"
  financingType?: "emi" | "no_cost_emi" | "partial_cost_emi"
  emiCostBearing?: "parent" | "institute" | "bank"
  partialCostSharing?: "parent_institute" | "bank_institute" | "parent_bank" | "parent_bank_institute"
  cardIssuingBank?: string
  nbfcPartner?: string
  financingCollectionType?: "edviron_collection" | "nbfc_collection"
  emiTenure?: number
  emiAmount?: number
  // International Payment Details
  isInternational?: boolean
  internationalMethod?: string
  internationalPricingType?: "inr_converted" | "foreign_currency"
  currency?: string
  exchangeRate?: number
  originalAmount?: number
  // Split and Pay (Multi-mode) Details
  splitPayModes?: Array<{
    mode: string
    amount: number
    status: "success" | "pending" | "failed"
    transactionId?: string
    cardNetwork?: string
    upiPsp?: string
    bankName?: string
  }>
  // School Counter Details
  schoolCounterDetails?: {
    mode: "demand_draft" | "cheque" | "cash"
    ddNumber?: string
    chequeNumber?: string
    issuingBank?: string
    receiptNumber?: string
    collectedBy?: string
    collectionDate?: string
  }
  // Transaction Fee Bearing Details
  transactionFeeBearing?: "payer" | "merchant" | "partial"
  partialFeeSharing?: "fixed_payer" | "fixed_merchant" | "percentage_split" | "mode_based"
  transactionFee?: number
  payerFeeAmount?: number
  merchantFeeAmount?: number
  feePercentage?: number
  // ERP Partner Custom Fields (passed via API)
  customFields?: Record<string, string | number | boolean>
  // ERP Commission Details
  erpCommission?: number
  erpCommissionPercentage?: number
  // Gateway Transaction ID
  gatewayTransactionId?: string
  // MDR Details
  mdrAmount?: number
  mdrPercentage?: number
  mdrBearing?: "surcharge" | "merchant_bearing"
  // Financing Charge Breakdown
  financingCharges?: {
    totalCharges: number
    parentCharge: number
    parentChargePercentage: number
    instituteCharge: number
    instituteChargePercentage: number
    bankCharge: number
    bankChargePercentage: number
    subventionAmount?: number
  }
  // Refund Details
  refundDetails?: {
    refundId: string
    refundDate: string
    refundedAmount: number
    originalOrderAmount: number
    pgChargesDeducted: number
    erpCommissionDeducted: number
    netRefundToParent: number
    refundReason: string
    refundStatus: "initiated" | "processing" | "completed" | "failed"
    refundArn?: string
  }
  // Autopay Details
  autopayDetails?: {
    mandateId: string
    mandateType: "UPI" | "NACH" | "E-Mandate"
    mandateStatus: "active" | "paused" | "revoked"
    maxAmount: number
    frequency: "monthly" | "quarterly" | "yearly" | "as_presented"
    validUntil: string
    bankAccountLast4?: string
    upiVpa?: string
  }
  // Split Pay Timeline (for Split and Pay mode) - Enhanced with charges
  splitPayTimeline?: {
    splitNumber: number
    amount: number
    paidDate?: string
    paidTime?: string
    dueDate?: string
    paymentMode: string | null
    status: "completed" | "pending" | "failed"
    transactionId: string | null
    // Charges for each split payment
    mdrAmount?: number
    mdrPercentage?: number
    erpCommission?: number
    erpCommissionPercentage?: number
    netAmount?: number
    gatewayTransactionId?: string
  }[]
  // Chargeback Details
  chargebackDetails?: {
    chargebackId: string
    chargebackDate: string
    chargebackAmount: number
    chargebackReason: string
    chargebackStatus: "initiated" | "under_review" | "won" | "lost" | "closed"
    disputeDeadline: string
    responseSubmittedAt?: string
    evidenceSubmitted?: boolean
    arbNumber?: string
    resolvedDate?: string
    chargebackFee?: number
  }
  // Transaction Lifecycle Events
  transactionLifecycle?: {
    event: string
    timestamp: string
    description: string
    status: "success" | "info" | "warning" | "error"
    metadata?: Record<string, string | number>
  }[]
}

// ERP Partner Custom Column Configuration
export interface CustomColumnConfig {
  id: string
  name: string
  apiField: string
  displayName: string
  type: "text" | "number" | "date" | "badge" | "currency"
  width?: string
  sortable?: boolean
  visible?: boolean
  order?: number
}

export const allTransactions: Transaction[] = [
  {
    id: "TXN001234567",
    orderId: "ORD-DPS-2024-001",
    edvironOrderId: "EDV-2024-001234567",
    institute: "Delhi Public School",
    studentName: "Rahul Sharma",
    studentId: "STU-DPS-045",
    orderAmount: 46000,
    transactionAmount: 45000,
    vendorAmount: 43875,
    amount: 45000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Online",
    status: "success",
    statusReason: "Payment completed successfully. Card authorized and captured.",
    date: "2024-01-15",
    time: "10:30 AM",
    payerEmail: "rahul.sharma@gmail.com",
    payerMobile: "+91 98765 43210",
    studentClass: "Class 10",
    studentDivision: "A",
    enrollmentNumber: "DPS/2024/10A/045",
    rollNumber: "45",
    feeType: "Tuition Fee - Q4",
    instrumentType: "Visa Credit Card",
    instrumentDetails: "•••• •••• •••• 4242",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "HDFC Bank",
    bankReferenceNumber: "BRN24011500001234",
    isSettled: true,
    settlementId: "STL001234",
    settlementUtr: "RAZP24011500001234",
    settlementDate: "2024-01-16",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-15 10:30:15",
    capturedAt: "2024-01-15 10:30:45",
    captureDelay: "30 seconds",
    isSplitPayment: true,
    splitDetails: {
      totalSplits: 2,
      splits: [
        {
          beneficiary: "Delhi Public School",
          account: "XXXX1234",
          ifsc: "HDFC0001234",
          amount: 40000,
          percentage: 88.9,
          status: "settled",
        },
        {
          beneficiary: "Transport Department",
          account: "XXXX5678",
          ifsc: "ICIC0005678",
          amount: 5000,
          percentage: 11.1,
          status: "settled",
        },
      ],
    },
    vendor: "Edviron",
    transactionFeeBearing: "payer",
    transactionFee: 1125,
    payerFeeAmount: 1125,
    merchantFeeAmount: 0,
    feePercentage: 2.5,
    // Sample custom fields from ERP API
    customFields: {
      academicYear: "2024-25",
      feeCategory: "Tuition",
      installmentNo: 4,
      dueDate: "2024-01-15",
      lateFeeApplied: false,
      scholarshipDiscount: 0,
      parentName: "Mr. Rajesh Sharma",
      section: "Science",
    },
    // ERP Commission
    erpCommission: 450,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-2024011514301234",
    // MDR Details
    mdrAmount: 900,
    mdrPercentage: 2.0,
    mdrBearing: "surcharge",
    // Financing Charges Breakdown
    financingCharges: {
      totalCharges: 1350,
      parentCharge: 675,
      parentChargePercentage: 1.5,
      instituteCharge: 450,
      instituteChargePercentage: 1.0,
      bankCharge: 225,
      bankChargePercentage: 0.5,
      subventionAmount: 225,
    },
  },
  {
    id: "TXN001234568",
    orderId: "ORD-SMC-2024-002",
    edvironOrderId: "EDV-2024-001234568",
    institute: "St. Mary's College",
    studentName: "Priya Patel",
    studentId: "STU-SMC-023",
    orderAmount: 32500,
    transactionAmount: 32500,
    vendorAmount: 31687,
    amount: 32500,
    gateway: "Cashfree",
    paymentMode: "UPI",
    channel: "Payment Link",
    status: "success",
    statusReason: "UPI payment verified. Amount credited to merchant account.",
    date: "2024-01-15",
    time: "10:25 AM",
    payerEmail: "priya.patel@outlook.com",
    payerMobile: "+91 87654 32109",
    studentClass: "Class 12",
    studentDivision: "B",
    enrollmentNumber: "SMC/2024/12B/023",
    rollNumber: "23",
    feeType: "Annual Fee",
    instrumentType: "UPI",
    instrumentDetails: "priya.patel@okaxis",
    psp: "PhonePe",
    upiId: "priya.patel@okaxis",
    bankReferenceNumber: "BRN24011500005678",
    isSettled: true,
    settlementId: "STL001234",
    settlementUtr: "CSHF24011500005678",
    settlementDate: "2024-01-16",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "SchoolPay",
    transactionFeeBearing: "merchant",
    transactionFee: 450,
    payerFeeAmount: 0,
    merchantFeeAmount: 450,
    feePercentage: 1.5,
    erpCommission: 325,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-CSF-2024011510255678",
    mdrAmount: 487,
    mdrPercentage: 1.5,
    mdrBearing: "merchant_bearing",
  },
  {
    id: "TXN001234569",
    orderId: "ORD-MOD-2024-003",
    edvironOrderId: "EDV-2024-001234569",
    institute: "Modern School",
    studentName: "Amit Kumar",
    studentId: "STU-MOD-067",
    orderAmount: 28000,
    transactionAmount: 28000,
    vendorAmount: 27300,
    amount: 28000,
    gateway: "Easebuzz",
    paymentMode: "Debit Card",
    channel: "POS",
    status: "pending",
    statusReason: "Authorization received. Awaiting capture confirmation from bank.",
    date: "2024-01-15",
    time: "10:20 AM",
    payerEmail: "amit.kumar@yahoo.com",
    payerMobile: "+91 76543 21098",
    studentClass: "Class 8",
    studentDivision: "C",
    enrollmentNumber: "MOD/2024/08C/067",
    rollNumber: "67",
    feeType: "Transport Fee",
    instrumentType: "Rupay Debit Card",
    instrumentDetails: "•••• •••• •••• 8765",
    cardBrand: "Rupay",
    cardType: "Debit",
    cardIssuer: "State Bank of India",
    bankReferenceNumber: "BRN24011500008765",
    isSettled: false,
    captureApiUsed: true,
    captureStatus: "authorized",
    authorizedAt: "2024-01-15 10:20:30",
    isSplitPayment: false,
    vendor: "Edviron",
    transactionFeeBearing: "partial",
    partialFeeSharing: "percentage_split",
    transactionFee: 700,
    payerFeeAmount: 350,
    merchantFeeAmount: 350,
    feePercentage: 2.5,
  },
  {
    id: "TXN001234570",
    orderId: "ORD-RYN-2024-004",
    edvironOrderId: "EDV-2024-001234570",
    institute: "Ryan International",
    studentName: "Sneha Gupta",
    studentId: "STU-RYN-012",
    orderAmount: 52000,
    transactionAmount: 52000,
    vendorAmount: 50700,
    amount: 52000,
    gateway: "Paytm",
    paymentMode: "Net Banking",
    channel: "Payment Form",
    status: "success",
    statusReason: "Net banking transaction successful. Bank reference received.",
    date: "2024-01-15",
    time: "10:15 AM",
    payerEmail: "sneha.gupta@gmail.com",
    payerMobile: "+91 65432 10987",
    studentClass: "Class 11",
    studentDivision: "A",
    enrollmentNumber: "RYN/2024/11A/012",
    rollNumber: "12",
    feeType: "Admission Fee",
    instrumentType: "Net Banking",
    instrumentDetails: "ICICI Bank",
    bankName: "ICICI Bank",
    bankReferenceNumber: "BRN24011500009012",
    isSettled: true,
    settlementId: "STL001235",
    settlementUtr: "PYTM24011500009012",
    settlementDate: "2024-01-16",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "FeePay",
  },
  {
    id: "TXN001234571",
    orderId: "ORD-AMT-2024-005",
    edvironOrderId: "EDV-2024-001234571",
    institute: "Amity University",
    studentName: "Vikram Singh",
    studentId: "STU-AMT-156",
    orderAmount: 125000,
    transactionAmount: 125000,
    vendorAmount: 121875,
    amount: 125000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Online",
    status: "failed",
    statusReason: "Card declined by issuing bank. Insufficient credit limit. Error Code: 10051",
    date: "2024-01-15",
    time: "10:10 AM",
    payerEmail: "vikram.singh@amity.edu",
    payerMobile: "+91 54321 09876",
    studentClass: "B.Tech Year 2",
    studentDivision: "CSE",
    enrollmentNumber: "AMT/2024/BTECH/CSE/156",
    rollNumber: "156",
    feeType: "Semester Fee",
    instrumentType: "Mastercard Credit Card",
    instrumentDetails: "•••• •••• •••• 5555",
    cardBrand: "Mastercard",
    cardType: "Credit",
    cardIssuer: "Axis Bank",
    bankReferenceNumber: "BRN24011500005555",
    isSettled: false,
    captureApiUsed: true,
    captureStatus: "authorized",
    authorizedAt: "2024-01-15 10:10:05",
    isSplitPayment: false,
    vendor: "Edviron",
  },
  {
    id: "TXN001234572",
    orderId: "ORD-DPS-2024-006",
    edvironOrderId: "EDV-2024-001234572",
    institute: "Delhi Public School",
    studentName: "Neha Verma",
    studentId: "STU-DPS-089",
    orderAmount: 38500,
    transactionAmount: 38000,
    vendorAmount: 37050,
    amount: 38000,
    gateway: "Cashfree",
    paymentMode: "UPI",
    channel: "Auto Debit",
    status: "success",
    statusReason: "UPI AutoPay mandate executed successfully.",
    date: "2024-01-15",
    time: "10:05 AM",
    payerEmail: "neha.verma@gmail.com",
    payerMobile: "+91 43210 98765",
    studentClass: "Class 9",
    studentDivision: "D",
    enrollmentNumber: "DPS/2024/09D/089",
    rollNumber: "89",
    feeType: "Tuition Fee - Q4",
    instrumentType: "UPI",
    instrumentDetails: "neha@ybl",
    psp: "Google Pay",
    upiId: "neha@ybl",
    bankReferenceNumber: "BRN24011500003456",
    isSettled: true,
    settlementId: "STL001235",
    settlementUtr: "CSHF24011500003456",
    settlementDate: "2024-01-16",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: true,
    splitDetails: {
      totalSplits: 3,
      splits: [
        {
          beneficiary: "Delhi Public School",
          account: "XXXX1234",
          ifsc: "HDFC0001234",
          amount: 30000,
          percentage: 78.9,
          status: "settled",
        },
        {
          beneficiary: "Lab Fee Account",
          account: "XXXX9012",
          ifsc: "SBIN0009012",
          amount: 5000,
          percentage: 13.2,
          status: "settled",
        },
        {
          beneficiary: "Library Fund",
          account: "XXXX3456",
          ifsc: "ICIC0003456",
          amount: 3000,
          percentage: 7.9,
          status: "pending",
        },
      ],
    },
    vendor: "SchoolPay",
  },
  {
    id: "TXN001234573",
    orderId: "ORD-SMC-2024-007",
    edvironOrderId: "EDV-2024-001234573",
    institute: "St. Mary's College",
    studentName: "Rohan Joshi",
    studentId: "STU-SMC-034",
    orderAmount: 42000,
    transactionAmount: 42000,
    vendorAmount: 40950,
    amount: 42000,
    gateway: "NTT Atom",
    paymentMode: "Credit Card",
    channel: "Online",
    status: "refunded",
    statusReason: "Full refund processed. Student transferred to another school. ARN: 74123456789012345678901",
    date: "2024-01-15",
    time: "10:00 AM",
    payerEmail: "rohan.joshi@gmail.com",
    payerMobile: "+91 32109 87654",
    studentClass: "Class 12",
    studentDivision: "A",
    enrollmentNumber: "SMC/2024/12A/034",
    rollNumber: "34",
    feeType: "Exam Fee",
    instrumentType: "Visa Credit Card",
    instrumentDetails: "•••• •••• •••• 1234",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "Kotak Mahindra Bank",
    bankReferenceNumber: "BRN24011500001234",
    isSettled: false,
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-15 10:00:10",
    capturedAt: "2024-01-15 10:00:25",
    captureDelay: "15 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 420,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-NTT-2024011510001234",
    mdrAmount: 840,
    mdrPercentage: 2.0,
    mdrBearing: "merchant_bearing",
    cardNetwork: "Visa",
    // Refund details showing why we don't refund the full transaction amount
    refundDetails: {
      refundId: "RFD-2024-001234579",
      refundDate: "2024-01-16",
      refundedAmount: 40740,
      originalOrderAmount: 42000,
      pgChargesDeducted: 840,
      erpCommissionDeducted: 420,
      netRefundToParent: 40740,
      refundReason: "Student transferred to another school",
      refundStatus: "completed",
      refundArn: "74123456789012345678901",
    },
  },
  {
    id: "TXN001234580",
    orderId: "ORD-DPS-2024-012",
    edvironOrderId: "EDV-2024-001234580",
    institute: "Delhi Public School",
    studentName: "Arjun Mehta",
    studentId: "STU-DPS-034",
    orderAmount: 85000,
    transactionAmount: 85000,
    vendorAmount: 82875,
    amount: 85000,
    gateway: "Bank Transfer",
    paymentMode: "Bank Transfer",
    channel: "Challan",
    status: "success",
    statusReason: "Bank challan verified and confirmed. Funds credited to school account.",
    date: "2024-01-14",
    time: "11:30 AM",
    payerEmail: "arjun.mehta@gmail.com",
    payerMobile: "+91 98123 45678",
    studentClass: "Class 11",
    studentDivision: "B",
    enrollmentNumber: "DPS/2024/11B/034",
    rollNumber: "34",
    feeType: "Annual Fee + Lab Fee",
    instrumentType: "Bank Challan",
    instrumentDetails: "HDFC Bank Challan",
    bankReferenceNumber: "HDFC24011400001234",
    isSettled: true,
    settlementId: "STL001240",
    settlementUtr: "HDFC24011400001234",
    settlementDate: "2024-01-14",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    bankTransferDetails: {
      type: "challan",
      challanNumber: "CHN-2024-DPS-001234",
      bankName: "HDFC Bank",
      accountNumber: "XXXX5678",
      ifscCode: "HDFC0001234",
      utrNumber: "HDFC24011400001234",
      depositDate: "2024-01-14",
      branchName: "Connaught Place, New Delhi",
      referenceNumber: "REF-DPS-2024-001234",
    },
    vendor: "PaySchool",
  },
  {
    id: "TXN001234581",
    orderId: "ORD-SMC-2024-013",
    edvironOrderId: "EDV-2024-001234581",
    institute: "St. Mary's College",
    studentName: "Kavya Reddy",
    studentId: "STU-SMC-056",
    orderAmount: 65000,
    transactionAmount: 65000,
    vendorAmount: 63375,
    amount: 65000,
    gateway: "Bank Transfer",
    paymentMode: "Bank Transfer",
    channel: "NEFT",
    status: "success",
    statusReason: "NEFT transfer verified. UTR confirmed by bank.",
    date: "2024-01-14",
    time: "02:15 PM",
    payerEmail: "kavya.reddy@outlook.com",
    payerMobile: "+91 87654 12345",
    studentClass: "Class 10",
    studentDivision: "A",
    enrollmentNumber: "SMC/2024/10A/056",
    rollNumber: "56",
    feeType: "Tuition Fee - Annual",
    instrumentType: "NEFT Transfer",
    instrumentDetails: "ICICI Bank NEFT",
    bankReferenceNumber: "ICIC24011400005678",
    isSettled: true,
    settlementId: "STL001241",
    settlementUtr: "ICIC24011400005678",
    settlementDate: "2024-01-14",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    bankTransferDetails: {
      type: "neft",
      bankName: "ICICI Bank",
      accountNumber: "XXXX9012",
      ifscCode: "ICIC0001234",
      utrNumber: "ICIC24011400005678",
      depositDate: "2024-01-14",
      branchName: "Banjara Hills, Hyderabad",
      referenceNumber: "NEFT/2024/SMC/005678",
    },
    vendor: "EduPay",
  },
  {
    id: "TXN001234582",
    orderId: "ORD-MOD-2024-014",
    edvironOrderId: "EDV-2024-001234582",
    institute: "Modern School",
    studentName: "Rohit Agarwal",
    studentId: "STU-MOD-078",
    orderAmount: 120000,
    transactionAmount: 120000,
    vendorAmount: 117000,
    amount: 120000,
    gateway: "Bank Transfer",
    paymentMode: "Bank Transfer",
    channel: "RTGS",
    status: "pending",
    statusReason: "RTGS initiated. Awaiting bank confirmation.",
    date: "2024-01-15",
    time: "09:45 AM",
    payerEmail: "rohit.agarwal@company.com",
    payerMobile: "+91 76543 98765",
    studentClass: "Class 12",
    studentDivision: "Science",
    enrollmentNumber: "MOD/2024/12S/078",
    rollNumber: "78",
    feeType: "Full Year Fee",
    instrumentType: "RTGS Transfer",
    instrumentDetails: "SBI RTGS",
    bankReferenceNumber: "SBIN24011500009012",
    isSettled: false,
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    bankTransferDetails: {
      type: "rtgs",
      bankName: "State Bank of India",
      accountNumber: "XXXX3456",
      ifscCode: "SBIN0001234",
      referenceNumber: "RTGS/2024/MOD/009012",
      branchName: "Parliament Street, New Delhi",
    },
    vendor: "Edviron",
  },
  {
    id: "TXN001234583",
    orderId: "ORD-RYN-2024-015",
    edvironOrderId: "EDV-2024-001234583",
    institute: "Ryan International",
    studentName: "Ananya Sharma",
    studentId: "STU-RYN-045",
    orderAmount: 45000,
    transactionAmount: 45000,
    vendorAmount: 43875,
    amount: 45000,
    gateway: "Bank Transfer",
    paymentMode: "Bank Transfer",
    channel: "VPA Collect",
    status: "success",
    statusReason: "VPA collect request completed. Payment confirmed via UPI.",
    date: "2024-01-14",
    time: "04:30 PM",
    payerEmail: "ananya.sharma@gmail.com",
    payerMobile: "+91 65432 87654",
    studentClass: "Class 9",
    studentDivision: "C",
    enrollmentNumber: "RYN/2024/09C/045",
    rollNumber: "45",
    feeType: "Quarterly Fee - Q4",
    instrumentType: "VPA Collect",
    instrumentDetails: "ryan.fees@ybl",
    upiId: "ryan.fees@ybl",
    bankReferenceNumber: "YESB24011400003456",
    isSettled: true,
    settlementId: "STL001242",
    settlementUtr: "YESB24011400003456",
    settlementDate: "2024-01-15",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    bankTransferDetails: {
      type: "vpa",
      vpa: "ryan.fees@ybl",
      bankName: "Yes Bank",
      utrNumber: "YESB24011400003456",
      referenceNumber: "VPA/2024/RYN/003456",
    },
    vendor: "SchoolPay",
  },
  // Pay Later Transactions
  {
    id: "TXN001234584",
    orderId: "ORD-DPS-2024-016",
    edvironOrderId: "EDV-2024-001234584",
    institute: "Delhi Public School",
    studentName: "Aditya Kapoor",
    studentId: "STU-DPS-112",
    orderAmount: 75000,
    transactionAmount: 25000,
    vendorAmount: 24375,
    amount: 25000,
    gateway: "Razorpay",
    paymentMode: "Pay Later",
    channel: "Online",
    status: "success",
    statusReason: "Pay Later - EMI 1 of 3 completed successfully. Next payment due on 15th Feb 2024.",
    date: "2024-01-15",
    time: "11:45 AM",
    payerEmail: "aditya.kapoor@gmail.com",
    payerMobile: "+91 99887 76655",
    studentClass: "Class 10",
    studentDivision: "A",
    enrollmentNumber: "DPS/2024/10A/112",
    rollNumber: "112",
    feeType: "Annual Fee - EMI Plan",
    instrumentType: "Pay Later - 3 EMI",
    instrumentDetails: "EMI Plan (3 months)",
    bankReferenceNumber: "BRN24011500012345",
    isSettled: true,
    settlementId: "STL001250",
    settlementUtr: "RAZP24011500012345",
    settlementDate: "2024-01-16",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
  },
  {
    id: "TXN001234585",
    orderId: "ORD-SMC-2024-017",
    edvironOrderId: "EDV-2024-001234585",
    institute: "St. Mary's College",
    studentName: "Meera Nair",
    studentId: "STU-SMC-078",
    orderAmount: 90000,
    transactionAmount: 30000,
    vendorAmount: 29250,
    amount: 30000,
    gateway: "Cashfree",
    paymentMode: "Pay Later",
    channel: "Payment Link",
    status: "pending",
    statusReason: "Pay Later - EMI 2 of 3. Payment link sent. Awaiting payment.",
    date: "2024-01-15",
    time: "02:30 PM",
    payerEmail: "meera.nair@outlook.com",
    payerMobile: "+91 88776 65544",
    studentClass: "Class 11",
    studentDivision: "B",
    enrollmentNumber: "SMC/2024/11B/078",
    rollNumber: "78",
    feeType: "Semester Fee - EMI Plan",
    instrumentType: "Pay Later - 3 EMI",
    instrumentDetails: "EMI Plan (3 months)",
    bankReferenceNumber: "BRN24011500023456",
    isSettled: false,
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "SchoolPay",
    erpCommission: 300,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-CSF-2024011514302345",
    mdrAmount: 450,
    mdrPercentage: 1.5,
    mdrBearing: "merchant_bearing",
    // Autopay/Mandate details for recurring payments
    autopayDetails: {
      mandateId: "MAND-UPI-2024-000123",
      mandateType: "UPI",
      mandateStatus: "active",
      maxAmount: 35000,
      frequency: "monthly",
      validUntil: "2025-01-15",
      upiVpa: "meera.nair@okaxis",
    },
  },
  // Split and Pay Transactions (Multi-mode payment)
  {
    id: "TXN001234586",
    orderId: "ORD-MOD-2024-018",
    edvironOrderId: "EDV-2024-001234586",
    institute: "Modern School",
    studentName: "Raj Malhotra",
    studentId: "STU-MOD-089",
    orderAmount: 200000,
    transactionAmount: 200000,
    vendorAmount: 195000,
    amount: 200000,
    gateway: "Razorpay",
    paymentMode: "Split and Pay",
    channel: "Online",
    status: "success",
    statusReason: "Split and Pay - Multi-mode payment completed. Parent paid using Credit Card + UPI + Net Banking.",
    date: "2024-01-15",
    time: "03:15 PM",
    payerEmail: "raj.malhotra@company.com",
    payerMobile: "+91 77665 54433",
    studentClass: "Class 12",
    studentDivision: "Commerce",
    enrollmentNumber: "MOD/2024/12C/089",
    rollNumber: "89",
    feeType: "Full Year Fee - Multi-mode Payment",
    instrumentType: "Split and Pay (Multi-mode)",
    instrumentDetails: "Credit Card + UPI + Net Banking",
    bankReferenceNumber: "BRN24011500034567",
    isSettled: true,
    settlementId: "STL001251",
    settlementUtr: "RAZP24011500034567",
    settlementDate: "2024-01-16",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: true,
    splitDetails: {
      totalSplits: 3,
      splits: [
        {
          beneficiary: "Modern School Main",
          account: "XXXX7890",
          ifsc: "HDFC0007890",
          amount: 160000,
          percentage: 80,
          status: "settled",
        },
        {
          beneficiary: "Transport Account",
          account: "XXXX4567",
          ifsc: "ICIC0004567",
          amount: 40000,
          percentage: 20,
          status: "settled",
        },
      ],
    },
    splitPayModes: [
      {
        mode: "Credit Card",
        amount: 100000,
        status: "success",
        transactionId: "TXN001234586-CC",
        cardNetwork: "Visa",
      },
      {
        mode: "UPI",
        amount: 60000,
        status: "success",
        transactionId: "TXN001234586-UPI",
        upiPsp: "Google Pay",
      },
      {
        mode: "Net Banking",
        amount: 40000,
        status: "success",
        transactionId: "TXN001234586-NB",
        bankName: "HDFC Bank",
      },
    ],
    vendor: "Edviron",
  },
  {
    id: "TXN001234587",
    orderId: "ORD-RYN-2024-019",
    edvironOrderId: "EDV-2024-001234587",
    institute: "Ryan International",
    studentName: "Priya Sharma",
    studentId: "STU-RYN-067",
    orderAmount: 120000,
    transactionAmount: 40000,
    vendorAmount: 39000,
    amount: 40000,
    gateway: "Easebuzz",
    paymentMode: "Split and Pay",
    channel: "Payment Form",
    status: "success",
    statusReason: "Split and Pay - Payment 2 of 3 completed. Remaining: ₹40,000",
    date: "2024-01-14",
    time: "10:00 AM",
    payerEmail: "priya.sharma@gmail.com",
    payerMobile: "+91 66554 43322",
    studentClass: "Class 8",
    studentDivision: "A",
    enrollmentNumber: "RYN/2024/08A/067",
    rollNumber: "67",
    feeType: "Annual Fee - Split Payment",
    instrumentType: "Split and Pay - 3 Parts",
    instrumentDetails: "Part 2 of 3 (₹40,000)",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "HDFC Bank",
    bankReferenceNumber: "BRN24011400045678",
    isSettled: true,
    settlementId: "STL001252",
    settlementUtr: "EASE24011400045678",
    settlementDate: "2024-01-15",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-14 10:00:15",
    capturedAt: "2024-01-14 10:00:45",
    captureDelay: "30 seconds",
    isSplitPayment: true,
    splitDetails: {
      totalSplits: 2,
      splits: [
        {
          beneficiary: "Ryan International",
          account: "XXXX2345",
          ifsc: "SBIN0002345",
          amount: 35000,
          percentage: 87.5,
          status: "settled",
        },
        {
          beneficiary: "Activity Fee Account",
          account: "XXXX6789",
          ifsc: "HDFC0006789",
          amount: 5000,
          percentage: 12.5,
          status: "pending",
        },
      ],
    },
    vendor: "FeePay",
    erpCommission: 400,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-EASE-2024011410004567",
    mdrAmount: 600,
    mdrPercentage: 1.5,
    mdrBearing: "surcharge",
    // Timeline showing split payments
    splitPayTimeline: [
      {
        splitNumber: 1,
        amount: 40000,
        paidDate: "2023-12-15",
        paymentMode: "UPI",
        status: "completed",
        transactionId: "TXN001234587-S1",
      },
      {
        splitNumber: 2,
        amount: 40000,
        paidDate: "2024-01-14",
        paymentMode: "Credit Card",
        status: "completed",
        transactionId: "TXN001234587-S2",
      },
      {
        splitNumber: 3,
        amount: 40000,
        dueDate: "2024-02-15",
        paymentMode: null,
        status: "pending",
        transactionId: null,
      },
    ],
  },
  {
    id: "TXN001234588",
    orderId: "ORD-AMT-2024-020",
    edvironOrderId: "EDV-2024-001234588",
    institute: "Amity University",
    studentName: "Karan Mehta",
    studentId: "STU-AMT-234",
    orderAmount: 200000,
    transactionAmount: 66667,
    vendorAmount: 65000,
    amount: 66667,
    gateway: "Razorpay",
    paymentMode: "Split and Pay",
    channel: "Online",
    status: "failed",
    statusReason: "Split and Pay - Payment 3 of 3 failed. Card declined. Please retry with different payment method.",
    date: "2024-01-15",
    time: "04:45 PM",
    payerEmail: "karan.mehta@amity.edu",
    payerMobile: "+91 55443 32211",
    studentClass: "MBA Year 1",
    studentDivision: "Finance",
    enrollmentNumber: "AMT/2024/MBA/FIN/234",
    rollNumber: "234",
    feeType: "Semester Fee - Split Payment",
    instrumentType: "Split and Pay - 3 Parts",
    instrumentDetails: "Part 3 of 3 (₹66,667)",
    cardBrand: "Mastercard",
    cardType: "Credit",
    cardIssuer: "ICICI Bank",
    bankReferenceNumber: "BRN24011500056789",
    isSettled: false,
    captureApiUsed: true,
    captureStatus: "authorized",
    authorizedAt: "2024-01-15 04:45:10",
    isSplitPayment: false,
    vendor: "EduPay",
  },
  // Card EMI Transaction
  {
    id: "TXN001234589",
    orderId: "ORD-DPS-2024-021",
    edvironOrderId: "EDV-2024-001234589",
    institute: "Delhi Public School",
    studentName: "Ankit Verma",
    studentId: "STU-DPS-145",
    orderAmount: 180000,
    transactionAmount: 180000,
    vendorAmount: 175500,
    amount: 180000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Online",
    status: "success",
    statusReason: "Card EMI - 6 month EMI converted. No Cost EMI - Institute bears interest.",
    date: "2024-01-15",
    time: "05:30 PM",
    payerEmail: "ankit.verma@gmail.com",
    payerMobile: "+91 99887 11223",
    studentClass: "Class 11",
    studentDivision: "Science",
    enrollmentNumber: "DPS/2024/11S/145",
    rollNumber: "145",
    feeType: "Annual Fee - No Cost EMI",
    instrumentType: "Credit Card EMI (6 months)",
    instrumentDetails: "•••• •••• •••• 7890",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "HDFC Bank",
    bankReferenceNumber: "BRN24011500067890",
    isSettled: true,
    settlementId: "STL001260",
    settlementUtr: "RAZP24011500067890",
    settlementDate: "2024-01-16",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-15 05:30:15",
    capturedAt: "2024-01-15 05:30:45",
    captureDelay: "30 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
  financingCategory: "card_emi",
  financingType: "no_cost_emi",
  emiCostBearing: "institute",
  cardIssuingBank: "HDFC Bank",
  emiTenure: 6,
  emiAmount: 30000,
  },
  // NBFC Financing Transaction
  {
    id: "TXN001234590",
    orderId: "ORD-AMT-2024-022",
    edvironOrderId: "EDV-2024-001234590",
    institute: "Amity University",
    studentName: "Priyanka Sharma",
    studentId: "STU-AMT-301",
    orderAmount: 350000,
    transactionAmount: 350000,
    vendorAmount: 341250,
    amount: 350000,
    gateway: "Razorpay",
    paymentMode: "NBFC Financing",
    channel: "Online",
    status: "success",
    statusReason: "NBFC Financing approved via Bajaj Finserv. 12 month EMI. Edviron handles collection.",
    date: "2024-01-15",
    time: "06:00 PM",
    payerEmail: "priyanka.sharma@amity.edu",
    payerMobile: "+91 88776 54321",
    studentClass: "MBA Year 1",
    studentDivision: "Marketing",
    enrollmentNumber: "AMT/2024/MBA/MKT/301",
    rollNumber: "301",
    feeType: "Semester Fee - NBFC Financing",
    instrumentType: "NBFC EMI (12 months)",
    instrumentDetails: "Bajaj Finserv",
    bankReferenceNumber: "BAJAJ24011500078901",
    isSettled: true,
    settlementId: "STL001261",
    settlementUtr: "BAJAJ24011500078901",
    settlementDate: "2024-01-16",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    financingCategory: "nbfc_financing",
    financingType: "emi",
    emiCostBearing: "parent",
    nbfcPartner: "Bajaj Finserv",
    financingCollectionType: "edviron_collection",
    emiTenure: 12,
    emiAmount: 29167,
  },
  // International Payment Transaction
  {
    id: "TXN001234591",
    orderId: "ORD-DPS-2024-023",
    edvironOrderId: "EDV-2024-001234591",
    institute: "Delhi Public School",
    studentName: "Ahmed Khan",
    studentId: "STU-DPS-NRI-012",
    orderAmount: 250000,
    transactionAmount: 250000,
    vendorAmount: 243750,
    amount: 250000,
    gateway: "Flywire",
    paymentMode: "International Payment",
    channel: "International Gateway",
    status: "success",
    statusReason: "International payment via Flywire. Paid in USD, converted to INR at 83.25 rate.",
    date: "2024-01-15",
    time: "08:30 AM",
    payerEmail: "ahmed.khan@gmail.com",
    payerMobile: "+971 50 123 4567",
    studentClass: "Class 10",
    studentDivision: "A",
    enrollmentNumber: "DPS/2024/10A/NRI-012",
    rollNumber: "NRI-012",
    feeType: "Annual Fee - NRI Student",
    instrumentType: "Wire Transfer (Flywire)",
    instrumentDetails: "USD Wire Transfer",
    bankReferenceNumber: "FLY24011500089012",
    isSettled: true,
    settlementId: "STL001262",
    settlementUtr: "FLY24011500089012",
    settlementDate: "2024-01-17",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    isInternational: true,
    internationalMethod: "flywire",
    internationalPricingType: "foreign_currency",
    currency: "USD",
    exchangeRate: 83.25,
    originalAmount: 3003,
  },
  // School Counter - Cash Transaction
  {
    id: "TXN001234592",
    orderId: "ORD-MOD-2024-024",
    edvironOrderId: "EDV-2024-001234592",
    institute: "Modern School",
    studentName: "Rahul Kumar",
    studentId: "STU-MOD-201",
    orderAmount: 25000,
    transactionAmount: 25000,
    vendorAmount: 25000,
    amount: 25000,
    gateway: "School Counter",
    paymentMode: "Cash",
    channel: "School Counter",
    status: "success",
    statusReason: "Cash payment collected at school counter. Receipt issued.",
    date: "2024-01-15",
    time: "10:00 AM",
    payerEmail: "rahul.kumar.parent@gmail.com",
    payerMobile: "+91 98765 12345",
    studentClass: "Class 6",
    studentDivision: "B",
    enrollmentNumber: "MOD/2024/06B/201",
    rollNumber: "201",
    feeType: "Quarterly Fee - Q4",
    instrumentType: "Cash",
    instrumentDetails: "School Counter Collection",
    bankReferenceNumber: "SCH24011500090123",
    isSettled: true,
    settlementId: "STL001263",
    settlementUtr: "SCH24011500090123",
    settlementDate: "2024-01-15",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    schoolCounterDetails: {
      mode: "cash",
      receiptNumber: "RCP-MOD-2024-001234",
      collectedBy: "Mr. Sharma (Accounts)",
      collectionDate: "2024-01-15",
    },
  },
  // School Counter - Cheque Transaction
  {
    id: "TXN001234593",
    orderId: "ORD-RYN-2024-025",
    edvironOrderId: "EDV-2024-001234593",
    institute: "Ryan International",
    studentName: "Sanya Gupta",
    studentId: "STU-RYN-156",
    orderAmount: 85000,
    transactionAmount: 85000,
    vendorAmount: 85000,
    amount: 85000,
    gateway: "School Counter",
    paymentMode: "Cheque",
    channel: "School Counter",
    status: "pending",
    statusReason: "Cheque submitted. Awaiting clearance (3-5 business days).",
    date: "2024-01-15",
    time: "11:30 AM",
    payerEmail: "gupta.family@outlook.com",
    payerMobile: "+91 87654 23456",
    studentClass: "Class 9",
    studentDivision: "C",
    enrollmentNumber: "RYN/2024/09C/156",
    rollNumber: "156",
    feeType: "Half-Yearly Fee",
    instrumentType: "Cheque",
    instrumentDetails: "HDFC Bank Cheque",
    bankReferenceNumber: "CHQ24011500101234",
    isSettled: false,
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "FeePay",
    schoolCounterDetails: {
      mode: "cheque",
      chequeNumber: "123456",
      issuingBank: "HDFC Bank",
      receiptNumber: "RCP-RYN-2024-002345",
      collectedBy: "Ms. Verma (Fee Counter)",
      collectionDate: "2024-01-15",
    },
  },
  // User Dropped Transaction
  {
    id: "TXN001234594",
    orderId: "ORD-SMC-2024-026",
    edvironOrderId: "EDV-2024-001234594",
    institute: "St. Mary's College",
    studentName: "Vikash Singh",
    studentId: "STU-SMC-089",
    orderAmount: 45000,
    transactionAmount: 0,
    vendorAmount: 0,
    amount: 0,
    gateway: "Razorpay",
    paymentMode: "UPI",
    channel: "Online",
    status: "user_dropped",
    statusReason: "User abandoned payment. Closed browser after reaching payment page.",
    date: "2024-01-15",
    time: "02:15 PM",
    payerEmail: "vikash.singh@gmail.com",
    payerMobile: "+91 76543 21098",
    studentClass: "Class 11",
    studentDivision: "A",
    enrollmentNumber: "SMC/2024/11A/089",
    rollNumber: "089",
    feeType: "Tuition Fee - Q4",
    instrumentType: "UPI",
    instrumentDetails: "Payment not completed",
    isSettled: false,
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "SchoolPay",
  },
  // ==================== COMPREHENSIVE SAMPLE TRANSACTIONS ====================
  // UPI with all PSPs
  {
    id: "TXN001234600",
    orderId: "ORD-DPS-2024-100",
    edvironOrderId: "EDV-2024-001234600",
    institute: "Delhi Public School",
    studentName: "Arjun Mehta",
    studentId: "STU-DPS-100",
    orderAmount: 35000,
    transactionAmount: 35000,
    vendorAmount: 34125,
    amount: 35000,
    gateway: "Razorpay",
    paymentMode: "UPI",
    channel: "Payment Link",
    status: "success",
    statusReason: "UPI payment via PhonePe completed successfully.",
    date: "2024-01-16",
    time: "09:15 AM",
    payerEmail: "arjun.mehta@gmail.com",
    payerMobile: "+91 99887 76655",
    studentClass: "Class 8",
    studentDivision: "A",
    enrollmentNumber: "DPS/2024/08A/100",
    rollNumber: "100",
    feeType: "Quarterly Fee - Q1",
    instrumentType: "UPI",
    instrumentDetails: "arjun.mehta@ybl",
    psp: "PhonePe",
    upiId: "arjun.mehta@ybl",
    bankReferenceNumber: "UPI24011609151234",
    isSettled: true,
    settlementId: "STL001300",
    settlementUtr: "RAZP24011609151234",
    settlementDate: "2024-01-17",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 350,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-UPI-001234600",
    mdrAmount: 175,
    mdrPercentage: 0.5,
    mdrBearing: "merchant_bearing",
  },
  // UPI with Google Pay
  {
    id: "TXN001234601",
    orderId: "ORD-MOD-2024-101",
    edvironOrderId: "EDV-2024-001234601",
    institute: "Modern School",
    studentName: "Sneha Patel",
    studentId: "STU-MOD-101",
    orderAmount: 42000,
    transactionAmount: 42000,
    vendorAmount: 40950,
    amount: 42000,
    gateway: "Cashfree",
    paymentMode: "UPI",
    channel: "Online",
    status: "success",
    statusReason: "UPI payment via Google Pay. Transaction verified.",
    date: "2024-01-16",
    time: "10:30 AM",
    payerEmail: "sneha.patel@gmail.com",
    payerMobile: "+91 88776 65544",
    studentClass: "Class 9",
    studentDivision: "B",
    enrollmentNumber: "MOD/2024/09B/101",
    rollNumber: "101",
    feeType: "Tuition Fee - Jan",
    instrumentType: "UPI",
    instrumentDetails: "sneha.patel@okaxis",
    psp: "Google Pay",
    upiId: "sneha.patel@okaxis",
    bankReferenceNumber: "UPI24011610301234",
    isSettled: true,
    settlementId: "STL001301",
    settlementUtr: "CSF24011610301234",
    settlementDate: "2024-01-17",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 420,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-CSF-UPI-001234601",
    mdrAmount: 210,
    mdrPercentage: 0.5,
    mdrBearing: "merchant_bearing",
  },
  // Credit Card - Visa
  {
    id: "TXN001234602",
    orderId: "ORD-RYN-2024-102",
    edvironOrderId: "EDV-2024-001234602",
    institute: "Ryan International",
    studentName: "Kabir Singh",
    studentId: "STU-RYN-102",
    orderAmount: 85000,
    transactionAmount: 85000,
    vendorAmount: 82875,
    amount: 85000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Payment Form",
    status: "success",
    statusReason: "Credit Card payment - Visa card authorized and captured.",
    date: "2024-01-16",
    time: "11:45 AM",
    payerEmail: "kabir.singh@company.com",
    payerMobile: "+91 77665 54433",
    studentClass: "Class 11",
    studentDivision: "Commerce",
    enrollmentNumber: "RYN/2024/11C/102",
    rollNumber: "102",
    feeType: "Annual Fee",
    instrumentType: "Credit Card",
    instrumentDetails: "Visa •••• 4242",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "HDFC Bank",
    bankReferenceNumber: "CC24011611451234",
    isSettled: true,
    settlementId: "STL001302",
    settlementUtr: "RAZP24011611451234",
    settlementDate: "2024-01-18",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-16 11:45:15",
    capturedAt: "2024-01-16 11:45:30",
    captureDelay: "15 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 850,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-CC-001234602",
    mdrAmount: 1700,
    mdrPercentage: 2.0,
    mdrBearing: "surcharge",
  },
  // Debit Card - RuPay
  {
    id: "TXN001234603",
    orderId: "ORD-DPS-2024-103",
    edvironOrderId: "EDV-2024-001234603",
    institute: "Delhi Public School",
    studentName: "Priya Verma",
    studentId: "STU-DPS-103",
    orderAmount: 28000,
    transactionAmount: 28000,
    vendorAmount: 27440,
    amount: 28000,
    gateway: "PayU",
    paymentMode: "Debit Card",
    channel: "Online",
    status: "success",
    statusReason: "Debit Card payment - RuPay card. Zero MDR transaction.",
    date: "2024-01-16",
    time: "02:20 PM",
    payerEmail: "priya.verma@gmail.com",
    payerMobile: "+91 66554 43322",
    studentClass: "Class 7",
    studentDivision: "A",
    enrollmentNumber: "DPS/2024/07A/103",
    rollNumber: "103",
    feeType: "Quarterly Fee - Q1",
    instrumentType: "Debit Card",
    instrumentDetails: "RuPay •••• 8765",
    cardBrand: "RuPay",
    cardType: "Debit",
    cardIssuer: "SBI",
    bankReferenceNumber: "DC24011614201234",
    isSettled: true,
    settlementId: "STL001303",
    settlementUtr: "PAYU24011614201234",
    settlementDate: "2024-01-17",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-16 02:20:10",
    capturedAt: "2024-01-16 02:20:25",
    captureDelay: "15 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 280,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-PAYU-DC-001234603",
    mdrAmount: 0,
    mdrPercentage: 0,
    mdrBearing: "merchant_bearing",
  },
  // Net Banking - HDFC
  {
    id: "TXN001234604",
    orderId: "ORD-MOD-2024-104",
    edvironOrderId: "EDV-2024-001234604",
    institute: "Modern School",
    studentName: "Ananya Sharma",
    studentId: "STU-MOD-104",
    orderAmount: 55000,
    transactionAmount: 55000,
    vendorAmount: 53625,
    amount: 55000,
    gateway: "Razorpay",
    paymentMode: "Net Banking",
    channel: "Payment Link",
    status: "success",
    statusReason: "Net Banking payment via HDFC Bank completed.",
    date: "2024-01-16",
    time: "03:45 PM",
    payerEmail: "ananya.sharma@gmail.com",
    payerMobile: "+91 55443 32211",
    studentClass: "Class 10",
    studentDivision: "A",
    enrollmentNumber: "MOD/2024/10A/104",
    rollNumber: "104",
    feeType: "Semester Fee",
    instrumentType: "Net Banking",
    instrumentDetails: "HDFC Bank",
    bankName: "HDFC Bank",
    bankReferenceNumber: "NB24011615451234",
    isSettled: true,
    settlementId: "STL001304",
    settlementUtr: "RAZP24011615451234",
    settlementDate: "2024-01-18",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 550,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-NB-001234604",
    mdrAmount: 825,
    mdrPercentage: 1.5,
    mdrBearing: "merchant_bearing",
  },
  // Wallet - Paytm
  {
    id: "TXN001234605",
    orderId: "ORD-RYN-2024-105",
    edvironOrderId: "EDV-2024-001234605",
    institute: "Ryan International",
    studentName: "Rohan Gupta",
    studentId: "STU-RYN-105",
    orderAmount: 15000,
    transactionAmount: 15000,
    vendorAmount: 14625,
    amount: 15000,
    gateway: "Paytm",
    paymentMode: "Wallet",
    channel: "Online",
    status: "success",
    statusReason: "Paytm Wallet payment completed. Instant credit.",
    date: "2024-01-16",
    time: "04:30 PM",
    payerEmail: "rohan.gupta@gmail.com",
    payerMobile: "+91 44332 21100",
    studentClass: "Class 5",
    studentDivision: "B",
    enrollmentNumber: "RYN/2024/05B/105",
    rollNumber: "105",
    feeType: "Monthly Fee - Jan",
    instrumentType: "Wallet",
    instrumentDetails: "Paytm Wallet",
    walletName: "Paytm",
    bankReferenceNumber: "WAL24011616301234",
    isSettled: true,
    settlementId: "STL001305",
    settlementUtr: "PAYTM24011616301234",
    settlementDate: "2024-01-16",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 150,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-PAYTM-WAL-001234605",
    mdrAmount: 225,
    mdrPercentage: 1.5,
    mdrBearing: "surcharge",
  },
  // Card EMI - No Cost EMI (Institute Bearing)
  {
    id: "TXN001234606",
    orderId: "ORD-DPS-2024-106",
    edvironOrderId: "EDV-2024-001234606",
    institute: "Delhi Public School",
    studentName: "Vikram Malhotra",
    studentId: "STU-DPS-106",
    orderAmount: 150000,
    transactionAmount: 150000,
    vendorAmount: 142500,
    amount: 150000,
    gateway: "Razorpay",
    paymentMode: "Card EMI",
    channel: "Payment Form",
    status: "success",
    statusReason: "No Cost EMI - 6 months @ ₹25,000/month. Interest subvented by institute.",
    date: "2024-01-16",
    time: "05:15 PM",
    payerEmail: "vikram.malhotra@company.com",
    payerMobile: "+91 33221 10099",
    studentClass: "Class 12",
    studentDivision: "Science",
    enrollmentNumber: "DPS/2024/12S/106",
    rollNumber: "106",
    feeType: "Annual Fee - EMI",
    instrumentType: "Card EMI",
    instrumentDetails: "ICICI Credit Card - 6 Month EMI",
    cardBrand: "Mastercard",
    cardType: "Credit",
    cardIssuer: "ICICI Bank",
    cardIssuingBank: "ICICI Bank",
    bankReferenceNumber: "EMI24011617151234",
    isSettled: true,
    settlementId: "STL001306",
    settlementUtr: "RAZP24011617151234",
    settlementDate: "2024-01-18",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-16 05:15:20",
    capturedAt: "2024-01-16 05:15:45",
    captureDelay: "25 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
    financingCategory: "card_emi",
    financingType: "no_cost_emi",
    emiCostBearing: "institute",
    emiTenure: 6,
    emiAmount: 25000,
    erpCommission: 1500,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-EMI-001234606",
    mdrAmount: 3000,
    mdrPercentage: 2.0,
    mdrBearing: "merchant_bearing",
    financingCharges: {
      totalCharges: 7500,
      parentCharge: 0,
      parentChargePercentage: 0,
      instituteCharge: 7500,
      instituteChargePercentage: 5,
      bankCharge: 0,
      bankChargePercentage: 0,
      subventionAmount: 7500,
    },
  },
  // Card EMI - Partial Cost EMI (Parent + Institute)
  {
    id: "TXN001234607",
    orderId: "ORD-MOD-2024-107",
    edvironOrderId: "EDV-2024-001234607",
    institute: "Modern School",
    studentName: "Ishaan Reddy",
    studentId: "STU-MOD-107",
    orderAmount: 120000,
    transactionAmount: 120000,
    vendorAmount: 115200,
    amount: 120000,
    gateway: "Easebuzz",
    paymentMode: "Card EMI",
    channel: "Payment Link",
    status: "success",
    statusReason: "Partial Cost EMI - 9 months. 2% by parent, 2% by institute.",
    date: "2024-01-17",
    time: "10:00 AM",
    payerEmail: "ishaan.reddy@gmail.com",
    payerMobile: "+91 22110 09988",
    studentClass: "Class 11",
    studentDivision: "Commerce",
    enrollmentNumber: "MOD/2024/11C/107",
    rollNumber: "107",
    feeType: "Annual Fee - EMI",
    instrumentType: "Card EMI",
    instrumentDetails: "HDFC Credit Card - 9 Month EMI",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "HDFC Bank",
    cardIssuingBank: "HDFC Bank",
    bankReferenceNumber: "EMI24011710001234",
    isSettled: true,
    settlementId: "STL001307",
    settlementUtr: "EASE24011710001234",
    settlementDate: "2024-01-19",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-17 10:00:15",
    capturedAt: "2024-01-17 10:00:35",
    captureDelay: "20 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
    financingCategory: "card_emi",
    financingType: "partial_cost_emi",
    partialCostSharing: "parent_institute",
    emiTenure: 9,
    emiAmount: 13333,
    erpCommission: 1200,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-EASE-EMI-001234607",
    mdrAmount: 2400,
    mdrPercentage: 2.0,
    mdrBearing: "surcharge",
    financingCharges: {
      totalCharges: 4800,
      parentCharge: 2400,
      parentChargePercentage: 2,
      instituteCharge: 2400,
      instituteChargePercentage: 2,
      bankCharge: 0,
      bankChargePercentage: 0,
    },
  },
  // NBFC Financing - Edviron Collection
  {
    id: "TXN001234608",
    orderId: "ORD-RYN-2024-108",
    edvironOrderId: "EDV-2024-001234608",
    institute: "Ryan International",
    studentName: "Aditya Joshi",
    studentId: "STU-RYN-108",
    orderAmount: 200000,
    transactionAmount: 200000,
    vendorAmount: 192000,
    amount: 200000,
    gateway: "Razorpay",
    paymentMode: "Pay Later",
    channel: "Payment Form",
    status: "success",
    statusReason: "NBFC Pay Later via Bajaj Finserv. 12 month tenure approved. Edviron collection.",
    date: "2024-01-17",
    time: "11:30 AM",
    payerEmail: "aditya.joshi@company.com",
    payerMobile: "+91 11009 98877",
    studentClass: "Class 12",
    studentDivision: "Science",
    enrollmentNumber: "RYN/2024/12S/108",
    rollNumber: "108",
    feeType: "Full Year Fee - Financed",
    instrumentType: "Pay Later",
    instrumentDetails: "Bajaj Finserv - 12 Month EMI",
    bankReferenceNumber: "NBFC24011711301234",
    isSettled: true,
    settlementId: "STL001308",
    settlementUtr: "BAJAJ24011711301234",
    settlementDate: "2024-01-19",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    financingCategory: "nbfc_financing",
    financingType: "emi",
    nbfcPartner: "Bajaj Finserv",
    financingCollectionType: "edviron_collection",
    emiTenure: 12,
    emiAmount: 16667,
    erpCommission: 2000,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-BAJAJ-NBFC-001234608",
    mdrAmount: 4000,
    mdrPercentage: 2.0,
    mdrBearing: "merchant_bearing",
    financingCharges: {
      totalCharges: 8000,
      parentCharge: 8000,
      parentChargePercentage: 4,
      instituteCharge: 0,
      instituteChargePercentage: 0,
      bankCharge: 0,
      bankChargePercentage: 0,
    },
  },
  // Split and Pay - 3 installments with detailed timeline
  {
    id: "TXN001234609",
    orderId: "ORD-DPS-2024-109",
    edvironOrderId: "EDV-2024-001234609",
    institute: "Delhi Public School",
    studentName: "Kavya Nair",
    studentId: "STU-DPS-109",
    orderAmount: 180000,
    transactionAmount: 60000,
    vendorAmount: 58500,
    amount: 60000,
    gateway: "Razorpay",
    paymentMode: "Split and Pay",
    channel: "Payment Form",
    status: "success",
    statusReason: "Split and Pay - Payment 1 of 3 completed via UPI. Next: ₹60,000 due Feb 15.",
    date: "2024-01-17",
    time: "02:00 PM",
    payerEmail: "kavya.nair@gmail.com",
    payerMobile: "+91 99000 88776",
    studentClass: "Class 10",
    studentDivision: "A",
    enrollmentNumber: "DPS/2024/10A/109",
    rollNumber: "109",
    feeType: "Annual Fee - 3 Installments",
    instrumentType: "Split and Pay",
    instrumentDetails: "Part 1 of 3 (₹60,000)",
    psp: "PhonePe",
    upiId: "kavya.nair@ybl",
    bankReferenceNumber: "SPL24011714001234",
    isSettled: true,
    settlementId: "STL001309",
    settlementUtr: "RAZP24011714001234",
    settlementDate: "2024-01-18",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 600,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-SPL-001234609",
    mdrAmount: 300,
    mdrPercentage: 0.5,
    mdrBearing: "merchant_bearing",
splitPayTimeline: [
    {
      splitNumber: 1,
      amount: 60000,
      paidDate: "2024-01-17",
      paidTime: "02:00:15 PM",
      paymentMode: "UPI",
      status: "completed",
      transactionId: "TXN001234609-S1",
      mdrAmount: 300,
      mdrPercentage: 0.5,
      erpCommission: 600,
      erpCommissionPercentage: 1.0,
      netAmount: 59100,
      gatewayTransactionId: "GTXN-RZP-SPL-S1-001234609",
    },
    {
      splitNumber: 2,
      amount: 60000,
      dueDate: "2024-02-15",
      paymentMode: null,
      status: "pending",
      transactionId: null,
      mdrAmount: 300,
      mdrPercentage: 0.5,
      erpCommission: 600,
      erpCommissionPercentage: 1.0,
      netAmount: 59100,
    },
    {
      splitNumber: 3,
      amount: 60000,
      dueDate: "2024-03-15",
      paymentMode: null,
      status: "pending",
      transactionId: null,
      mdrAmount: 300,
      mdrPercentage: 0.5,
      erpCommission: 600,
      erpCommissionPercentage: 1.0,
      netAmount: 59100,
    },
  ],
  // Transaction Lifecycle
  transactionLifecycle: [
    { event: "Order Created", timestamp: "2024-01-17 01:55:00 PM", description: "Fee payment order initiated for Annual Fee - 3 Installments", status: "info" },
    { event: "Payment Link Sent", timestamp: "2024-01-17 01:55:05 PM", description: "Payment link shared via SMS and Email", status: "info" },
    { event: "Payment Initiated", timestamp: "2024-01-17 02:00:00 PM", description: "Parent initiated UPI payment via PhonePe", status: "info" },
    { event: "Payment Authorized", timestamp: "2024-01-17 02:00:10 PM", description: "UPI payment authorized by PhonePe", status: "success" },
    { event: "Payment Captured", timestamp: "2024-01-17 02:00:15 PM", description: "Payment of ₹60,000 captured successfully", status: "success" },
    { event: "Settlement Initiated", timestamp: "2024-01-17 06:00:00 PM", description: "Settlement batch created for ₹59,100", status: "info" },
    { event: "Settlement Completed", timestamp: "2024-01-18 10:30:00 AM", description: "Amount settled to institute bank account", status: "success" },
  ],
  },
  // Autopay / Recurring Payment
  {
    id: "TXN001234610",
    orderId: "ORD-MOD-2024-110",
    edvironOrderId: "EDV-2024-001234610",
    institute: "Modern School",
    studentName: "Rahul Kapoor",
    studentId: "STU-MOD-110",
    orderAmount: 25000,
    transactionAmount: 25000,
    vendorAmount: 24375,
    amount: 25000,
    gateway: "Razorpay",
    paymentMode: "UPI Autopay",
    channel: "Autopay",
    status: "success",
    statusReason: "Monthly autopay mandate executed. UPI mandate ID: MAND-UPI-2024-110.",
    date: "2024-01-17",
    time: "09:00 AM",
    payerEmail: "rahul.kapoor@gmail.com",
    payerMobile: "+91 88997 76655",
    studentClass: "Class 8",
    studentDivision: "B",
    enrollmentNumber: "MOD/2024/08B/110",
    rollNumber: "110",
    feeType: "Monthly Fee - Autopay",
    instrumentType: "UPI Autopay",
    instrumentDetails: "Monthly UPI Mandate",
    psp: "Google Pay",
    upiId: "rahul.kapoor@okaxis",
    bankReferenceNumber: "AUTO24011709001234",
    isSettled: true,
    settlementId: "STL001310",
    settlementUtr: "RAZP24011709001234",
    settlementDate: "2024-01-18",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 250,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-AUTO-001234610",
    mdrAmount: 125,
    mdrPercentage: 0.5,
    mdrBearing: "merchant_bearing",
    autopayDetails: {
      mandateId: "MAND-UPI-2024-110",
      mandateType: "UPI",
      mandateStatus: "active",
      maxAmount: 30000,
      frequency: "monthly",
      validUntil: "2025-01-17",
      upiVpa: "rahul.kapoor@okaxis",
    },
  },
  // School Counter - Demand Draft
  {
    id: "TXN001234611",
    orderId: "ORD-RYN-2024-111",
    edvironOrderId: "EDV-2024-001234611",
    institute: "Ryan International",
    studentName: "Neha Agarwal",
    studentId: "STU-RYN-111",
    orderAmount: 95000,
    transactionAmount: 95000,
    vendorAmount: 95000,
    amount: 95000,
    gateway: "School Counter",
    paymentMode: "Demand Draft",
    channel: "School Counter",
    status: "success",
    statusReason: "Demand Draft received and cleared. DD No: 123456.",
    date: "2024-01-17",
    time: "11:00 AM",
    payerEmail: "neha.agarwal.parent@gmail.com",
    payerMobile: "+91 77886 65544",
    studentClass: "Class 9",
    studentDivision: "A",
    enrollmentNumber: "RYN/2024/09A/111",
    rollNumber: "111",
    feeType: "Annual Fee - DD Payment",
    instrumentType: "Demand Draft",
    instrumentDetails: "DD No: 123456 - ICICI Bank",
    bankReferenceNumber: "DD24011711001234",
    isSettled: true,
    settlementId: "STL001311",
    settlementUtr: "DD24011711001234",
    settlementDate: "2024-01-20",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 0,
    erpCommissionPercentage: 0,
    gatewayTransactionId: "SCH-DD-001234611",
    mdrAmount: 0,
    mdrPercentage: 0,
    mdrBearing: "merchant_bearing",
    schoolCounterDetails: {
      mode: "demand_draft",
      ddNumber: "123456",
      issuingBank: "ICICI Bank",
      receiptNumber: "RCP-RYN-2024-001111",
      collectedBy: "Mrs. Verma (Accounts)",
      collectionDate: "2024-01-17",
    },
  },
  // International Payment - USD
  {
    id: "TXN001234612",
    orderId: "ORD-DPS-2024-112",
    edvironOrderId: "EDV-2024-001234612",
    institute: "Delhi Public School",
    studentName: "Omar Al-Rashid",
    studentId: "STU-DPS-NRI-112",
    orderAmount: 300000,
    transactionAmount: 300000,
    vendorAmount: 291000,
    amount: 300000,
    gateway: "Flywire",
    paymentMode: "International Payment",
    channel: "International Gateway",
    status: "success",
    statusReason: "International wire transfer via Flywire. Paid in USD ($3,600), converted at 83.33 INR/USD.",
    date: "2024-01-17",
    time: "08:30 AM",
    payerEmail: "omar.alrashid@gmail.com",
    payerMobile: "+971 50 987 6543",
    studentClass: "Class 11",
    studentDivision: "Science",
    enrollmentNumber: "DPS/2024/11S/NRI-112",
    rollNumber: "NRI-112",
    feeType: "Annual Fee - NRI",
    instrumentType: "Wire Transfer",
    instrumentDetails: "USD Wire via Flywire",
    bankReferenceNumber: "FLY24011708301234",
    isSettled: true,
    settlementId: "STL001312",
    settlementUtr: "FLY24011708301234",
    settlementDate: "2024-01-20",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    isInternational: true,
    internationalMethod: "flywire",
    internationalPricingType: "foreign_currency",
    currency: "USD",
    exchangeRate: 83.33,
    originalAmount: 3600,
    erpCommission: 3000,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-FLY-INT-001234612",
    mdrAmount: 6000,
    mdrPercentage: 2.0,
    mdrBearing: "surcharge",
  },
  // Bank Transfer - NEFT
  {
    id: "TXN001234613",
    orderId: "ORD-MOD-2024-113",
    edvironOrderId: "EDV-2024-001234613",
    institute: "Modern School",
    studentName: "Arun Kumar",
    studentId: "STU-MOD-113",
    orderAmount: 75000,
    transactionAmount: 75000,
    vendorAmount: 73875,
    amount: 75000,
    gateway: "Bank Transfer",
    paymentMode: "Bank Transfer",
    channel: "Bank Transfer",
    status: "success",
    statusReason: "NEFT transfer received and verified. UTR: SBIN24011710001234.",
    date: "2024-01-17",
    time: "10:30 AM",
    payerEmail: "arun.kumar@company.com",
    payerMobile: "+91 66554 43322",
    studentClass: "Class 10",
    studentDivision: "B",
    enrollmentNumber: "MOD/2024/10B/113",
    rollNumber: "113",
    feeType: "Semester Fee - NEFT",
    instrumentType: "Bank Transfer",
    instrumentDetails: "NEFT from SBI",
    bankReferenceNumber: "SBIN24011710001234",
    isSettled: true,
    settlementId: "STL001313",
    settlementUtr: "SBIN24011710001234",
    settlementDate: "2024-01-17",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 750,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "BT-NEFT-001234613",
    mdrAmount: 375,
    mdrPercentage: 0.5,
    mdrBearing: "merchant_bearing",
    bankTransferDetails: {
      type: "neft",
      bankName: "State Bank of India",
      accountNumber: "XXXX4567",
      ifscCode: "SBIN0001234",
      utrNumber: "SBIN24011710001234",
      depositDate: "2024-01-17",
      branchName: "SBI Connaught Place",
      referenceNumber: "REF-NEFT-001234613",
    },
  },
  // Refunded Transaction with full breakdown
  {
    id: "TXN001234614",
    orderId: "ORD-RYN-2024-114",
    edvironOrderId: "EDV-2024-001234614",
    institute: "Ryan International",
    studentName: "Divya Menon",
    studentId: "STU-RYN-114",
    orderAmount: 50000,
    transactionAmount: 50000,
    vendorAmount: 48750,
    amount: 50000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Online",
    status: "refunded",
    statusReason: "Full refund processed. Student transferred to another school.",
    date: "2024-01-10",
    time: "02:30 PM",
    payerEmail: "divya.menon@gmail.com",
    payerMobile: "+91 55443 32211",
    studentClass: "Class 7",
    studentDivision: "A",
    enrollmentNumber: "RYN/2024/07A/114",
    rollNumber: "114",
    feeType: "Quarterly Fee - Refunded",
    instrumentType: "Credit Card",
    instrumentDetails: "Mastercard •••• 5678",
    cardBrand: "Mastercard",
    cardType: "Credit",
    cardIssuer: "Axis Bank",
    bankReferenceNumber: "CC24011014301234",
    isSettled: true,
    settlementId: "STL001314",
    settlementUtr: "RAZP24011014301234",
    settlementDate: "2024-01-11",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-10 02:30:10",
    capturedAt: "2024-01-10 02:30:25",
    captureDelay: "15 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 500,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-CC-001234614",
    mdrAmount: 1000,
    mdrPercentage: 2.0,
    mdrBearing: "merchant_bearing",
    refundDetails: {
      refundId: "RFD-2024-001234614",
      refundDate: "2024-01-15",
      refundedAmount: 48500,
      originalOrderAmount: 50000,
      pgChargesDeducted: 1000,
      erpCommissionDeducted: 500,
      netRefundToParent: 48500,
      refundReason: "Student transferred to another school",
      refundStatus: "completed",
      refundArn: "74123456789012345678902",
    },
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-01-10 02:25:00 PM", description: "Quarterly Fee payment order created", status: "info" },
      { event: "Payment Initiated", timestamp: "2024-01-10 02:30:00 PM", description: "Credit Card payment initiated", status: "info" },
      { event: "Payment Authorized", timestamp: "2024-01-10 02:30:10 PM", description: "Credit Card authorized by Axis Bank", status: "success" },
      { event: "Payment Captured", timestamp: "2024-01-10 02:30:25 PM", description: "Payment of ₹50,000 captured", status: "success" },
      { event: "Settlement Completed", timestamp: "2024-01-11 11:00:00 AM", description: "₹48,750 settled to institute", status: "success" },
      { event: "Refund Requested", timestamp: "2024-01-14 03:00:00 PM", description: "Refund initiated - Student transferred to another school", status: "warning" },
      { event: "Refund Processing", timestamp: "2024-01-14 03:05:00 PM", description: "Refund of ₹48,500 being processed (ORDER AMT ₹50,000 - PG Charges ₹1,000 - ERP Comm ₹500)", status: "info" },
      { event: "Refund Completed", timestamp: "2024-01-15 10:30:00 AM", description: "₹48,500 refunded to parent's card. Note: Refund based on ORDER AMOUNT, not transaction amount", status: "success" },
    ],
  },
  // Failed Transaction
  {
    id: "TXN001234615",
    orderId: "ORD-DPS-2024-115",
    edvironOrderId: "EDV-2024-001234615",
    institute: "Delhi Public School",
    studentName: "Manish Tiwari",
    studentId: "STU-DPS-115",
    orderAmount: 40000,
    transactionAmount: 40000,
    vendorAmount: 0,
    amount: 40000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Payment Form",
    status: "failed",
    statusReason: "Card declined by issuing bank. Insufficient funds or limit exceeded.",
    date: "2024-01-17",
    time: "03:45 PM",
    payerEmail: "manish.tiwari@gmail.com",
    payerMobile: "+91 44332 21100",
    studentClass: "Class 9",
    studentDivision: "B",
    enrollmentNumber: "DPS/2024/09B/115",
    rollNumber: "115",
    feeType: "Quarterly Fee",
    instrumentType: "Credit Card",
    instrumentDetails: "Visa •••• 9876",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "HDFC Bank",
    isSettled: false,
    captureApiUsed: true,
    captureStatus: "void",
    authorizedAt: "2024-01-17 03:45:10",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 0,
    erpCommissionPercentage: 0,
    gatewayTransactionId: "GTXN-RZP-CC-001234615",
    mdrAmount: 0,
    mdrPercentage: 0,
    mdrBearing: "merchant_bearing",
  },
  // Multi-mode Split and Pay (Credit Card + UPI + Net Banking)
  {
    id: "TXN001234616",
    orderId: "ORD-MOD-2024-116",
    edvironOrderId: "EDV-2024-001234616",
    institute: "Modern School",
    studentName: "Pooja Sharma",
    studentId: "STU-MOD-116",
    orderAmount: 180000,
    transactionAmount: 180000,
    vendorAmount: 175500,
    amount: 180000,
    gateway: "Razorpay",
    paymentMode: "Split and Pay",
    channel: "Payment Form",
    status: "success",
    statusReason: "Multi-mode payment: CC (₹80,000) + UPI (₹60,000) + Net Banking (₹40,000).",
    date: "2024-01-18",
    time: "11:00 AM",
    payerEmail: "pooja.sharma@company.com",
    payerMobile: "+91 99887 76655",
    studentClass: "Class 12",
    studentDivision: "Commerce",
    enrollmentNumber: "MOD/2024/12C/116",
    rollNumber: "116",
    feeType: "Annual Fee - Multi-mode",
    instrumentType: "Split and Pay (Multi-mode)",
    instrumentDetails: "Credit Card + UPI + Net Banking",
    bankReferenceNumber: "SPL24011811001234",
    isSettled: true,
    settlementId: "STL001316",
    settlementUtr: "RAZP24011811001234",
    settlementDate: "2024-01-19",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-18 11:00:15",
    capturedAt: "2024-01-18 11:00:45",
    captureDelay: "30 seconds",
    isSplitPayment: true,
    splitPayModes: [
      {
        mode: "Credit Card",
        amount: 80000,
        status: "success",
        transactionId: "TXN001234616-CC",
        cardNetwork: "Mastercard",
      },
      {
        mode: "UPI",
        amount: 60000,
        status: "success",
        transactionId: "TXN001234616-UPI",
        upiPsp: "PhonePe",
      },
      {
        mode: "Net Banking",
        amount: 40000,
        status: "success",
        transactionId: "TXN001234616-NB",
        bankName: "SBI",
      },
    ],
    vendor: "Edviron",
    erpCommission: 1800,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-SPL-001234616",
    mdrAmount: 2700,
    mdrPercentage: 1.5,
    mdrBearing: "surcharge",
  },
  // NACH Autopay
  {
    id: "TXN001234617",
    orderId: "ORD-RYN-2024-117",
    edvironOrderId: "EDV-2024-001234617",
    institute: "Ryan International",
    studentName: "Siddharth Rao",
    studentId: "STU-RYN-117",
    orderAmount: 35000,
    transactionAmount: 35000,
    vendorAmount: 34125,
    amount: 35000,
    gateway: "Razorpay",
    paymentMode: "NACH Autopay",
    channel: "Autopay",
    status: "success",
    statusReason: "NACH mandate executed. Monthly debit from HDFC Bank account.",
    date: "2024-01-18",
    time: "06:00 AM",
    payerEmail: "siddharth.rao@gmail.com",
    payerMobile: "+91 88776 65544",
    studentClass: "Class 6",
    studentDivision: "A",
    enrollmentNumber: "RYN/2024/06A/117",
    rollNumber: "117",
    feeType: "Monthly Fee - NACH",
    instrumentType: "NACH Autopay",
    instrumentDetails: "NACH Mandate - HDFC Bank",
    bankName: "HDFC Bank",
    bankReferenceNumber: "NACH24011806001234",
    isSettled: true,
    settlementId: "STL001317",
    settlementUtr: "RAZP24011806001234",
    settlementDate: "2024-01-20",
    captureApiUsed: false,
    captureStatus: "not_applicable",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 350,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-NACH-001234617",
    mdrAmount: 525,
    mdrPercentage: 1.5,
    mdrBearing: "merchant_bearing",
autopayDetails: {
      mandateId: "MAND-NACH-2024-117",
      mandateType: "NACH",
      mandateStatus: "active",
      maxAmount: 50000,
      frequency: "monthly",
      validUntil: "2026-01-18",
      bankAccountLast4: "7890",
    },
  },
  // Chargeback Transaction Sample
  {
    id: "TXN001234618",
    orderId: "ORD-DPS-2024-118",
    edvironOrderId: "EDV-2024-001234618",
    institute: "Delhi Public School",
    studentName: "Ravi Shankar",
    studentId: "STU-DPS-118",
    orderAmount: 75000,
    transactionAmount: 75000,
    vendorAmount: 0, // Under dispute
    amount: 75000,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Payment Form",
    status: "failed",
    statusReason: "Chargeback initiated - Payment disputed by cardholder. Under review.",
    date: "2024-01-05",
    time: "03:30 PM",
    payerEmail: "ravi.shankar@gmail.com",
    payerMobile: "+91 77665 54433",
    studentClass: "Class 11",
    studentDivision: "Science",
    enrollmentNumber: "DPS/2024/11S/118",
    rollNumber: "118",
    feeType: "Tuition Fee - Disputed",
    instrumentType: "Credit Card",
    instrumentDetails: "Visa •••• 1234",
    cardBrand: "Visa",
    cardType: "Credit",
    cardIssuer: "ICICI Bank",
    bankReferenceNumber: "CC24010515301234",
    isSettled: false,
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-05 03:30:10 PM",
    capturedAt: "2024-01-05 03:30:25 PM",
    captureDelay: "15 seconds",
    isSplitPayment: false,
    vendor: "Edviron",
    erpCommission: 0, // Not charged due to chargeback
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-CC-001234618",
    mdrAmount: 0, // Reversed
    mdrPercentage: 2.0,
    mdrBearing: "surcharge",
    chargebackDetails: {
      chargebackId: "CB-2024-001234618",
      chargebackDate: "2024-01-12",
      chargebackAmount: 75000, // Full ORDER AMOUNT disputed
      chargebackReason: "Goods/Services not received - Parent claims student left school",
      chargebackStatus: "under_review",
      disputeDeadline: "2024-01-26",
      responseSubmittedAt: "2024-01-14 10:00:00 AM",
      evidenceSubmitted: true,
      arbNumber: "ARB-VISA-2024-001234",
      chargebackFee: 1500,
    },
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-01-05 03:25:00 PM", description: "Tuition Fee payment order created", status: "info" },
      { event: "Payment Initiated", timestamp: "2024-01-05 03:30:00 PM", description: "Credit Card payment initiated", status: "info" },
      { event: "Payment Authorized", timestamp: "2024-01-05 03:30:10 PM", description: "Visa Card authorized by ICICI Bank", status: "success" },
      { event: "Payment Captured", timestamp: "2024-01-05 03:30:25 PM", description: "Payment of ₹75,000 captured", status: "success" },
      { event: "Settlement Initiated", timestamp: "2024-01-05 06:00:00 PM", description: "Settlement batch created", status: "info" },
      { event: "Settlement Completed", timestamp: "2024-01-06 11:00:00 AM", description: "₹73,125 settled to institute", status: "success" },
      { event: "Chargeback Filed", timestamp: "2024-01-12 02:00:00 PM", description: "Cardholder disputed ₹75,000 (ORDER AMOUNT). Reason: Services not received", status: "error" },
      { event: "Evidence Requested", timestamp: "2024-01-12 02:05:00 PM", description: "Bank requested proof of service delivery", status: "warning" },
      { event: "Evidence Submitted", timestamp: "2024-01-14 10:00:00 AM", description: "Admission receipt, fee structure, and attendance records submitted", status: "info" },
      { event: "Under Arbitration", timestamp: "2024-01-16 09:00:00 AM", description: "Case under review by Visa. Decision expected by Jan 26. Chargeback on ORDER AMOUNT ₹75,000", status: "warning" },
    ],
  },
  // Multi-mode Split Pay with all charges (Credit Card + UPI + Net Banking)
  {
    id: "TXN001234619",
    orderId: "ORD-MOD-2024-119",
    edvironOrderId: "EDV-2024-001234619",
    institute: "Modern School",
    studentName: "Anita Desai",
    studentId: "STU-MOD-119",
    orderAmount: 240000,
    transactionAmount: 240000,
    vendorAmount: 232800,
    amount: 240000,
    gateway: "Razorpay",
    paymentMode: "Split and Pay",
    channel: "Payment Form",
    status: "success",
    statusReason: "Multi-mode payment completed: CC (₹100,000) + UPI (₹80,000) + Net Banking (₹60,000). All modes include individual charges.",
    date: "2024-01-19",
    time: "11:30 AM",
    payerEmail: "anita.desai@company.com",
    payerMobile: "+91 99887 76655",
    studentClass: "Class 12",
    studentDivision: "Commerce",
    enrollmentNumber: "MOD/2024/12C/119",
    rollNumber: "119",
    feeType: "Annual Fee - Multi-mode Split",
    instrumentType: "Split and Pay (Multi-mode)",
    instrumentDetails: "Credit Card + UPI + Net Banking",
    bankReferenceNumber: "SPL24011911301234",
    isSettled: true,
    settlementId: "STL001319",
    settlementUtr: "RAZP24011911301234",
    settlementDate: "2024-01-20",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-01-19 11:30:15 AM",
    capturedAt: "2024-01-19 11:31:00 AM",
    captureDelay: "45 seconds",
    isSplitPayment: true,
    splitPayModes: [
      {
        mode: "Credit Card",
        amount: 100000,
        status: "success",
        transactionId: "TXN001234619-CC",
        cardNetwork: "Mastercard",
      },
      {
        mode: "UPI",
        amount: 80000,
        status: "success",
        transactionId: "TXN001234619-UPI",
        upiPsp: "Google Pay",
      },
      {
        mode: "Net Banking",
        amount: 60000,
        status: "success",
        transactionId: "TXN001234619-NB",
        bankName: "HDFC Bank",
      },
    ],
    vendor: "Edviron",
    erpCommission: 2400,
    erpCommissionPercentage: 1.0,
    gatewayTransactionId: "GTXN-RZP-SPL-001234619",
    mdrAmount: 4800,
    mdrPercentage: 2.0,
    mdrBearing: "surcharge",
    // Detailed Split Pay Timeline with charges for each mode
    splitPayTimeline: [
      {
        splitNumber: 1,
        amount: 100000,
        paidDate: "2024-01-19",
        paidTime: "11:30:15 AM",
        paymentMode: "Credit Card",
        status: "completed",
        transactionId: "TXN001234619-CC",
        mdrAmount: 2000, // 2% for CC
        mdrPercentage: 2.0,
        erpCommission: 1000, // 1% ERP commission
        erpCommissionPercentage: 1.0,
        netAmount: 97000,
        gatewayTransactionId: "GTXN-RZP-SPL-CC-001234619",
      },
      {
        splitNumber: 2,
        amount: 80000,
        paidDate: "2024-01-19",
        paidTime: "11:30:35 AM",
        paymentMode: "UPI",
        status: "completed",
        transactionId: "TXN001234619-UPI",
        mdrAmount: 400, // 0.5% for UPI
        mdrPercentage: 0.5,
        erpCommission: 800, // 1% ERP commission
        erpCommissionPercentage: 1.0,
        netAmount: 78800,
        gatewayTransactionId: "GTXN-RZP-SPL-UPI-001234619",
      },
      {
        splitNumber: 3,
        amount: 60000,
        paidDate: "2024-01-19",
        paidTime: "11:30:55 AM",
        paymentMode: "Net Banking",
        status: "completed",
        transactionId: "TXN001234619-NB",
        mdrAmount: 900, // 1.5% for Net Banking
        mdrPercentage: 1.5,
        erpCommission: 600, // 1% ERP commission
        erpCommissionPercentage: 1.0,
        netAmount: 58500,
        gatewayTransactionId: "GTXN-RZP-SPL-NB-001234619",
      },
    ],
    // Complete Transaction Lifecycle
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-01-19 11:25:00 AM", description: "Annual Fee order of ₹2,40,000 created with Split Payment option enabled", status: "info" },
      { event: "Payment Link Sent", timestamp: "2024-01-19 11:25:05 AM", description: "Multi-mode payment link shared via SMS and Email", status: "info" },
      { event: "Payment Page Opened", timestamp: "2024-01-19 11:28:00 AM", description: "Parent opened payment page and selected multi-mode payment", status: "info" },
      { event: "Split 1: CC Initiated", timestamp: "2024-01-19 11:30:00 AM", description: "Credit Card payment of ₹1,00,000 initiated", status: "info" },
      { event: "Split 1: CC Authorized", timestamp: "2024-01-19 11:30:10 AM", description: "Mastercard authorized by HDFC Bank", status: "success" },
      { event: "Split 1: CC Captured", timestamp: "2024-01-19 11:30:15 AM", description: "₹1,00,000 captured. MDR: ₹2,000 (2%), ERP: ₹1,000 (1%)", status: "success" },
      { event: "Split 2: UPI Initiated", timestamp: "2024-01-19 11:30:20 AM", description: "UPI payment of ₹80,000 initiated via Google Pay", status: "info" },
      { event: "Split 2: UPI Completed", timestamp: "2024-01-19 11:30:35 AM", description: "₹80,000 captured. MDR: ₹400 (0.5%), ERP: ₹800 (1%)", status: "success" },
      { event: "Split 3: NB Initiated", timestamp: "2024-01-19 11:30:40 AM", description: "Net Banking payment of ₹60,000 initiated", status: "info" },
      { event: "Split 3: NB Completed", timestamp: "2024-01-19 11:30:55 AM", description: "₹60,000 captured. MDR: ₹900 (1.5%), ERP: ₹600 (1%)", status: "success" },
      { event: "All Payments Complete", timestamp: "2024-01-19 11:31:00 AM", description: "Total ₹2,40,000 collected. Total MDR: ₹3,300. Total ERP: ₹2,400", status: "success" },
      { event: "Settlement Initiated", timestamp: "2024-01-19 06:00:00 PM", description: "Settlement batch created for net amount ₹2,34,300", status: "info" },
      { event: "Settlement Completed", timestamp: "2024-01-20 10:30:00 AM", description: "₹2,34,300 settled to institute bank account", status: "success" },
    ],
  },
]

const statusColors = {
  success: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
  refunded: "bg-info/10 text-info border-info/20",
  user_dropped: "bg-gray-500/10 text-gray-400 border-gray-500/20",
}

const baseColumns = [
  "Institute Name",
  "Date & Time",
  "Order ID",
  "Edviron Order ID",
  "Gateway Txn ID",
  "Order Amt",
  "Transaction Amt",
  "ERP Commission",
  "MDR",
  "Payment Method",
  "Channel",
  "Status",
  "Student Name",
  "Student ID",
  "Phone No.",
  "Vendor Amount",
  "Gateway",
  "Capture Status",
  "Bank Reference Number",
  "Split",
  "Settlement",
  "Financing",
  "Currency",
  "Txn Fee",
]

// Helper to get value from nested path (e.g., "customFields.academicYear")
const getNestedValue = (obj: Record<string, unknown>, path: string): unknown => {
  return path.split('.').reduce((current: unknown, key: string) => {
    if (current && typeof current === 'object' && key in (current as Record<string, unknown>)) {
      return (current as Record<string, unknown>)[key]
    }
    return undefined
  }, obj)
}

const captureStatusColors = {
  authorized: "bg-warning/10 text-warning border-warning/20",
  captured: "bg-success/10 text-success border-success/20",
  void: "bg-destructive/10 text-destructive border-destructive/20",
  not_applicable: "bg-secondary text-muted-foreground border-border",
}

interface TransactionsTableProps {
  filters: FilterState
  onSelectionChange?: (selected: string[]) => void
  rowsPerPage?: number
  onRowsPerPageChange?: (value: number) => void
  customColumns?: CustomColumnConfig[]
}

// Transform raw JSON transaction data to Transaction interface
function transformRawTransaction(raw: RawTransaction): Transaction {
  // Handle flat JSON structure (actual format from JSON file)
  const instituteName = typeof raw.institute === "string" ? raw.institute : "Unknown Institute"
  const orderAmount = raw.order_amount || 0
  const transactionAmount = raw.transaction_amount || orderAmount
  const vendorAmount = raw.vendor_amount || 0
  
  // Map status from JSON to expected status values
  const statusMap: Record<string, Transaction["status"]> = {
    "success": "success",
    "completed": "success",
    "paid": "success",
    "failed": "failed",
    "failure": "failed",
    "pending": "pending",
    "processing": "pending",
    "refunded": "refunded",
    "partially_refunded": "partially_refunded",
    "chargeback": "chargeback",
    "disputed": "chargeback",
  }
  
  return {
    id: raw.id || "",
    orderId: raw.order_id || "",
    edvironOrderId: raw.edviron_order_id || raw.order_id || "",
    gatewayTransactionId: raw.gateway_transaction_id || undefined,
    bankReferenceNumber: raw.bank_reference_number || undefined,
    institute: instituteName,
    studentName: raw.student_name || "Unknown",
    studentId: raw.student_id || "",
    orderAmount: orderAmount,
    transactionAmount: transactionAmount,
    vendorAmount: vendorAmount,
    amount: transactionAmount,
    gateway: raw.gateway || "",
    paymentMode: raw.payment_mode || "",
    channel: raw.channel || "Online",
    status: statusMap[raw.status?.toLowerCase()] || "pending",
    statusReason: raw.status_reason || "",
    date: raw.date || "",
    time: raw.time || "",
    payerEmail: raw.payer_email || "",
    payerMobile: raw.payer_mobile || "",
    studentClass: raw.student_class || "",
    studentDivision: raw.student_division || "",
    enrollmentNumber: raw.enrollment_number || "",
    rollNumber: raw.roll_number || "",
    feeType: raw.fee_type || "",
    instrumentType: raw.instrument_type || raw.payment_mode || "",
    instrumentDetails: raw.instrument_details || "",
    psp: raw.psp || undefined,
    cardBrand: raw.card_brand || undefined,
    cardType: raw.card_type || undefined,
    cardIssuer: raw.card_issuer || raw.card_issuing_bank || undefined,
    bankName: raw.bank_name || undefined,
    upiId: raw.upi_id || undefined,
    walletName: raw.wallet_name || undefined,
    isSettled: raw.is_settled === 1,
    settlementId: raw.settlement_id || undefined,
    settlementUtr: raw.settlement_utr || undefined,
    settlementDate: raw.settlement_date || undefined,
    captureApiUsed: raw.capture_api_used === 1,
    captureStatus: raw.capture_status || "not_applicable",
    isSplitPayment: raw.is_split_payment === 1,
    splitDetails: raw.split_details?.splits ? {
      totalSplits: raw.split_details.splits.length,
      splits: raw.split_details.splits.map(s => ({
        beneficiary: s.beneficiary,
        account: s.account,
        ifsc: s.ifsc,
        amount: s.amount,
        percentage: s.percentage,
        status: s.status as "settled" | "pending",
      })),
    } : undefined,
    vendor: raw.split_details?.splits?.find(s => s.beneficiary !== instituteName)?.beneficiary || "",
    mdrAmount: raw.mdr_amount || 0,
    mdrPercentage: raw.mdr_percentage || 0,
    mdrBearing: raw.mdr_bearing as "surcharge" | "merchant_bearing" | undefined,
    erpCommission: raw.erp_commission || 0,
    erpCommissionPercentage: raw.erp_commission_percentage || 0,
    customFields: raw.custom_fields || {},
    refundDetails: raw.refund_details ? {
      refundId: raw.refund_details.refundId,
      refundDate: raw.refund_details.refundDate,
      refundedAmount: raw.refund_details.originalOrderAmount || 0,
      originalOrderAmount: raw.refund_details.originalOrderAmount || 0,
      pgChargesDeducted: raw.refund_details.pgChargesDeducted || 0,
      erpCommissionDeducted: raw.refund_details.erpCommissionDeducted || 0,
      netRefundToParent: raw.refund_details.netRefundToParent || 0,
      refundReason: raw.refund_details.refundReason || "",
      refundStatus: raw.refund_details.refundStatus as "initiated" | "processing" | "completed" | "failed",
      refundArn: raw.refund_details.refundArn,
    } : undefined,
    chargebackDetails: raw.chargeback_details ? {
      chargebackId: raw.chargeback_details.chargebackId,
      chargebackDate: raw.chargeback_details.raisedDate,
      chargebackAmount: raw.chargeback_details.chargebackAmount || 0,
      chargebackReason: raw.chargeback_details.chargebackReason || "",
      chargebackStatus: raw.chargeback_details.chargebackStatus as "initiated" | "under_review" | "won" | "lost" | "closed",
      disputeDeadline: raw.chargeback_details.dueDate,
      responseSubmittedAt: raw.chargeback_details.responseSubmittedAt,
      evidenceSubmitted: raw.chargeback_details.evidenceSubmitted || false,
      arbNumber: raw.chargeback_details.arbNumber,
      chargebackFee: raw.chargeback_details.chargebackFee || 0,
    } : undefined,
    transactionLifecycle: raw.transaction_lifecycle?.map(e => ({
      event: e.event,
      timestamp: e.timestamp,
      description: e.description || e.event,
      status: e.status as "success" | "info" | "warning" | "error",
    })),
  }
}

export function TransactionsTable({ 
  filters, 
  onSelectionChange,
  rowsPerPage = 10,
  onRowsPerPageChange,
  customColumns = []
}: TransactionsTableProps) {
  const router = useRouter()
  const [selectedTransactions, setSelectedTransactions] = useState<string[]>([])
  const [currentPage, setCurrentPage] = useState(1)
  const [visibleColumns, setVisibleColumns] = useState<string[]>([
  "Institute Name",
    "Date & Time",
    "Order ID",
    "Order Amt",
    "Transaction Amt",
    "Payment Method",
    "Status",
    "Student Name",
    "Gateway",
    "Capture Status",
  ])
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  const itemsPerPage = rowsPerPage

  // Load transactions from JSON file
  const { transactions: rawTransactions, isLoading, totalCount } = useTransactionsData()
  
  // Transform raw data to Transaction interface - memoized for performance
  const allLoadedTransactions = useMemo(() => {
    return rawTransactions.map(transformRawTransaction)
  }, [rawTransactions])

  // Combine base columns with custom columns from ERP
  const allColumns = [
    ...baseColumns,
    ...customColumns.map(c => c.displayName)
  ]

  const filteredTransactions = allLoadedTransactions.filter((txn) => {
    // Institute filter
    if (filters.institute !== "all" && filters.institute) {
      const instituteMatch = txn.institute.toLowerCase().includes(filters.institute.toLowerCase())
      if (!instituteMatch) return false
    }
    
    // Date range filter
    if (filters.dateRange && filters.dateRange !== "all") {
      const txnDate = new Date(txn.date)
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      
      // Check for custom date range format (startDate_endDate)
      if (filters.dateRange.includes("_")) {
        const [startStr, endStr] = filters.dateRange.split("_")
        const startDate = new Date(startStr)
        const endDate = new Date(endStr)
        endDate.setHours(23, 59, 59, 999)
        if (txnDate < startDate || txnDate > endDate) return false
      } else {
        let startDate: Date
        switch (filters.dateRange) {
          case "today":
            startDate = today
            break
          case "yesterday":
            startDate = new Date(today)
            startDate.setDate(startDate.getDate() - 1)
            const endOfYesterday = new Date(startDate)
            endOfYesterday.setHours(23, 59, 59, 999)
            if (txnDate < startDate || txnDate > endOfYesterday) return false
            break
          case "7d":
            startDate = new Date(today)
            startDate.setDate(startDate.getDate() - 7)
            if (txnDate < startDate) return false
            break
          case "30d":
            startDate = new Date(today)
            startDate.setDate(startDate.getDate() - 30)
            if (txnDate < startDate) return false
            break
          case "90d":
            startDate = new Date(today)
            startDate.setDate(startDate.getDate() - 90)
            if (txnDate < startDate) return false
            break
          case "this_month":
            startDate = new Date(today.getFullYear(), today.getMonth(), 1)
            if (txnDate < startDate) return false
            break
          case "last_month":
            startDate = new Date(today.getFullYear(), today.getMonth() - 1, 1)
            const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0, 23, 59, 59, 999)
            if (txnDate < startDate || txnDate > endOfLastMonth) return false
            break
          case "this_year":
            startDate = new Date(today.getFullYear(), 0, 1)
            if (txnDate < startDate) return false
            break
          default:
            break
        }
      }
    }
    
    if (filters.status !== "all" && txn.status !== filters.status) return false
    if (filters.gateway !== "all" && !txn.gateway.toLowerCase().includes(filters.gateway.toLowerCase())) return false
    if (filters.channel !== "all" && !txn.channel.toLowerCase().includes(filters.channel.toLowerCase())) return false
    if (filters.vendor !== "all" && txn.vendor.toLowerCase() !== filters.vendor.toLowerCase()) return false
    if (filters.captureStatus !== "all" && txn.captureStatus !== filters.captureStatus) return false
    
    // Payment mode filter with support for pay_later and split_and_pay
    if (filters.paymentMode !== "all") {
      const modeMap: Record<string, string> = {
        "pay_later": "Pay Later",
        "split_and_pay": "Split and Pay",
        "credit_card": "Credit Card",
        "debit_card": "Debit Card",
        "upi": "UPI",
        "netbanking": "Net Banking",
        "wallet": "Wallet",
        "bank_transfer": "Bank Transfer",
        "international": "International Payment",
        "school_counter": "School Counter",
        "cash": "Cash",
        "cheque": "Cheque",
        "demand_draft": "Demand Draft",
        "nbfc_financing": "NBFC Financing",
      }
      const targetMode = modeMap[filters.paymentMode] || filters.paymentMode
      if (!txn.paymentMode.toLowerCase().includes(targetMode.toLowerCase())) return false
    }

    // Financing category filter
    if (filters.financingCategory && filters.financingCategory !== "all") {
      if (filters.financingCategory === "none" && txn.financingCategory) return false
      if (filters.financingCategory !== "none" && txn.financingCategory !== filters.financingCategory) return false
    }

    // Financing type filter (EMI, No Cost EMI, Partial Cost EMI)
    if (filters.financingType && filters.financingType !== "all" && txn.financingType !== filters.financingType) return false

    // EMI cost bearing filter
    if (filters.emiCostBearing && filters.emiCostBearing !== "all" && txn.emiCostBearing !== filters.emiCostBearing) return false

    // NBFC partner filter
    if (filters.nbfcPartner && filters.nbfcPartner !== "all" && txn.nbfcPartner?.toLowerCase() !== filters.nbfcPartner.toLowerCase()) return false

    // Financing collection type filter
    if (filters.financingCollectionType && filters.financingCollectionType !== "all" && txn.financingCollectionType !== filters.financingCollectionType) return false

    // Card Issuing Bank filter (for Card EMI)
    if (filters.cardIssuingBank && filters.cardIssuingBank !== "all") {
      const bankName = txn.cardIssuingBank || txn.cardIssuer
      if (!bankName || !bankName.toLowerCase().includes(filters.cardIssuingBank.toLowerCase())) return false
    }

    // Financing Charge Percentage filters
    if (txn.financingCharges) {
      if (filters.parentChargePercentage && filters.parentChargePercentage !== "all") {
        const targetPercentage = parseFloat(filters.parentChargePercentage)
        if (!isNaN(targetPercentage) && txn.financingCharges.parentChargePercentage !== targetPercentage) return false
      }
      if (filters.instituteChargePercentage && filters.instituteChargePercentage !== "all") {
        const targetPercentage = parseFloat(filters.instituteChargePercentage)
        if (!isNaN(targetPercentage) && txn.financingCharges.instituteChargePercentage !== targetPercentage) return false
      }
      if (filters.bankChargePercentage && filters.bankChargePercentage !== "all") {
        const targetPercentage = parseFloat(filters.bankChargePercentage)
        if (!isNaN(targetPercentage) && txn.financingCharges.bankChargePercentage !== targetPercentage) return false
      }
    }

    // International payment filters
    if (filters.paymentMode === "international") {
      if (filters.internationalMethod && filters.internationalMethod !== "all" && txn.internationalMethod !== filters.internationalMethod) return false
      if (filters.internationalPricingType && filters.internationalPricingType !== "all" && txn.internationalPricingType !== filters.internationalPricingType) return false
      if (filters.currency && filters.currency !== "all" && txn.currency?.toLowerCase() !== filters.currency) return false
    }

    // Transaction fee bearing filter
    if (filters.transactionFeeBearing && filters.transactionFeeBearing !== "all") {
      if (txn.transactionFeeBearing !== filters.transactionFeeBearing) return false
    }

    // Partial fee sharing filter
    if (filters.transactionFeeBearing === "partial" && filters.partialFeeSharing && filters.partialFeeSharing !== "all") {
      if (txn.partialFeeSharing !== filters.partialFeeSharing) return false
    }
    
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase()
      const searchType = filters.searchType || "all"
      
      switch (searchType) {
        case "order_id":
          return txn.orderId.toLowerCase().includes(query)
        case "edviron_order_id":
          return txn.edvironOrderId.toLowerCase().includes(query)
        case "transaction_id":
          return txn.id.toLowerCase().includes(query)
        case "student_name":
          return txn.studentName.toLowerCase().includes(query)
        case "student_id":
          return txn.studentId.toLowerCase().includes(query)
        case "payer_phone":
          return txn.payerMobile.toLowerCase().includes(query)
        case "payer_email":
          return txn.payerEmail.toLowerCase().includes(query)
        case "upi_id":
          return (txn.upiId?.toLowerCase().includes(query) || txn.instrumentDetails.toLowerCase().includes(query))
        case "bank_ref_no":
          return txn.bankReferenceNumber?.toLowerCase().includes(query) || false
        default:
          // Search all fields
          return (
            txn.id.toLowerCase().includes(query) ||
            txn.orderId.toLowerCase().includes(query) ||
            txn.edvironOrderId.toLowerCase().includes(query) ||
            txn.institute.toLowerCase().includes(query) ||
            txn.studentName.toLowerCase().includes(query) ||
            txn.studentId.toLowerCase().includes(query) ||
            txn.payerMobile.toLowerCase().includes(query) ||
            txn.payerEmail.toLowerCase().includes(query) ||
            (txn.upiId?.toLowerCase().includes(query) ?? false) ||
            (txn.bankReferenceNumber?.toLowerCase().includes(query) ?? false)
          )
      }
    }
    return true
  })

  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage)
  const paginatedTransactions = filteredTransactions.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  const toggleSelectAll = () => {
    if (selectedTransactions.length === paginatedTransactions.length) {
      setSelectedTransactions([])
      onSelectionChange?.([])
    } else {
      const newSelection = paginatedTransactions.map((t) => t.id)
      setSelectedTransactions(newSelection)
      onSelectionChange?.(newSelection)
    }
  }

  const toggleSelect = (id: string) => {
    setSelectedTransactions((prev) => {
      const newSelection = prev.includes(id) ? prev.filter((t) => t !== id) : [...prev, id]
      onSelectionChange?.(newSelection)
      return newSelection
    })
  }

const handleViewDetails = (transaction: Transaction) => {
  router.push(`/transactions/${transaction.id}`)
  }

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="p-8">
          <div className="flex flex-col items-center justify-center gap-4">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
            <p className="text-muted-foreground">Loading {totalCount > 0 ? totalCount.toLocaleString() : ""} transactions...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">
              {filteredTransactions.length.toLocaleString()} Transactions
              {totalCount > 0 && filteredTransactions.length !== totalCount && (
                <span className="text-sm font-normal text-muted-foreground ml-2">
                  (filtered from {totalCount.toLocaleString()})
                </span>
              )}
            </CardTitle>
            <div className="flex items-center gap-3">
              {/* Rows per page selector */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Rows:</span>
                <select
                  value={rowsPerPage}
                  onChange={(e) => {
                    onRowsPerPageChange?.(Number(e.target.value))
                    setCurrentPage(1)
                  }}
                  className="h-8 rounded-md border border-input bg-secondary px-2 text-sm"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                </select>
              </div>
              
              <ColumnFilter columns={allColumns} visibleColumns={visibleColumns} onColumnsChange={setVisibleColumns} />
              {selectedTransactions.length > 0 && (
                <>
                  <span className="text-sm text-muted-foreground">{selectedTransactions.length} selected</span>
                  <Button variant="outline" size="sm">
                    Bulk Export
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/50">
                  <th className="p-4 text-left">
                    <Checkbox
                      checked={
                        selectedTransactions.length === paginatedTransactions.length && paginatedTransactions.length > 0
                      }
                      onCheckedChange={toggleSelectAll}
                    />
                  </th>
                  {/* DYNAMIC HEADER RENDERING BASED ON VISIBLE COLUMNS */}
                  {visibleColumns.includes("Institute Name") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institute</th>
                  )}
                  {visibleColumns.includes("Date & Time") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Date & Time</th>
                  )}
                  {visibleColumns.includes("Order ID") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Order ID</th>
                  )}
                  {visibleColumns.includes("Edviron Order ID") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Edviron Order ID</th>
                  )}
                  {visibleColumns.includes("Gateway Txn ID") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Gateway Txn ID</th>
                  )}
                  {visibleColumns.includes("Order Amt") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Order Amt</th>
                  )}
                  {visibleColumns.includes("Transaction Amt") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Txn Amt</th>
                  )}
                  {visibleColumns.includes("ERP Commission") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">
                      <div className="flex items-center gap-1">
                        ERP Comm
                        <Badge variant="outline" className="text-[8px] px-1 py-0 h-4 bg-emerald-500/10 text-emerald-400">
                          %
                        </Badge>
                      </div>
                    </th>
                  )}
                  {visibleColumns.includes("MDR") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">MDR</th>
                  )}
                  {visibleColumns.includes("Payment Method") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Payment Method</th>
                  )}
                  {visibleColumns.includes("Channel") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Channel</th>
                  )}
                  {visibleColumns.includes("Status") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                  )}
                  {visibleColumns.includes("Student Name") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Student Name</th>
                  )}
                  {visibleColumns.includes("Student ID") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Student ID</th>
                  )}
                  {visibleColumns.includes("Phone No.") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Phone</th>
                  )}
                  {visibleColumns.includes("Vendor Amount") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Vendor Amt</th>
                  )}
                  {visibleColumns.includes("Gateway") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Gateway</th>
                  )}
                  {visibleColumns.includes("Capture Status") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Capture</th>
                  )}
                  {visibleColumns.includes("Bank Reference Number") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Bank Ref</th>
                  )}
                  {visibleColumns.includes("Split") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Split</th>
                  )}
                  {visibleColumns.includes("Settlement") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Settlement</th>
                  )}
                  {visibleColumns.includes("Financing") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Financing</th>
                  )}
                  {visibleColumns.includes("Currency") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Currency</th>
                  )}
                  {visibleColumns.includes("Txn Fee") && (
                    <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Txn Fee</th>
                  )}
                  {/* Custom ERP Columns */}
                  {customColumns.map((col) => (
                    visibleColumns.includes(col.displayName) && (
                      <th key={col.id} className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">
                        <div className="flex items-center gap-1">
                          {col.displayName}
                          <Badge variant="outline" className="text-[8px] px-1 py-0 h-4 bg-primary/10 text-primary">
                            ERP
                          </Badge>
                        </div>
                      </th>
                    )
                  ))}
                  <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {paginatedTransactions.map((txn) => (
                  <tr key={txn.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                    <td className="p-4">
                      <Checkbox
                        checked={selectedTransactions.includes(txn.id)}
                        onCheckedChange={() => toggleSelect(txn.id)}
                      />
                    </td>
                    {/* DYNAMIC CELL RENDERING BASED ON VISIBLE COLUMNS */}
                    {visibleColumns.includes("Institute Name") && (
                      <td className="p-4">
                        <span className="text-sm">{txn.institute}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Date & Time") && (
                      <td className="p-4">
                        <span className="text-sm">{txn.date}</span>
                        <p className="text-xs text-muted-foreground">{txn.time}</p>
                      </td>
                    )}
                    {visibleColumns.includes("Order ID") && (
                      <td className="p-4">
                        <Link href={`/transactions/${txn.id}`}>
                          <span className="font-mono text-sm font-medium text-primary hover:underline cursor-pointer">
                            {txn.orderId}
                          </span>
                        </Link>
                        <p className="text-xs text-muted-foreground">{txn.id}</p>
                      </td>
                    )}
                    {visibleColumns.includes("Edviron Order ID") && (
                      <td className="p-4">
                        <span className="font-mono text-xs">{txn.edvironOrderId}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Gateway Txn ID") && (
                      <td className="p-4">
                        <span className="font-mono text-xs text-muted-foreground">
                          {txn.gatewayTransactionId || "-"}
                        </span>
                      </td>
                    )}
                    {visibleColumns.includes("Order Amt") && (
                      <td className="p-4">
                        <span className="text-sm text-muted-foreground">₹{txn.orderAmount.toLocaleString()}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Transaction Amt") && (
                      <td className="p-4">
                        <span className="font-semibold">₹{txn.transactionAmount.toLocaleString()}</span>
                      </td>
                    )}
                    {visibleColumns.includes("ERP Commission") && (
                      <td className="p-4">
                        {txn.erpCommission ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="space-y-0.5">
                                  <span className="font-semibold text-emerald-500">₹{txn.erpCommission.toLocaleString()}</span>
                                  <p className="text-[10px] text-muted-foreground">{txn.erpCommissionPercentage}%</p>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">ERP Commission: ₹{txn.erpCommission} ({txn.erpCommissionPercentage}% of txn amount)</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.includes("MDR") && (
                      <td className="p-4">
                        {txn.mdrAmount ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="space-y-0.5">
                                  <span className="font-medium">₹{txn.mdrAmount.toLocaleString()}</span>
                                  <Badge 
                                    variant="outline" 
                                    className={`text-[9px] px-1 ${
                                      txn.mdrBearing === "surcharge" 
                                        ? "bg-red-500/10 text-red-400 border-red-500/20" 
                                        : "bg-green-500/10 text-green-400 border-green-500/20"
                                    }`}
                                  >
                                    {txn.mdrBearing === "surcharge" ? "Surcharge" : "Merchant"}
                                  </Badge>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <div className="text-xs space-y-1">
                                  <p>MDR: ₹{txn.mdrAmount} ({txn.mdrPercentage}%)</p>
                                  <p>Bearing: {txn.mdrBearing === "surcharge" ? "Charged to Parent" : "Absorbed by Merchant"}</p>
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.includes("Payment Method") && (
                      <td className="p-4">
                        <div className="flex items-center gap-1">
                          <span className="text-sm">{txn.paymentMode}</span>
                          {txn.splitPayModes && txn.splitPayModes.length > 1 && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Badge variant="outline" className="text-[10px] bg-teal-500/10 text-teal-400 border-teal-500/20">
                                    Multi-mode
                                  </Badge>
                                </TooltipTrigger>
                                <TooltipContent className="max-w-sm">
                                  <div className="space-y-2">
                                    <p className="font-semibold text-xs">Payment Modes Used</p>
                                    {txn.splitPayModes.map((mode, idx) => (
                                      <div
                                        key={idx}
                                        className="flex justify-between items-center text-xs border-b border-border pb-1 last:border-0"
                                      >
                                        <div className="flex items-center gap-2">
                                          <span>{mode.mode}</span>
                                          {mode.cardNetwork && (
                                            <Badge variant="secondary" className="text-[10px]">{mode.cardNetwork}</Badge>
                                          )}
                                          {mode.upiPsp && (
                                            <Badge variant="secondary" className="text-[10px]">{mode.upiPsp}</Badge>
                                          )}
                                          {mode.bankName && (
                                            <Badge variant="secondary" className="text-[10px]">{mode.bankName}</Badge>
                                          )}
                                        </div>
                                        <span className={`font-medium ${mode.status === "success" ? "text-success" : mode.status === "pending" ? "text-warning" : "text-destructive"}`}>
                                          ₹{mode.amount.toLocaleString()}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{txn.channel}</p>
                      </td>
                    )}
                    {visibleColumns.includes("Channel") && (
                      <td className="p-4">
                        <span className="text-sm">{txn.channel}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Status") && (
                      <td className="p-4">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center gap-1">
                                <Badge variant="outline" className={statusColors[txn.status]}>
                                  {txn.status}
                                </Badge>
                                <Info className="h-3 w-3 text-muted-foreground" />
                              </div>
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p className="text-xs">{txn.statusReason}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </td>
                    )}
                    {visibleColumns.includes("Student Name") && (
                      <td className="p-4">
                        <span className="text-sm">{txn.studentName}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Student ID") && (
                      <td className="p-4">
                        <span className="font-mono text-xs">{txn.studentId}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Phone No.") && (
                      <td className="p-4">
                        <span className="text-sm">{txn.payerMobile}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Vendor Amount") && (
                      <td className="p-4">
                        <span className="text-sm">₹{txn.vendorAmount.toLocaleString()}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Gateway") && (
                      <td className="p-4">
                        <span className="text-sm">{txn.gateway}</span>
                        <p className="text-xs text-muted-foreground">{txn.vendor}</p>
                      </td>
                    )}
                    {visibleColumns.includes("Capture Status") && (
                      <td className="p-4">
                        <Badge variant="outline" className={captureStatusColors[txn.captureStatus]}>
                          {txn.captureStatus === "authorized" ? "Authorized" : 
                           txn.captureStatus === "captured" ? "Captured" : "N/A"}
                        </Badge>
                        {txn.captureStatus === "authorized" && (
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="h-auto p-0 text-xs text-primary ml-2"
                            onClick={() => {
                              // Handle capture action
                              alert(`Capture transaction ${txn.id}`)
                            }}
                          >
                            Capture
                          </Button>
                        )}
                      </td>
                    )}
                    {visibleColumns.includes("Bank Reference Number") && (
                      <td className="p-4">
                        <span className="font-mono text-xs">{txn.bankReferenceNumber || "-"}</span>
                      </td>
                    )}
                    {visibleColumns.includes("Split") && (
                      <td className="p-4">
                        {txn.isSplitPayment && txn.splitDetails ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="flex items-center gap-1">
                                  <SplitSquareVertical className="h-4 w-4 text-primary" />
                                  <Badge
                                    variant="outline"
                                    className="text-xs bg-primary/10 text-primary border-primary/20"
                                  >
                                    {txn.splitDetails.totalSplits} splits
                                  </Badge>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-sm">
                                <div className="space-y-2">
                                  <p className="font-semibold text-xs">Split Payment Details</p>
                                  {txn.splitDetails.splits.map((split, idx) => (
                                    <div
                                      key={idx}
                                      className="flex justify-between text-xs border-b border-border pb-1 last:border-0"
                                    >
                                      <span>{split.beneficiary}</span>
                                      <span className="font-medium">
                                        ₹{split.amount.toLocaleString()} ({split.percentage}%)
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.includes("Settlement") && (
                      <td className="p-4">
                        {txn.isSettled ? (
                          <div className="flex items-center gap-1.5">
                            <CheckCircle2 className="h-3.5 w-3.5 text-success" />
                            <div>
                              <span className="text-xs font-medium text-success">Settled</span>
                              <p className="text-xs text-muted-foreground font-mono truncate max-w-[120px]">
                                {txn.settlementUtr}
                              </p>
                            </div>
                          </div>
                        ) : (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="flex items-center gap-1.5">
                                  <Clock className="h-3.5 w-3.5 text-warning" />
                                  <span className="text-xs font-medium text-warning">Pending</span>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="text-xs">Expected: 2024-01-17</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </td>
                    )}
                    {visibleColumns.includes("Date") && (
                      <td className="p-4">
                        <span className="text-sm">{txn.date}</span>
                        <p className="text-xs text-muted-foreground">{txn.time}</p>
                      </td>
                    )}
                    {visibleColumns.includes("Financing") && (
                      <td className="p-4">
                        {txn.financingCategory && txn.financingCategory !== "none" ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="space-y-1">
                                  <Badge 
                                    variant="outline" 
                                    className={
                                      txn.financingCategory === "card_emi" 
                                        ? "bg-blue-500/10 text-blue-400 border-blue-500/20 text-[10px]"
                                        : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[10px]"
                                    }
                                  >
                                    {txn.financingCategory === "card_emi" ? "Card EMI" : "NBFC"}
                                  </Badge>
                                  <p className="text-[10px] text-muted-foreground">
                                    {txn.emiTenure} months
                                  </p>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <div className="space-y-2 text-xs">
                                  <p className="font-semibold">Financing Details</p>
                                  <div className="grid grid-cols-2 gap-2">
                                    <span className="text-muted-foreground">Type:</span>
                                    <span>{txn.financingType === "no_cost_emi" ? "No Cost EMI" : txn.financingType === "partial_cost_emi" ? "Partial Cost EMI" : "EMI"}</span>
                                    <span className="text-muted-foreground">Cost Bearer:</span>
                                    <span>{txn.emiCostBearing === "institute" ? "Institute" : txn.emiCostBearing === "bank" ? "Bank" : "Parent"}</span>
                                    {txn.financingType === "partial_cost_emi" && txn.partialCostSharing && (
                                      <>
                                        <span className="text-muted-foreground">Sharing:</span>
                                        <span>{
                                          txn.partialCostSharing === "parent_institute" ? "Parent + Institute" : 
                                          txn.partialCostSharing === "bank_institute" ? "Bank + Institute" : 
                                          txn.partialCostSharing === "parent_bank" ? "Parent + Bank" :
                                          "Parent + Bank + Institute"
                                        }</span>
                                      </>
                                    )}
                                    <span className="text-muted-foreground">EMI Amount:</span>
                                    <span>₹{txn.emiAmount?.toLocaleString()}/month</span>
                                    {txn.financingCategory === "card_emi" && (txn.cardIssuingBank || txn.cardIssuer) && (
                                      <>
                                        <span className="text-muted-foreground">Issuing Bank:</span>
                                        <span>{txn.cardIssuingBank || txn.cardIssuer}</span>
                                      </>
                                    )}
                                    {txn.nbfcPartner && (
                                      <>
                                        <span className="text-muted-foreground">NBFC Partner:</span>
                                        <span>{txn.nbfcPartner}</span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.includes("Currency") && (
                      <td className="p-4">
                        {txn.isInternational ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="space-y-1">
                                  <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/20 text-[10px]">
                                    {txn.currency}
                                  </Badge>
                                  <p className="text-[10px] text-muted-foreground">
                                    {txn.internationalPricingType === "inr_converted" ? "INR Conv." : "Foreign"}
                                  </p>
                                </div>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <div className="space-y-2 text-xs">
                                  <p className="font-semibold">International Payment</p>
                                  <div className="grid grid-cols-2 gap-2">
                                    <span className="text-muted-foreground">Original Amount:</span>
                                    <span>{txn.currency} {txn.originalAmount?.toLocaleString()}</span>
                                    <span className="text-muted-foreground">Exchange Rate:</span>
                                    <span>1 {txn.currency} = ₹{txn.exchangeRate}</span>
                                    <span className="text-muted-foreground">Method:</span>
                                    <span className="capitalize">{txn.internationalMethod}</span>
                                  </div>
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <span className="text-xs text-muted-foreground">INR</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.includes("Txn Fee") && (
                      <td className="p-4">
                        {txn.transactionFeeBearing ? (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="space-y-1">
                                  <Badge 
                                    variant="outline" 
                                    className={`text-[10px] ${
                                      txn.transactionFeeBearing === "payer" 
                                        ? "bg-red-500/10 text-red-400 border-red-500/20"
                                        : txn.transactionFeeBearing === "merchant"
                                          ? "bg-green-500/10 text-green-400 border-green-500/20"
                                          : "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                                    }`}
                                  >
                                    {txn.transactionFeeBearing === "payer" ? "Payer" : txn.transactionFeeBearing === "merchant" ? "Merchant" : "Partial"}
                                  </Badge>
                                  {txn.transactionFee && (
                                    <p className="text-[10px] text-muted-foreground">
                                      ₹{txn.transactionFee.toLocaleString()}
                                    </p>
                                  )}
                                </div>
                              </TooltipTrigger>
                              <TooltipContent className="max-w-xs">
                                <div className="space-y-2 text-xs">
                                  <p className="font-semibold">Transaction Fee Details</p>
                                  <div className="grid grid-cols-2 gap-2">
                                    <span className="text-muted-foreground">Total Fee:</span>
                                    <span>₹{txn.transactionFee?.toLocaleString() || "0"}</span>
                                    <span className="text-muted-foreground">Fee Bearer:</span>
                                    <span>
                                      {txn.transactionFeeBearing === "payer" ? "Payer (Parent)" : 
                                       txn.transactionFeeBearing === "merchant" ? "Merchant (Institute)" : "Partial"}
                                    </span>
                                    {txn.transactionFeeBearing === "partial" && (
                                      <>
                                        <span className="text-muted-foreground">Sharing:</span>
                                        <span>
                                          {txn.partialFeeSharing === "fixed_payer" ? "Fixed by Payer" :
                                           txn.partialFeeSharing === "fixed_merchant" ? "Fixed by Merchant" :
                                           txn.partialFeeSharing === "percentage_split" ? "Percentage Split" : "Mode-based"}
                                        </span>
                                        {txn.payerFeeAmount !== undefined && (
                                          <>
                                            <span className="text-muted-foreground">Payer Pays:</span>
                                            <span>₹{txn.payerFeeAmount.toLocaleString()}</span>
                                          </>
                                        )}
                                        {txn.merchantFeeAmount !== undefined && (
                                          <>
                                            <span className="text-muted-foreground">Merchant Pays:</span>
                                            <span>₹{txn.merchantFeeAmount.toLocaleString()}</span>
                                          </>
                                        )}
                                      </>
                                    )}
                                  </div>
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        ) : (
                          <span className="text-xs text-muted-foreground">-</span>
                        )}
                      </td>
                    )}
                    {/* Custom ERP Column Cells */}
                    {customColumns.map((col) => (
                      visibleColumns.includes(col.displayName) && (
                        <td key={col.id} className="p-4">
                          {(() => {
                            const value = getNestedValue(txn as unknown as Record<string, unknown>, col.apiField)
                            if (value === undefined || value === null) {
                              return <span className="text-xs text-muted-foreground">-</span>
                            }
                            switch (col.type) {
                              case "currency":
                                return <span className="text-sm font-medium">₹{Number(value).toLocaleString()}</span>
                              case "number":
                                return <span className="text-sm font-medium">{value}</span>
                              case "date":
                                return <span className="text-sm">{String(value)}</span>
                              case "badge":
                                return (
                                  <Badge variant="outline" className="text-xs bg-primary/10 text-primary">
                                    {String(value)}
                                  </Badge>
                                )
                              default:
                                return <span className="text-sm">{String(value)}</span>
                            }
                          })()}
                        </td>
                      )
                    ))}
                    <td className="p-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => handleViewDetails(txn)}
                            className="flex items-center cursor-pointer"
                          >
                            <ArrowRight className="mr-2 h-4 w-4" />
                            View Full Details
                          </DropdownMenuItem>
                          {txn.status === "success" && (
                            <DropdownMenuItem>
                              <RotateCcw className="mr-2 h-4 w-4" />
                              Initiate Refund
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            Download Receipt
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between border-t border-border p-4">
            <p className="text-sm text-muted-foreground">
              Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
              {Math.min(currentPage * itemsPerPage, filteredTransactions.length)} of {filteredTransactions.length}{" "}
              results
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedTransaction && (
        <TransactionDetailModal transaction={selectedTransaction} onClose={() => setSelectedTransaction(null)} />
      )}
    </>
  )
}
