"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Copy,
  Download,
  RotateCcw,
  User,
  CreditCard,
  Smartphone,
  Building2,
  CheckCircle2,
  Clock,
  Mail,
  Phone,
  GraduationCap,
  Hash,
  Wallet,
  Landmark,
  AlertCircle,
  SplitSquareVertical,
  FileText,
  ArrowRight,
  CalendarClock,
  Banknote,
  TrendingUp,
  Globe,
  Layers,
  Receipt,
  History,
  XCircle,
  AlertTriangle,
  RefreshCw,
  ArrowUpRight,
  CircleDollarSign,
  ShieldAlert,
  Percent,
} from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Transaction } from "./transactions-table"

interface TransactionDetailModalProps {
  transaction: Transaction | null
  onClose: () => void
}

const statusColors = {
  success: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
  refunded: "bg-info/10 text-info border-info/20",
  user_dropped: "bg-gray-500/10 text-gray-400 border-gray-500/20",
}

const pspColors: Record<string, string> = {
  PhonePe: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  "Google Pay": "bg-blue-500/10 text-blue-400 border-blue-500/20",
  Paytm: "bg-sky-500/10 text-sky-400 border-sky-500/20",
  CRED: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  "Amazon Pay": "bg-orange-500/10 text-orange-400 border-orange-500/20",
  WhatsApp: "bg-green-500/10 text-green-400 border-green-500/20",
}

const cardBrandColors: Record<string, string> = {
  Visa: "bg-blue-600/10 text-blue-400 border-blue-600/20",
  Mastercard: "bg-red-500/10 text-red-400 border-red-500/20",
  Rupay: "bg-green-600/10 text-green-400 border-green-600/20",
  Amex: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
}

interface SplitWithSettlement {
  beneficiary: string
  percentage: number
  amount: number
  account: string
  ifsc: string
  status: "settled" | "pending" | "processing"
  // Settlement details
  settlementId?: string
  settlementDate?: string
  settlementUtr?: string
  expectedSettlementDate?: string
  gateway?: string
  netAmount?: number
  fees?: number
  feeBearer?: "platform" | "beneficiary"
}

// Transaction Lifecycle Event
interface LifecycleEvent {
  id: string
  event: string
  status: "success" | "pending" | "failed" | "info"
  timestamp: string
  description: string
  metadata?: Record<string, string>
  impactOnSettlement?: string
  impactOnRefund?: string
}

// Split and Pay Mode Details
interface SplitPayModeDetail {
  mode: string
  amount: number
  status: "success" | "pending" | "failed"
  transactionId?: string
  cardNetwork?: string
  upiPsp?: string
  bankName?: string
  settlementStatus?: "settled" | "pending" | "processing"
  settlementId?: string
  settlementUtr?: string
  settlementDate?: string
  refundStatus?: "none" | "partial" | "full"
  refundAmount?: number
  chargebackStatus?: "none" | "raised" | "won" | "lost"
}

export function TransactionDetailModal({ transaction, onClose }: TransactionDetailModalProps) {
  if (!transaction) return null

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const enhancedSplitDetails: SplitWithSettlement[] =
    transaction.splitDetails?.splits?.map((split, idx) => ({
      ...split,
      settlementId: split.status === "settled" ? `SPLIT-SETTLE-${transaction.id}-${idx + 1}` : undefined,
      settlementDate: split.status === "settled" ? "2025-01-10" : undefined,
      settlementUtr: split.status === "settled" ? `UTR${Date.now()}${idx}` : undefined,
      expectedSettlementDate: split.status === "pending" ? "2025-01-11" : undefined,
      gateway: ["Razorpay", "Cashfree", "Paytm"][idx % 3],
      netAmount: split.amount * 0.98,
      fees: split.amount * 0.02,
      feeBearer: idx % 2 === 0 ? "platform" : ("beneficiary" as "platform" | "beneficiary"),
    })) || []

  const splitSettlementSummary = {
    totalSplits: enhancedSplitDetails.length,
    totalAmount: enhancedSplitDetails.reduce((sum, s) => sum + s.amount, 0),
    settledCount: enhancedSplitDetails.filter((s) => s.status === "settled").length,
    settledAmount: enhancedSplitDetails.filter((s) => s.status === "settled").reduce((sum, s) => sum + s.amount, 0),
    pendingCount: enhancedSplitDetails.filter((s) => s.status === "pending").length,
    pendingAmount: enhancedSplitDetails.filter((s) => s.status === "pending").reduce((sum, s) => sum + s.amount, 0),
    totalFees: enhancedSplitDetails.reduce((sum, s) => sum + (s.fees || 0), 0),
    totalNetAmount: enhancedSplitDetails.reduce((sum, s) => sum + (s.netAmount || 0), 0),
  }

  // Enhanced Split and Pay Mode Details (for multi-mode payments)
  const splitPayModeDetails: SplitPayModeDetail[] = transaction.splitPayModes?.map((mode, idx) => ({
    ...mode,
    settlementStatus: mode.status === "success" ? (idx === 0 ? "settled" : "pending") : "pending",
    settlementId: mode.status === "success" && idx === 0 ? `SPLIT-PAY-${transaction.id}-${idx + 1}` : undefined,
    settlementUtr: mode.status === "success" && idx === 0 ? `UTR${Date.now()}${idx}` : undefined,
    settlementDate: mode.status === "success" && idx === 0 ? "2025-01-16" : undefined,
    refundStatus: idx === 1 ? "partial" : "none",
    refundAmount: idx === 1 ? Math.floor(mode.amount * 0.2) : undefined,
    chargebackStatus: "none",
  })) || []

  // Transaction Lifecycle Events
  const lifecycleEvents: LifecycleEvent[] = [
    {
      id: "evt1",
      event: "Payment Initiated",
      status: "success",
      timestamp: `${transaction.date} ${transaction.time}`,
      description: `Payment request created for ₹${transaction.orderAmount.toLocaleString()}`,
      metadata: { orderId: transaction.orderId, channel: transaction.channel },
    },
    {
      id: "evt2",
      event: "Gateway Selected",
      status: "success",
      timestamp: `${transaction.date} ${transaction.time}`,
      description: `${transaction.gateway} selected as payment gateway`,
      metadata: { gateway: transaction.gateway, mode: transaction.paymentMode },
    },
    {
      id: "evt3",
      event: transaction.captureApiUsed ? "Authorization" : "Payment Processing",
      status: transaction.status === "failed" ? "failed" : "success",
      timestamp: transaction.authorizedAt || `${transaction.date} ${transaction.time}`,
      description: transaction.captureApiUsed 
        ? `Card authorized for ₹${transaction.transactionAmount.toLocaleString()}`
        : `${transaction.paymentMode} payment processing started`,
      metadata: transaction.captureApiUsed ? { captureStatus: transaction.captureStatus } : undefined,
      impactOnSettlement: transaction.captureApiUsed ? "Authorization hold placed, awaiting capture" : undefined,
    },
    ...(transaction.captureApiUsed && transaction.captureStatus === "captured" ? [{
      id: "evt4",
      event: "Payment Captured",
      status: "success" as const,
      timestamp: transaction.capturedAt || `${transaction.date} ${transaction.time}`,
      description: `Payment captured after ${transaction.captureDelay}`,
      metadata: { captureDelay: transaction.captureDelay || "immediate" },
      impactOnSettlement: "Settlement process initiated",
    }] : []),
    ...(transaction.status === "success" ? [{
      id: "evt5",
      event: "Payment Successful",
      status: "success" as const,
      timestamp: `${transaction.date} ${transaction.time}`,
      description: transaction.statusReason,
      metadata: { bankRef: transaction.bankReferenceNumber },
      impactOnSettlement: "Eligible for T+1 settlement",
    }] : []),
    ...(transaction.status === "failed" ? [{
      id: "evt5",
      event: "Payment Failed",
      status: "failed" as const,
      timestamp: `${transaction.date} ${transaction.time}`,
      description: transaction.statusReason,
      impactOnSettlement: "No settlement - payment failed",
      impactOnRefund: "Auto-refund initiated if debited",
    }] : []),
    ...(transaction.isSplitPayment ? [{
      id: "evt6",
      event: "Split Applied",
      status: "info" as const,
      timestamp: `${transaction.date} ${transaction.time}`,
      description: `Payment split into ${transaction.splitDetails?.totalSplits} beneficiaries`,
      impactOnSettlement: "Individual settlements for each beneficiary",
    }] : []),
    ...(transaction.isSettled ? [{
      id: "evt7",
      event: "Settlement Complete",
      status: "success" as const,
      timestamp: transaction.settlementDate || "",
      description: `Funds settled via UTR: ${transaction.settlementUtr}`,
      metadata: { settlementId: transaction.settlementId, utr: transaction.settlementUtr },
    }] : [{
      id: "evt7",
      event: "Settlement Pending",
      status: "pending" as const,
      timestamp: "Expected T+1",
      description: "Awaiting settlement cycle",
      impactOnSettlement: "Will be settled in next business day cycle",
    }]),
    ...(transaction.status === "refunded" ? [{
      id: "evt8",
      event: "Refund Processed",
      status: "success" as const,
      timestamp: transaction.date,
      description: transaction.statusReason,
      impactOnSettlement: "Settlement reversed",
      impactOnRefund: "Full refund credited to payer",
    }] : []),
  ]

  // Summary stats for Split and Pay
  const splitPaySummary = {
    totalModes: splitPayModeDetails.length,
    totalAmount: splitPayModeDetails.reduce((sum, m) => sum + m.amount, 0),
    successCount: splitPayModeDetails.filter(m => m.status === "success").length,
    settledAmount: splitPayModeDetails.filter(m => m.settlementStatus === "settled").reduce((sum, m) => sum + m.amount, 0),
    pendingSettlement: splitPayModeDetails.filter(m => m.settlementStatus === "pending").reduce((sum, m) => sum + m.amount, 0),
    refundedAmount: splitPayModeDetails.reduce((sum, m) => sum + (m.refundAmount || 0), 0),
  }

  return (
    <Dialog open={!!transaction} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-card max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-3">
              <span className="font-mono">{transaction.id}</span>
              <Badge variant="outline" className={statusColors[transaction.status]}>
                {transaction.status}
              </Badge>
            </DialogTitle>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Amount Header with Order vs Transaction Amount */}
          <div className="rounded-lg bg-secondary/50 p-4">
            <div className="grid grid-cols-2 gap-4 text-center">
              <div>
                <p className="text-sm text-muted-foreground">Order Amount</p>
                <p className="text-2xl font-bold text-muted-foreground">₹{transaction.orderAmount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Transaction Amount</p>
                <p className="text-2xl font-bold text-foreground">₹{transaction.transactionAmount.toLocaleString()}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mt-2 text-center">{transaction.feeType}</p>
          </div>

          <div className={`rounded-lg p-4 border ${statusColors[transaction.status]}`}>
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-semibold">
                  Status: {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                </p>
                <p className="text-sm mt-1">{transaction.statusReason}</p>
              </div>
            </div>
          </div>

          <Tabs defaultValue="payer" className="w-full">
            <TabsList className="grid w-full grid-cols-7 bg-secondary/50">
              <TabsTrigger value="payer">Payer</TabsTrigger>
              <TabsTrigger value="payment">Payment</TabsTrigger>
              <TabsTrigger value="splitpay" className="flex items-center gap-1">
                Split Pay
                {transaction.splitPayModes && transaction.splitPayModes.length > 0 && (
                  <Badge variant="secondary" className="h-4 w-4 p-0 text-[10px] flex items-center justify-center">
                    {transaction.splitPayModes.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="split">Split</TabsTrigger>
              <TabsTrigger value="lifecycle" className="flex items-center gap-1">
                <History className="h-3 w-3" />
                Lifecycle
              </TabsTrigger>
              <TabsTrigger value="bank">Bank</TabsTrigger>
              <TabsTrigger value="settlement">Settlement</TabsTrigger>
            </TabsList>

            <TabsContent value="payer" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                {/* Student Information */}
                <div className="rounded-lg bg-secondary/30 p-4 space-y-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <GraduationCap className="h-4 w-4" />
                    Student Information
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Name</span>
                      <span className="font-medium">{transaction.studentName}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Class / Division</span>
                      <span className="font-medium">
                        {transaction.studentClass} - {transaction.studentDivision}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Enrollment No.</span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm">{transaction.enrollmentNumber}</span>
                        <button onClick={() => copyToClipboard(transaction.enrollmentNumber)}>
                          <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Roll Number</span>
                      <span className="font-medium">{transaction.rollNumber}</span>
                    </div>
                  </div>
                </div>

                {/* Contact Information */}
                <div className="rounded-lg bg-secondary/30 p-4 space-y-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Contact Information
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm flex items-center gap-2">
                        <Mail className="h-3.5 w-3.5" />
                        Email
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{transaction.payerEmail}</span>
                        <button onClick={() => copyToClipboard(transaction.payerEmail)}>
                          <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm flex items-center gap-2">
                        <Phone className="h-3.5 w-3.5" />
                        Mobile
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{transaction.payerMobile}</span>
                        <button onClick={() => copyToClipboard(transaction.payerMobile)}>
                          <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                        </button>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm flex items-center gap-2">
                        <Building2 className="h-3.5 w-3.5" />
                        Institute
                      </span>
                      <span className="font-medium">{transaction.institute}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Transaction Reference */}
              <div className="rounded-lg bg-secondary/30 p-4">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2 mb-3">
                  <Hash className="h-4 w-4" />
                  Transaction Reference
                </h3>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Transaction ID</p>
                    <p className="font-mono text-sm">{transaction.id}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Order ID</p>
                    <p className="font-mono text-sm">{transaction.orderId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Date & Time</p>
                    <p className="text-sm">
                      {transaction.date} {transaction.time}
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="payment" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                {/* Payment Gateway */}
                <div className="rounded-lg bg-secondary/30 p-4 space-y-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <Wallet className="h-4 w-4" />
                    Payment Gateway
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Gateway</span>
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        {transaction.gateway}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Payment Mode</span>
                      <span className="font-medium">{transaction.paymentMode}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Channel</span>
                      <span className="font-medium">{transaction.channel}</span>
                    </div>
                  </div>
                </div>

                {/* Payment Instrument Details */}
                <div className="rounded-lg bg-secondary/30 p-4 space-y-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    {transaction.paymentMode === "UPI" ? (
                      <Smartphone className="h-4 w-4" />
                    ) : transaction.paymentMode === "Net Banking" ? (
                      <Landmark className="h-4 w-4" />
                    ) : (
                      <CreditCard className="h-4 w-4" />
                    )}
                    Instrument Details
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">Type</span>
                      <span className="font-medium">{transaction.instrumentType}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground text-sm">
                        {transaction.paymentMode === "UPI"
                          ? "VPA"
                          : transaction.paymentMode === "Net Banking"
                            ? "Bank"
                            : "Card Number"}
                      </span>
                      <span className="font-mono text-sm">{transaction.instrumentDetails}</span>
                    </div>

                    {/* UPI PSP Details */}
                    {transaction.psp && (
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground text-sm">PSP App</span>
                        <Badge variant="outline" className={pspColors[transaction.psp] || "bg-secondary"}>
                          {transaction.psp}
                        </Badge>
                      </div>
                    )}

                    {/* Card Details */}
                    {transaction.cardBrand && (
                      <>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground text-sm">Card Network</span>
                          <Badge variant="outline" className={cardBrandColors[transaction.cardBrand] || "bg-secondary"}>
                            {transaction.cardBrand}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground text-sm">Card Type</span>
                          <span className="font-medium">{transaction.cardType}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground text-sm">Issuing Bank</span>
                          <span className="font-medium">{transaction.cardIssuer}</span>
                        </div>
                      </>
                    )}

                    {/* Net Banking Details */}
                    {transaction.bankName && !transaction.bankTransferDetails && (
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground text-sm">Bank Name</span>
                        <span className="font-medium">{transaction.bankName}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Transaction Receipt / Fee Breakdown */}
              <div className="rounded-lg bg-secondary/30 p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <Receipt className="h-4 w-4" />
                    Transaction Receipt
                  </h3>
                  <Badge variant="outline" className="text-xs">
                    {transaction.id}
                  </Badge>
                </div>

                {/* Order IDs */}
                <div className="grid grid-cols-3 gap-3 p-3 rounded-lg bg-background/50">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">School Order ID</p>
                    <p className="font-mono text-xs">{transaction.orderId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Edviron Order ID</p>
                    <p className="font-mono text-xs">{transaction.edvironOrderId}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Gateway Txn ID</p>
                    <p className="font-mono text-xs">{transaction.gatewayTransactionId || transaction.bankReferenceNumber}</p>
                  </div>
                </div>

                {/* Amount Breakdown */}
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase">Amount Breakdown</p>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Order Amount</span>
                    <span className="font-medium">₹{transaction.orderAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Transaction Amount</span>
                    <span className="font-medium">₹{transaction.transactionAmount.toLocaleString()}</span>
                  </div>
                </div>

                <Separator />

                {/* MDR Details */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-muted-foreground uppercase">MDR / PG Charges</p>
                    <Badge 
                      variant="outline" 
                      className={`text-[10px] ${
                        transaction.mdrBearing === "surcharge" 
                          ? "bg-red-500/10 text-red-400 border-red-500/20" 
                          : "bg-green-500/10 text-green-400 border-green-500/20"
                      }`}
                    >
                      {transaction.mdrBearing === "surcharge" ? "Surcharge (Payer)" : "Merchant Bearing"}
                    </Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">MDR Amount ({transaction.mdrPercentage || 2}%)</span>
                    <span className="text-destructive">-₹{(transaction.mdrAmount || transaction.transactionAmount * 0.02).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Platform Fee (0.5%)</span>
                    <span className="text-destructive">-₹{(transaction.transactionAmount * 0.005).toLocaleString()}</span>
                  </div>
                </div>

                <Separator />

                {/* ERP Commission */}
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase">ERP Commission</p>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">
                      ERP Commission ({transaction.erpCommissionPercentage || 1}%)
                    </span>
                    <span className="text-emerald-500 font-medium">
                      ₹{(transaction.erpCommission || Math.floor(transaction.transactionAmount * 0.01)).toLocaleString()}
                    </span>
                  </div>
                </div>

                <Separator />

                {/* Net Settlement */}
                <div className="rounded-lg bg-primary/5 p-3">
                  <div className="flex justify-between font-semibold">
                    <span>Net Settlement to Institute</span>
                    <span className="text-primary text-lg">
                      ₹{(transaction.vendorAmount || transaction.transactionAmount * 0.975).toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Payment Mode Details */}
                <div className="space-y-2 pt-2">
                  <p className="text-xs font-semibold text-muted-foreground uppercase">Payment Mode Details</p>
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Mode</span>
                      <span>{transaction.paymentMode}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Channel</span>
                      <span>{transaction.channel}</span>
                    </div>
                    {transaction.cardNetwork && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Card Network</span>
                        <Badge variant="outline" className="text-xs">{transaction.cardNetwork}</Badge>
                      </div>
                    )}
                    {transaction.cardIssuer && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Issuing Bank</span>
                        <span className="text-xs">{transaction.cardIssuer}</span>
                      </div>
                    )}
                    {transaction.psp && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">UPI PSP</span>
                        <Badge variant="outline" className="text-xs">{transaction.psp}</Badge>
                      </div>
                    )}
                    {transaction.upiId && (
                      <div className="flex justify-between text-sm col-span-2">
                        <span className="text-muted-foreground">UPI ID</span>
                        <span className="font-mono text-xs">{transaction.upiId}</span>
                      </div>
                    )}
                    {transaction.walletProvider && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Wallet</span>
                        <Badge variant="outline" className="text-xs">{transaction.walletProvider}</Badge>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Transaction Fee Bearing */}
              {transaction.transactionFeeBearing && (
                <div className="rounded-lg bg-secondary/30 p-4 space-y-3">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase">Transaction Fee Bearing</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Fee Bearer</span>
                      <Badge variant="outline" className={`${
                        transaction.transactionFeeBearing === "payer" 
                          ? "bg-red-500/10 text-red-400 border-red-500/20"
                          : transaction.transactionFeeBearing === "merchant"
                            ? "bg-green-500/10 text-green-400 border-green-500/20"
                            : "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                      }`}>
                        {transaction.transactionFeeBearing === "payer" ? "Payer (Parent)" : 
                         transaction.transactionFeeBearing === "merchant" ? "Merchant (Institute)" : "Partial (Shared)"}
                      </Badge>
                    </div>
                    {transaction.transactionFee && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Total Transaction Fee</span>
                        <span>₹{transaction.transactionFee.toLocaleString()}</span>
                      </div>
                    )}
                    {transaction.transactionFeeBearing === "partial" && (
                      <>
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Sharing Type</span>
                          <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                            {transaction.partialFeeSharing === "fixed_payer" ? "Fixed by Payer" :
                             transaction.partialFeeSharing === "fixed_merchant" ? "Fixed by Merchant" :
                             transaction.partialFeeSharing === "percentage_split" ? "Percentage Split" : "Mode-based Split"}
                          </Badge>
                        </div>
                        {transaction.payerFeeAmount !== undefined && (
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Payer Pays</span>
                            <span className="text-red-400">₹{transaction.payerFeeAmount.toLocaleString()}</span>
                          </div>
                        )}
                        {transaction.merchantFeeAmount !== undefined && (
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Merchant Pays</span>
                            <span className="text-green-400">₹{transaction.merchantFeeAmount.toLocaleString()}</span>
                          </div>
                        )}
                      </>
                    )}
                    {transaction.feePercentage && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fee Percentage</span>
                        <span>{transaction.feePercentage}%</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Financing Charges Breakdown - for EMI transactions */}
              {transaction.financingCharges && (
                <div className="rounded-lg bg-gradient-to-br from-indigo-500/5 to-purple-500/5 border border-indigo-500/20 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Percent className="h-4 w-4 text-indigo-400" />
                      Financing Charges Breakdown
                    </h3>
                    <Badge className="bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
                      Total: ₹{transaction.financingCharges.totalCharges.toLocaleString()}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    {/* Parent Charge */}
                    <div className="flex justify-between text-sm items-center">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-red-500" />
                        <span className="text-muted-foreground">
                          Parent Bears ({transaction.financingCharges.parentChargePercentage}%)
                        </span>
                      </div>
                      <span className="text-red-400 font-medium">
                        ₹{transaction.financingCharges.parentCharge.toLocaleString()}
                      </span>
                    </div>
                    {/* Institute Charge */}
                    <div className="flex justify-between text-sm items-center">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-green-500" />
                        <span className="text-muted-foreground">
                          Institute Bears ({transaction.financingCharges.instituteChargePercentage}%)
                        </span>
                      </div>
                      <span className="text-green-400 font-medium">
                        ₹{transaction.financingCharges.instituteCharge.toLocaleString()}
                      </span>
                    </div>
                    {/* Bank Charge */}
                    <div className="flex justify-between text-sm items-center">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-blue-500" />
                        <span className="text-muted-foreground">
                          Bank Bears ({transaction.financingCharges.bankChargePercentage}%)
                        </span>
                      </div>
                      <span className="text-blue-400 font-medium">
                        ₹{transaction.financingCharges.bankCharge.toLocaleString()}
                      </span>
                    </div>
                    {transaction.financingCharges.subventionAmount && (
                      <>
                        <Separator className="my-2" />
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Subvention Amount (Bank Subsidy)</span>
                          <span className="text-primary font-medium">
                            ₹{transaction.financingCharges.subventionAmount.toLocaleString()}
                          </span>
                        </div>
                      </>
                    )}
                  </div>
                  {/* Visual Breakdown */}
                  <div className="mt-3">
                    <div className="flex h-3 rounded-full overflow-hidden">
                      <div 
                        className="bg-red-500" 
                        style={{ width: `${(transaction.financingCharges.parentCharge / transaction.financingCharges.totalCharges) * 100}%` }}
                      />
                      <div 
                        className="bg-green-500" 
                        style={{ width: `${(transaction.financingCharges.instituteCharge / transaction.financingCharges.totalCharges) * 100}%` }}
                      />
                      <div 
                        className="bg-blue-500" 
                        style={{ width: `${(transaction.financingCharges.bankCharge / transaction.financingCharges.totalCharges) * 100}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                      <span>Parent: {transaction.financingCharges.parentChargePercentage}%</span>
                      <span>Institute: {transaction.financingCharges.instituteChargePercentage}%</span>
                      <span>Bank: {transaction.financingCharges.bankChargePercentage}%</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Refund Breakdown - shows why we don't refund full transaction amount */}
              {(transaction.status === "refunded" || transaction.refundDetails) && (
                <div className="rounded-lg bg-orange-500/5 border border-orange-500/20 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <RefreshCw className="h-4 w-4 text-orange-400" />
                      Refund Breakdown
                    </h3>
                    <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20">
                      {transaction.refundDetails?.refundStatus || "Completed"}
                    </Badge>
                  </div>
                  
                  <div className="p-3 rounded-lg bg-orange-500/5 border border-orange-500/10">
                    <p className="text-xs text-orange-400 mb-2 font-medium">
                      Note: Refund amount differs from transaction amount due to non-refundable charges
                    </p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Original Order Amount</span>
                      <span>₹{(transaction.refundDetails?.originalOrderAmount || transaction.orderAmount).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Transaction Amount</span>
                      <span>₹{transaction.transactionAmount.toLocaleString()}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">PG Charges (Non-refundable)</span>
                      <span className="text-destructive">
                        -₹{(transaction.refundDetails?.pgChargesDeducted || transaction.mdrAmount || Math.floor(transaction.transactionAmount * 0.02)).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">ERP Commission (Non-refundable)</span>
                      <span className="text-destructive">
                        -₹{(transaction.refundDetails?.erpCommissionDeducted || transaction.erpCommission || Math.floor(transaction.transactionAmount * 0.01)).toLocaleString()}
                      </span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between font-semibold">
                      <span>Net Refund to Parent</span>
                      <span className="text-orange-500">
                        ₹{(transaction.refundDetails?.netRefundToParent || 
                           (transaction.transactionAmount - (transaction.mdrAmount || Math.floor(transaction.transactionAmount * 0.02)) - 
                            (transaction.erpCommission || Math.floor(transaction.transactionAmount * 0.01)))).toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {transaction.refundDetails?.refundArn && (
                    <div className="pt-2 border-t border-border space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Refund ID</span>
                        <span className="font-mono">{transaction.refundDetails.refundId}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">ARN</span>
                        <span className="font-mono">{transaction.refundDetails.refundArn}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-muted-foreground">Refund Date</span>
                        <span>{transaction.refundDetails.refundDate}</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Autopay Details */}
              {transaction.autopayDetails && (
                <div className="rounded-lg bg-cyan-500/5 border border-cyan-500/20 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <CalendarClock className="h-4 w-4 text-cyan-400" />
                      Autopay / Mandate Details
                    </h3>
                    <Badge className={`${
                      transaction.autopayDetails.mandateStatus === "active" 
                        ? "bg-green-500/10 text-green-400 border-green-500/20"
                        : transaction.autopayDetails.mandateStatus === "paused"
                          ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                          : "bg-red-500/10 text-red-400 border-red-500/20"
                    }`}>
                      {transaction.autopayDetails.mandateStatus}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Mandate ID</span>
                      <span className="font-mono text-xs">{transaction.autopayDetails.mandateId}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Type</span>
                      <Badge variant="outline" className="text-xs">{transaction.autopayDetails.mandateType}</Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Max Amount</span>
                      <span>₹{transaction.autopayDetails.maxAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Frequency</span>
                      <span className="capitalize">{transaction.autopayDetails.frequency.replace("_", " ")}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Valid Until</span>
                      <span>{transaction.autopayDetails.validUntil}</span>
                    </div>
                    {transaction.autopayDetails.upiVpa && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">UPI VPA</span>
                        <span className="font-mono text-xs">{transaction.autopayDetails.upiVpa}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* School Counter Details */}
              {transaction.schoolCounterDetails && (
                <div className="rounded-lg bg-amber-500/5 border border-amber-500/20 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-amber-400" />
                      School Counter Collection
                    </h3>
                    <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/20 uppercase">
                      {transaction.schoolCounterDetails.mode.replace("_", " ")}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {transaction.schoolCounterDetails.ddNumber && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">DD Number</span>
                        <span className="font-mono text-xs">{transaction.schoolCounterDetails.ddNumber}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.chequeNumber && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Cheque Number</span>
                        <span className="font-mono text-xs">{transaction.schoolCounterDetails.chequeNumber}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.issuingBank && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Issuing Bank</span>
                        <span>{transaction.schoolCounterDetails.issuingBank}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.receiptNumber && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Receipt No.</span>
                        <span className="font-mono text-xs">{transaction.schoolCounterDetails.receiptNumber}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.collectedBy && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Collected By</span>
                        <span>{transaction.schoolCounterDetails.collectedBy}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.collectionDate && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Collection Date</span>
                        <span>{transaction.schoolCounterDetails.collectionDate}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Pay Later / Split and Pay Details */}
              {(transaction.paymentMode === "Pay Later" || transaction.paymentMode === "Split and Pay") && (
                <div className="rounded-lg bg-gradient-to-br from-indigo-500/10 to-purple-500/10 p-4 space-y-4 border border-indigo-500/20">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      {transaction.paymentMode === "Pay Later" ? (
                        <CalendarClock className="h-4 w-4 text-indigo-400" />
                      ) : (
                        <SplitSquareVertical className="h-4 w-4 text-teal-400" />
                      )}
                      {transaction.paymentMode === "Pay Later" ? "EMI Payment Plan" : "Split Payment Plan"}
                    </h3>
                    <Badge className="bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
                      {transaction.instrumentType}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-3">
                    <div className="rounded-lg bg-background/50 p-3 text-center">
                      <p className="text-xs text-muted-foreground">Total Order</p>
                      <p className="text-lg font-bold">₹{transaction.orderAmount.toLocaleString()}</p>
                    </div>
                    <div className="rounded-lg bg-background/50 p-3 text-center">
                      <p className="text-xs text-muted-foreground">This Payment</p>
                      <p className="text-lg font-bold text-success">₹{transaction.transactionAmount.toLocaleString()}</p>
                    </div>
                    <div className="rounded-lg bg-background/50 p-3 text-center">
                      <p className="text-xs text-muted-foreground">Remaining</p>
                      <p className="text-lg font-bold text-warning">₹{(transaction.orderAmount - transaction.transactionAmount).toLocaleString()}</p>
                    </div>
                  </div>

                  {/* Payment Schedule */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Payment Schedule</p>
                    <div className="space-y-2">
                      {transaction.paymentMode === "Pay Later" ? (
                        <>
                          <div className="flex items-center justify-between p-2 rounded bg-success/10 border border-success/20">
                            <div className="flex items-center gap-2">
                              <CheckCircle2 className="h-4 w-4 text-success" />
                              <span className="text-sm">EMI 1</span>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-medium">₹{transaction.transactionAmount.toLocaleString()}</span>
                              <p className="text-xs text-muted-foreground">{transaction.date}</p>
                            </div>
                          </div>
                          <div className="flex items-center justify-between p-2 rounded bg-secondary/30 border border-border">
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">EMI 2</span>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-medium">₹{transaction.transactionAmount.toLocaleString()}</span>
                              <p className="text-xs text-muted-foreground">Due: Feb 15, 2024</p>
                            </div>
                          </div>
                          <div className="flex items-center justify-between p-2 rounded bg-secondary/30 border border-border">
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">EMI 3</span>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-medium">₹{(transaction.orderAmount - transaction.transactionAmount * 2).toLocaleString()}</span>
                              <p className="text-xs text-muted-foreground">Due: Mar 15, 2024</p>
                            </div>
                          </div>
                        </>
                      ) : transaction.splitPayTimeline && transaction.splitPayTimeline.length > 0 ? (
                        /* Use actual split pay timeline data */
                        <>
                          {transaction.splitPayTimeline.map((split, index) => (
                            <div 
                              key={index}
                              className={`flex items-center justify-between p-3 rounded ${
                                split.status === "completed" 
                                  ? "bg-success/10 border border-success/20"
                                  : split.status === "failed"
                                    ? "bg-destructive/10 border border-destructive/20"
                                    : "bg-secondary/30 border border-border"
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                {split.status === "completed" ? (
                                  <CheckCircle2 className="h-4 w-4 text-success" />
                                ) : split.status === "failed" ? (
                                  <XCircle className="h-4 w-4 text-destructive" />
                                ) : (
                                  <Clock className="h-4 w-4 text-muted-foreground" />
                                )}
                                <div>
                                  <span className="text-sm font-medium">Payment {split.splitNumber}</span>
                                  {split.paymentMode && (
                                    <Badge variant="outline" className="ml-2 text-[10px] py-0">
                                      {split.paymentMode}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <div className="text-right">
                                <span className="text-sm font-medium">₹{split.amount.toLocaleString()}</span>
                                <p className="text-xs text-muted-foreground">
                                  {split.status === "completed" && split.paidDate 
                                    ? `Paid: ${split.paidDate}`
                                    : split.dueDate 
                                      ? `Due: ${split.dueDate}`
                                      : "Scheduled"}
                                </p>
                                {split.transactionId && (
                                  <p className="text-[10px] font-mono text-muted-foreground">{split.transactionId}</p>
                                )}
                              </div>
                            </div>
                          ))}
                        </>
                      ) : (
                        /* Fallback to default display */
                        <>
                          <div className="flex items-center justify-between p-2 rounded bg-success/10 border border-success/20">
                            <div className="flex items-center gap-2">
                              <CheckCircle2 className="h-4 w-4 text-success" />
                              <span className="text-sm">Payment 1</span>
                            </div>
                            <div className="text-right">
                              <span className="text-sm font-medium">₹{transaction.transactionAmount.toLocaleString()}</span>
                              <p className="text-xs text-muted-foreground">{transaction.date}</p>
                            </div>
                          </div>
                          {transaction.orderAmount > transaction.transactionAmount && (
                            <>
                              <div className="flex items-center justify-between p-2 rounded bg-secondary/30 border border-border">
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-sm">Payment 2</span>
                                </div>
                                <div className="text-right">
                                  <span className="text-sm font-medium">₹{transaction.transactionAmount.toLocaleString()}</span>
                                  <p className="text-xs text-muted-foreground">Scheduled</p>
                                </div>
                              </div>
                              <div className="flex items-center justify-between p-2 rounded bg-secondary/30 border border-border">
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-sm">Payment 3</span>
                                </div>
                                <div className="text-right">
                                  <span className="text-sm font-medium">₹{(transaction.orderAmount - transaction.transactionAmount * 2).toLocaleString()}</span>
                                  <p className="text-xs text-muted-foreground">Scheduled</p>
                                </div>
                              </div>
                            </>
                          )}
                        </>
                      )}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Payment Progress</span>
                      <span>{Math.round((transaction.transactionAmount / transaction.orderAmount) * 100)}% Complete</span>
                    </div>
                    <Progress value={(transaction.transactionAmount / transaction.orderAmount) * 100} className="h-2" />
                  </div>
                </div>
              )}

              {/* Multi-Mode Payment Details (Split and Pay with different payment modes) */}
              {transaction.splitPayModes && transaction.splitPayModes.length > 0 && (
                <div className="rounded-lg bg-gradient-to-br from-teal-500/10 to-cyan-500/10 p-4 space-y-4 border border-teal-500/20">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Layers className="h-4 w-4 text-teal-400" />
                      Multi-Mode Payment Breakdown
                    </h3>
                    <Badge className="bg-teal-500/10 text-teal-400 border-teal-500/20">
                      {transaction.splitPayModes.length} Payment Modes
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    {transaction.splitPayModes.map((mode, idx) => (
                      <div 
                        key={idx} 
                        className={`rounded-lg border p-3 ${
                          mode.status === "success" 
                            ? "bg-success/5 border-success/20" 
                            : mode.status === "pending" 
                              ? "bg-warning/5 border-warning/20" 
                              : "bg-destructive/5 border-destructive/20"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`flex h-8 w-8 items-center justify-center rounded-full ${
                              mode.status === "success" ? "bg-success/10" : mode.status === "pending" ? "bg-warning/10" : "bg-destructive/10"
                            }`}>
                              {mode.status === "success" ? (
                                <CheckCircle2 className="h-4 w-4 text-success" />
                              ) : mode.status === "pending" ? (
                                <Clock className="h-4 w-4 text-warning" />
                              ) : (
                                <AlertCircle className="h-4 w-4 text-destructive" />
                              )}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{mode.mode}</span>
                                {mode.cardNetwork && (
                                  <Badge variant="secondary" className="text-xs">{mode.cardNetwork}</Badge>
                                )}
                                {mode.upiPsp && (
                                  <Badge variant="secondary" className="text-xs">{mode.upiPsp}</Badge>
                                )}
                                {mode.bankName && (
                                  <Badge variant="secondary" className="text-xs">{mode.bankName}</Badge>
                                )}
                              </div>
                              {mode.transactionId && (
                                <p className="text-xs text-muted-foreground font-mono">{mode.transactionId}</p>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`text-lg font-bold ${
                              mode.status === "success" ? "text-success" : mode.status === "pending" ? "text-warning" : "text-destructive"
                            }`}>
                              ₹{mode.amount.toLocaleString()}
                            </p>
                            <Badge 
                              variant="outline" 
                              className={`text-[10px] ${
                                mode.status === "success" 
                                  ? "bg-success/10 text-success border-success/20" 
                                  : mode.status === "pending" 
                                    ? "bg-warning/10 text-warning border-warning/20" 
                                    : "bg-destructive/10 text-destructive border-destructive/20"
                              }`}
                            >
                              {mode.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Total Summary */}
                  <div className="rounded-lg bg-background/50 p-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Total Collected</span>
                      <span className="text-lg font-bold text-foreground">
                        ₹{transaction.splitPayModes.filter(m => m.status === "success").reduce((sum, m) => sum + m.amount, 0).toLocaleString()}
                      </span>
                    </div>
                    {transaction.splitPayModes.some(m => m.status === "pending") && (
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-xs text-muted-foreground">Pending</span>
                        <span className="text-sm text-warning">
                          ₹{transaction.splitPayModes.filter(m => m.status === "pending").reduce((sum, m) => sum + m.amount, 0).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Financing Details */}
              {transaction.financingCategory && transaction.financingCategory !== "none" && (
                <div className="rounded-lg bg-gradient-to-br from-emerald-500/10 to-green-500/10 p-4 space-y-4 border border-emerald-500/20">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Banknote className="h-4 w-4 text-emerald-400" />
                      {transaction.financingCategory === "card_emi" ? "Card EMI Details" : "NBFC Financing Details"}
                    </h3>
                    <Badge className={`${
                      transaction.financingType === "no_cost_emi" 
                        ? "bg-green-500/10 text-green-400 border-green-500/20"
                        : transaction.financingType === "partial_cost_emi"
                          ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                          : "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                    }`}>
                      {transaction.financingType === "no_cost_emi" ? "No Cost EMI" : transaction.financingType === "partial_cost_emi" ? "Partial Cost EMI" : "EMI"}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-lg bg-background/50 p-3">
                      <p className="text-xs text-muted-foreground">EMI Tenure</p>
                      <p className="text-lg font-bold">{transaction.emiTenure} months</p>
                    </div>
                    <div className="rounded-lg bg-background/50 p-3">
                      <p className="text-xs text-muted-foreground">Monthly EMI</p>
                      <p className="text-lg font-bold">₹{transaction.emiAmount?.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="rounded-lg bg-background/50 p-3 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Cost Bearing</span>
                      <Badge variant="outline" className={`${
                        transaction.emiCostBearing === "institute" 
                          ? "bg-green-500/10 text-green-400 border-green-500/20"
                          : transaction.emiCostBearing === "bank"
                            ? "bg-blue-500/10 text-blue-400 border-blue-500/20"
                            : "bg-red-500/10 text-red-400 border-red-500/20"
                      }`}>
                        {transaction.emiCostBearing === "institute" ? "Institute Bears Cost" : transaction.emiCostBearing === "bank" ? "Bank Bears Cost" : "Parent Bears Cost"}
                      </Badge>
                    </div>
                    {transaction.financingType === "partial_cost_emi" && transaction.partialCostSharing && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Cost Sharing</span>
                        <Badge variant="outline" className={`${
                          transaction.partialCostSharing === "parent_institute" 
                            ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                            : transaction.partialCostSharing === "bank_institute"
                              ? "bg-purple-500/10 text-purple-400 border-purple-500/20"
                              : transaction.partialCostSharing === "parent_bank"
                                ? "bg-orange-500/10 text-orange-400 border-orange-500/20"
                                : "bg-teal-500/10 text-teal-400 border-teal-500/20"
                        }`}>
                          {
                            transaction.partialCostSharing === "parent_institute" ? "Parent + Institute" : 
                            transaction.partialCostSharing === "bank_institute" ? "Bank + Institute" : 
                            transaction.partialCostSharing === "parent_bank" ? "Parent + Bank" :
                            "Parent + Bank + Institute"
                          }
                        </Badge>
                      </div>
                    )}
                    {transaction.financingCategory === "card_emi" && (transaction.cardIssuingBank || transaction.cardIssuer) && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Issuing Bank</span>
                        <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                          {transaction.cardIssuingBank || transaction.cardIssuer}
                        </Badge>
                      </div>
                    )}
                    {transaction.nbfcPartner && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">NBFC Partner</span>
                        <span className="font-medium">{transaction.nbfcPartner}</span>
                      </div>
                    )}
                    {transaction.financingCollectionType && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Collection Type</span>
                        <span className="font-medium">{transaction.financingCollectionType === "edviron_collection" ? "Edviron Collection" : "NBFC Collection"}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* International Payment Details */}
              {transaction.isInternational && (
                <div className="rounded-lg bg-gradient-to-br from-purple-500/10 to-violet-500/10 p-4 space-y-4 border border-purple-500/20">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Globe className="h-4 w-4 text-purple-400" />
                      International Payment Details
                    </h3>
                    <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/20">
                      {transaction.internationalPricingType === "inr_converted" ? "INR Converted" : "Foreign Currency"}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-lg bg-background/50 p-3">
                      <p className="text-xs text-muted-foreground">Original Amount</p>
                      <p className="text-lg font-bold">{transaction.currency} {transaction.originalAmount?.toLocaleString()}</p>
                    </div>
                    <div className="rounded-lg bg-background/50 p-3">
                      <p className="text-xs text-muted-foreground">Exchange Rate</p>
                      <p className="text-lg font-bold">1 {transaction.currency} = ₹{transaction.exchangeRate}</p>
                    </div>
                  </div>

                  <div className="rounded-lg bg-background/50 p-3 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Payment Method</span>
                      <span className="font-medium capitalize">{transaction.internationalMethod}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">INR Equivalent</span>
                      <span className="font-bold text-success">₹{transaction.transactionAmount.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* School Counter Details */}
              {transaction.schoolCounterDetails && (
                <div className="rounded-lg bg-gradient-to-br from-amber-500/10 to-orange-500/10 p-4 space-y-4 border border-amber-500/20">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                      <Receipt className="h-4 w-4 text-amber-400" />
                      School Counter Collection
                    </h3>
                    <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/20 capitalize">
                      {transaction.schoolCounterDetails.mode}
                    </Badge>
                  </div>

                  <div className="rounded-lg bg-background/50 p-3 space-y-2">
                    {transaction.schoolCounterDetails.receiptNumber && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Receipt Number</span>
                        <span className="font-mono text-sm">{transaction.schoolCounterDetails.receiptNumber}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.chequeNumber && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Cheque Number</span>
                        <span className="font-mono text-sm">{transaction.schoolCounterDetails.chequeNumber}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.ddNumber && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">DD Number</span>
                        <span className="font-mono text-sm">{transaction.schoolCounterDetails.ddNumber}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.issuingBank && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Issuing Bank</span>
                        <span className="font-medium">{transaction.schoolCounterDetails.issuingBank}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.collectedBy && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Collected By</span>
                        <span className="font-medium">{transaction.schoolCounterDetails.collectedBy}</span>
                      </div>
                    )}
                    {transaction.schoolCounterDetails.collectionDate && (
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Collection Date</span>
                        <span className="font-medium">{transaction.schoolCounterDetails.collectionDate}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </TabsContent>

            {/* Split Pay Tab - Multi-mode payment breakup */}
            <TabsContent value="splitpay" className="space-y-4 mt-4">
              <div className="rounded-lg bg-secondary/30 p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <Layers className="h-4 w-4" />
                    Split & Pay Breakdown
                  </h3>
                  {splitPayModeDetails.length > 0 ? (
                    <Badge className="bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
                      {splitPayModeDetails.length} Payment Mode{splitPayModeDetails.length > 1 ? 's' : ''}
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-muted-foreground">
                      Single Mode Payment
                    </Badge>
                  )}
                </div>

                {splitPayModeDetails.length > 0 ? (
                  <div className="space-y-6">
                    {/* Summary Cards */}
                    <div className="grid grid-cols-4 gap-3">
                      <div className="rounded-lg bg-secondary/50 p-3 text-center">
                        <p className="text-xs text-muted-foreground mb-1">Total Modes</p>
                        <p className="text-xl font-bold">{splitPaySummary.totalModes}</p>
                      </div>
                      <div className="rounded-lg bg-secondary/50 p-3 text-center">
                        <p className="text-xs text-muted-foreground mb-1">Total Amount</p>
                        <p className="text-xl font-bold">₹{splitPaySummary.totalAmount.toLocaleString()}</p>
                      </div>
                      <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/20 p-3 text-center">
                        <p className="text-xs text-emerald-400 mb-1">Settled</p>
                        <p className="text-xl font-bold text-emerald-500">₹{splitPaySummary.settledAmount.toLocaleString()}</p>
                      </div>
                      <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3 text-center">
                        <p className="text-xs text-amber-400 mb-1">Pending</p>
                        <p className="text-xl font-bold text-amber-500">₹{splitPaySummary.pendingSettlement.toLocaleString()}</p>
                      </div>
                    </div>

                    {/* Individual Mode Cards */}
                    <div className="space-y-4">
                      <h4 className="text-sm font-semibold text-muted-foreground">Payment Mode Details</h4>
                      {splitPayModeDetails.map((mode, idx) => (
                        <div key={idx} className="rounded-lg border border-border overflow-hidden">
                          {/* Mode Header */}
                          <div className="p-4 bg-secondary/30">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                                  mode.mode === "Credit Card" || mode.mode === "Debit Card" 
                                    ? "bg-blue-500/10" 
                                    : mode.mode === "UPI" 
                                      ? "bg-purple-500/10" 
                                      : "bg-green-500/10"
                                }`}>
                                  {mode.mode === "Credit Card" || mode.mode === "Debit Card" ? (
                                    <CreditCard className="h-5 w-5 text-blue-500" />
                                  ) : mode.mode === "UPI" ? (
                                    <Smartphone className="h-5 w-5 text-purple-500" />
                                  ) : (
                                    <Landmark className="h-5 w-5 text-green-500" />
                                  )}
                                </div>
                                <div>
                                  <p className="font-semibold">{mode.mode}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {mode.cardNetwork && `${mode.cardNetwork} • `}
                                    {mode.upiPsp && `${mode.upiPsp} • `}
                                    {mode.bankName && `${mode.bankName} • `}
                                    {mode.transactionId && (
                                      <span className="font-mono">{mode.transactionId}</span>
                                    )}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <Badge
                                  variant="outline"
                                  className={
                                    mode.status === "success"
                                      ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                                      : mode.status === "pending"
                                        ? "bg-amber-500/10 text-amber-500 border-amber-500/20"
                                        : "bg-red-500/10 text-red-500 border-red-500/20"
                                  }
                                >
                                  {mode.status === "success" ? (
                                    <CheckCircle2 className="h-3 w-3 mr-1" />
                                  ) : mode.status === "pending" ? (
                                    <Clock className="h-3 w-3 mr-1" />
                                  ) : (
                                    <XCircle className="h-3 w-3 mr-1" />
                                  )}
                                  {mode.status}
                                </Badge>
                                <p className="text-lg font-bold mt-1">₹{mode.amount.toLocaleString()}</p>
                              </div>
                            </div>
                          </div>

                          {/* Mode Details */}
                          <div className="p-4 space-y-3">
                            {/* Settlement Status */}
                            <div className="grid grid-cols-3 gap-4">
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">Settlement Status</p>
                                <Badge variant="secondary" className={`text-xs ${
                                  mode.settlementStatus === "settled" 
                                    ? "bg-emerald-500/10 text-emerald-500" 
                                    : "bg-amber-500/10 text-amber-500"
                                }`}>
                                  {mode.settlementStatus === "settled" ? "Settled" : "Pending T+1"}
                                </Badge>
                              </div>
                              {mode.settlementId && (
                                <div>
                                  <p className="text-xs text-muted-foreground mb-1">Settlement ID</p>
                                  <p className="font-mono text-xs">{mode.settlementId}</p>
                                </div>
                              )}
                              {mode.settlementUtr && (
                                <div>
                                  <p className="text-xs text-muted-foreground mb-1">UTR</p>
                                  <p className="font-mono text-xs text-emerald-500">{mode.settlementUtr}</p>
                                </div>
                              )}
                            </div>

                            {/* Refund & Chargeback Status */}
                            <div className="flex gap-3 pt-2 border-t border-border">
                              <div className="flex-1 rounded-lg bg-secondary/50 p-2">
                                <div className="flex items-center gap-2">
                                  <RefreshCw className="h-3.5 w-3.5 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">Refund:</span>
                                  <Badge variant="outline" className={`text-[10px] ${
                                    mode.refundStatus === "none" 
                                      ? "" 
                                      : mode.refundStatus === "partial" 
                                        ? "bg-orange-500/10 text-orange-400" 
                                        : "bg-blue-500/10 text-blue-400"
                                  }`}>
                                    {mode.refundStatus === "none" ? "None" : mode.refundStatus === "partial" ? `Partial (₹${mode.refundAmount?.toLocaleString()})` : "Full"}
                                  </Badge>
                                </div>
                              </div>
                              <div className="flex-1 rounded-lg bg-secondary/50 p-2">
                                <div className="flex items-center gap-2">
                                  <ShieldAlert className="h-3.5 w-3.5 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">Chargeback:</span>
                                  <Badge variant="outline" className={`text-[10px] ${
                                    mode.chargebackStatus === "none" ? "" : 
                                    mode.chargebackStatus === "raised" ? "bg-red-500/10 text-red-400" :
                                    mode.chargebackStatus === "won" ? "bg-green-500/10 text-green-400" :
                                    "bg-red-500/10 text-red-400"
                                  }`}>
                                    {mode.chargebackStatus === "none" ? "None" : mode.chargebackStatus}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Impact Summary */}
                    {splitPaySummary.refundedAmount > 0 && (
                      <div className="rounded-lg bg-orange-500/5 border border-orange-500/20 p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertTriangle className="h-4 w-4 text-orange-500" />
                          <span className="font-semibold text-orange-500">Impact Summary</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground">Total Refunded:</span>
                            <span className="ml-2 font-medium text-orange-400">₹{splitPaySummary.refundedAmount.toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">Net Settlement:</span>
                            <span className="ml-2 font-medium">₹{(splitPaySummary.settledAmount - splitPaySummary.refundedAmount).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Layers className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                    <p className="text-muted-foreground">Single payment mode used</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Paid via {transaction.paymentMode} - ₹{transaction.transactionAmount.toLocaleString()}
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Lifecycle Tab - Complete transaction timeline */}
            <TabsContent value="lifecycle" className="space-y-4 mt-4">
              <div className="rounded-lg bg-secondary/30 p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <History className="h-4 w-4" />
                    Transaction Lifecycle
                  </h3>
                  <Badge variant="outline" className={statusColors[transaction.status]}>
                    Final: {transaction.status}
                  </Badge>
                </div>

                {/* Timeline */}
                <ScrollArea className="h-[400px] pr-4">
                  <div className="relative">
                    {/* Vertical line */}
                    <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border" />

                    <div className="space-y-6">
                      {lifecycleEvents.map((event, idx) => (
                        <div key={event.id} className="relative pl-10">
                          {/* Timeline dot */}
                          <div className={`absolute left-0 w-8 h-8 rounded-full flex items-center justify-center ${
                            event.status === "success" 
                              ? "bg-emerald-500/10 border-2 border-emerald-500" 
                              : event.status === "pending" 
                                ? "bg-amber-500/10 border-2 border-amber-500"
                                : event.status === "failed"
                                  ? "bg-red-500/10 border-2 border-red-500"
                                  : "bg-blue-500/10 border-2 border-blue-500"
                          }`}>
                            {event.status === "success" ? (
                              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                            ) : event.status === "pending" ? (
                              <Clock className="h-4 w-4 text-amber-500" />
                            ) : event.status === "failed" ? (
                              <XCircle className="h-4 w-4 text-red-500" />
                            ) : (
                              <ArrowUpRight className="h-4 w-4 text-blue-500" />
                            )}
                          </div>

                          {/* Event Card */}
                          <div className={`rounded-lg border p-4 ${
                            event.status === "failed" 
                              ? "border-red-500/30 bg-red-500/5" 
                              : "border-border bg-secondary/50"
                          }`}>
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <p className="font-semibold">{event.event}</p>
                                <p className="text-xs text-muted-foreground">{event.timestamp}</p>
                              </div>
                              <Badge variant="outline" className={`text-[10px] ${
                                event.status === "success" 
                                  ? "bg-emerald-500/10 text-emerald-400" 
                                  : event.status === "pending" 
                                    ? "bg-amber-500/10 text-amber-400"
                                    : event.status === "failed"
                                      ? "bg-red-500/10 text-red-400"
                                      : "bg-blue-500/10 text-blue-400"
                              }`}>
                                {event.status}
                              </Badge>
                            </div>
                            
                            <p className="text-sm text-muted-foreground mb-3">{event.description}</p>

                            {/* Metadata */}
                            {event.metadata && Object.keys(event.metadata).length > 0 && (
                              <div className="flex flex-wrap gap-2 mb-3">
                                {Object.entries(event.metadata).map(([key, value]) => (
                                  <Badge key={key} variant="secondary" className="text-[10px] font-mono">
                                    {key}: {value}
                                  </Badge>
                                ))}
                              </div>
                            )}

                            {/* Impact on Settlement/Refund */}
                            {(event.impactOnSettlement || event.impactOnRefund) && (
                              <div className="flex flex-wrap gap-2 pt-2 border-t border-border">
                                {event.impactOnSettlement && (
                                  <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                                    <CircleDollarSign className="h-3 w-3" />
                                    <span>Settlement: {event.impactOnSettlement}</span>
                                  </div>
                                )}
                                {event.impactOnRefund && (
                                  <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                                    <RefreshCw className="h-3 w-3" />
                                    <span>Refund: {event.impactOnRefund}</span>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </ScrollArea>

                {/* Filter Options Applied Summary */}
                <div className="mt-4 pt-4 border-t border-border">
                  <h4 className="text-sm font-semibold text-muted-foreground mb-3">Transaction Attributes</h4>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="text-xs">Gateway: {transaction.gateway}</Badge>
                    <Badge variant="outline" className="text-xs">Mode: {transaction.paymentMode}</Badge>
                    <Badge variant="outline" className="text-xs">Channel: {transaction.channel}</Badge>
                    {transaction.isSplitPayment && (
                      <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400">Split Payment</Badge>
                    )}
                    {transaction.captureApiUsed && (
                      <Badge variant="outline" className="text-xs bg-purple-500/10 text-purple-400">Capture API</Badge>
                    )}
                    {transaction.isInternational && (
                      <Badge variant="outline" className="text-xs bg-cyan-500/10 text-cyan-400">International</Badge>
                    )}
                    {transaction.financingCategory && transaction.financingCategory !== "none" && (
                      <Badge variant="outline" className="text-xs bg-indigo-500/10 text-indigo-400">
                        {transaction.financingCategory === "card_emi" ? "Card EMI" : "NBFC Financing"}
                      </Badge>
                    )}
                    {transaction.transactionFeeBearing && (
                      <Badge variant="outline" className="text-xs">
                        Fee: {transaction.transactionFeeBearing === "payer" ? "Payer" : transaction.transactionFeeBearing === "merchant" ? "Merchant" : "Partial"}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="split" className="space-y-4 mt-4">
              <div className="rounded-lg bg-secondary/30 p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <SplitSquareVertical className="h-4 w-4" />
                    Split Payment Details
                  </h3>
                  {transaction.isSplitPayment ? (
                    <Badge className="bg-primary/10 text-primary border-primary/20">
                      <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
                      Split Enabled
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-muted-foreground">
                      No Split
                    </Badge>
                  )}
                </div>

                {transaction.isSplitPayment && transaction.splitDetails ? (
                  <div className="space-y-6">
                    {/* Split Settlement Summary */}
                    <div className="grid grid-cols-4 gap-3">
                      <div className="rounded-lg bg-secondary/50 p-3 text-center">
                        <p className="text-xs text-muted-foreground mb-1">Total Splits</p>
                        <p className="text-xl font-bold">{splitSettlementSummary.totalSplits}</p>
                      </div>
                      <div className="rounded-lg bg-secondary/50 p-3 text-center">
                        <p className="text-xs text-muted-foreground mb-1">Total Amount</p>
                        <p className="text-xl font-bold">₹{splitSettlementSummary.totalAmount.toLocaleString()}</p>
                      </div>
                      <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/20 p-3 text-center">
                        <p className="text-xs text-emerald-400 mb-1">Settled</p>
                        <p className="text-xl font-bold text-emerald-500">
                          {splitSettlementSummary.settledCount}/{splitSettlementSummary.totalSplits}
                        </p>
                      </div>
                      <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3 text-center">
                        <p className="text-xs text-amber-400 mb-1">Pending</p>
                        <p className="text-xl font-bold text-amber-500">
                          ₹{splitSettlementSummary.pendingAmount.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Settlement Progress */}
                    <div className="rounded-lg bg-secondary/50 p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">Settlement Progress</span>
                        <span className="text-sm text-muted-foreground">
                          {Math.round(
                            (splitSettlementSummary.settledAmount / splitSettlementSummary.totalAmount) * 100,
                          )}
                          %
                        </span>
                      </div>
                      <Progress
                        value={(splitSettlementSummary.settledAmount / splitSettlementSummary.totalAmount) * 100}
                        className="h-2"
                      />
                      <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                        <span>₹{splitSettlementSummary.settledAmount.toLocaleString()} settled</span>
                        <span>₹{splitSettlementSummary.pendingAmount.toLocaleString()} pending</span>
                      </div>
                    </div>

                    {/* Individual Split Beneficiaries with Settlement Details */}
                    <div className="space-y-4">
                      <h4 className="text-sm font-semibold text-muted-foreground">Beneficiary Settlement Details</h4>
                      {enhancedSplitDetails.map((split, idx) => (
                        <div key={idx} className="rounded-lg border border-border overflow-hidden">
                          {/* Beneficiary Header */}
                          <div className="p-4 bg-secondary/30">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary font-bold">
                                  {idx + 1}
                                </div>
                                <div>
                                  <p className="font-semibold">{split.beneficiary}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {split.percentage}% share • {split.gateway}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right">
                                <Badge
                                  variant="outline"
                                  className={
                                    split.status === "settled"
                                      ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                                      : split.status === "processing"
                                        ? "bg-blue-500/10 text-blue-500 border-blue-500/20"
                                        : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                                  }
                                >
                                  {split.status === "settled" ? (
                                    <CheckCircle2 className="h-3 w-3 mr-1" />
                                  ) : (
                                    <Clock className="h-3 w-3 mr-1" />
                                  )}
                                  {split.status}
                                </Badge>
                                <p className="text-lg font-bold mt-1">₹{split.amount.toLocaleString()}</p>
                              </div>
                            </div>
                          </div>

                          {/* Settlement Details */}
                          <div className="p-4 space-y-4">
                            {/* Account Details */}
                            <div className="grid grid-cols-3 gap-4">
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">Account Number</p>
                                <p className="font-mono text-sm">{split.account}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">IFSC Code</p>
                                <p className="font-mono text-sm">{split.ifsc}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground mb-1">Fee Bearer</p>
                                <Badge variant="secondary" className="text-xs">
                                  {split.feeBearer === "platform" ? "Platform" : "Beneficiary"}
                                </Badge>
                              </div>
                            </div>

                            {/* Settlement Info based on status */}
                            {split.status === "settled" ? (
                              <div className="rounded-lg bg-emerald-500/5 border border-emerald-500/20 p-4">
                                <div className="flex items-center gap-2 mb-3">
                                  <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                                  <span className="font-semibold text-emerald-500">Settlement Complete</span>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-xs text-muted-foreground mb-1">Settlement ID</p>
                                    <div className="flex items-center gap-2">
                                      <span className="font-mono text-sm">{split.settlementId}</span>
                                      <button onClick={() => copyToClipboard(split.settlementId || "")}>
                                        <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                                      </button>
                                    </div>
                                  </div>
                                  <div>
                                    <p className="text-xs text-muted-foreground mb-1">Settlement Date</p>
                                    <span className="text-sm font-medium">{split.settlementDate}</span>
                                  </div>
                                  <div>
                                    <p className="text-xs text-muted-foreground mb-1">UTR Number</p>
                                    <div className="flex items-center gap-2">
                                      <span className="font-mono text-sm text-emerald-500">{split.settlementUtr}</span>
                                      <button onClick={() => copyToClipboard(split.settlementUtr || "")}>
                                        <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                                      </button>
                                    </div>
                                  </div>
                                  <div>
                                    <p className="text-xs text-muted-foreground mb-1">Net Credited</p>
                                    <span className="text-sm font-bold text-emerald-500">
                                      ₹{split.netAmount?.toLocaleString()}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <div className="rounded-lg bg-amber-500/5 border border-amber-500/20 p-4">
                                <div className="flex items-center gap-2 mb-3">
                                  <CalendarClock className="h-5 w-5 text-amber-500" />
                                  <span className="font-semibold text-amber-500">Settlement Pending (T+1)</span>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-xs text-muted-foreground mb-1">Expected Settlement</p>
                                    <span className="text-sm font-medium">{split.expectedSettlementDate}</span>
                                  </div>
                                  <div>
                                    <p className="text-xs text-muted-foreground mb-1">Expected Amount</p>
                                    <span className="text-sm font-medium">₹{split.netAmount?.toLocaleString()}</span>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* Fee Breakdown for this split */}
                            <div className="rounded-lg bg-secondary/50 p-3">
                              <p className="text-xs font-semibold text-muted-foreground mb-2">Split Fee Breakdown</p>
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">Gross Amount</span>
                                <span>₹{split.amount.toLocaleString()}</span>
                              </div>
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">
                                  Processing Fee (2%)
                                  {split.feeBearer === "platform" && (
                                    <Badge variant="outline" className="ml-2 text-[10px] py-0">
                                      Paid by Platform
                                    </Badge>
                                  )}
                                </span>
                                <span
                                  className={
                                    split.feeBearer === "beneficiary"
                                      ? "text-destructive"
                                      : "text-muted-foreground line-through"
                                  }
                                >
                                  -₹{split.fees?.toLocaleString()}
                                </span>
                              </div>
                              <Separator className="my-2" />
                              <div className="flex items-center justify-between font-semibold">
                                <span>Net Amount</span>
                                <span className="text-primary">
                                  ₹
                                  {split.feeBearer === "platform"
                                    ? split.amount.toLocaleString()
                                    : split.netAmount?.toLocaleString()}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Settlement Flow Timeline */}
                    <div className="rounded-lg bg-secondary/30 p-4">
                      <h4 className="text-sm font-semibold text-muted-foreground mb-4">Settlement Flow</h4>
                      <div className="flex items-center justify-between">
                        <div className="text-center">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                            <Banknote className="h-5 w-5 text-primary" />
                          </div>
                          <p className="text-xs font-medium">Payment Received</p>
                          <p className="text-xs text-muted-foreground">
                            ₹{transaction.transactionAmount.toLocaleString()}
                          </p>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground" />
                        <div className="text-center">
                          <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto mb-2">
                            <SplitSquareVertical className="h-5 w-5 text-blue-500" />
                          </div>
                          <p className="text-xs font-medium">Split Applied</p>
                          <p className="text-xs text-muted-foreground">
                            {splitSettlementSummary.totalSplits} Beneficiaries
                          </p>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground" />
                        <div className="text-center">
                          <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center mx-auto mb-2">
                            <Clock className="h-5 w-5 text-amber-500" />
                          </div>
                          <p className="text-xs font-medium">T+1 Processing</p>
                          <p className="text-xs text-muted-foreground">Next Business Day</p>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground" />
                        <div className="text-center">
                          <div
                            className={`h-10 w-10 rounded-full flex items-center justify-center mx-auto mb-2 ${
                              splitSettlementSummary.settledCount === splitSettlementSummary.totalSplits
                                ? "bg-emerald-500/10"
                                : "bg-secondary"
                            }`}
                          >
                            <TrendingUp
                              className={`h-5 w-5 ${
                                splitSettlementSummary.settledCount === splitSettlementSummary.totalSplits
                                  ? "text-emerald-500"
                                  : "text-muted-foreground"
                              }`}
                            />
                          </div>
                          <p className="text-xs font-medium">
                            {splitSettlementSummary.settledCount === splitSettlementSummary.totalSplits
                              ? "All Settled"
                              : "Partial Settlement"}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            ₹{splitSettlementSummary.settledAmount.toLocaleString()} credited
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <SplitSquareVertical className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                    <p className="text-muted-foreground">Split payment was not used for this transaction</p>
                    <p className="text-xs text-muted-foreground mt-1">Full amount credited to primary account</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="bank" className="space-y-4 mt-4">
              <div className="rounded-lg bg-secondary/30 p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    Bank Transfer Details
                  </h3>
                  {transaction.bankTransferDetails ? (
                    <Badge className="bg-primary/10 text-primary border-primary/20 uppercase">
                      {transaction.bankTransferDetails.type}
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-muted-foreground">
                      Not Applicable
                    </Badge>
                  )}
                </div>

                {transaction.bankTransferDetails ? (
                  <div className="space-y-4">
                    {/* Transfer Type Banner */}
                    <div className="rounded-lg bg-primary/5 border border-primary/20 p-4">
                      <div className="flex items-center gap-3">
                        {transaction.bankTransferDetails.type === "vpa" && (
                          <Smartphone className="h-6 w-6 text-primary" />
                        )}
                        {transaction.bankTransferDetails.type === "challan" && (
                          <FileText className="h-6 w-6 text-primary" />
                        )}
                        {["neft", "rtgs", "imps"].includes(transaction.bankTransferDetails.type) && (
                          <Landmark className="h-6 w-6 text-primary" />
                        )}
                        <div>
                          <p className="font-semibold">{transaction.bankTransferDetails.type.toUpperCase()} Transfer</p>
                          <p className="text-xs text-muted-foreground">
                            {transaction.bankTransferDetails.type === "vpa" && "Virtual Payment Address Collect"}
                            {transaction.bankTransferDetails.type === "challan" && "Bank Challan Deposit"}
                            {transaction.bankTransferDetails.type === "neft" && "National Electronic Funds Transfer"}
                            {transaction.bankTransferDetails.type === "rtgs" && "Real Time Gross Settlement"}
                            {transaction.bankTransferDetails.type === "imps" && "Immediate Payment Service"}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Details Grid */}
                    <div className="grid grid-cols-2 gap-4">
                      {transaction.bankTransferDetails.vpa && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">VPA Address</p>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-medium">{transaction.bankTransferDetails.vpa}</span>
                            <button onClick={() => copyToClipboard(transaction.bankTransferDetails!.vpa!)}>
                              <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                            </button>
                          </div>
                        </div>
                      )}

                      {transaction.bankTransferDetails.challanNumber && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">Challan Number</p>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-medium">
                              {transaction.bankTransferDetails.challanNumber}
                            </span>
                            <button onClick={() => copyToClipboard(transaction.bankTransferDetails!.challanNumber!)}>
                              <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                            </button>
                          </div>
                        </div>
                      )}

                      {transaction.bankTransferDetails.bankName && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">Bank Name</p>
                          <span className="font-medium">{transaction.bankTransferDetails.bankName}</span>
                        </div>
                      )}

                      {transaction.bankTransferDetails.accountNumber && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">Account Number</p>
                          <span className="font-mono">{transaction.bankTransferDetails.accountNumber}</span>
                        </div>
                      )}

                      {transaction.bankTransferDetails.ifscCode && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">IFSC Code</p>
                          <span className="font-mono">{transaction.bankTransferDetails.ifscCode}</span>
                        </div>
                      )}

                      {transaction.bankTransferDetails.branchName && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">Branch</p>
                          <span className="text-sm">{transaction.bankTransferDetails.branchName}</span>
                        </div>
                      )}

                      {transaction.bankTransferDetails.depositDate && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">Deposit Date</p>
                          <span className="font-medium">{transaction.bankTransferDetails.depositDate}</span>
                        </div>
                      )}

                      {transaction.bankTransferDetails.referenceNumber && (
                        <div className="rounded-lg bg-secondary/50 p-3">
                          <p className="text-xs text-muted-foreground mb-1">Reference Number</p>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm">{transaction.bankTransferDetails.referenceNumber}</span>
                            <button onClick={() => copyToClipboard(transaction.bankTransferDetails!.referenceNumber!)}>
                              <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* UTR Number Highlight */}
                    {transaction.bankTransferDetails.utrNumber && (
                      <div className="rounded-lg bg-success/5 border border-success/20 p-4">
                        <p className="text-xs text-muted-foreground mb-1">UTR / Reference Number</p>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-lg font-semibold text-success">
                            {transaction.bankTransferDetails.utrNumber}
                          </span>
                          <button onClick={() => copyToClipboard(transaction.bankTransferDetails!.utrNumber!)}>
                            <Copy className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                    <p className="text-muted-foreground">This transaction was not a bank transfer</p>
                    <p className="text-xs text-muted-foreground mt-1">Payment made via {transaction.paymentMode}</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="settlement" className="space-y-4 mt-4">
              <div className="rounded-lg bg-secondary/30 p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    Settlement Status
                  </h3>
                  {transaction.isSettled ? (
                    <Badge className="bg-success/10 text-success border-success/20">
                      <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
                      Settled
                    </Badge>
                  ) : (
                    <Badge className="bg-warning/10 text-warning border-warning/20">
                      <Clock className="h-3.5 w-3.5 mr-1.5" />
                      Pending T+1
                    </Badge>
                  )}
                </div>

                {transaction.isSettled ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-lg bg-secondary/50 p-3">
                        <p className="text-xs text-muted-foreground mb-1">Settlement ID</p>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-sm font-medium">{transaction.settlementId}</span>
                          <button onClick={() => copyToClipboard(transaction.settlementId || "")}>
                            <Copy className="h-3 w-3 text-muted-foreground hover:text-foreground" />
                          </button>
                        </div>
                      </div>
                      <div className="rounded-lg bg-secondary/50 p-3">
                        <p className="text-xs text-muted-foreground mb-1">Settlement Date</p>
                        <span className="text-sm font-medium">{transaction.settlementDate}</span>
                      </div>
                    </div>

                    <div className="rounded-lg bg-primary/5 border border-primary/20 p-4">
                      <p className="text-xs text-muted-foreground mb-1">UTR / Reference Number</p>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-lg font-semibold text-primary">
                          {transaction.settlementUtr}
                        </span>
                        <button onClick={() => copyToClipboard(transaction.settlementUtr || "")}>
                          <Copy className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 p-3 rounded-lg bg-success/5 border border-success/20">
                      <CheckCircle2 className="h-5 w-5 text-success" />
                      <div>
                        <p className="text-sm font-medium text-success">Settlement Complete</p>
                        <p className="text-xs text-muted-foreground">
                          Amount credited to merchant account on {transaction.settlementDate}
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-warning/5 border border-warning/20">
                      <Clock className="h-5 w-5 text-warning" />
                      <div>
                        <p className="text-sm font-medium text-warning">Settlement Pending</p>
                        <p className="text-xs text-muted-foreground">Expected settlement by T+1 working day</p>
                      </div>
                    </div>
                    <div className="rounded-lg bg-secondary/50 p-3">
                      <p className="text-xs text-muted-foreground mb-1">Expected Settlement</p>
                      <span className="text-sm font-medium">
                        {new Date(new Date(transaction.date).getTime() + 86400000).toISOString().split("T")[0]}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-4 border-t border-border">
            {transaction.status === "success" && (
              <Button variant="outline" className="gap-2 bg-transparent">
                <RotateCcw className="h-4 w-4" />
                Initiate Refund
              </Button>
            )}
            <Button variant="outline" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Download Receipt
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
