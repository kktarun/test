"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Settings2 } from "lucide-react"

interface ColumnFilterProps {
  columns: string[]
  visibleColumns: string[]
  onColumnsChange: (columns: string[]) => void
}

export function ColumnFilter({ columns, visibleColumns, onColumnsChange }: ColumnFilterProps) {
  const [open, setOpen] = useState(false)

  const toggleColumn = (column: string) => {
    if (visibleColumns.includes(column)) {
      onColumnsChange(visibleColumns.filter((c) => c !== column))
    } else {
      onColumnsChange([...visibleColumns, column])
    }
  }

  const toggleAll = () => {
    if (visibleColumns.length === columns.length) {
      onColumnsChange([])
    } else {
      onColumnsChange(columns)
    }
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 bg-transparent">
          <Settings2 className="h-4 w-4" />
          Columns ({visibleColumns.length}/{columns.length})
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64">
        <div className="space-y-4">
          <h4 className="font-medium">Select Columns</h4>
          <div className="flex items-center gap-2 pb-2 border-b">
            <Checkbox checked={visibleColumns.length === columns.length} onCheckedChange={toggleAll} />
            <label className="text-sm font-medium">Select All</label>
          </div>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {columns.map((column) => (
              <div key={column} className="flex items-center gap-2">
                <Checkbox checked={visibleColumns.includes(column)} onCheckedChange={() => toggleColumn(column)} />
                <label className="text-sm cursor-pointer">{column}</label>
              </div>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}
