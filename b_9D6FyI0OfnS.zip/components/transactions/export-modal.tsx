"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { FileSpreadsheet, FileText, File, Download, Loader2, Calendar, Filter } from "lucide-react"

interface ExportModalProps {
  open: boolean
  onClose: () => void
  totalRecords: number
  selectedRecords: number
  filters: {
    dateRange: string
    status: string
    gateway: string
  }
}

const exportFormats = [
  {
    id: "excel",
    name: "Excel (.xlsx)",
    description: "Best for data analysis and pivot tables",
    icon: FileSpreadsheet,
    color: "text-green-500",
  },
  {
    id: "csv",
    name: "CSV (.csv)",
    description: "Universal format for all spreadsheet apps",
    icon: File,
    color: "text-blue-500",
  },
  {
    id: "pdf",
    name: "PDF (.pdf)",
    description: "Best for sharing and printing reports",
    icon: FileText,
    color: "text-red-500",
  },
]

const exportFields = [
  { id: "transaction_id", label: "Transaction ID", default: true },
  { id: "order_id", label: "Order ID", default: true },
  { id: "institute", label: "Institute", default: true },
  { id: "student_name", label: "Student Name", default: true },
  { id: "order_amount", label: "Order Amount", default: true },
  { id: "transaction_amount", label: "Transaction Amount", default: true },
  { id: "gateway", label: "Payment Gateway", default: true },
  { id: "payment_mode", label: "Payment Mode", default: true },
  { id: "channel", label: "Channel", default: true },
  { id: "status", label: "Status", default: true },
  { id: "status_reason", label: "Status Reason", default: true },
  { id: "split_payment", label: "Split Payment Details", default: false },
  { id: "bank_transfer", label: "Bank Transfer / VPA / Challan", default: false },
  { id: "settlement", label: "Settlement Details", default: false },
  { id: "payer_email", label: "Payer Email", default: false },
  { id: "payer_mobile", label: "Payer Mobile", default: false },
  { id: "date_time", label: "Date & Time", default: true },
  { id: "utr", label: "UTR Number", default: false },
]

export function ExportModal({ open, onClose, totalRecords, selectedRecords, filters }: ExportModalProps) {
  const [format, setFormat] = useState("excel")
  const [exportScope, setExportScope] = useState<"all" | "selected" | "filtered">("filtered")
  const [selectedFields, setSelectedFields] = useState<string[]>(exportFields.filter((f) => f.default).map((f) => f.id))
  const [isExporting, setIsExporting] = useState(false)

  const toggleField = (fieldId: string) => {
    setSelectedFields((prev) => (prev.includes(fieldId) ? prev.filter((f) => f !== fieldId) : [...prev, fieldId]))
  }

  const handleExport = async () => {
    setIsExporting(true)
    // Simulate export
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsExporting(false)
    onClose()
  }

  const getRecordCount = () => {
    switch (exportScope) {
      case "selected":
        return selectedRecords
      case "all":
        return totalRecords
      default:
        return totalRecords // filtered
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-card max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Transactions
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Export Format Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Export Format</Label>
            <RadioGroup value={format} onValueChange={setFormat} className="grid grid-cols-3 gap-3">
              {exportFormats.map((fmt) => (
                <div key={fmt.id}>
                  <RadioGroupItem value={fmt.id} id={fmt.id} className="peer sr-only" />
                  <Label
                    htmlFor={fmt.id}
                    className="flex flex-col items-center gap-2 rounded-lg border-2 border-border p-4 cursor-pointer hover:bg-secondary/50 peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5"
                  >
                    <fmt.icon className={`h-8 w-8 ${fmt.color}`} />
                    <span className="text-sm font-medium">{fmt.name}</span>
                    <span className="text-xs text-muted-foreground text-center">{fmt.description}</span>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <Separator />

          {/* Export Scope */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Export Scope</Label>
            <RadioGroup
              value={exportScope}
              onValueChange={(v) => setExportScope(v as "all" | "selected" | "filtered")}
              className="space-y-2"
            >
              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="filtered" id="filtered" />
                  <Label htmlFor="filtered" className="cursor-pointer">
                    <p className="text-sm font-medium">Current Filtered View</p>
                    <p className="text-xs text-muted-foreground">Export based on applied filters</p>
                  </Label>
                </div>
                <Badge variant="outline">{totalRecords.toLocaleString()} records</Badge>
              </div>

              {selectedRecords > 0 && (
                <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value="selected" id="selected" />
                    <Label htmlFor="selected" className="cursor-pointer">
                      <p className="text-sm font-medium">Selected Records Only</p>
                      <p className="text-xs text-muted-foreground">Export only checked transactions</p>
                    </Label>
                  </div>
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                    {selectedRecords} selected
                  </Badge>
                </div>
              )}

              <div className="flex items-center justify-between p-3 rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <RadioGroupItem value="all" id="all" />
                  <Label htmlFor="all" className="cursor-pointer">
                    <p className="text-sm font-medium">All Transactions</p>
                    <p className="text-xs text-muted-foreground">Export entire transaction history</p>
                  </Label>
                </div>
                <Badge variant="outline">{totalRecords.toLocaleString()} records</Badge>
              </div>
            </RadioGroup>
          </div>

          {/* Current Filters Info */}
          <div className="rounded-lg bg-secondary/30 p-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
              <Filter className="h-4 w-4" />
              Active Filters
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="gap-1">
                <Calendar className="h-3 w-3" />
                {filters.dateRange}
              </Badge>
              {filters.status !== "all" && <Badge variant="outline">Status: {filters.status}</Badge>}
              {filters.gateway !== "all" && <Badge variant="outline">Gateway: {filters.gateway}</Badge>}
            </div>
          </div>

          <Separator />

          {/* Field Selection */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Select Fields to Export</Label>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm" onClick={() => setSelectedFields(exportFields.map((f) => f.id))}>
                  Select All
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedFields(exportFields.filter((f) => f.default).map((f) => f.id))}
                >
                  Reset
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 rounded-lg bg-secondary/30">
              {exportFields.map((field) => (
                <div key={field.id} className="flex items-center gap-2">
                  <Checkbox
                    id={field.id}
                    checked={selectedFields.includes(field.id)}
                    onCheckedChange={() => toggleField(field.id)}
                  />
                  <Label htmlFor={field.id} className="text-sm cursor-pointer">
                    {field.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter className="mt-6">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleExport} disabled={isExporting || selectedFields.length === 0}>
            {isExporting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Exporting...
              </>
            ) : (
              <>
                <Download className="mr-2 h-4 w-4" />
                Export {getRecordCount().toLocaleString()} Records
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
