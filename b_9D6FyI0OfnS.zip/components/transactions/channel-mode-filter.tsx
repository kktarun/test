"use client"
import { ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface ChannelModeFilterProps {
  selectedChannels: string[]
  selectedModes: string[]
  onChannelsChange: (channels: string[]) => void
  onModesChange: (modes: string[]) => void
}

const channelsAndModes = {
  Online: ["Credit Card", "Debit Card", "UPI", "Net Banking", "Wallet", "Pay Later", "Split and Pay (Multi-mode)"],
  POS: ["Credit Card", "Debit Card"],
  "Payment Link": ["Credit Card", "UPI", "Net Banking", "Pay Later", "Split and Pay (Multi-mode)"],
  "Payment Form": ["All Modes", "Pay Later", "Split and Pay (Multi-mode)"],
  "Auto Debit": ["UPI", "Mandate"],
  "Netbanking Transfer": ["NEFT", "RTGS", "IMPS"],
  "Challan": ["Challan Payment"],
  "Static QR Code": ["UPI"],
  "Dynamic QR Code": ["UPI"],
  "School Counter": ["Demand Draft", "Cheque", "Cash"],
  "International Gateway": ["International Card", "Wire Transfer (SWIFT)", "PayPal", "Flywire", "Western Union", "Wise", "Remitly"],
}

export function ChannelModeFilter({
  selectedChannels,
  selectedModes,
  onChannelsChange,
  onModesChange,
}: ChannelModeFilterProps) {
  const allChannels = Object.keys(channelsAndModes)
  const allModes = [
    "Credit Card",
    "Debit Card",
    "UPI",
    "Net Banking",
    "Wallet",
    "NEFT",
    "RTGS",
    "IMPS",
    "Challan Payment",
    "Mandate",
    "Pay Later",
    "Split and Pay (Multi-mode)",
    "Demand Draft",
    "Cheque",
    "Cash",
    "International Card",
    "Wire Transfer (SWIFT)",
    "PayPal",
    "Flywire",
    "Western Union",
    "Wise",
    "Remitly",
  ]

  const toggleChannel = (channel: string) => {
    if (selectedChannels.includes(channel)) {
      const newChannels = selectedChannels.filter((c) => c !== channel)
      onChannelsChange(newChannels)
      // Remove modes not available in remaining channels
      const availableModes = newChannels.flatMap((ch) => channelsAndModes[ch as keyof typeof channelsAndModes] || [])
      onModesChange(selectedModes.filter((m) => availableModes.includes(m) || m === ""))
    } else {
      onChannelsChange([...selectedChannels, channel])
    }
  }

  const toggleMode = (mode: string) => {
    if (selectedModes.includes(mode)) {
      onModesChange(selectedModes.filter((m) => m !== mode))
    } else {
      onModesChange([...selectedModes, mode])
    }
  }

  const availableModes =
    selectedChannels.length > 0
      ? [...new Set(selectedChannels.flatMap((ch) => channelsAndModes[ch as keyof typeof channelsAndModes] || []))]
      : allModes

  const toggleAllChannels = () => {
    if (selectedChannels.length === allChannels.length) {
      onChannelsChange([])
      onModesChange([])
    } else {
      onChannelsChange(allChannels)
      onModesChange(allModes)
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 bg-transparent">
          Channels & Modes
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80">
        <div className="p-4 space-y-4 max-h-80 overflow-y-auto">
          <div>
            <h4 className="text-sm font-semibold mb-2">Channels</h4>
            <div className="flex items-center gap-2 pb-2 border-b mb-2">
              <Checkbox checked={selectedChannels.length === allChannels.length} onCheckedChange={toggleAllChannels} />
              <label className="text-sm">Select All Channels</label>
            </div>
            <div className="space-y-2">
              {allChannels.map((channel) => (
                <div key={channel} className="flex items-center gap-2">
                  <Checkbox
                    checked={selectedChannels.includes(channel)}
                    onCheckedChange={() => toggleChannel(channel)}
                  />
                  <label className="text-sm cursor-pointer">{channel}</label>
                </div>
              ))}
            </div>
          </div>

          {selectedChannels.length > 0 && (
            <div className="border-t pt-3">
              <h4 className="text-sm font-semibold mb-2">Modes (filtered by selected channels)</h4>
              <div className="space-y-2">
                {availableModes.map((mode) => (
                  <div key={mode} className="flex items-center gap-2">
                    <Checkbox checked={selectedModes.includes(mode)} onCheckedChange={() => toggleMode(mode)} />
                    <label className="text-sm cursor-pointer">{mode}</label>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
