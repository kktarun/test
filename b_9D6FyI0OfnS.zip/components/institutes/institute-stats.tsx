"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Building2, CheckCircle2, Clock, XCircle, Rocket, Shield, Zap } from "lucide-react"

const stats = [
  {
    name: "Total Institutes",
    value: "127",
    subValue: "+3 this month",
    icon: Building2,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    name: "Onboarded",
    value: "15",
    subValue: "KYC Pending",
    icon: Clock,
    color: "text-amber-500",
    bgColor: "bg-amber-500/10",
  },
  {
    name: "Activated",
    value: "8",
    subValue: "Testing Phase",
    icon: Shield,
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
  },
  {
    name: "Live",
    value: "104",
    subValue: "Processing Payments",
    icon: Zap,
    color: "text-success",
    bgColor: "bg-success/10",
  },
]

const additionalStats = [
  {
    name: "Active Terminals",
    value: "342",
    subValue: "POS + QR",
    icon: Rocket,
    color: "text-purple-500",
    bgColor: "bg-purple-500/10",
  },
  {
    name: "Active",
    value: "118",
    subValue: "93% of total",
    icon: CheckCircle2,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    name: "Pending Setup",
    value: "6",
    subValue: "Awaiting verification",
    icon: Clock,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    name: "Suspended",
    value: "3",
    subValue: "Payment issues",
    icon: XCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
]

export function InstituteStats() {
  return (
    <div className="space-y-4">
      {/* Onboarding Pipeline */}
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-medium text-muted-foreground mb-3">Onboarding Pipeline</h3>
        <div className="grid gap-4 md:grid-cols-4">
          {stats.map((stat, index) => (
            <div key={stat.name} className="flex items-center gap-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div className="flex-1">
                <p className="text-xl font-bold text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.name}</p>
              </div>
              {index < stats.length - 1 && <div className="hidden md:block text-muted-foreground">→</div>}
            </div>
          ))}
        </div>
      </div>

      {/* Status Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {additionalStats.map((stat) => (
          <Card key={stat.name} className="bg-card border-border">
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.name}</p>
                <p className={`text-xs ${stat.color}`}>{stat.subValue}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
