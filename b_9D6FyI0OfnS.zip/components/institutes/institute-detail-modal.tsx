"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import {
  Building2,
  CreditCard,
  TrendingUp,
  Calendar,
  Send,
  ChevronDown,
  ChevronRight,
  Search,
  ArrowUpRight,
  Zap,
  Landmark,
  Wallet,
  QrCode,
  Smartphone,
  Building,
  CheckCircle2,
  XCircle,
  Download,
  Users,
  IndianRupee,
  Percent,
  BarChart3,
  ExternalLink,
} from "lucide-react"

interface InstituteDetailModalProps {
  instituteId: string
  open: boolean
  onClose: () => void
}

const paymentChannelsData = {
  cards: {
    name: "Cards",
    icon: CreditCard,
    subChannels: [
      { id: "visa", name: "Visa", type: "Credit/Debit" },
      { id: "mastercard", name: "Mastercard", type: "Credit/Debit" },
      { id: "rupay", name: "RuPay", type: "Credit/Debit" },
      { id: "amex", name: "American Express", type: "Credit" },
      { id: "diners", name: "Diners Club", type: "Credit" },
      { id: "discover", name: "Discover", type: "Credit" },
      { id: "maestro", name: "Maestro", type: "Debit" },
      { id: "jcb", name: "JCB", type: "Credit" },
    ],
  },
  netBanking: {
    name: "Net Banking",
    icon: Landmark,
    subChannels: [
      { id: "sbi", name: "State Bank of India", type: "Public" },
      { id: "hdfc", name: "HDFC Bank", type: "Private" },
      { id: "icici", name: "ICICI Bank", type: "Private" },
      { id: "axis", name: "Axis Bank", type: "Private" },
      { id: "kotak", name: "Kotak Mahindra Bank", type: "Private" },
      { id: "yes", name: "Yes Bank", type: "Private" },
      { id: "idbi", name: "IDBI Bank", type: "Public" },
      { id: "bob", name: "Bank of Baroda", type: "Public" },
      { id: "pnb", name: "Punjab National Bank", type: "Public" },
      { id: "canara", name: "Canara Bank", type: "Public" },
      { id: "union", name: "Union Bank of India", type: "Public" },
      { id: "indian", name: "Indian Bank", type: "Public" },
      { id: "boi", name: "Bank of India", type: "Public" },
      { id: "central", name: "Central Bank of India", type: "Public" },
      { id: "iob", name: "Indian Overseas Bank", type: "Public" },
      { id: "uco", name: "UCO Bank", type: "Public" },
      { id: "psb", name: "Punjab & Sind Bank", type: "Public" },
      { id: "bandhan", name: "Bandhan Bank", type: "Private" },
      { id: "rbl", name: "RBL Bank", type: "Private" },
      { id: "federal", name: "Federal Bank", type: "Private" },
      { id: "idfc", name: "IDFC First Bank", type: "Private" },
      { id: "indusind", name: "IndusInd Bank", type: "Private" },
      { id: "au", name: "AU Small Finance Bank", type: "SFB" },
      { id: "equitas", name: "Equitas Small Finance Bank", type: "SFB" },
      { id: "ujjivan", name: "Ujjivan Small Finance Bank", type: "SFB" },
      { id: "jana", name: "Jana Small Finance Bank", type: "SFB" },
      { id: "karnataka", name: "Karnataka Bank", type: "Private" },
      { id: "south", name: "South Indian Bank", type: "Private" },
      { id: "karur", name: "Karur Vysya Bank", type: "Private" },
      { id: "tamilnad", name: "Tamilnad Mercantile Bank", type: "Private" },
      { id: "csb", name: "CSB Bank", type: "Private" },
      { id: "dcb", name: "DCB Bank", type: "Private" },
      { id: "jk", name: "Jammu & Kashmir Bank", type: "Private" },
      { id: "city", name: "City Union Bank", type: "Private" },
      { id: "nainital", name: "Nainital Bank", type: "Private" },
      { id: "dhanlaxmi", name: "Dhanlaxmi Bank", type: "Private" },
      { id: "lakshmi", name: "Lakshmi Vilas Bank", type: "Private" },
      { id: "saraswat", name: "Saraswat Bank", type: "Cooperative" },
      { id: "cosmos", name: "Cosmos Bank", type: "Cooperative" },
      { id: "tjsb", name: "TJSB Sahakari Bank", type: "Cooperative" },
      { id: "akola", name: "Akola Urban Co-op Bank", type: "Cooperative" },
      { id: "bassein", name: "Bassein Catholic Co-op Bank", type: "Cooperative" },
      { id: "bharat", name: "Bharat Co-op Bank", type: "Cooperative" },
      { id: "gp", name: "GP Parsik Bank", type: "Cooperative" },
      { id: "janata", name: "Janata Sahakari Bank", type: "Cooperative" },
      { id: "kalyan", name: "Kalyan Janata Sahakari Bank", type: "Cooperative" },
      { id: "mehsana", name: "Mehsana Urban Co-op Bank", type: "Cooperative" },
      { id: "nkgsb", name: "NKGSB Co-op Bank", type: "Cooperative" },
      { id: "shamrao", name: "Shamrao Vithal Co-op Bank", type: "Cooperative" },
      { id: "thane", name: "Thane Bharat Sahakari Bank", type: "Cooperative" },
      { id: "zoroastrian", name: "Zoroastrian Co-op Bank", type: "Cooperative" },
    ],
  },
  upi: {
    name: "UPI",
    icon: Smartphone,
    subChannels: [
      { id: "gpay", name: "Google Pay", type: "App" },
      { id: "phonepe", name: "PhonePe", type: "App" },
      { id: "paytm_upi", name: "Paytm UPI", type: "App" },
      { id: "bhim", name: "BHIM", type: "App" },
      { id: "amazon_pay", name: "Amazon Pay", type: "App" },
      { id: "whatsapp", name: "WhatsApp Pay", type: "App" },
      { id: "cred", name: "CRED", type: "App" },
      { id: "mobikwik_upi", name: "MobiKwik UPI", type: "App" },
      { id: "freecharge_upi", name: "Freecharge UPI", type: "App" },
      { id: "airtel_upi", name: "Airtel Thanks UPI", type: "App" },
      { id: "sbi_yono", name: "SBI YONO", type: "Bank" },
      { id: "hdfc_upi", name: "HDFC Bank UPI", type: "Bank" },
      { id: "icici_imobile", name: "ICICI iMobile Pay", type: "Bank" },
      { id: "axis_upi", name: "Axis Bank UPI", type: "Bank" },
      { id: "kotak_upi", name: "Kotak UPI", type: "Bank" },
    ],
  },
  wallets: {
    name: "Wallets",
    icon: Wallet,
    subChannels: [
      { id: "paytm", name: "Paytm Wallet", type: "Full KYC" },
      { id: "phonepe_wallet", name: "PhonePe Wallet", type: "Full KYC" },
      { id: "amazon_wallet", name: "Amazon Pay Balance", type: "Full KYC" },
      { id: "mobikwik", name: "MobiKwik", type: "Full KYC" },
      { id: "freecharge", name: "Freecharge", type: "Full KYC" },
      { id: "airtel", name: "Airtel Money", type: "Full KYC" },
      { id: "jio", name: "JioMoney", type: "Full KYC" },
      { id: "ola", name: "Ola Money", type: "Full KYC" },
      { id: "oxigen", name: "Oxigen Wallet", type: "Full KYC" },
      { id: "itzcash", name: "ItzCash", type: "Full KYC" },
    ],
  },
  emi: {
    name: "EMI",
    icon: CreditCard,
    subChannels: [
      { id: "hdfc_emi", name: "HDFC Bank EMI", type: "Bank" },
      { id: "icici_emi", name: "ICICI Bank EMI", type: "Bank" },
      { id: "sbi_emi", name: "SBI Card EMI", type: "Bank" },
      { id: "axis_emi", name: "Axis Bank EMI", type: "Bank" },
      { id: "kotak_emi", name: "Kotak Bank EMI", type: "Bank" },
      { id: "yes_emi", name: "Yes Bank EMI", type: "Bank" },
      { id: "rbl_emi", name: "RBL Bank EMI", type: "Bank" },
      { id: "indusind_emi", name: "IndusInd Bank EMI", type: "Bank" },
      { id: "bajaj", name: "Bajaj Finserv", type: "NBFC" },
      { id: "zestmoney", name: "ZestMoney", type: "BNPL" },
      { id: "simpl", name: "Simpl", type: "BNPL" },
      { id: "lazypay", name: "LazyPay", type: "BNPL" },
      { id: "flexmoney", name: "FlexMoney", type: "BNPL" },
    ],
  },
  qr: {
    name: "QR Code",
    icon: QrCode,
    subChannels: [
      { id: "bharat_qr", name: "Bharat QR", type: "Interoperable" },
      { id: "upi_qr", name: "UPI QR", type: "Interoperable" },
      { id: "paytm_qr", name: "Paytm QR", type: "Proprietary" },
      { id: "phonepe_qr", name: "PhonePe QR", type: "Proprietary" },
      { id: "gpay_qr", name: "Google Pay QR", type: "Proprietary" },
    ],
  },
  bankTransfer: {
    name: "Bank Transfer",
    icon: Building,
    subChannels: [
      { id: "neft", name: "NEFT", type: "Transfer" },
      { id: "rtgs", name: "RTGS", type: "Transfer" },
      { id: "imps", name: "IMPS", type: "Transfer" },
      { id: "vpa", name: "Virtual Account (VPA)", type: "Transfer" },
      { id: "challan", name: "Challan/Deposit Slip", type: "Offline" },
    ],
  },
}

// Mock gateway data with channel-wise configuration
const gatewayChannelConfig = {
  Razorpay: {
    cards: {
      enabled: true,
      channels: {
        visa: { enabled: true, buyRate: 1.8, sellRate: 2.2, volume: 450000, txns: 180 },
        mastercard: { enabled: true, buyRate: 1.8, sellRate: 2.2, volume: 320000, txns: 145 },
        rupay: { enabled: true, buyRate: 0.6, sellRate: 1.0, volume: 280000, txns: 220 },
        amex: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        diners: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        discover: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        maestro: { enabled: true, buyRate: 0.6, sellRate: 1.0, volume: 85000, txns: 65 },
        jcb: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
      },
      feeBearing: "customer" as const,
      partnerCommission: 0.15,
    },
    netBanking: {
      enabled: true,
      channels: {
        sbi: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 520000, txns: 125 },
        hdfc: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 380000, txns: 95 },
        icici: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 290000, txns: 72 },
        axis: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 185000, txns: 46 },
        kotak: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 145000, txns: 36 },
        yes: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        idbi: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 78000, txns: 20 },
        bob: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 92000, txns: 23 },
        pnb: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 156000, txns: 39 },
        canara: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 67000, txns: 17 },
        union: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 45000, txns: 11 },
        indian: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        boi: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 34000, txns: 9 },
        central: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        iob: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        uco: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        psb: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        bandhan: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 28000, txns: 7 },
        rbl: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        federal: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 21000, txns: 5 },
        idfc: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 38000, txns: 10 },
        indusind: { enabled: true, buyRate: 1.5, sellRate: 1.8, volume: 52000, txns: 13 },
        au: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        equitas: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        ujjivan: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        jana: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        karnataka: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        south: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        karur: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        tamilnad: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        csb: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        dcb: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        jk: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        city: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        nainital: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        dhanlaxmi: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        lakshmi: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        saraswat: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        cosmos: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        tjsb: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        akola: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        bassein: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        bharat: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        gp: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        janata: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        kalyan: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        mehsana: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        nkgsb: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        shamrao: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        thane: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
        zoroastrian: { enabled: false, buyRate: 1.5, sellRate: 1.8, volume: 0, txns: 0 },
      },
      feeBearing: "customer" as const,
      partnerCommission: 0.12,
    },
    upi: {
      enabled: true,
      channels: {
        gpay: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 680000, txns: 850 },
        phonepe: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 520000, txns: 650 },
        paytm_upi: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 245000, txns: 306 },
        bhim: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 125000, txns: 156 },
        amazon_pay: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 98000, txns: 123 },
        whatsapp: { enabled: false, buyRate: 0.25, sellRate: 0.5, volume: 0, txns: 0 },
        cred: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 78000, txns: 98 },
        mobikwik_upi: { enabled: false, buyRate: 0.25, sellRate: 0.5, volume: 0, txns: 0 },
        freecharge_upi: { enabled: false, buyRate: 0.25, sellRate: 0.5, volume: 0, txns: 0 },
        airtel_upi: { enabled: false, buyRate: 0.25, sellRate: 0.5, volume: 0, txns: 0 },
        sbi_yono: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 156000, txns: 195 },
        hdfc_upi: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 134000, txns: 168 },
        icici_imobile: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 112000, txns: 140 },
        axis_upi: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 89000, txns: 111 },
        kotak_upi: { enabled: true, buyRate: 0.25, sellRate: 0.5, volume: 67000, txns: 84 },
      },
      feeBearing: "merchant" as const,
      partnerCommission: 0.08,
    },
    wallets: {
      enabled: true,
      channels: {
        paytm: { enabled: true, buyRate: 1.2, sellRate: 1.5, volume: 125000, txns: 62 },
        phonepe_wallet: { enabled: true, buyRate: 1.2, sellRate: 1.5, volume: 89000, txns: 45 },
        amazon_wallet: { enabled: true, buyRate: 1.2, sellRate: 1.5, volume: 67000, txns: 34 },
        mobikwik: { enabled: true, buyRate: 1.2, sellRate: 1.5, volume: 34000, txns: 17 },
        freecharge: { enabled: false, buyRate: 1.2, sellRate: 1.5, volume: 0, txns: 0 },
        airtel: { enabled: false, buyRate: 1.2, sellRate: 1.5, volume: 0, txns: 0 },
        jio: { enabled: false, buyRate: 1.2, sellRate: 1.5, volume: 0, txns: 0 },
        ola: { enabled: false, buyRate: 1.2, sellRate: 1.5, volume: 0, txns: 0 },
        oxigen: { enabled: false, buyRate: 1.2, sellRate: 1.5, volume: 0, txns: 0 },
        itzcash: { enabled: false, buyRate: 1.2, sellRate: 1.5, volume: 0, txns: 0 },
      },
      feeBearing: "customer" as const,
      partnerCommission: 0.1,
    },
    emi: {
      enabled: false,
      channels: {
        hdfc_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        icici_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        sbi_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        axis_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        kotak_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        yes_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        rbl_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        indusind_emi: { enabled: false, buyRate: 2.5, sellRate: 3.0, volume: 0, txns: 0 },
        bajaj: { enabled: false, buyRate: 2.0, sellRate: 2.5, volume: 0, txns: 0 },
        zestmoney: { enabled: false, buyRate: 2.0, sellRate: 2.5, volume: 0, txns: 0 },
        simpl: { enabled: false, buyRate: 2.0, sellRate: 2.5, volume: 0, txns: 0 },
        lazypay: { enabled: false, buyRate: 2.0, sellRate: 2.5, volume: 0, txns: 0 },
        flexmoney: { enabled: false, buyRate: 2.0, sellRate: 2.5, volume: 0, txns: 0 },
      },
      feeBearing: "customer" as const,
      partnerCommission: 0.2,
    },
    qr: {
      enabled: true,
      channels: {
        bharat_qr: { enabled: true, buyRate: 0.2, sellRate: 0.4, volume: 89000, txns: 178 },
        upi_qr: { enabled: true, buyRate: 0.2, sellRate: 0.4, volume: 156000, txns: 312 },
        paytm_qr: { enabled: false, buyRate: 0.2, sellRate: 0.4, volume: 0, txns: 0 },
        phonepe_qr: { enabled: false, buyRate: 0.2, sellRate: 0.4, volume: 0, txns: 0 },
        gpay_qr: { enabled: false, buyRate: 0.2, sellRate: 0.4, volume: 0, txns: 0 },
      },
      feeBearing: "merchant" as const,
      partnerCommission: 0.05,
    },
    bankTransfer: {
      enabled: true,
      channels: {
        neft: { enabled: true, buyRate: 0.0, sellRate: 5.0, volume: 450000, txns: 12 },
        rtgs: { enabled: true, buyRate: 0.0, sellRate: 10.0, volume: 1200000, txns: 4 },
        imps: { enabled: true, buyRate: 0.0, sellRate: 2.5, volume: 180000, txns: 36 },
        vpa: { enabled: true, buyRate: 0.0, sellRate: 0.0, volume: 890000, txns: 45 },
        challan: { enabled: true, buyRate: 0.0, sellRate: 0.0, volume: 560000, txns: 28 },
      },
      feeBearing: "customer" as const,
      partnerCommission: 0.0,
    },
  },
  Cashfree: {
    upi: {
      enabled: true,
      channels: {
        gpay: { enabled: true, buyRate: 0.2, sellRate: 0.45, volume: 320000, txns: 400 },
        phonepe: { enabled: true, buyRate: 0.2, sellRate: 0.45, volume: 280000, txns: 350 },
        paytm_upi: { enabled: true, buyRate: 0.2, sellRate: 0.45, volume: 145000, txns: 181 },
        bhim: { enabled: true, buyRate: 0.2, sellRate: 0.45, volume: 89000, txns: 111 },
        amazon_pay: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
        whatsapp: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
        cred: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
        mobikwik_upi: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
        freecharge_upi: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
        airtel_upi: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
        sbi_yono: { enabled: true, buyRate: 0.2, sellRate: 0.45, volume: 78000, txns: 98 },
        hdfc_upi: { enabled: true, buyRate: 0.2, sellRate: 0.45, volume: 67000, txns: 84 },
        icici_imobile: { enabled: true, buyRate: 0.2, sellRate: 0.45, volume: 56000, txns: 70 },
        axis_upi: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
        kotak_upi: { enabled: false, buyRate: 0.2, sellRate: 0.45, volume: 0, txns: 0 },
      },
      feeBearing: "merchant" as const,
      partnerCommission: 0.06,
    },
    qr: {
      enabled: true,
      channels: {
        bharat_qr: { enabled: true, buyRate: 0.15, sellRate: 0.35, volume: 67000, txns: 134 },
        upi_qr: { enabled: true, buyRate: 0.15, sellRate: 0.35, volume: 123000, txns: 246 },
        paytm_qr: { enabled: false, buyRate: 0.15, sellRate: 0.35, volume: 0, txns: 0 },
        phonepe_qr: { enabled: false, buyRate: 0.15, sellRate: 0.35, volume: 0, txns: 0 },
        gpay_qr: { enabled: false, buyRate: 0.15, sellRate: 0.35, volume: 0, txns: 0 },
      },
      feeBearing: "merchant" as const,
      partnerCommission: 0.04,
    },
  },
  Paytm: {
    wallets: {
      enabled: true,
      channels: {
        paytm: { enabled: true, buyRate: 1.0, sellRate: 1.4, volume: 234000, txns: 117 },
        phonepe_wallet: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        amazon_wallet: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        mobikwik: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        freecharge: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        airtel: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        jio: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        ola: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        oxigen: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
        itzcash: { enabled: false, buyRate: 1.0, sellRate: 1.4, volume: 0, txns: 0 },
      },
      feeBearing: "customer" as const,
      partnerCommission: 0.08,
    },
    upi: {
      enabled: true,
      channels: {
        gpay: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        phonepe: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        paytm_upi: { enabled: true, buyRate: 0.22, sellRate: 0.48, volume: 189000, txns: 236 },
        bhim: { enabled: true, buyRate: 0.22, sellRate: 0.48, volume: 56000, txns: 70 },
        amazon_pay: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        whatsapp: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        cred: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        mobikwik_upi: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        freecharge_upi: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        airtel_upi: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        sbi_yono: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        hdfc_upi: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        icici_imobile: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        axis_upi: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
        kotak_upi: { enabled: false, buyRate: 0.22, sellRate: 0.48, volume: 0, txns: 0 },
      },
      feeBearing: "merchant" as const,
      partnerCommission: 0.06,
    },
  },
}

export function InstituteDetailModal({ instituteId, open, onClose }: InstituteDetailModalProps) {
  const [periodFilter, setPeriodFilter] = useState("month")
  const [showCommercialRequest, setShowCommercialRequest] = useState(false)
  const [selectedGateway, setSelectedGateway] = useState("Razorpay")
  const [expandedModes, setExpandedModes] = useState<string[]>(["cards", "netBanking", "upi"])
  const [channelSearch, setChannelSearch] = useState("")
  const [showOnlyActive, setShowOnlyActive] = useState(false)

  // Mock institute data
  const institute = {
    id: instituteId,
    name: "Delhi Public School",
    location: "New Delhi",
    type: "School",
    email: "finance@dpsdelhi.edu.in",
    phone: "+91 98765 43210",
    onboardingStage: "live" as const,
    onboardedDate: "2023-06-15",
    activatedDate: "2023-06-20",
    liveDate: "2023-06-25",
    referralPartner: {
      name: "EduConnect Partners",
      email: "admin@educonnect.com",
      commissionRate: 5,
    },
    terminals: [
      { type: "POS", count: 5, online: 4, model: "Pine Labs" },
      { type: "QR", count: 10, online: 10, model: "Static QR" },
    ],
    revenue: {
      day: { volume: 125000, transactions: 62, revenue: 2875, trend: 12 },
      week: { volume: 875000, transactions: 437, revenue: 20125, trend: 8 },
      month: { volume: 2500000, transactions: 1250, revenue: 57500, trend: 15 },
      year: { volume: 12000000, transactions: 6000, revenue: 276000, trend: 22 },
    },
  }

  const currentRevenue = institute.revenue[periodFilter as keyof typeof institute.revenue]
  const currentGatewayConfig = gatewayChannelConfig[selectedGateway as keyof typeof gatewayChannelConfig]

  const stageColors = {
    onboarded: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    activated: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    live: "bg-success/10 text-success border-success/20",
  }

  const toggleMode = (modeKey: string) => {
    setExpandedModes((prev) => (prev.includes(modeKey) ? prev.filter((m) => m !== modeKey) : [...prev, modeKey]))
  }

  const getChannelStats = (modeKey: string) => {
    const modeConfig = currentGatewayConfig?.[modeKey as keyof typeof currentGatewayConfig]
    if (!modeConfig || !("channels" in modeConfig)) return { total: 0, active: 0, volume: 0, txns: 0 }

    const channels = modeConfig.channels as Record<string, { enabled: boolean; volume: number; txns: number }>
    const total = Object.keys(channels).length
    const active = Object.values(channels).filter((c) => c.enabled).length
    const volume = Object.values(channels).reduce((sum, c) => sum + (c.volume || 0), 0)
    const txns = Object.values(channels).reduce((sum, c) => sum + (c.txns || 0), 0)

    return { total, active, volume, txns }
  }

  const filterChannels = (
    channels: Record<string, { enabled: boolean; buyRate: number; sellRate: number; volume: number; txns: number }>,
    subChannels: { id: string; name: string; type: string }[],
  ) => {
    return subChannels.filter((sc) => {
      const channel = channels[sc.id]
      if (!channel) return false
      if (showOnlyActive && !channel.enabled) return false
      if (channelSearch && !sc.name.toLowerCase().includes(channelSearch.toLowerCase())) return false
      return true
    })
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden bg-background flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <DialogTitle className="text-xl">{institute.name}</DialogTitle>
                <p className="text-sm text-muted-foreground">
                  {institute.id} • {institute.location} • {institute.type}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={stageColors[institute.onboardingStage]}>
                <Zap className="h-3 w-3 mr-1" />
                {institute.onboardingStage.toUpperCase()}
              </Badge>
              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                <ExternalLink className="h-3 w-3" />
                Login as Merchant
              </Button>
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="overview" className="flex-1 flex flex-col overflow-hidden mt-4">
          <TabsList className="bg-secondary flex-shrink-0">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="channels">Payment Channels</TabsTrigger>
            <TabsTrigger value="commercials">Commercials</TabsTrigger>
            <TabsTrigger value="revenue">Revenue Analytics</TabsTrigger>
            <TabsTrigger value="terminals">Terminals</TabsTrigger>
            <TabsTrigger value="referral">Referral</TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4">
            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4 m-0">
              <div className="grid gap-4 md:grid-cols-3">
                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-2">
                      <Calendar className="h-4 w-4" />
                      <span className="text-sm">Onboarding Timeline</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-amber-500" />
                        <span className="text-xs">Onboarded: {institute.onboardedDate}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-blue-500" />
                        <span className="text-xs">Activated: {institute.activatedDate}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-2 rounded-full bg-success" />
                        <span className="text-xs">Live: {institute.liveDate}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-2">
                      <CreditCard className="h-4 w-4" />
                      <span className="text-sm">Active Gateways</span>
                    </div>
                    <div className="space-y-2">
                      {Object.keys(gatewayChannelConfig).map((gw) => {
                        const config = gatewayChannelConfig[gw as keyof typeof gatewayChannelConfig]
                        const enabledModes = Object.values(config).filter((m: any) => m.enabled).length
                        const totalModes = Object.keys(config).length
                        return (
                          <div key={gw} className="flex items-center justify-between">
                            <span className="text-sm font-medium">{gw}</span>
                            <span className="text-xs text-muted-foreground">
                              {enabledModes}/{totalModes} modes
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-2">
                      <TrendingUp className="h-4 w-4" />
                      <span className="text-sm">This Month</span>
                    </div>
                    <div className="space-y-1">
                      <p className="text-2xl font-bold">₹{(institute.revenue.month.volume / 100000).toFixed(2)}L</p>
                      <p className="text-xs text-muted-foreground">
                        {institute.revenue.month.transactions} transactions
                      </p>
                      <div className="flex items-center gap-1 text-success text-xs">
                        <ArrowUpRight className="h-3 w-3" />
                        {institute.revenue.month.trend}% vs last month
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Gateway Summary */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Gateway & Channel Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-3">
                    {Object.entries(gatewayChannelConfig).map(([gateway, config]) => {
                      let totalVolume = 0
                      let totalTxns = 0
                      let activeChannels = 0
                      let totalChannels = 0

                      Object.values(config).forEach((mode: any) => {
                        if (mode.channels) {
                          Object.values(mode.channels).forEach((ch: any) => {
                            totalChannels++
                            if (ch.enabled) {
                              activeChannels++
                              totalVolume += ch.volume || 0
                              totalTxns += ch.txns || 0
                            }
                          })
                        }
                      })

                      return (
                        <div key={gateway} className="p-3 rounded-lg bg-secondary/50">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">{gateway}</span>
                            <Badge variant="outline" className="bg-success/10 text-success text-xs">
                              Active
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <p className="text-muted-foreground">Volume</p>
                              <p className="font-medium">₹{(totalVolume / 100000).toFixed(2)}L</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Transactions</p>
                              <p className="font-medium">{totalTxns.toLocaleString()}</p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Channels</p>
                              <p className="font-medium">
                                {activeChannels}/{totalChannels}
                              </p>
                            </div>
                            <div>
                              <p className="text-muted-foreground">Modes</p>
                              <p className="font-medium">{Object.keys(config).length}</p>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payment Channels Tab - NEW GRANULAR VIEW */}
            <TabsContent value="channels" className="space-y-4 m-0">
              {/* Gateway Selector & Filters */}
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2">
                  <Label className="text-sm">Gateway:</Label>
                  <Select value={selectedGateway} onValueChange={setSelectedGateway}>
                    <SelectTrigger className="w-[180px] bg-secondary">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(gatewayChannelConfig).map((gw) => (
                        <SelectItem key={gw} value={gw}>
                          {gw}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="relative flex-1 max-w-xs">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search channels..."
                    value={channelSearch}
                    onChange={(e) => setChannelSearch(e.target.value)}
                    className="pl-9 bg-secondary"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="activeOnly"
                    checked={showOnlyActive}
                    onCheckedChange={(checked) => setShowOnlyActive(checked as boolean)}
                  />
                  <Label htmlFor="activeOnly" className="text-sm cursor-pointer">
                    Show Active Only
                  </Label>
                </div>

                <Button variant="outline" size="sm" className="gap-2 ml-auto bg-transparent">
                  <Download className="h-4 w-4" />
                  Export Config
                </Button>
              </div>

              {/* Channel Stats Summary */}
              <div className="grid gap-3 grid-cols-2 md:grid-cols-4 lg:grid-cols-7">
                {Object.entries(paymentChannelsData).map(([key, mode]) => {
                  const stats = getChannelStats(key)
                  const Icon = mode.icon
                  const modeConfig = currentGatewayConfig?.[key as keyof typeof currentGatewayConfig]
                  const isEnabled = modeConfig && "enabled" in modeConfig ? modeConfig.enabled : false

                  return (
                    <Card
                      key={key}
                      className={`bg-card border-border cursor-pointer transition-colors ${isEnabled ? "hover:border-primary/50" : "opacity-50"}`}
                      onClick={() => isEnabled && toggleMode(key)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <Icon className="h-4 w-4 text-primary" />
                          <span className="text-xs font-medium truncate">{mode.name}</span>
                          {isEnabled ? (
                            <CheckCircle2 className="h-3 w-3 text-success ml-auto" />
                          ) : (
                            <XCircle className="h-3 w-3 text-muted-foreground ml-auto" />
                          )}
                        </div>
                        <div className="text-lg font-bold">
                          {stats.active}/{stats.total}
                        </div>
                        <div className="text-[10px] text-muted-foreground">
                          ₹{(stats.volume / 100000).toFixed(1)}L • {stats.txns} txns
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>

              {/* Expanded Channel Details */}
              <div className="space-y-3">
                {Object.entries(paymentChannelsData).map(([modeKey, mode]) => {
                  const modeConfig = currentGatewayConfig?.[modeKey as keyof typeof currentGatewayConfig]
                  if (!modeConfig || !("channels" in modeConfig)) return null

                  const channels = modeConfig.channels as Record<
                    string,
                    { enabled: boolean; buyRate: number; sellRate: number; volume: number; txns: number }
                  >
                  const filteredChannels = filterChannels(channels, mode.subChannels)
                  const Icon = mode.icon
                  const isExpanded = expandedModes.includes(modeKey)

                  return (
                    <Collapsible key={modeKey} open={isExpanded} onOpenChange={() => toggleMode(modeKey)}>
                      <Card className="bg-card border-border">
                        <CollapsibleTrigger asChild>
                          <CardHeader className="cursor-pointer hover:bg-secondary/30 transition-colors py-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                {isExpanded ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                                <Icon className="h-5 w-5 text-primary" />
                                <div>
                                  <CardTitle className="text-base">{mode.name}</CardTitle>
                                  <p className="text-xs text-muted-foreground">
                                    {filteredChannels.filter((c) => channels[c.id]?.enabled).length} of{" "}
                                    {mode.subChannels.length} channels active
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center gap-4">
                                <div className="text-right">
                                  <p className="text-sm font-medium">
                                    Buy: {(modeConfig as any).channels[mode.subChannels[0]?.id]?.buyRate || 0}%
                                  </p>
                                  <p className="text-xs text-muted-foreground">Base Rate</p>
                                </div>
                                <div className="text-right">
                                  <p className="text-sm font-medium">
                                    Sell: {(modeConfig as any).channels[mode.subChannels[0]?.id]?.sellRate || 0}%
                                  </p>
                                  <p className="text-xs text-muted-foreground">Customer Rate</p>
                                </div>
                                <Badge
                                  variant="outline"
                                  className={
                                    (modeConfig as any).feeBearing === "customer"
                                      ? "bg-blue-500/10 text-blue-500"
                                      : (modeConfig as any).feeBearing === "merchant"
                                        ? "bg-purple-500/10 text-purple-500"
                                        : "bg-amber-500/10 text-amber-500"
                                  }
                                >
                                  {(modeConfig as any).feeBearing}
                                </Badge>
                                <Switch checked={(modeConfig as any).enabled} />
                              </div>
                            </div>
                          </CardHeader>
                        </CollapsibleTrigger>

                        <CollapsibleContent>
                          <CardContent className="pt-0">
                            <ScrollArea className="h-[400px]">
                              <table className="w-full">
                                <thead className="sticky top-0 bg-card z-10">
                                  <tr className="border-b border-border">
                                    <th className="p-2 text-left text-xs font-medium uppercase text-muted-foreground w-8">
                                      #
                                    </th>
                                    <th className="p-2 text-left text-xs font-medium uppercase text-muted-foreground">
                                      Channel
                                    </th>
                                    <th className="p-2 text-left text-xs font-medium uppercase text-muted-foreground">
                                      Type
                                    </th>
                                    <th className="p-2 text-center text-xs font-medium uppercase text-muted-foreground">
                                      Status
                                    </th>
                                    <th className="p-2 text-right text-xs font-medium uppercase text-muted-foreground">
                                      Buy Rate
                                    </th>
                                    <th className="p-2 text-right text-xs font-medium uppercase text-muted-foreground">
                                      Sell Rate
                                    </th>
                                    <th className="p-2 text-right text-xs font-medium uppercase text-muted-foreground">
                                      Margin
                                    </th>
                                    <th className="p-2 text-right text-xs font-medium uppercase text-muted-foreground">
                                      Volume
                                    </th>
                                    <th className="p-2 text-right text-xs font-medium uppercase text-muted-foreground">
                                      Txns
                                    </th>
                                    <th className="p-2 text-center text-xs font-medium uppercase text-muted-foreground">
                                      Action
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {filteredChannels.map((subChannel, idx) => {
                                    const channel = channels[subChannel.id]
                                    if (!channel) return null

                                    return (
                                      <tr
                                        key={subChannel.id}
                                        className={`border-b border-border/50 hover:bg-secondary/30 ${!channel.enabled ? "opacity-50" : ""}`}
                                      >
                                        <td className="p-2 text-xs text-muted-foreground">{idx + 1}</td>
                                        <td className="p-2">
                                          <span className="text-sm font-medium">{subChannel.name}</span>
                                        </td>
                                        <td className="p-2">
                                          <Badge variant="outline" className="text-xs">
                                            {subChannel.type}
                                          </Badge>
                                        </td>
                                        <td className="p-2 text-center">
                                          <Switch checked={channel.enabled} />
                                        </td>
                                        <td className="p-2 text-right text-sm text-muted-foreground">
                                          {channel.buyRate}%
                                        </td>
                                        <td className="p-2 text-right text-sm font-medium">{channel.sellRate}%</td>
                                        <td className="p-2 text-right text-sm text-success">
                                          {(channel.sellRate - channel.buyRate).toFixed(2)}%
                                        </td>
                                        <td className="p-2 text-right text-sm">
                                          {channel.volume > 0 ? `₹${(channel.volume / 1000).toFixed(0)}K` : "-"}
                                        </td>
                                        <td className="p-2 text-right text-sm">
                                          {channel.txns > 0 ? channel.txns : "-"}
                                        </td>
                                        <td className="p-2 text-center">
                                          <Button variant="ghost" size="sm" className="h-7 text-xs">
                                            Edit
                                          </Button>
                                        </td>
                                      </tr>
                                    )
                                  })}
                                </tbody>
                              </table>
                            </ScrollArea>
                          </CardContent>
                        </CollapsibleContent>
                      </Card>
                    </Collapsible>
                  )
                })}
              </div>
            </TabsContent>

            {/* Commercials Tab - Summary View */}
            <TabsContent value="commercials" className="space-y-4 m-0">
              {/* Fee Bearing Legend */}
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex flex-wrap items-center gap-4">
                    <span className="text-sm font-medium">Fee Bearing:</span>
                    <div className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full bg-blue-500" />
                      <span className="text-xs">Customer Pays</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full bg-purple-500" />
                      <span className="text-xs">Merchant Pays</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full bg-amber-500" />
                      <span className="text-xs">Split</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="ml-auto gap-2 bg-transparent"
                      onClick={() => setShowCommercialRequest(true)}
                    >
                      <Send className="h-3 w-3" />
                      Request Rate Change
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Gateway-wise Commercial Summary */}
              {Object.entries(gatewayChannelConfig).map(([gateway, config]) => (
                <Card key={gateway} className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base font-semibold">{gateway}</CardTitle>
                      <Badge variant="outline" className="bg-success/10 text-success">
                        Active
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-border">
                            <th className="p-3 text-left text-xs font-medium uppercase text-muted-foreground">Mode</th>
                            <th className="p-3 text-center text-xs font-medium uppercase text-muted-foreground">
                              Channels
                            </th>
                            <th className="p-3 text-center text-xs font-medium uppercase text-muted-foreground">
                              Status
                            </th>
                            <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">
                              Avg Buy Rate
                            </th>
                            <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">
                              Avg Sell Rate
                            </th>
                            <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">
                              Avg Margin
                            </th>
                            <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">
                              Partner Commission
                            </th>
                            <th className="p-3 text-center text-xs font-medium uppercase text-muted-foreground">
                              Fee Bearing
                            </th>
                            <th className="p-3 text-right text-xs font-medium uppercase text-muted-foreground">
                              Volume
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {Object.entries(config).map(([modeKey, modeConfig]) => {
                            const modeData = paymentChannelsData[modeKey as keyof typeof paymentChannelsData]
                            if (!modeData) return null

                            const channels = (modeConfig as any).channels
                            const activeChannels = Object.values(channels).filter((c: any) => c.enabled).length
                            const totalChannels = Object.keys(channels).length
                            const volume = Object.values(channels).reduce(
                              (sum: number, c: any) => sum + (c.volume || 0),
                              0,
                            )

                            // Calculate average rates from first channel (they're typically the same)
                            const firstChannel = Object.values(channels)[0] as any
                            const Icon = modeData.icon

                            return (
                              <tr key={modeKey} className="border-b border-border hover:bg-secondary/30">
                                <td className="p-3">
                                  <div className="flex items-center gap-2">
                                    <Icon className="h-4 w-4 text-primary" />
                                    <span className="font-medium">{modeData.name}</span>
                                  </div>
                                </td>
                                <td className="p-3 text-center">
                                  <span className="text-sm">
                                    {activeChannels}/{totalChannels}
                                  </span>
                                </td>
                                <td className="p-3 text-center">
                                  <Switch checked={(modeConfig as any).enabled} />
                                </td>
                                <td className="p-3 text-right text-sm text-muted-foreground">
                                  {firstChannel?.buyRate}%
                                </td>
                                <td className="p-3 text-right text-sm font-medium">{firstChannel?.sellRate}%</td>
                                <td className="p-3 text-right text-sm text-success">
                                  {(firstChannel?.sellRate - firstChannel?.buyRate).toFixed(2)}%
                                </td>
                                <td className="p-3 text-right text-sm text-blue-400">
                                  {(modeConfig as any).partnerCommission}%
                                </td>
                                <td className="p-3 text-center">
                                  <Badge
                                    variant="outline"
                                    className={
                                      (modeConfig as any).feeBearing === "customer"
                                        ? "bg-blue-500/10 text-blue-500 border-blue-500/20"
                                        : (modeConfig as any).feeBearing === "merchant"
                                          ? "bg-purple-500/10 text-purple-500 border-purple-500/20"
                                          : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                                    }
                                  >
                                    {(modeConfig as any).feeBearing}
                                  </Badge>
                                </td>
                                <td className="p-3 text-right text-sm">₹{(volume / 100000).toFixed(2)}L</td>
                              </tr>
                            )
                          })}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Commercial Change Request Form */}
              {showCommercialRequest && (
                <Card className="bg-card border-border border-primary/50">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-semibold">Request Commercial Change</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-4">
                      <div>
                        <Label>Gateway</Label>
                        <Select>
                          <SelectTrigger className="bg-secondary">
                            <SelectValue placeholder="Select gateway" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.keys(gatewayChannelConfig).map((gw) => (
                              <SelectItem key={gw} value={gw}>
                                {gw}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Payment Mode</Label>
                        <Select>
                          <SelectTrigger className="bg-secondary">
                            <SelectValue placeholder="Select mode" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.entries(paymentChannelsData).map(([key, mode]) => (
                              <SelectItem key={key} value={key}>
                                {mode.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Channel (Optional)</Label>
                        <Select>
                          <SelectTrigger className="bg-secondary">
                            <SelectValue placeholder="All channels" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">All Channels</SelectItem>
                            <SelectItem value="visa">Visa</SelectItem>
                            <SelectItem value="mastercard">Mastercard</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label>Request Type</Label>
                        <Select>
                          <SelectTrigger className="bg-secondary">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="rate">Rate Change</SelectItem>
                            <SelectItem value="bearing">Fee Bearing Change</SelectItem>
                            <SelectItem value="enable">Enable Channel</SelectItem>
                            <SelectItem value="commission">Partner Commission</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid gap-4 md:grid-cols-3">
                      <div>
                        <Label>Current Sell Rate</Label>
                        <Input type="text" value="2.2%" disabled className="bg-secondary" />
                      </div>
                      <div>
                        <Label>Requested Sell Rate (%)</Label>
                        <Input type="number" step="0.1" placeholder="Enter new rate" className="bg-secondary" />
                      </div>
                      <div>
                        <Label>Reason</Label>
                        <Input placeholder="Enter reason for change" className="bg-secondary" />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button className="gap-2">
                        <Send className="h-4 w-4" />
                        Submit Request
                      </Button>
                      <Button variant="outline" onClick={() => setShowCommercialRequest(false)}>
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Revenue Analytics Tab */}
            <TabsContent value="revenue" className="space-y-4 m-0">
              {/* Period Filter */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Period:</span>
                <div className="flex gap-1">
                  {["day", "week", "month", "year"].map((p) => (
                    <Button
                      key={p}
                      variant={periodFilter === p ? "default" : "outline"}
                      size="sm"
                      onClick={() => setPeriodFilter(p)}
                      className={periodFilter === p ? "" : "bg-transparent"}
                    >
                      {p.charAt(0).toUpperCase() + p.slice(1)}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Revenue Stats */}
              <div className="grid gap-4 md:grid-cols-4">
                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <IndianRupee className="h-4 w-4" />
                      <span className="text-xs">Volume</span>
                    </div>
                    <p className="text-2xl font-bold">₹{(currentRevenue.volume / 100000).toFixed(2)}L</p>
                    <div className="flex items-center gap-1 text-success text-xs mt-1">
                      <ArrowUpRight className="h-3 w-3" />
                      {currentRevenue.trend}% vs previous
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Users className="h-4 w-4" />
                      <span className="text-xs">Transactions</span>
                    </div>
                    <p className="text-2xl font-bold">{currentRevenue.transactions.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Avg: ₹{(currentRevenue.volume / currentRevenue.transactions).toFixed(0)}
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Percent className="h-4 w-4" />
                      <span className="text-xs">Your Revenue</span>
                    </div>
                    <p className="text-2xl font-bold text-success">₹{currentRevenue.revenue.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {((currentRevenue.revenue / currentRevenue.volume) * 100).toFixed(2)}% of volume
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <BarChart3 className="h-4 w-4" />
                      <span className="text-xs">Partner Commission</span>
                    </div>
                    <p className="text-2xl font-bold text-blue-400">
                      ₹{(currentRevenue.revenue * 0.15).toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">15% of revenue</p>
                  </CardContent>
                </Card>
              </div>

              {/* Revenue by Mode & Gateway */}
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Revenue by Payment Mode</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Object.entries(paymentChannelsData)
                        .slice(0, 5)
                        .map(([key, mode]) => {
                          const stats = getChannelStats(key)
                          const Icon = mode.icon
                          const percentage = stats.volume > 0 ? (stats.volume / currentRevenue.volume) * 100 : 0

                          return (
                            <div key={key} className="space-y-1">
                              <div className="flex items-center justify-between text-sm">
                                <div className="flex items-center gap-2">
                                  <Icon className="h-4 w-4 text-primary" />
                                  <span>{mode.name}</span>
                                </div>
                                <span className="font-medium">₹{(stats.volume / 100000).toFixed(2)}L</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Progress value={percentage} className="h-2 flex-1" />
                                <span className="text-xs text-muted-foreground w-12 text-right">
                                  {percentage.toFixed(1)}%
                                </span>
                              </div>
                            </div>
                          )
                        })}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Revenue by Gateway</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {Object.entries(gatewayChannelConfig).map(([gateway, config]) => {
                        let totalVolume = 0
                        Object.values(config).forEach((mode: any) => {
                          if (mode.channels) {
                            Object.values(mode.channels).forEach((ch: any) => {
                              if (ch.enabled) totalVolume += ch.volume || 0
                            })
                          }
                        })

                        const percentage = totalVolume > 0 ? (totalVolume / currentRevenue.volume) * 100 : 0

                        return (
                          <div key={gateway} className="space-y-1">
                            <div className="flex items-center justify-between text-sm">
                              <span>{gateway}</span>
                              <span className="font-medium">₹{(totalVolume / 100000).toFixed(2)}L</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Progress value={percentage} className="h-2 flex-1" />
                              <span className="text-xs text-muted-foreground w-12 text-right">
                                {percentage.toFixed(1)}%
                              </span>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Terminals Tab */}
            <TabsContent value="terminals" className="space-y-4 m-0">
              <div className="grid gap-4 md:grid-cols-2">
                {institute.terminals.map((terminal) => (
                  <Card key={terminal.type} className="bg-card border-border">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          {terminal.type === "POS" ? (
                            <CreditCard className="h-5 w-5 text-primary" />
                          ) : (
                            <QrCode className="h-5 w-5 text-primary" />
                          )}
                          <span className="font-medium">{terminal.type} Terminals</span>
                        </div>
                        <Badge variant="outline">{terminal.model}</Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <p className="text-2xl font-bold">{terminal.count}</p>
                          <p className="text-xs text-muted-foreground">Total</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-success">{terminal.online}</p>
                          <p className="text-xs text-muted-foreground">Online</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-destructive">{terminal.count - terminal.online}</p>
                          <p className="text-xs text-muted-foreground">Offline</p>
                        </div>
                      </div>
                      <Progress value={(terminal.online / terminal.count) * 100} className="h-2 mt-4" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Referral Tab */}
            <TabsContent value="referral" className="space-y-4 m-0">
              <Card className="bg-card border-border">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Referral Partner Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">Partner Name</Label>
                      <p className="font-medium">{institute.referralPartner.name}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Email</Label>
                      <p className="font-medium">{institute.referralPartner.email}</p>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Commission Rate</Label>
                      <p className="font-medium text-success">{institute.referralPartner.commissionRate}%</p>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-3 pt-4 border-t border-border">
                    <Card className="bg-secondary/50">
                      <CardContent className="p-3 text-center">
                        <p className="text-xs text-muted-foreground">Total Earnings</p>
                        <p className="text-xl font-bold text-success">
                          ₹
                          {((currentRevenue.revenue * institute.referralPartner.commissionRate) / 100).toLocaleString()}
                        </p>
                      </CardContent>
                    </Card>
                    <Card className="bg-secondary/50">
                      <CardContent className="p-3 text-center">
                        <p className="text-xs text-muted-foreground">Pending Payout</p>
                        <p className="text-xl font-bold text-amber-500">₹12,500</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-secondary/50">
                      <CardContent className="p-3 text-center">
                        <p className="text-xs text-muted-foreground">Last Payout</p>
                        <p className="text-xl font-bold">₹45,000</p>
                        <p className="text-xs text-muted-foreground">Jan 1, 2024</p>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button variant="outline" className="gap-2 bg-transparent">
                      <ExternalLink className="h-4 w-4" />
                      Login as Partner
                    </Button>
                    <Button variant="outline" className="gap-2 bg-transparent">
                      <Send className="h-4 w-4" />
                      Send Payout
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
