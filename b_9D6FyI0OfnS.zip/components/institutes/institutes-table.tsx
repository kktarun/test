"use client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  MoreHorizontal,
  Eye,
  Settings,
  FileText,
  Pause,
  ChevronLeft,
  ChevronRight,
  LogIn,
  CreditCard,
  Wifi,
  WifiOff,
  CheckCircle2,
  Clock,
  Zap,
} from "lucide-react"

interface PaymentMode {
  name: string
  enabled: boolean
  sellRate: number
  buyRate: number
  feeBearing: "customer" | "merchant" | "split"
}

interface Gateway {
  name: string
  status: "active" | "inactive"
  modes: PaymentMode[]
}

interface Terminal {
  type: "POS" | "QR"
  count: number
  online: number
}

interface Institute {
  id: string
  name: string
  location: string
  type: string
  onboardingStage: "onboarded" | "activated" | "live"
  gateways: Gateway[]
  terminals: Terminal[]
  collections: number
  monthlyVolume: number
  transactionCount: number
  status: "active" | "pending" | "suspended"
  onboardedDate: string
  activatedDate?: string
  liveDate?: string
  referralPartner?: string
  paymentFormUrl: string
}

const institutes: Institute[] = [
  {
    id: "INST001",
    name: "Delhi Public School",
    location: "New Delhi",
    type: "School",
    onboardingStage: "live",
    gateways: [
      {
        name: "Razorpay",
        status: "active",
        modes: [
          { name: "Credit Card", enabled: true, sellRate: 2.2, buyRate: 1.8, feeBearing: "customer" },
          { name: "Debit Card", enabled: true, sellRate: 1.5, buyRate: 1.2, feeBearing: "customer" },
          { name: "UPI", enabled: true, sellRate: 0.5, buyRate: 0.3, feeBearing: "merchant" },
          { name: "Net Banking", enabled: true, sellRate: 1.8, buyRate: 1.5, feeBearing: "customer" },
          { name: "EMI", enabled: false, sellRate: 3.0, buyRate: 2.5, feeBearing: "customer" },
        ],
      },
      {
        name: "Cashfree",
        status: "active",
        modes: [
          { name: "UPI", enabled: true, sellRate: 0.4, buyRate: 0.25, feeBearing: "merchant" },
          { name: "QR", enabled: true, sellRate: 0.3, buyRate: 0.2, feeBearing: "merchant" },
        ],
      },
    ],
    terminals: [
      { type: "POS", count: 5, online: 4 },
      { type: "QR", count: 10, online: 10 },
    ],
    collections: 12000000,
    monthlyVolume: 2500000,
    transactionCount: 1250,
    status: "active",
    onboardedDate: "2023-06-15",
    activatedDate: "2023-06-20",
    liveDate: "2023-06-25",
    referralPartner: "EduConnect Partners",
    paymentFormUrl: "/pay/dps-delhi",
  },
  {
    id: "INST002",
    name: "Amity University",
    location: "Noida",
    type: "University",
    onboardingStage: "live",
    gateways: [
      {
        name: "Cashfree",
        status: "active",
        modes: [
          { name: "Credit Card", enabled: true, sellRate: 2.0, buyRate: 1.6, feeBearing: "customer" },
          { name: "UPI", enabled: true, sellRate: 0.45, buyRate: 0.3, feeBearing: "split" },
          { name: "Net Banking", enabled: true, sellRate: 1.6, buyRate: 1.3, feeBearing: "customer" },
        ],
      },
      {
        name: "Paytm",
        status: "active",
        modes: [
          { name: "Wallet", enabled: true, sellRate: 1.5, buyRate: 1.2, feeBearing: "merchant" },
          { name: "UPI", enabled: true, sellRate: 0.5, buyRate: 0.35, feeBearing: "merchant" },
        ],
      },
    ],
    terminals: [
      { type: "POS", count: 8, online: 7 },
      { type: "QR", count: 15, online: 15 },
    ],
    collections: 9800000,
    monthlyVolume: 1800000,
    transactionCount: 980,
    status: "active",
    onboardedDate: "2023-07-20",
    activatedDate: "2023-07-25",
    liveDate: "2023-07-30",
    paymentFormUrl: "/pay/amity-noida",
  },
  {
    id: "INST003",
    name: "St. Mary's College",
    location: "Mumbai",
    type: "College",
    onboardingStage: "activated",
    gateways: [
      {
        name: "Easebuzz",
        status: "active",
        modes: [
          { name: "Credit Card", enabled: true, sellRate: 2.1, buyRate: 1.7, feeBearing: "customer" },
          { name: "UPI", enabled: true, sellRate: 0.5, buyRate: 0.35, feeBearing: "customer" },
        ],
      },
    ],
    terminals: [
      { type: "POS", count: 2, online: 2 },
      { type: "QR", count: 5, online: 5 },
    ],
    collections: 7600000,
    monthlyVolume: 0,
    transactionCount: 0,
    status: "pending",
    onboardedDate: "2023-08-10",
    activatedDate: "2024-01-05",
    paymentFormUrl: "/pay/stmarys-mumbai",
  },
  {
    id: "INST004",
    name: "Ryan International",
    location: "Bangalore",
    type: "School",
    onboardingStage: "live",
    gateways: [
      {
        name: "Paytm",
        status: "active",
        modes: [
          { name: "Credit Card", enabled: true, sellRate: 2.3, buyRate: 1.9, feeBearing: "customer" },
          { name: "Debit Card", enabled: true, sellRate: 1.6, buyRate: 1.3, feeBearing: "customer" },
          { name: "UPI", enabled: true, sellRate: 0.5, buyRate: 0.3, feeBearing: "merchant" },
          { name: "Wallet", enabled: true, sellRate: 1.5, buyRate: 1.2, feeBearing: "merchant" },
        ],
      },
    ],
    terminals: [
      { type: "POS", count: 4, online: 3 },
      { type: "QR", count: 8, online: 8 },
    ],
    collections: 6500000,
    monthlyVolume: 1200000,
    transactionCount: 650,
    status: "active",
    onboardedDate: "2023-09-05",
    activatedDate: "2023-09-10",
    liveDate: "2023-09-15",
    referralPartner: "School Solutions Ltd",
    paymentFormUrl: "/pay/ryan-blr",
  },
  {
    id: "INST005",
    name: "Modern School",
    location: "Lucknow",
    type: "School",
    onboardingStage: "onboarded",
    gateways: [
      {
        name: "Razorpay",
        status: "inactive",
        modes: [
          { name: "Credit Card", enabled: false, sellRate: 2.2, buyRate: 1.8, feeBearing: "customer" },
          { name: "UPI", enabled: false, sellRate: 0.5, buyRate: 0.3, feeBearing: "customer" },
        ],
      },
    ],
    terminals: [],
    collections: 0,
    monthlyVolume: 0,
    transactionCount: 0,
    status: "pending",
    onboardedDate: "2024-01-10",
    paymentFormUrl: "/pay/modern-lko",
  },
  {
    id: "INST006",
    name: "Presidency College",
    location: "Chennai",
    type: "College",
    onboardingStage: "live",
    gateways: [
      {
        name: "NTT Atom",
        status: "inactive",
        modes: [
          { name: "Credit Card", enabled: false, sellRate: 2.0, buyRate: 1.6, feeBearing: "customer" },
          { name: "Debit Card", enabled: false, sellRate: 1.4, buyRate: 1.1, feeBearing: "customer" },
          { name: "UPI", enabled: false, sellRate: 0.45, buyRate: 0.3, feeBearing: "merchant" },
        ],
      },
    ],
    terminals: [
      { type: "POS", count: 3, online: 0 },
      { type: "QR", count: 6, online: 0 },
    ],
    collections: 4200000,
    monthlyVolume: 0,
    transactionCount: 0,
    status: "suspended",
    onboardedDate: "2023-05-20",
    activatedDate: "2023-05-25",
    liveDate: "2023-06-01",
    paymentFormUrl: "/pay/presidency-chennai",
  },
]

const statusColors = {
  active: "bg-success/10 text-success border-success/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  suspended: "bg-destructive/10 text-destructive border-destructive/20",
}

const stageColors = {
  onboarded: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  activated: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  live: "bg-success/10 text-success border-success/20",
}

const stageIcons = {
  onboarded: Clock,
  activated: CheckCircle2,
  live: Zap,
}

interface InstitutesTableProps {
  searchQuery: string
  statusFilter: string
  onboardingFilter: string
  onSelectInstitute: (id: string) => void
}

export function InstitutesTable({
  searchQuery,
  statusFilter,
  onboardingFilter,
  onSelectInstitute,
}: InstitutesTableProps) {
  const filteredInstitutes = institutes.filter((inst) => {
    if (statusFilter !== "all" && inst.status !== statusFilter) return false
    if (onboardingFilter !== "all" && inst.onboardingStage !== onboardingFilter) return false
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        inst.name.toLowerCase().includes(query) ||
        inst.id.toLowerCase().includes(query) ||
        inst.location.toLowerCase().includes(query)
      )
    }
    return true
  })

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">{filteredInstitutes.length} Institutes</CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-secondary/50">
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institute</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Stage</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Gateways & Modes</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Terminals</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">This Month</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInstitutes.map((institute) => {
                const StageIcon = stageIcons[institute.onboardingStage]
                const totalModes = institute.gateways.reduce((acc, g) => acc + g.modes.length, 0)
                const enabledModes = institute.gateways.reduce(
                  (acc, g) => acc + g.modes.filter((m) => m.enabled).length,
                  0,
                )
                const totalTerminals = institute.terminals.reduce((acc, t) => acc + t.count, 0)
                const onlineTerminals = institute.terminals.reduce((acc, t) => acc + t.online, 0)

                return (
                  <tr key={institute.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{institute.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {institute.id} • {institute.location}
                        </p>
                        {institute.referralPartner && (
                          <p className="text-xs text-primary mt-1">Ref: {institute.referralPartner}</p>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            <Badge variant="outline" className={`${stageColors[institute.onboardingStage]} gap-1`}>
                              <StageIcon className="h-3 w-3" />
                              {institute.onboardingStage}
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent>
                            <div className="text-xs space-y-1">
                              <p>Onboarded: {institute.onboardedDate}</p>
                              {institute.activatedDate && <p>Activated: {institute.activatedDate}</p>}
                              {institute.liveDate && <p>Live: {institute.liveDate}</p>}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </td>
                    <td className="p-4">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            <div className="space-y-1">
                              <p className="text-sm font-medium">{institute.gateways.length} Gateways</p>
                              <p className="text-xs text-muted-foreground">
                                {enabledModes}/{totalModes} modes active
                              </p>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent className="max-w-xs">
                            <div className="text-xs space-y-2">
                              {institute.gateways.map((gw) => (
                                <div key={gw.name}>
                                  <p className="font-medium">{gw.name}</p>
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    {gw.modes.map((mode) => (
                                      <span
                                        key={mode.name}
                                        className={`px-1.5 py-0.5 rounded text-xs ${
                                          mode.enabled ? "bg-success/20 text-success" : "bg-muted text-muted-foreground"
                                        }`}
                                      >
                                        {mode.name}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </td>
                    <td className="p-4">
                      {totalTerminals > 0 ? (
                        <div className="flex items-center gap-2">
                          {onlineTerminals === totalTerminals ? (
                            <Wifi className="h-4 w-4 text-success" />
                          ) : onlineTerminals > 0 ? (
                            <Wifi className="h-4 w-4 text-warning" />
                          ) : (
                            <WifiOff className="h-4 w-4 text-destructive" />
                          )}
                          <span className="text-sm">
                            {onlineTerminals}/{totalTerminals}
                          </span>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">No terminals</span>
                      )}
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-semibold">₹{(institute.monthlyVolume / 100000).toFixed(2)}L</p>
                        <p className="text-xs text-muted-foreground">{institute.transactionCount} txns</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline" className={statusColors[institute.status]}>
                        {institute.status}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onSelectInstitute(institute.id)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <CreditCard className="mr-2 h-4 w-4" />
                            Configure Commercials
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Settings className="mr-2 h-4 w-4" />
                            Payment Modes
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            Payment Forms
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <LogIn className="mr-2 h-4 w-4" />
                            Login as Merchant
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-destructive">
                            <Pause className="mr-2 h-4 w-4" />
                            Suspend
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-border p-4">
          <p className="text-sm text-muted-foreground">
            Showing 1 to {filteredInstitutes.length} of {filteredInstitutes.length} institutes
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">Page 1 of 1</span>
            <Button variant="outline" size="sm" disabled>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
