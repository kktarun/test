"use client"

import { useState } from "react"
import { InstituteStats } from "./institute-stats"
import { InstitutesTable } from "./institutes-table"
import { InstituteDetailModal } from "./institute-detail-modal"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Download, Building2, Users, CreditCard } from "lucide-react"

export function InstitutesContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [onboardingFilter, setOnboardingFilter] = useState("all")
  const [selectedInstitute, setSelectedInstitute] = useState<string | null>(null)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Institutes</h1>
          <p className="text-muted-foreground">Manage institutes, commercials, and payment configurations</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Onboard Institute
        </Button>
      </div>

      <InstituteStats />

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="bg-secondary">
          <TabsTrigger value="all" className="gap-2">
            <Building2 className="h-4 w-4" />
            All Institutes
          </TabsTrigger>
          <TabsTrigger value="referrals" className="gap-2">
            <Users className="h-4 w-4" />
            Referral Partners
          </TabsTrigger>
          <TabsTrigger value="pending-commercials" className="gap-2">
            <CreditCard className="h-4 w-4" />
            Pending Commercial Requests
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="relative flex-1 min-w-[250px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search by institute name, ID, or location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-secondary pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-36 bg-secondary">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
            <Select value={onboardingFilter} onValueChange={setOnboardingFilter}>
              <SelectTrigger className="w-44 bg-secondary">
                <SelectValue placeholder="Onboarding Stage" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stages</SelectItem>
                <SelectItem value="onboarded">Onboarded</SelectItem>
                <SelectItem value="activated">Activated</SelectItem>
                <SelectItem value="live">Live</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </div>

          <InstitutesTable
            searchQuery={searchQuery}
            statusFilter={statusFilter}
            onboardingFilter={onboardingFilter}
            onSelectInstitute={setSelectedInstitute}
          />
        </TabsContent>

        <TabsContent value="referrals" className="space-y-4">
          <ReferralPartnersTable onSelectInstitute={setSelectedInstitute} />
        </TabsContent>

        <TabsContent value="pending-commercials" className="space-y-4">
          <PendingCommercialRequests />
        </TabsContent>
      </Tabs>

      {selectedInstitute && (
        <InstituteDetailModal
          instituteId={selectedInstitute}
          open={!!selectedInstitute}
          onClose={() => setSelectedInstitute(null)}
        />
      )}
    </div>
  )
}

// Referral Partners Table Component
function ReferralPartnersTable({ onSelectInstitute }: { onSelectInstitute: (id: string) => void }) {
  const referralPartners = [
    {
      id: "REF001",
      name: "EduConnect Partners",
      email: "admin@educonnect.com",
      institutesReferred: 12,
      activeInstitutes: 10,
      totalRevenue: 2450000,
      commission: 125000,
      status: "active",
    },
    {
      id: "REF002",
      name: "School Solutions Ltd",
      email: "info@schoolsolutions.in",
      institutesReferred: 8,
      activeInstitutes: 7,
      totalRevenue: 1820000,
      commission: 91000,
      status: "active",
    },
    {
      id: "REF003",
      name: "Campus Connect",
      email: "partner@campusconnect.com",
      institutesReferred: 5,
      activeInstitutes: 4,
      totalRevenue: 980000,
      commission: 49000,
      status: "active",
    },
  ]

  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold">Referral Partners</h3>
        <p className="text-sm text-muted-foreground">Partners who have referred institutes to the platform</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-secondary/50">
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Partner</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institutes Referred</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Active</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Total Revenue</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Commission Earned</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {referralPartners.map((partner) => (
              <tr key={partner.id} className="border-b border-border hover:bg-secondary/30">
                <td className="p-4">
                  <div>
                    <p className="font-medium">{partner.name}</p>
                    <p className="text-xs text-muted-foreground">{partner.email}</p>
                  </div>
                </td>
                <td className="p-4 font-medium">{partner.institutesReferred}</td>
                <td className="p-4">
                  <span className="text-success">{partner.activeInstitutes}</span>
                </td>
                <td className="p-4 font-medium">₹{(partner.totalRevenue / 100000).toFixed(2)}L</td>
                <td className="p-4 font-medium text-success">₹{(partner.commission / 1000).toFixed(1)}K</td>
                <td className="p-4">
                  <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                    Login as Partner
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// Pending Commercial Requests Component
function PendingCommercialRequests() {
  const requests = [
    {
      id: "REQ001",
      institute: "Delhi Public School",
      instituteId: "INST001",
      requestType: "Rate Reduction",
      currentRate: "2.2%",
      requestedRate: "1.8%",
      mode: "Credit Card",
      gateway: "Razorpay",
      requestedBy: "Finance Manager",
      requestDate: "2024-01-10",
      status: "pending",
    },
    {
      id: "REQ002",
      institute: "Amity University",
      instituteId: "INST002",
      requestType: "Fee Bearing Change",
      currentRate: "Customer Pays",
      requestedRate: "Merchant Pays",
      mode: "UPI",
      gateway: "Cashfree",
      requestedBy: "Admin",
      requestDate: "2024-01-09",
      status: "pending",
    },
    {
      id: "REQ003",
      institute: "St. Mary's College",
      instituteId: "INST003",
      requestType: "Enable Mode",
      currentRate: "Disabled",
      requestedRate: "Enable EMI",
      mode: "EMI",
      gateway: "Easebuzz",
      requestedBy: "Principal",
      requestDate: "2024-01-08",
      status: "under_review",
    },
  ]

  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold">Pending Commercial Change Requests</h3>
        <p className="text-sm text-muted-foreground">Review and approve rate/mode change requests from institutes</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-secondary/50">
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institute</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Request Type</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Mode/Gateway</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Current</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Requested</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Date</th>
              <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((req) => (
              <tr key={req.id} className="border-b border-border hover:bg-secondary/30">
                <td className="p-4">
                  <div>
                    <p className="font-medium">{req.institute}</p>
                    <p className="text-xs text-muted-foreground">By {req.requestedBy}</p>
                  </div>
                </td>
                <td className="p-4">
                  <span
                    className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                      req.requestType === "Rate Reduction"
                        ? "bg-blue-500/10 text-blue-500"
                        : req.requestType === "Fee Bearing Change"
                          ? "bg-purple-500/10 text-purple-500"
                          : "bg-green-500/10 text-green-500"
                    }`}
                  >
                    {req.requestType}
                  </span>
                </td>
                <td className="p-4">
                  <p className="text-sm">{req.mode}</p>
                  <p className="text-xs text-muted-foreground">{req.gateway}</p>
                </td>
                <td className="p-4 text-sm">{req.currentRate}</td>
                <td className="p-4 text-sm font-medium text-primary">{req.requestedRate}</td>
                <td className="p-4 text-sm text-muted-foreground">{req.requestDate}</td>
                <td className="p-4">
                  <div className="flex gap-2">
                    <Button size="sm" className="h-7 bg-success hover:bg-success/90">
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-7 text-destructive border-destructive/50 bg-transparent"
                    >
                      Reject
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
