"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  CreditCard,
  Smartphone,
  Building2,
  Wallet,
  QrCode,
  Banknote,
  Settings2,
  Info,
  IndianRupee,
  Percent,
  ArrowRight,
  Check,
  AlertCircle,
  TrendingUp,
  Calculator,
  Users,
  Building,
  Save,
  RotateCcw,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface PaymentMode {
  id: string
  name: string
  icon: React.ElementType
  enabled: boolean
  buyRate: number
  buyRateType: "percentage" | "flat"
  sellRate: number
  sellRateType: "percentage" | "flat"
  feeBearing: "customer" | "merchant" | "split"
  splitPercentage?: number
  minTransaction: number
  maxTransaction: number
  dailyLimit: number
  subModes?: SubMode[]
}

interface SubMode {
  id: string
  name: string
  enabled: boolean
  buyRate: number
  sellRate: number
}

const initialPaymentModes: PaymentMode[] = [
  {
    id: "cards",
    name: "Credit/Debit Cards",
    icon: CreditCard,
    enabled: true,
    buyRate: 1.8,
    buyRateType: "percentage",
    sellRate: 2.2,
    sellRateType: "percentage",
    feeBearing: "customer",
    minTransaction: 100,
    maxTransaction: 500000,
    dailyLimit: 2000000,
    subModes: [
      { id: "visa", name: "Visa", enabled: true, buyRate: 1.8, sellRate: 2.2 },
      { id: "mastercard", name: "Mastercard", enabled: true, buyRate: 1.8, sellRate: 2.2 },
      { id: "rupay", name: "RuPay", enabled: true, buyRate: 0.6, sellRate: 1.0 },
      { id: "amex", name: "American Express", enabled: false, buyRate: 2.5, sellRate: 3.0 },
      { id: "diners", name: "Diners Club", enabled: false, buyRate: 2.8, sellRate: 3.2 },
    ],
  },
  {
    id: "upi",
    name: "UPI",
    icon: Smartphone,
    enabled: true,
    buyRate: 0,
    buyRateType: "percentage",
    sellRate: 0.5,
    sellRateType: "percentage",
    feeBearing: "merchant",
    minTransaction: 1,
    maxTransaction: 100000,
    dailyLimit: 1000000,
    subModes: [
      { id: "gpay", name: "Google Pay", enabled: true, buyRate: 0, sellRate: 0.5 },
      { id: "phonepe", name: "PhonePe", enabled: true, buyRate: 0, sellRate: 0.5 },
      { id: "paytm", name: "Paytm", enabled: true, buyRate: 0, sellRate: 0.5 },
      { id: "bhim", name: "BHIM", enabled: true, buyRate: 0, sellRate: 0.5 },
    ],
  },
  {
    id: "netbanking",
    name: "Net Banking",
    icon: Building2,
    enabled: true,
    buyRate: 1.5,
    buyRateType: "percentage",
    sellRate: 2.0,
    sellRateType: "percentage",
    feeBearing: "customer",
    minTransaction: 100,
    maxTransaction: 1000000,
    dailyLimit: 5000000,
    subModes: [
      { id: "hdfc", name: "HDFC Bank", enabled: true, buyRate: 1.5, sellRate: 2.0 },
      { id: "icici", name: "ICICI Bank", enabled: true, buyRate: 1.5, sellRate: 2.0 },
      { id: "sbi", name: "SBI", enabled: true, buyRate: 1.2, sellRate: 1.8 },
      { id: "axis", name: "Axis Bank", enabled: true, buyRate: 1.5, sellRate: 2.0 },
      { id: "kotak", name: "Kotak Mahindra", enabled: false, buyRate: 1.5, sellRate: 2.0 },
    ],
  },
  {
    id: "wallets",
    name: "Wallets",
    icon: Wallet,
    enabled: true,
    buyRate: 1.0,
    buyRateType: "percentage",
    sellRate: 1.5,
    sellRateType: "percentage",
    feeBearing: "split",
    splitPercentage: 50,
    minTransaction: 10,
    maxTransaction: 50000,
    dailyLimit: 200000,
    subModes: [
      { id: "paytm_wallet", name: "Paytm Wallet", enabled: true, buyRate: 1.0, sellRate: 1.5 },
      { id: "mobikwik", name: "MobiKwik", enabled: true, buyRate: 1.0, sellRate: 1.5 },
      { id: "freecharge", name: "Freecharge", enabled: false, buyRate: 1.2, sellRate: 1.8 },
      { id: "airtel", name: "Airtel Money", enabled: false, buyRate: 1.0, sellRate: 1.5 },
    ],
  },
  {
    id: "qr",
    name: "QR Code / Static QR",
    icon: QrCode,
    enabled: true,
    buyRate: 0,
    buyRateType: "percentage",
    sellRate: 0.3,
    sellRateType: "percentage",
    feeBearing: "merchant",
    minTransaction: 1,
    maxTransaction: 100000,
    dailyLimit: 500000,
  },
  {
    id: "emi",
    name: "EMI Options",
    icon: Calculator,
    enabled: false,
    buyRate: 2.5,
    buyRateType: "percentage",
    sellRate: 3.5,
    sellRateType: "percentage",
    feeBearing: "customer",
    minTransaction: 3000,
    maxTransaction: 500000,
    dailyLimit: 1000000,
    subModes: [
      { id: "emi_3", name: "3 Months EMI", enabled: true, buyRate: 2.0, sellRate: 3.0 },
      { id: "emi_6", name: "6 Months EMI", enabled: true, buyRate: 2.5, sellRate: 3.5 },
      { id: "emi_9", name: "9 Months EMI", enabled: false, buyRate: 3.0, sellRate: 4.0 },
      { id: "emi_12", name: "12 Months EMI", enabled: false, buyRate: 3.5, sellRate: 4.5 },
    ],
  },
  {
    id: "cash",
    name: "Cash Collection",
    icon: Banknote,
    enabled: false,
    buyRate: 0.5,
    buyRateType: "percentage",
    sellRate: 1.0,
    sellRateType: "percentage",
    feeBearing: "merchant",
    minTransaction: 100,
    maxTransaction: 50000,
    dailyLimit: 200000,
  },
]

export function PaymentModesConfig() {
  const [paymentModes, setPaymentModes] = useState<PaymentMode[]>(initialPaymentModes)
  const [selectedMode, setSelectedMode] = useState<PaymentMode | null>(null)
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false)
  const [hasChanges, setHasChanges] = useState(false)

  const toggleMode = (modeId: string) => {
    setPaymentModes((prev) => prev.map((mode) => (mode.id === modeId ? { ...mode, enabled: !mode.enabled } : mode)))
    setHasChanges(true)
  }

  const toggleSubMode = (modeId: string, subModeId: string) => {
    setPaymentModes((prev) =>
      prev.map((mode) =>
        mode.id === modeId
          ? {
              ...mode,
              subModes: mode.subModes?.map((sub) => (sub.id === subModeId ? { ...sub, enabled: !sub.enabled } : sub)),
            }
          : mode,
      ),
    )
    setHasChanges(true)
  }

  const openConfigModal = (mode: PaymentMode) => {
    setSelectedMode({ ...mode })
    setIsConfigModalOpen(true)
  }

  const saveConfig = () => {
    if (selectedMode) {
      setPaymentModes((prev) => prev.map((mode) => (mode.id === selectedMode.id ? selectedMode : mode)))
      setIsConfigModalOpen(false)
      setHasChanges(true)
    }
  }

  const calculateMargin = (buyRate: number, sellRate: number) => {
    return (sellRate - buyRate).toFixed(2)
  }

  const calculateRevenueExample = (sellRate: number, buyRate: number, amount = 10000) => {
    const margin = sellRate - buyRate
    return ((margin / 100) * amount).toFixed(2)
  }

  const enabledModesCount = paymentModes.filter((m) => m.enabled).length

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <CreditCard className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Active Modes</p>
                <p className="text-2xl font-bold">
                  {enabledModesCount}/{paymentModes.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/10">
                <TrendingUp className="h-5 w-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Avg. Margin</p>
                <p className="text-2xl font-bold">0.65%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/10">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Customer Bearing</p>
                <p className="text-2xl font-bold">{paymentModes.filter((m) => m.feeBearing === "customer").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/10">
                <Building className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Merchant Bearing</p>
                <p className="text-2xl font-bold">{paymentModes.filter((m) => m.feeBearing === "merchant").length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Buy/Sell Rate Explainer */}
      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Info className="mt-0.5 h-5 w-5 text-blue-500" />
            <div className="space-y-2">
              <h4 className="font-semibold text-foreground">Understanding Buy Rate vs Sell Rate</h4>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-blue-500">Buy Rate (Your Cost)</p>
                  <p className="text-sm text-muted-foreground">
                    The rate charged by payment gateway/bank to you. This is your cost of accepting payments.
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-emerald-500">Sell Rate (Customer Rate)</p>
                  <p className="text-sm text-muted-foreground">
                    The rate you charge to institutes/customers. This should be higher than buy rate to earn margin.
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-primary">Your Margin</p>
                  <p className="text-sm text-muted-foreground">
                    Sell Rate - Buy Rate = Your Revenue. Example: 2.2% - 1.8% = 0.4% margin on each transaction.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Modes List */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Payment Modes Configuration</CardTitle>
            <CardDescription>Enable/disable payment modes and configure rates for your payment page</CardDescription>
          </div>
          {hasChanges && (
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setPaymentModes(initialPaymentModes)
                  setHasChanges(false)
                }}
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                Reset
              </Button>
              <Button size="sm" onClick={() => setHasChanges(false)}>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </div>
          )}
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {paymentModes.map((mode) => (
              <div
                key={mode.id}
                className={cn(
                  "rounded-lg border p-4 transition-all",
                  mode.enabled ? "border-border bg-card" : "border-border/50 bg-muted/30",
                )}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div
                      className={cn(
                        "flex h-12 w-12 items-center justify-center rounded-lg",
                        mode.enabled ? "bg-primary/10" : "bg-muted",
                      )}
                    >
                      <mode.icon className={cn("h-6 w-6", mode.enabled ? "text-primary" : "text-muted-foreground")} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className={cn("font-semibold", !mode.enabled && "text-muted-foreground")}>{mode.name}</h4>
                        {mode.enabled && (
                          <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">
                            Active
                          </Badge>
                        )}
                      </div>
                      <div className="mt-1 flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <span className="text-blue-500">Buy:</span> {mode.buyRate}%
                        </span>
                        <ArrowRight className="h-3 w-3" />
                        <span className="flex items-center gap-1">
                          <span className="text-emerald-500">Sell:</span> {mode.sellRate}%
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="text-primary">Margin:</span> {calculateMargin(mode.buyRate, mode.sellRate)}%
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Badge
                            variant="outline"
                            className={cn(
                              mode.feeBearing === "customer"
                                ? "border-amber-500/20 bg-amber-500/10 text-amber-500"
                                : mode.feeBearing === "merchant"
                                  ? "border-blue-500/20 bg-blue-500/10 text-blue-500"
                                  : "border-purple-500/20 bg-purple-500/10 text-purple-500",
                            )}
                          >
                            {mode.feeBearing === "customer" && "Customer Pays"}
                            {mode.feeBearing === "merchant" && "Merchant Pays"}
                            {mode.feeBearing === "split" && `Split ${mode.splitPercentage}%`}
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>
                            {mode.feeBearing === "customer" && "Transaction fee is added to customer's payment"}
                            {mode.feeBearing === "merchant" && "Transaction fee is deducted from settlement"}
                            {mode.feeBearing === "split" &&
                              `${mode.splitPercentage}% paid by customer, rest by merchant`}
                          </p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openConfigModal(mode)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      <Settings2 className="h-4 w-4" />
                    </Button>

                    <Switch checked={mode.enabled} onCheckedChange={() => toggleMode(mode.id)} />
                  </div>
                </div>

                {/* Sub-modes */}
                {mode.enabled && mode.subModes && (
                  <div className="mt-4 border-t pt-4">
                    <p className="mb-3 text-sm font-medium text-muted-foreground">Payment Options</p>
                    <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
                      {mode.subModes.map((sub) => (
                        <div
                          key={sub.id}
                          className={cn(
                            "flex items-center justify-between rounded-md border px-3 py-2",
                            sub.enabled ? "border-border bg-background" : "border-border/50 bg-muted/20",
                          )}
                        >
                          <div>
                            <p className={cn("text-sm font-medium", !sub.enabled && "text-muted-foreground")}>
                              {sub.name}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {sub.buyRate}% → {sub.sellRate}%
                            </p>
                          </div>
                          <Switch checked={sub.enabled} onCheckedChange={() => toggleSubMode(mode.id, sub.id)} />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Configuration Modal */}
      <Dialog open={isConfigModalOpen} onOpenChange={setIsConfigModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedMode && <selectedMode.icon className="h-5 w-5" />}
              Configure {selectedMode?.name}
            </DialogTitle>
            <DialogDescription>Set rates, limits, and fee bearing options for this payment mode</DialogDescription>
          </DialogHeader>

          {selectedMode && (
            <Tabs defaultValue="rates" className="mt-4">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="rates">Rates & Margin</TabsTrigger>
                <TabsTrigger value="fees">Fee Bearing</TabsTrigger>
                <TabsTrigger value="limits">Limits</TabsTrigger>
              </TabsList>

              <TabsContent value="rates" className="space-y-4 pt-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full bg-blue-500" />
                      Buy Rate (Your Cost)
                    </Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        step="0.01"
                        value={selectedMode.buyRate}
                        onChange={(e) =>
                          setSelectedMode({ ...selectedMode, buyRate: Number.parseFloat(e.target.value) || 0 })
                        }
                        className="flex-1"
                      />
                      <Select
                        value={selectedMode.buyRateType}
                        onValueChange={(value: "percentage" | "flat") =>
                          setSelectedMode({ ...selectedMode, buyRateType: value })
                        }
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentage">%</SelectItem>
                          <SelectItem value="flat">₹ Flat</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <p className="text-xs text-muted-foreground">Rate charged by payment gateway to you</p>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <span className="h-2 w-2 rounded-full bg-emerald-500" />
                      Sell Rate (Customer Rate)
                    </Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        step="0.01"
                        value={selectedMode.sellRate}
                        onChange={(e) =>
                          setSelectedMode({ ...selectedMode, sellRate: Number.parseFloat(e.target.value) || 0 })
                        }
                        className="flex-1"
                      />
                      <Select
                        value={selectedMode.sellRateType}
                        onValueChange={(value: "percentage" | "flat") =>
                          setSelectedMode({ ...selectedMode, sellRateType: value })
                        }
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentage">%</SelectItem>
                          <SelectItem value="flat">₹ Flat</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <p className="text-xs text-muted-foreground">Rate you charge to institutes/customers</p>
                  </div>
                </div>

                {/* Margin Calculator */}
                <div className="rounded-lg border bg-muted/30 p-4">
                  <h4 className="mb-3 font-medium">Margin Calculator</h4>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-primary">
                        {calculateMargin(selectedMode.buyRate, selectedMode.sellRate)}%
                      </p>
                      <p className="text-sm text-muted-foreground">Your Margin</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-emerald-500">
                        ₹{calculateRevenueExample(selectedMode.sellRate, selectedMode.buyRate, 10000)}
                      </p>
                      <p className="text-sm text-muted-foreground">Revenue on ₹10,000</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-blue-500">
                        ₹{calculateRevenueExample(selectedMode.sellRate, selectedMode.buyRate, 100000)}
                      </p>
                      <p className="text-sm text-muted-foreground">Revenue on ₹1,00,000</p>
                    </div>
                  </div>
                </div>

                {selectedMode.sellRate <= selectedMode.buyRate && (
                  <div className="flex items-center gap-2 rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-red-500">
                    <AlertCircle className="h-4 w-4" />
                    <p className="text-sm">Sell rate should be higher than buy rate to earn margin</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="fees" className="space-y-4 pt-4">
                <div className="space-y-4">
                  <Label>Who bears the transaction fee?</Label>

                  <div className="grid gap-3">
                    <div
                      className={cn(
                        "cursor-pointer rounded-lg border p-4 transition-all",
                        selectedMode.feeBearing === "customer"
                          ? "border-primary bg-primary/5"
                          : "hover:border-primary/50",
                      )}
                      onClick={() => setSelectedMode({ ...selectedMode, feeBearing: "customer" })}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-500/10">
                            <Users className="h-5 w-5 text-amber-500" />
                          </div>
                          <div>
                            <p className="font-medium">Customer/Payer Bears Fee</p>
                            <p className="text-sm text-muted-foreground">
                              Fee is added on top of payment amount. Customer pays more.
                            </p>
                          </div>
                        </div>
                        {selectedMode.feeBearing === "customer" && <Check className="h-5 w-5 text-primary" />}
                      </div>
                      <div className="mt-3 rounded bg-muted/50 p-2 text-sm">
                        <span className="text-muted-foreground">Example:</span> ₹10,000 fee + ₹220 (2.2%) ={" "}
                        <span className="font-medium">₹10,220 total paid</span>
                      </div>
                    </div>

                    <div
                      className={cn(
                        "cursor-pointer rounded-lg border p-4 transition-all",
                        selectedMode.feeBearing === "merchant"
                          ? "border-primary bg-primary/5"
                          : "hover:border-primary/50",
                      )}
                      onClick={() => setSelectedMode({ ...selectedMode, feeBearing: "merchant" })}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-500/10">
                            <Building className="h-5 w-5 text-blue-500" />
                          </div>
                          <div>
                            <p className="font-medium">Merchant/Institute Bears Fee</p>
                            <p className="text-sm text-muted-foreground">
                              Fee is deducted from settlement. Customer pays exact amount.
                            </p>
                          </div>
                        </div>
                        {selectedMode.feeBearing === "merchant" && <Check className="h-5 w-5 text-primary" />}
                      </div>
                      <div className="mt-3 rounded bg-muted/50 p-2 text-sm">
                        <span className="text-muted-foreground">Example:</span> ₹10,000 paid → ₹9,780 settled{" "}
                        <span className="font-medium">(₹220 fee deducted)</span>
                      </div>
                    </div>

                    <div
                      className={cn(
                        "cursor-pointer rounded-lg border p-4 transition-all",
                        selectedMode.feeBearing === "split" ? "border-primary bg-primary/5" : "hover:border-primary/50",
                      )}
                      onClick={() => setSelectedMode({ ...selectedMode, feeBearing: "split", splitPercentage: 50 })}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-500/10">
                            <Percent className="h-5 w-5 text-purple-500" />
                          </div>
                          <div>
                            <p className="font-medium">Split Fee Between Both</p>
                            <p className="text-sm text-muted-foreground">
                              Fee is shared between customer and merchant.
                            </p>
                          </div>
                        </div>
                        {selectedMode.feeBearing === "split" && <Check className="h-5 w-5 text-primary" />}
                      </div>
                      {selectedMode.feeBearing === "split" && (
                        <div className="mt-3 space-y-2">
                          <Label>Customer pays what % of fee?</Label>
                          <div className="flex items-center gap-4">
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              value={selectedMode.splitPercentage || 50}
                              onChange={(e) =>
                                setSelectedMode({
                                  ...selectedMode,
                                  splitPercentage: Number.parseInt(e.target.value) || 0,
                                })
                              }
                              className="w-24"
                            />
                            <span className="text-sm text-muted-foreground">
                              Customer: {selectedMode.splitPercentage}% | Merchant:{" "}
                              {100 - (selectedMode.splitPercentage || 0)}%
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="limits" className="space-y-4 pt-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label>Minimum Transaction</Label>
                    <div className="relative">
                      <IndianRupee className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        type="number"
                        value={selectedMode.minTransaction}
                        onChange={(e) =>
                          setSelectedMode({ ...selectedMode, minTransaction: Number.parseInt(e.target.value) || 0 })
                        }
                        className="pl-9"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Maximum Transaction</Label>
                    <div className="relative">
                      <IndianRupee className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        type="number"
                        value={selectedMode.maxTransaction}
                        onChange={(e) =>
                          setSelectedMode({ ...selectedMode, maxTransaction: Number.parseInt(e.target.value) || 0 })
                        }
                        className="pl-9"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Daily Limit</Label>
                    <div className="relative">
                      <IndianRupee className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        type="number"
                        value={selectedMode.dailyLimit}
                        onChange={(e) =>
                          setSelectedMode({ ...selectedMode, dailyLimit: Number.parseInt(e.target.value) || 0 })
                        }
                        className="pl-9"
                      />
                    </div>
                  </div>
                </div>

                <div className="rounded-lg border bg-muted/30 p-4">
                  <h4 className="mb-2 font-medium">Current Limits Summary</h4>
                  <p className="text-sm text-muted-foreground">
                    Transactions between{" "}
                    <span className="font-medium text-foreground">₹{selectedMode.minTransaction.toLocaleString()}</span>{" "}
                    and{" "}
                    <span className="font-medium text-foreground">₹{selectedMode.maxTransaction.toLocaleString()}</span>{" "}
                    per transaction. Daily limit of{" "}
                    <span className="font-medium text-foreground">₹{selectedMode.dailyLimit.toLocaleString()}</span>.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          )}

          <DialogFooter className="mt-6">
            <Button variant="outline" onClick={() => setIsConfigModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={saveConfig}>
              <Save className="mr-2 h-4 w-4" />
              Save Configuration
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
