"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  CheckCircle,
  XCircle,
  Clock,
  RotateCcw,
  User,
  Building2,
  CreditCard,
  FileText,
  Landmark,
  ArrowRight,
  AlertCircle,
} from "lucide-react"
import type { Refund } from "./refunds-table"

interface RefundDetailModalProps {
  refund: Refund | null
  onClose: () => void
}

const statusConfig = {
  processed: { icon: CheckCircle, color: "text-success", bgColor: "bg-success/10", label: "Processed" },
  pending: { icon: Clock, color: "text-warning", bgColor: "bg-warning/10", label: "Pending Approval" },
  initiated: { icon: RotateCcw, color: "text-info", bgColor: "bg-info/10", label: "Initiated" },
  failed: { icon: XCircle, color: "text-destructive", bgColor: "bg-destructive/10", label: "Failed" },
  rejected: { icon: XCircle, color: "text-muted-foreground", bgColor: "bg-muted", label: "Rejected" },
}

export function RefundDetailModal({ refund, onClose }: RefundDetailModalProps) {
  if (!refund) return null

  const status = statusConfig[refund.status]
  const StatusIcon = status.icon

  return (
    <Dialog open={!!refund} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-card border-border max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold">Refund Details</DialogTitle>
            <Badge variant="outline" className={`${status.bgColor} ${status.color} border-transparent`}>
              <StatusIcon className="mr-1 h-3 w-3" />
              {status.label}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Refund Summary */}
          <div className="rounded-lg bg-secondary/50 p-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-muted-foreground">Refund ID</p>
                <p className="font-mono font-semibold text-primary">{refund.id}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Original Transaction</p>
                <p className="font-mono text-sm">{refund.transactionId}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Original Amount</p>
                <p className="text-lg font-semibold text-muted-foreground">₹{refund.originalAmount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Refund Amount</p>
                <p className="text-lg font-bold text-primary">₹{refund.refundAmount.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-4">
            <div className="flex items-center gap-2 mb-3">
              <Landmark className="h-4 w-4 text-amber-500" />
              <h3 className="font-semibold">Settlement Impact</h3>
            </div>

            {refund.originalSettlement && (
              <div className="space-y-4">
                {/* Settlement Flow */}
                <div className="flex items-center justify-center gap-4 p-4 bg-card rounded-lg">
                  <div className="text-center">
                    <p className="text-xs text-muted-foreground mb-1">Original Payment Settlement</p>
                    <p className="font-mono font-semibold">{refund.originalSettlement.id}</p>
                    <p className="text-xs text-muted-foreground">{refund.originalSettlement.date}</p>
                    <Badge variant="outline" className="mt-1 bg-success/10 text-success border-success/20 text-xs">
                      Settled to Institute
                    </Badge>
                  </div>

                  <ArrowRight className="h-6 w-6 text-muted-foreground" />

                  {refund.adjustedFromSettlement ? (
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">Refund Adjusted From</p>
                      <p className="font-mono font-semibold text-amber-600">{refund.adjustedFromSettlement.id}</p>
                      <p className="text-xs text-muted-foreground">{refund.adjustedFromSettlement.date}</p>
                      <Badge
                        variant="outline"
                        className="mt-1 bg-amber-500/10 text-amber-600 border-amber-500/20 text-xs"
                      >
                        ₹{refund.refundAmount.toLocaleString()} Deducted
                      </Badge>
                    </div>
                  ) : (
                    <div className="text-center">
                      <p className="text-xs text-muted-foreground mb-1">Pending Adjustment</p>
                      <div className="flex items-center gap-1 justify-center">
                        <AlertCircle className="h-4 w-4 text-warning" />
                        <p className="font-medium text-warning">Next Settlement</p>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        ₹{refund.refundAmount.toLocaleString()} will be deducted
                      </p>
                    </div>
                  )}
                </div>

                {/* Explanation */}
                <div className="text-sm text-muted-foreground bg-card rounded-lg p-3">
                  <p className="flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    {refund.adjustedFromSettlement ? (
                      <span>
                        This refund of <strong>₹{refund.refundAmount.toLocaleString()}</strong> was deducted from
                        settlement <strong>{refund.adjustedFromSettlement.id}</strong> on{" "}
                        {refund.adjustedFromSettlement.adjustmentDate}. The original payment was part of settlement{" "}
                        {refund.originalSettlement.id}.
                      </span>
                    ) : (
                      <span>
                        This refund of <strong>₹{refund.refundAmount.toLocaleString()}</strong> will be adjusted from
                        the next settlement for {refund.institute}. The original payment was part of settlement{" "}
                        <strong>{refund.originalSettlement.id}</strong>.
                      </span>
                    )}
                  </p>
                </div>
              </div>
            )}
          </div>

          <Separator />

          {/* Student Details */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <User className="h-4 w-4 text-muted-foreground" />
              <h3 className="font-semibold">Student Details</h3>
            </div>
            <div className="grid grid-cols-2 gap-4 rounded-lg bg-secondary/30 p-4">
              <div>
                <p className="text-xs text-muted-foreground">Name</p>
                <p className="font-medium">{refund.studentName}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Email</p>
                <p className="text-sm">{refund.studentEmail}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Mobile</p>
                <p className="text-sm">{refund.studentMobile}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Order ID</p>
                <p className="font-mono text-sm">{refund.orderId}</p>
              </div>
            </div>
          </div>

          {/* Institute Details */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Building2 className="h-4 w-4 text-muted-foreground" />
              <h3 className="font-semibold">Institute Details</h3>
            </div>
            <div className="rounded-lg bg-secondary/30 p-4">
              <p className="font-medium">{refund.institute}</p>
            </div>
          </div>

          {/* Payment Details */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <CreditCard className="h-4 w-4 text-muted-foreground" />
              <h3 className="font-semibold">Payment Details</h3>
            </div>
            <div className="grid grid-cols-2 gap-4 rounded-lg bg-secondary/30 p-4">
              <div>
                <p className="text-xs text-muted-foreground">Gateway</p>
                <p className="font-medium">{refund.gateway}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Payment Mode</p>
                <p className="text-sm">{refund.paymentMode}</p>
              </div>
              {refund.arn && (
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">ARN (Acquirer Reference Number)</p>
                  <p className="font-mono text-sm text-primary">{refund.arn}</p>
                </div>
              )}
            </div>
          </div>

          {/* Refund Reason */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <h3 className="font-semibold">Refund Reason</h3>
            </div>
            <div className="rounded-lg bg-secondary/30 p-4">
              <p className="text-sm">{refund.reason}</p>
              <div className="mt-3 flex items-center gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Requested By</p>
                  <p className="text-sm">{refund.requestedBy}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Requested At</p>
                  <p className="text-sm">{refund.requestedAt}</p>
                </div>
                {refund.processedAt && (
                  <div>
                    <p className="text-xs text-muted-foreground">Processed At</p>
                    <p className="text-sm">{refund.processedAt}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Actions */}
          {(refund.status === "pending" || refund.status === "initiated") && (
            <div className="flex justify-end gap-2">
              <Button variant="outline" className="bg-transparent">
                Reject Refund
              </Button>
              <Button>Approve Refund</Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
