"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Search, CheckCircle2 } from "lucide-react"

interface InitiateRefundModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function InitiateRefundModal({ open, onOpenChange }: InitiateRefundModalProps) {
  const [step, setStep] = useState(1)
  const [transactionId, setTransactionId] = useState("")
  const [transactionFound, setTransactionFound] = useState(false)
  const [refundType, setRefundType] = useState("full")
  const [refundAmount, setRefundAmount] = useState("")

  const mockTransaction = {
    id: "TXN001234567",
    studentName: "Rahul Sharma",
    institute: "Delhi Public School",
    amount: 45000,
    date: "2024-01-15",
    gateway: "Razorpay",
    paymentMode: "Credit Card",
  }

  const handleSearch = () => {
    if (transactionId.length > 5) {
      setTransactionFound(true)
      setRefundAmount(mockTransaction.amount.toString())
    }
  }

  const handleSubmit = () => {
    onOpenChange(false)
    setStep(1)
    setTransactionId("")
    setTransactionFound(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">Initiate Refund</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {step === 1 && (
            <>
              <div className="space-y-2">
                <Label>Transaction ID</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter Transaction ID (e.g., TXN001234567)"
                    value={transactionId}
                    onChange={(e) => setTransactionId(e.target.value)}
                    className="bg-secondary"
                  />
                  <Button onClick={handleSearch}>
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {transactionFound && (
                <div className="rounded-lg border border-success/30 bg-success/5 p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <CheckCircle2 className="h-5 w-5 text-success" />
                    <span className="font-semibold text-success">Transaction Found</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">Student</p>
                      <p className="font-medium">{mockTransaction.studentName}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Institute</p>
                      <p className="font-medium">{mockTransaction.institute}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Amount</p>
                      <p className="font-semibold text-primary">₹{mockTransaction.amount.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Date</p>
                      <p>{mockTransaction.date}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Gateway</p>
                      <p>{mockTransaction.gateway}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Payment Mode</p>
                      <p>{mockTransaction.paymentMode}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end">
                <Button onClick={() => setStep(2)} disabled={!transactionFound}>
                  Continue
                </Button>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Refund Type</Label>
                  <RadioGroup value={refundType} onValueChange={setRefundType}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="full" id="full" />
                      <Label htmlFor="full" className="font-normal">
                        Full Refund (₹{mockTransaction.amount.toLocaleString()})
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="partial" id="partial" />
                      <Label htmlFor="partial" className="font-normal">
                        Partial Refund
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {refundType === "partial" && (
                  <div className="space-y-2">
                    <Label>Refund Amount</Label>
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      value={refundAmount}
                      onChange={(e) => setRefundAmount(e.target.value)}
                      max={mockTransaction.amount}
                      className="bg-secondary"
                    />
                    <p className="text-xs text-muted-foreground">
                      Maximum refund: ₹{mockTransaction.amount.toLocaleString()}
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label>Refund Reason</Label>
                  <Select>
                    <SelectTrigger className="bg-secondary">
                      <SelectValue placeholder="Select reason" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="duplicate">Duplicate Payment</SelectItem>
                      <SelectItem value="cancellation">Course Cancellation</SelectItem>
                      <SelectItem value="withdrawal">Student Withdrawal</SelectItem>
                      <SelectItem value="error">Payment Error</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Additional Notes</Label>
                  <Textarea placeholder="Enter any additional details..." className="bg-secondary" rows={3} />
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)} className="bg-transparent">
                  Back
                </Button>
                <Button onClick={handleSubmit}>Submit Refund Request</Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
