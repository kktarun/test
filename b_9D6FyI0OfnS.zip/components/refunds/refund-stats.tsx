"use client"

import { Card, CardContent } from "@/components/ui/card"
import { RotateCcw, Clock, CheckCircle2, XCircle, TrendingUp } from "lucide-react"

const stats = [
  {
    name: "Total Refunded",
    value: "₹42.8 L",
    subValue: "847 refunds",
    icon: RotateCcw,
    color: "text-info",
    bgColor: "bg-info/10",
  },
  {
    name: "Pending Refunds",
    value: "₹8.2 L",
    subValue: "34 requests",
    icon: Clock,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
  {
    name: "Processed Today",
    value: "₹3.5 L",
    subValue: "12 refunds",
    icon: CheckCircle2,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    name: "Failed/Rejected",
    value: "₹1.2 L",
    subValue: "8 refunds",
    icon: XCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
  {
    name: "Avg Processing Time",
    value: "2.4 hrs",
    subValue: "↓ 15% from last week",
    icon: TrendingUp,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
]

export function RefundStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
      {stats.map((stat) => (
        <Card key={stat.name} className="bg-card border-border">
          <CardContent className="flex items-center gap-4 p-4">
            <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${stat.bgColor}`}>
              <stat.icon className={`h-6 w-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.name}</p>
              <p className={`text-xs ${stat.color}`}>{stat.subValue}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
