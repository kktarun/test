"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus,
  Search,
  CreditCard,
  Smartphone,
  Building,
  Calendar,
  CheckCircle2,
  Clock,
  XCircle,
  MoreHorizontal,
  Pause,
  Play,
  Trash2,
} from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const mandates = [
  {
    id: "MND001",
    studentName: "Rahul Sharma",
    institute: "Delhi Public School",
    amount: 15000,
    frequency: "Monthly",
    paymentMethod: "Credit Card",
    cardLast4: "4521",
    status: "active",
    nextDebit: "2024-02-01",
    createdAt: "2023-09-15",
  },
  {
    id: "MND002",
    studentName: "Priya Patel",
    institute: "Amity University",
    amount: 25000,
    frequency: "Quarterly",
    paymentMethod: "UPI",
    upiId: "priya@okaxis",
    status: "active",
    nextDebit: "2024-03-01",
    createdAt: "2023-10-20",
  },
  {
    id: "MND003",
    studentName: "Amit Kumar",
    institute: "St. Mary's College",
    amount: 12000,
    frequency: "Monthly",
    paymentMethod: "Debit Card",
    cardLast4: "8976",
    status: "paused",
    nextDebit: "-",
    createdAt: "2023-11-05",
  },
  {
    id: "MND004",
    studentName: "Sneha Gupta",
    institute: "Ryan International",
    amount: 18000,
    frequency: "Monthly",
    paymentMethod: "Net Banking",
    bankName: "HDFC Bank",
    status: "active",
    nextDebit: "2024-02-01",
    createdAt: "2023-08-10",
  },
  {
    id: "MND005",
    studentName: "Vikram Singh",
    institute: "Delhi Public School",
    amount: 20000,
    frequency: "Monthly",
    paymentMethod: "UPI",
    upiId: "vikram@paytm",
    status: "failed",
    nextDebit: "2024-01-20",
    createdAt: "2023-12-01",
  },
]

const stats = [
  { name: "Active Mandates", value: "2,847", icon: CheckCircle2, color: "text-success", bgColor: "bg-success/10" },
  { name: "Monthly Collection", value: "₹4.2 Cr", icon: Calendar, color: "text-primary", bgColor: "bg-primary/10" },
  { name: "Pending Execution", value: "156", icon: Clock, color: "text-warning", bgColor: "bg-warning/10" },
  { name: "Failed This Month", value: "23", icon: XCircle, color: "text-destructive", bgColor: "bg-destructive/10" },
]

const statusColors = {
  active: "bg-success/10 text-success border-success/20",
  paused: "bg-warning/10 text-warning border-warning/20",
  failed: "bg-destructive/10 text-destructive border-destructive/20",
  cancelled: "bg-muted/10 text-muted-foreground border-muted/20",
}

const paymentMethodIcons = {
  "Credit Card": CreditCard,
  "Debit Card": CreditCard,
  UPI: Smartphone,
  "Net Banking": Building,
}

export function AutoDebitContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredMandates = mandates.filter((mandate) => {
    if (statusFilter !== "all" && mandate.status !== statusFilter) return false
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        mandate.studentName.toLowerCase().includes(query) ||
        mandate.institute.toLowerCase().includes(query) ||
        mandate.id.toLowerCase().includes(query)
      )
    }
    return true
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Auto Debit / Recurring Payments</h1>
          <p className="text-muted-foreground">Manage automated recurring fee collections</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Create Mandate
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.name} className="bg-card border-border">
            <CardContent className="flex items-center gap-4 p-4">
              <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.name}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="all">
        <div className="flex items-center justify-between">
          <TabsList className="bg-secondary">
            <TabsTrigger value="all">All Mandates</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="failed">Failed</TabsTrigger>
          </TabsList>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search mandates..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 bg-secondary pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32 bg-secondary">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="paused">Paused</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <TabsContent value="all" className="mt-6">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold">{filteredMandates.length} Mandates</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-secondary/50">
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Mandate ID</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Student</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Institute</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Amount</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Frequency</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Method</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Next Debit</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Status</th>
                      <th className="p-4 text-left text-xs font-medium uppercase text-muted-foreground">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMandates.map((mandate) => {
                      const PaymentIcon =
                        paymentMethodIcons[mandate.paymentMethod as keyof typeof paymentMethodIcons] || CreditCard
                      return (
                        <tr key={mandate.id} className="border-b border-border hover:bg-secondary/30 transition-colors">
                          <td className="p-4">
                            <span className="font-mono text-sm font-medium text-primary">{mandate.id}</span>
                          </td>
                          <td className="p-4">
                            <span className="font-medium">{mandate.studentName}</span>
                          </td>
                          <td className="p-4">
                            <span className="text-sm text-muted-foreground">{mandate.institute}</span>
                          </td>
                          <td className="p-4">
                            <span className="font-semibold">₹{mandate.amount.toLocaleString()}</span>
                          </td>
                          <td className="p-4">
                            <span className="text-sm">{mandate.frequency}</span>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              <PaymentIcon className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">{mandate.paymentMethod}</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <span className="text-sm">{mandate.nextDebit}</span>
                          </td>
                          <td className="p-4">
                            <Badge
                              variant="outline"
                              className={statusColors[mandate.status as keyof typeof statusColors]}
                            >
                              {mandate.status}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                {mandate.status === "active" ? (
                                  <DropdownMenuItem>
                                    <Pause className="mr-2 h-4 w-4" />
                                    Pause Mandate
                                  </DropdownMenuItem>
                                ) : mandate.status === "paused" ? (
                                  <DropdownMenuItem>
                                    <Play className="mr-2 h-4 w-4" />
                                    Resume Mandate
                                  </DropdownMenuItem>
                                ) : null}
                                <DropdownMenuItem className="text-destructive">
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Cancel Mandate
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upcoming" className="mt-6">
          <Card className="bg-card border-border p-6">
            <p className="text-center text-muted-foreground">Upcoming debits scheduled for the next 7 days</p>
          </Card>
        </TabsContent>

        <TabsContent value="failed" className="mt-6">
          <Card className="bg-card border-border p-6">
            <p className="text-center text-muted-foreground">Failed mandates requiring attention</p>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
