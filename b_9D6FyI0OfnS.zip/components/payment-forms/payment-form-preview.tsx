"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CreditCard, Smartphone, Building } from "lucide-react"

interface PaymentFormPreviewProps {
  onClose: () => void
}

export function PaymentFormPreview({ onClose }: PaymentFormPreviewProps) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-card max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Payment Form Preview</DialogTitle>
        </DialogHeader>

        <div className="rounded-lg border border-border bg-background p-6">
          <div className="mb-6 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <span className="text-2xl font-bold text-primary">DPS</span>
            </div>
            <h2 className="text-xl font-bold">Delhi Public School</h2>
            <p className="text-muted-foreground">Tuition Fee Collection</p>
          </div>

          <form className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="studentName">Student Name</Label>
                <Input id="studentName" placeholder="Enter student name" className="bg-secondary" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="studentId">Student ID / Roll No</Label>
                <Input id="studentId" placeholder="Enter student ID" className="bg-secondary" />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="class">Class</Label>
                <Select>
                  <SelectTrigger className="bg-secondary">
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Class 1</SelectItem>
                    <SelectItem value="2">Class 2</SelectItem>
                    <SelectItem value="3">Class 3</SelectItem>
                    <SelectItem value="10">Class 10</SelectItem>
                    <SelectItem value="12">Class 12</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="feeType">Fee Type</Label>
                <Select>
                  <SelectTrigger className="bg-secondary">
                    <SelectValue placeholder="Select fee type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tuition">Tuition Fee</SelectItem>
                    <SelectItem value="exam">Exam Fee</SelectItem>
                    <SelectItem value="transport">Transport Fee</SelectItem>
                    <SelectItem value="annual">Annual Fee</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Enter amount"
                className="bg-secondary"
                defaultValue="45000"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input id="email" type="email" placeholder="Enter email for receipt" className="bg-secondary" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Mobile Number</Label>
              <Input id="phone" type="tel" placeholder="Enter mobile number" className="bg-secondary" />
            </div>

            <Card className="bg-secondary/30 border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Select Payment Method</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-3 md:grid-cols-3">
                <button
                  type="button"
                  className="flex flex-col items-center gap-2 rounded-lg border border-primary bg-primary/10 p-4 transition-colors"
                >
                  <CreditCard className="h-6 w-6 text-primary" />
                  <span className="text-sm font-medium">Card</span>
                </button>
                <button
                  type="button"
                  className="flex flex-col items-center gap-2 rounded-lg border border-border p-4 hover:border-primary/50 transition-colors"
                >
                  <Smartphone className="h-6 w-6" />
                  <span className="text-sm font-medium">UPI</span>
                </button>
                <button
                  type="button"
                  className="flex flex-col items-center gap-2 rounded-lg border border-border p-4 hover:border-primary/50 transition-colors"
                >
                  <Building className="h-6 w-6" />
                  <span className="text-sm font-medium">Net Banking</span>
                </button>
              </CardContent>
            </Card>

            <div className="rounded-lg bg-secondary/50 p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>₹45,000</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Convenience Fee</span>
                <span>₹450</span>
              </div>
              <div className="mt-2 flex items-center justify-between border-t border-border pt-2 font-semibold">
                <span>Total Amount</span>
                <span className="text-primary">₹45,450</span>
              </div>
            </div>

            <Button className="w-full" size="lg">
              Pay ₹45,450
            </Button>

            <p className="text-center text-xs text-muted-foreground">
              Powered by ClearN • Secure payment processing
            </p>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}
