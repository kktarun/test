"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Copy, ExternalLink, Settings, Eye, MoreHorizontal, FileText, Zap } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { PaymentFormPreview } from "./payment-form-preview"
import Link from "next/link"

const paymentForms = [
  {
    id: "PF001",
    name: "Tuition Fee Collection",
    institute: "Delhi Public School",
    url: "pay.orchestra.com/dps/tuition",
    collections: 8500000,
    transactions: 892,
    status: "active",
    createdAt: "2024-01-05",
  },
  {
    id: "PF002",
    name: "Admission Fee",
    institute: "Delhi Public School",
    url: "pay.orchestra.com/dps/admission",
    collections: 3500000,
    transactions: 245,
    status: "active",
    createdAt: "2024-01-08",
  },
  {
    id: "PF003",
    name: "Semester Fee",
    institute: "Amity University",
    url: "pay.orchestra.com/amity/semester",
    collections: 6200000,
    transactions: 520,
    status: "active",
    createdAt: "2024-01-02",
  },
  {
    id: "PF004",
    name: "Hostel Fee",
    institute: "Amity University",
    url: "pay.orchestra.com/amity/hostel",
    collections: 3600000,
    transactions: 380,
    status: "active",
    createdAt: "2024-01-03",
  },
  {
    id: "PF005",
    name: "Annual Fee",
    institute: "St. Mary's College",
    url: "pay.orchestra.com/stmarys/annual",
    collections: 4800000,
    transactions: 410,
    status: "draft",
    createdAt: "2024-01-12",
  },
]

const statusColors = {
  active: "bg-success/10 text-success border-success/20",
  draft: "bg-warning/10 text-warning border-warning/20",
  disabled: "bg-muted/10 text-muted-foreground border-muted/20",
}

export function PaymentFormsContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showPreview, setShowPreview] = useState(false)

  const filteredForms = paymentForms.filter((form) => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        form.name.toLowerCase().includes(query) ||
        form.institute.toLowerCase().includes(query) ||
        form.url.toLowerCase().includes(query)
      )
    }
    return true
  })

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(`https://${url}`)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Payment Forms</h1>
          <p className="text-muted-foreground">Create and manage customizable payment forms for institutes</p>
        </div>
        <Link href="/payment-forms/builder">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Create Form
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="all">
        <div className="flex items-center justify-between">
          <TabsList className="bg-secondary">
            <TabsTrigger value="all">All Forms</TabsTrigger>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="draft">Drafts</TabsTrigger>
          </TabsList>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search forms..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64 bg-secondary pl-10"
            />
          </div>
        </div>

        <TabsContent value="all" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredForms.map((form) => (
              <Card key={form.id} className="bg-card border-border">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base font-semibold">{form.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{form.institute}</p>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => setShowPreview(true)}>
                          <Eye className="mr-2 h-4 w-4" />
                          Preview
                        </DropdownMenuItem>
                        <Link href="/payment-forms/builder">
                          <DropdownMenuItem>
                            <Settings className="mr-2 h-4 w-4" />
                            Edit Form
                          </DropdownMenuItem>
                        </Link>
                        <DropdownMenuItem onClick={() => copyUrl(form.url)}>
                          <Copy className="mr-2 h-4 w-4" />
                          Copy URL
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 rounded-lg bg-secondary/50 p-2">
                    <code className="flex-1 truncate text-xs text-muted-foreground">{form.url}</code>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyUrl(form.url)}>
                      <Copy className="h-3 w-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      <ExternalLink className="h-3 w-3" />
                    </Button>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Collections</p>
                      <p className="font-semibold">₹{(form.collections / 100000).toFixed(2)} L</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Transactions</p>
                      <p className="font-semibold">{form.transactions}</p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className={statusColors[form.status as keyof typeof statusColors]}>
                      {form.status}
                    </Badge>
                    <span className="text-xs text-muted-foreground">Created {form.createdAt}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="active" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredForms
              .filter((f) => f.status === "active")
              .map((form) => (
                <Card key={form.id} className="bg-card border-border">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-base font-semibold">{form.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{form.institute}</p>
                      </div>
                      <Badge variant="outline" className={statusColors.active}>
                        {form.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Collections</p>
                        <p className="font-semibold">₹{(form.collections / 100000).toFixed(2)} L</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Transactions</p>
                        <p className="font-semibold">{form.transactions}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="draft" className="mt-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredForms
              .filter((f) => f.status === "draft")
              .map((form) => (
                <Card key={form.id} className="bg-card border-border">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-base font-semibold">{form.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">{form.institute}</p>
                      </div>
                      <Badge variant="outline" className={statusColors.draft}>
                        {form.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full">Publish Form</Button>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>

      {showPreview && <PaymentFormPreview onClose={() => setShowPreview(false)} />}
    </div>
  )
}
