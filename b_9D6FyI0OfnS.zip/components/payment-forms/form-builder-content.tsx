"use client"

import { useState, useCallback } from "react"
import NextLink from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import {
  ArrowLeft,
  Plus,
  GripVertical,
  Copy,
  Trash2,
  Type,
  AlignLeft,
  Mail,
  Phone,
  Hash,
  List,
  ChevronDown,
  CheckSquare,
  Star,
  Upload,
  Calendar,
  MapPin,
  User,
  Users,
  GraduationCap,
  Building,
  FileText,
  CreditCard,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Eye,
  Settings,
  Palette,
  Share2,
  Smartphone,
  Monitor,
  Play,
  Save,
  MoreHorizontal,
  Link2,
  QrCode,
  Code,
  MessageSquare,
  Zap,
  Image,
  X,
} from "lucide-react"

// Types
interface FormBlock {
  id: string
  type: "welcome" | "question" | "payment" | "thankyou"
  questionType?: QuestionType
  title: string
  description?: string
  required?: boolean
  placeholder?: string
  options?: string[]
  paymentConfig?: PaymentConfig
  imageUrl?: string
  buttonText?: string
}

type QuestionType = 
  | "short_text" 
  | "long_text" 
  | "email" 
  | "phone" 
  | "number" 
  | "multiple_choice" 
  | "dropdown" 
  | "checkbox" 
  | "rating" 
  | "file_upload" 
  | "date" 
  | "address"
  | "student_name"
  | "parent_name"
  | "class_selection"
  | "previous_school"
  | "document_upload"

interface PaymentConfig {
  amount: number
  currency: string
  description: string
  paymentModes: string[]
  paymentType: "fixed" | "dynamic" | "optional"
  dynamicRules?: { condition: string; amount: number }[]
}

interface FormDesign {
  logo?: string
  primaryColor: string
  backgroundColor: string
  fontFamily: string
  buttonStyle: "rounded" | "square" | "pill"
  borderRadius: number
  backgroundImage?: string
}

interface LogicRule {
  id: string
  sourceBlockId: string
  condition: string
  value: string
  targetBlockId: string
}

const questionTypes: { type: QuestionType; label: string; icon: React.ReactNode; category: string }[] = [
  { type: "short_text", label: "Short Text", icon: <Type className="h-4 w-4" />, category: "Basic" },
  { type: "long_text", label: "Long Text", icon: <AlignLeft className="h-4 w-4" />, category: "Basic" },
  { type: "email", label: "Email", icon: <Mail className="h-4 w-4" />, category: "Basic" },
  { type: "phone", label: "Phone", icon: <Phone className="h-4 w-4" />, category: "Basic" },
  { type: "number", label: "Number", icon: <Hash className="h-4 w-4" />, category: "Basic" },
  { type: "multiple_choice", label: "Multiple Choice", icon: <List className="h-4 w-4" />, category: "Choice" },
  { type: "dropdown", label: "Dropdown", icon: <ChevronDown className="h-4 w-4" />, category: "Choice" },
  { type: "checkbox", label: "Checkbox", icon: <CheckSquare className="h-4 w-4" />, category: "Choice" },
  { type: "rating", label: "Rating Scale", icon: <Star className="h-4 w-4" />, category: "Choice" },
  { type: "file_upload", label: "File Upload", icon: <Upload className="h-4 w-4" />, category: "Advanced" },
  { type: "date", label: "Date Picker", icon: <Calendar className="h-4 w-4" />, category: "Advanced" },
  { type: "address", label: "Address", icon: <MapPin className="h-4 w-4" />, category: "Advanced" },
  { type: "student_name", label: "Student Name", icon: <User className="h-4 w-4" />, category: "Education" },
  { type: "parent_name", label: "Parent Name", icon: <Users className="h-4 w-4" />, category: "Education" },
  { type: "class_selection", label: "Class Selection", icon: <GraduationCap className="h-4 w-4" />, category: "Education" },
  { type: "previous_school", label: "Previous School", icon: <Building className="h-4 w-4" />, category: "Education" },
  { type: "document_upload", label: "Document Upload", icon: <FileText className="h-4 w-4" />, category: "Education" },
]

const templates = [
  { id: "admission", name: "Admission Form", description: "Complete student admission form" },
  { id: "registration", name: "Student Registration", description: "New student registration" },
  { id: "event", name: "Event Registration", description: "School event registration" },
  { id: "workshop", name: "Workshop Enrollment", description: "Workshop & training enrollment" },
  { id: "scholarship", name: "Scholarship Application", description: "Scholarship application form" },
]

// Initial form blocks
const initialBlocks: FormBlock[] = [
  {
    id: "welcome",
    type: "welcome",
    title: "Admission Form",
    description: "Welcome to ABC School Admission Portal",
    buttonText: "Start Application",
  },
  {
    id: "q1",
    type: "question",
    questionType: "student_name",
    title: "What is the student's name?",
    required: true,
    placeholder: "Enter full name",
  },
  {
    id: "q2",
    type: "question",
    questionType: "class_selection",
    title: "Which class are you applying for?",
    required: true,
    options: ["Nursery", "LKG", "UKG", "Class 1", "Class 2", "Class 3", "Class 4", "Class 5", "Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12"],
  },
  {
    id: "q3",
    type: "question",
    questionType: "parent_name",
    title: "Parent/Guardian's name?",
    required: true,
    placeholder: "Enter parent's full name",
  },
  {
    id: "q4",
    type: "question",
    questionType: "phone",
    title: "Contact number?",
    required: true,
    placeholder: "+91 98765 43210",
  },
  {
    id: "q5",
    type: "question",
    questionType: "email",
    title: "Email address?",
    required: true,
    placeholder: "parent@email.com",
  },
  {
    id: "q6",
    type: "question",
    questionType: "document_upload",
    title: "Upload required documents",
    description: "Please upload birth certificate, previous school records, and passport photos",
    required: true,
  },
  {
    id: "payment",
    type: "payment",
    title: "Application Fee",
    description: "Pay the application processing fee",
    paymentConfig: {
      amount: 500,
      currency: "INR",
      description: "Application Processing Fee",
      paymentModes: ["upi", "card", "netbanking"],
      paymentType: "fixed",
    },
  },
  {
    id: "thankyou",
    type: "thankyou",
    title: "Application Submitted!",
    description: "Thank you for your application. We will contact you within 3-5 business days.",
  },
]

const initialDesign: FormDesign = {
  primaryColor: "#6366f1",
  backgroundColor: "#ffffff",
  fontFamily: "Inter",
  buttonStyle: "rounded",
  borderRadius: 12,
}

export function FormBuilderContent() {
  const [blocks, setBlocks] = useState<FormBlock[]>(initialBlocks)
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>("welcome")
  const [currentPreviewIndex, setCurrentPreviewIndex] = useState(0)
  const [design, setDesign] = useState<FormDesign>(initialDesign)
  const [logicRules, setLogicRules] = useState<LogicRule[]>([])
  const [rightPanelTab, setRightPanelTab] = useState<"settings" | "design" | "logic" | "share">("settings")
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "mobile">("desktop")
  const [isPreviewMode, setIsPreviewMode] = useState(false)
  const [draggedBlockId, setDraggedBlockId] = useState<string | null>(null)

  const selectedBlock = blocks.find(b => b.id === selectedBlockId)

  const addQuestion = (type: QuestionType) => {
    const newBlock: FormBlock = {
      id: `q${Date.now()}`,
      type: "question",
      questionType: type,
      title: `New ${questionTypes.find(q => q.type === type)?.label || "Question"}`,
      required: false,
      placeholder: "",
      options: type === "multiple_choice" || type === "dropdown" || type === "checkbox" ? ["Option 1", "Option 2"] : undefined,
    }
    // Insert before payment block
    const paymentIndex = blocks.findIndex(b => b.type === "payment")
    const newBlocks = [...blocks]
    newBlocks.splice(paymentIndex, 0, newBlock)
    setBlocks(newBlocks)
    setSelectedBlockId(newBlock.id)
  }

  const updateBlock = (id: string, updates: Partial<FormBlock>) => {
    setBlocks(blocks.map(b => b.id === id ? { ...b, ...updates } : b))
  }

  const deleteBlock = (id: string) => {
    if (blocks.find(b => b.id === id)?.type === "welcome" || blocks.find(b => b.id === id)?.type === "thankyou") return
    setBlocks(blocks.filter(b => b.id !== id))
    setSelectedBlockId(null)
  }

  const duplicateBlock = (id: string) => {
    const block = blocks.find(b => b.id === id)
    if (!block || block.type === "welcome" || block.type === "thankyou" || block.type === "payment") return
    const index = blocks.findIndex(b => b.id === id)
    const newBlock = { ...block, id: `q${Date.now()}`, title: `${block.title} (Copy)` }
    const newBlocks = [...blocks]
    newBlocks.splice(index + 1, 0, newBlock)
    setBlocks(newBlocks)
  }

  const moveBlock = (fromIndex: number, toIndex: number) => {
    const block = blocks[fromIndex]
    // Don't allow moving welcome, payment, or thankyou blocks
    if (block.type === "welcome" || block.type === "thankyou" || block.type === "payment") return
    // Don't allow moving to before welcome or after thankyou
    if (toIndex === 0 || toIndex >= blocks.length - 1) return
    
    const newBlocks = [...blocks]
    newBlocks.splice(fromIndex, 1)
    newBlocks.splice(toIndex, 0, block)
    setBlocks(newBlocks)
  }

  const getBlockIcon = (block: FormBlock) => {
    if (block.type === "welcome") return <Sparkles className="h-4 w-4" />
    if (block.type === "payment") return <CreditCard className="h-4 w-4" />
    if (block.type === "thankyou") return <CheckSquare className="h-4 w-4" />
    const qt = questionTypes.find(q => q.type === block.questionType)
    return qt?.icon || <Type className="h-4 w-4" />
  }

  const navigatePreview = (direction: "prev" | "next") => {
    if (direction === "prev" && currentPreviewIndex > 0) {
      setCurrentPreviewIndex(currentPreviewIndex - 1)
    } else if (direction === "next" && currentPreviewIndex < blocks.length - 1) {
      setCurrentPreviewIndex(currentPreviewIndex + 1)
    }
  }

  return (
    <div className="flex h-[calc(100vh-64px)] flex-col">
      {/* Top Bar */}
      <div className="flex h-14 items-center justify-between border-b border-border bg-card px-4">
        <div className="flex items-center gap-4">
          <NextLink href="/payment-forms">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </NextLink>
          <div>
            <Input 
              value="Admission Form - ABC School" 
              className="h-8 border-none bg-transparent text-lg font-semibold focus-visible:ring-0 px-0"
            />
          </div>
          <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">Draft</Badge>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-lg border border-border p-1">
            <Button
              variant={previewDevice === "desktop" ? "secondary" : "ghost"}
              size="sm"
              className="h-7 px-2"
              onClick={() => setPreviewDevice("desktop")}
            >
              <Monitor className="h-4 w-4" />
            </Button>
            <Button
              variant={previewDevice === "mobile" ? "secondary" : "ghost"}
              size="sm"
              className="h-7 px-2"
              onClick={() => setPreviewDevice("mobile")}
            >
              <Smartphone className="h-4 w-4" />
            </Button>
          </div>
          <Button variant="outline" size="sm" onClick={() => setIsPreviewMode(!isPreviewMode)}>
            <Play className="mr-2 h-4 w-4" />
            {isPreviewMode ? "Exit Preview" : "Preview"}
          </Button>
          <Button variant="outline" size="sm">
            <Save className="mr-2 h-4 w-4" />
            Save
          </Button>
          <Button size="sm">
            Publish
          </Button>
        </div>
      </div>

      {/* Main Builder Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Form Flow */}
        <div className="w-72 border-r border-border bg-card flex flex-col">
          <div className="p-4 border-b border-border">
            <h3 className="font-semibold text-sm text-foreground">Form Structure</h3>
            <p className="text-xs text-muted-foreground mt-1">{blocks.length} blocks</p>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-3 space-y-1">
              {blocks.map((block, index) => (
                <div
                  key={block.id}
                  draggable={block.type === "question"}
                  onDragStart={() => setDraggedBlockId(block.id)}
                  onDragEnd={() => setDraggedBlockId(null)}
                  onDragOver={(e) => {
                    e.preventDefault()
                    if (draggedBlockId && draggedBlockId !== block.id) {
                      const fromIndex = blocks.findIndex(b => b.id === draggedBlockId)
                      moveBlock(fromIndex, index)
                    }
                  }}
                  className={`
                    group flex items-center gap-2 rounded-lg p-2.5 cursor-pointer transition-all
                    ${selectedBlockId === block.id 
                      ? "bg-primary/10 border border-primary/30" 
                      : "hover:bg-secondary/50 border border-transparent"
                    }
                    ${draggedBlockId === block.id ? "opacity-50" : ""}
                  `}
                  onClick={() => {
                    setSelectedBlockId(block.id)
                    setCurrentPreviewIndex(index)
                  }}
                >
                  {block.type === "question" && (
                    <GripVertical className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 cursor-grab" />
                  )}
                  {block.type !== "question" && <div className="w-4" />}
                  <div className={`
                    flex h-8 w-8 items-center justify-center rounded-lg
                    ${block.type === "welcome" ? "bg-primary/20 text-primary" : ""}
                    ${block.type === "question" ? "bg-secondary text-foreground" : ""}
                    ${block.type === "payment" ? "bg-success/20 text-success" : ""}
                    ${block.type === "thankyou" ? "bg-primary/20 text-primary" : ""}
                  `}>
                    {getBlockIcon(block)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{block.title}</p>
                    <p className="text-xs text-muted-foreground capitalize">
                      {block.type === "question" ? block.questionType?.replace("_", " ") : block.type}
                    </p>
                  </div>
                  {block.required && (
                    <span className="text-destructive text-xs">*</span>
                  )}
                  {block.type === "question" && (
                    <div className="opacity-0 group-hover:opacity-100 flex gap-1">
                      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={(e) => { e.stopPropagation(); duplicateBlock(block.id); }}>
                        <Copy className="h-3 w-3" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={(e) => { e.stopPropagation(); deleteBlock(block.id); }}>
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Add Question Button */}
          <div className="p-3 border-t border-border">
            <Popover>
              <PopoverTrigger asChild>
                <Button className="w-full gap-2">
                  <Plus className="h-4 w-4" />
                  Add Question
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 p-0" align="start">
                <div className="p-3 border-b border-border">
                  <h4 className="font-semibold">Add Question Block</h4>
                  <p className="text-xs text-muted-foreground">Choose a question type</p>
                </div>
                <ScrollArea className="h-80">
                  <div className="p-2">
                    {["Basic", "Choice", "Advanced", "Education"].map(category => (
                      <div key={category} className="mb-3">
                        <p className="text-xs font-medium text-muted-foreground px-2 mb-1">{category}</p>
                        <div className="space-y-0.5">
                          {questionTypes.filter(q => q.category === category).map(qt => (
                            <button
                              key={qt.type}
                              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-secondary transition-colors text-left"
                              onClick={() => addQuestion(qt.type)}
                            >
                              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary">
                                {qt.icon}
                              </div>
                              <span className="text-sm">{qt.label}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {/* Center Panel - Conversational Preview */}
        <div className="flex-1 bg-secondary/30 flex flex-col items-center justify-center p-8 relative overflow-hidden">
          {/* Preview Controls */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-card rounded-full px-4 py-2 shadow-lg border border-border">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full"
              onClick={() => navigatePreview("prev")}
              disabled={currentPreviewIndex === 0}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm text-muted-foreground min-w-[80px] text-center">
              {currentPreviewIndex + 1} / {blocks.length}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full"
              onClick={() => navigatePreview("next")}
              disabled={currentPreviewIndex === blocks.length - 1}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Preview Frame */}
          <div 
            className={`
              bg-background rounded-2xl shadow-2xl border border-border overflow-hidden transition-all duration-300
              ${previewDevice === "mobile" ? "w-[375px] h-[667px]" : "w-full max-w-2xl h-[600px]"}
            `}
            style={{ backgroundColor: design.backgroundColor }}
          >
            <div className="h-full flex flex-col">
              {/* Preview Header Progress */}
              <div className="h-1 bg-secondary">
                <div 
                  className="h-full transition-all duration-300"
                  style={{ 
                    width: `${((currentPreviewIndex + 1) / blocks.length) * 100}%`,
                    backgroundColor: design.primaryColor
                  }}
                />
              </div>

              {/* Preview Content */}
              <div className="flex-1 flex items-center justify-center p-8">
                <PreviewBlock 
                  block={blocks[currentPreviewIndex]} 
                  design={design}
                  onNext={() => navigatePreview("next")}
                  isLast={currentPreviewIndex === blocks.length - 1}
                />
              </div>

              {/* Preview Footer */}
              <div className="p-4 border-t border-border flex items-center justify-between">
                <p className="text-xs text-muted-foreground">Powered by Edviron</p>
                {blocks[currentPreviewIndex].type === "question" && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Press Enter ↵</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Panel - Customization */}
        <div className="w-80 border-l border-border bg-card flex flex-col">
          <Tabs value={rightPanelTab} onValueChange={(v) => setRightPanelTab(v as typeof rightPanelTab)} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-4 bg-secondary/50 rounded-none border-b border-border">
              <TabsTrigger value="settings" className="gap-1.5 text-xs">
                <Settings className="h-3.5 w-3.5" />
                Settings
              </TabsTrigger>
              <TabsTrigger value="design" className="gap-1.5 text-xs">
                <Palette className="h-3.5 w-3.5" />
                Design
              </TabsTrigger>
              <TabsTrigger value="logic" className="gap-1.5 text-xs">
                <Zap className="h-3.5 w-3.5" />
                Logic
              </TabsTrigger>
              <TabsTrigger value="share" className="gap-1.5 text-xs">
                <Share2 className="h-3.5 w-3.5" />
                Share
              </TabsTrigger>
            </TabsList>

            <TabsContent value="settings" className="flex-1 m-0 overflow-hidden">
              <ScrollArea className="h-full">
                {selectedBlock ? (
                  <div className="p-4 space-y-6">
                    {/* Block Settings */}
                    {selectedBlock.type === "welcome" && (
                      <WelcomeBlockSettings block={selectedBlock} onUpdate={(updates) => updateBlock(selectedBlock.id, updates)} />
                    )}
                    {selectedBlock.type === "question" && (
                      <QuestionBlockSettings block={selectedBlock} onUpdate={(updates) => updateBlock(selectedBlock.id, updates)} />
                    )}
                    {selectedBlock.type === "payment" && (
                      <PaymentBlockSettings block={selectedBlock} onUpdate={(updates) => updateBlock(selectedBlock.id, updates)} />
                    )}
                    {selectedBlock.type === "thankyou" && (
                      <ThankYouBlockSettings block={selectedBlock} onUpdate={(updates) => updateBlock(selectedBlock.id, updates)} />
                    )}
                  </div>
                ) : (
                  <div className="p-4 text-center text-muted-foreground">
                    <p>Select a block to edit its settings</p>
                  </div>
                )}
              </ScrollArea>
            </TabsContent>

            <TabsContent value="design" className="flex-1 m-0 overflow-hidden">
              <ScrollArea className="h-full">
                <DesignSettings design={design} onUpdate={setDesign} />
              </ScrollArea>
            </TabsContent>

            <TabsContent value="logic" className="flex-1 m-0 overflow-hidden">
              <ScrollArea className="h-full">
                <LogicBuilder blocks={blocks} rules={logicRules} onRulesChange={setLogicRules} />
              </ScrollArea>
            </TabsContent>

            <TabsContent value="share" className="flex-1 m-0 overflow-hidden">
              <ScrollArea className="h-full">
                <ShareSettings />
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

// Preview Block Component
function PreviewBlock({ block, design, onNext, isLast }: { block: FormBlock; design: FormDesign; onNext: () => void; isLast: boolean }) {
  const [value, setValue] = useState("")

  if (block.type === "welcome") {
    return (
      <div className="text-center space-y-6 max-w-md">
        {block.imageUrl && (
          <div className="h-20 w-20 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center">
            <Sparkles className="h-10 w-10 text-primary" />
          </div>
        )}
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-3">{block.title}</h1>
          <p className="text-lg text-muted-foreground">{block.description}</p>
        </div>
        <Button 
          size="lg" 
          className="px-8 rounded-full"
          style={{ backgroundColor: design.primaryColor }}
          onClick={onNext}
        >
          {block.buttonText || "Start"}
          <ChevronRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    )
  }

  if (block.type === "thankyou") {
    return (
      <div className="text-center space-y-6 max-w-md">
        <div className="h-20 w-20 mx-auto rounded-full bg-success/20 flex items-center justify-center">
          <CheckSquare className="h-10 w-10 text-success" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-3">{block.title}</h1>
          <p className="text-lg text-muted-foreground">{block.description}</p>
        </div>
      </div>
    )
  }

  if (block.type === "payment") {
    return (
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-2">{block.title}</h2>
          <p className="text-muted-foreground">{block.description}</p>
        </div>
        
        <Card className="border-2">
          <CardContent className="p-6">
            <div className="text-center mb-6">
              <p className="text-sm text-muted-foreground">Amount to pay</p>
              <p className="text-4xl font-bold" style={{ color: design.primaryColor }}>
                ₹{block.paymentConfig?.amount?.toLocaleString()}
              </p>
            </div>
            
            <div className="space-y-3">
              <p className="text-sm font-medium text-center">Select Payment Method</p>
              <div className="grid grid-cols-3 gap-3">
                <button className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-primary bg-primary/5">
                  <Smartphone className="h-6 w-6" />
                  <span className="text-xs font-medium">UPI</span>
                </button>
                <button className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-border hover:border-primary/50">
                  <CreditCard className="h-6 w-6" />
                  <span className="text-xs font-medium">Card</span>
                </button>
                <button className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-border hover:border-primary/50">
                  <Building className="h-6 w-6" />
                  <span className="text-xs font-medium">Bank</span>
                </button>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Button 
          size="lg" 
          className="w-full rounded-xl"
          style={{ backgroundColor: design.primaryColor }}
        >
          Pay ₹{block.paymentConfig?.amount?.toLocaleString()}
        </Button>
      </div>
    )
  }

  // Question block
  return (
    <div className="w-full max-w-md space-y-6">
      <div>
        <div className="flex items-start gap-2 mb-2">
          <span className="text-2xl font-bold text-primary">→</span>
          <h2 className="text-2xl font-bold text-foreground">
            {block.title}
            {block.required && <span className="text-destructive ml-1">*</span>}
          </h2>
        </div>
        {block.description && (
          <p className="text-muted-foreground ml-8">{block.description}</p>
        )}
      </div>

      <div className="ml-8">
        {(block.questionType === "short_text" || block.questionType === "student_name" || block.questionType === "parent_name" || block.questionType === "previous_school") && (
          <Input
            placeholder={block.placeholder || "Type your answer here..."}
            className="text-lg h-14 bg-transparent border-0 border-b-2 rounded-none focus-visible:ring-0 focus-visible:border-primary px-0"
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        )}

        {block.questionType === "long_text" && (
          <Textarea
            placeholder={block.placeholder || "Type your answer here..."}
            className="text-lg min-h-[120px] bg-transparent border-0 border-b-2 rounded-none focus-visible:ring-0 focus-visible:border-primary px-0 resize-none"
          />
        )}

        {block.questionType === "email" && (
          <Input
            type="email"
            placeholder={block.placeholder || "email@example.com"}
            className="text-lg h-14 bg-transparent border-0 border-b-2 rounded-none focus-visible:ring-0 focus-visible:border-primary px-0"
          />
        )}

        {block.questionType === "phone" && (
          <Input
            type="tel"
            placeholder={block.placeholder || "+91 98765 43210"}
            className="text-lg h-14 bg-transparent border-0 border-b-2 rounded-none focus-visible:ring-0 focus-visible:border-primary px-0"
          />
        )}

        {(block.questionType === "dropdown" || block.questionType === "class_selection") && (
          <Select>
            <SelectTrigger className="text-lg h-14 bg-transparent border-0 border-b-2 rounded-none focus:ring-0 px-0">
              <SelectValue placeholder="Select an option..." />
            </SelectTrigger>
            <SelectContent>
              {block.options?.map((opt, i) => (
                <SelectItem key={i} value={opt}>{opt}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {block.questionType === "multiple_choice" && (
          <div className="space-y-2">
            {block.options?.map((opt, i) => (
              <button
                key={i}
                className="w-full flex items-center gap-3 p-4 rounded-xl border-2 border-border hover:border-primary/50 text-left transition-colors"
              >
                <div className="h-6 w-6 rounded-full border-2 border-border flex items-center justify-center text-sm font-medium">
                  {String.fromCharCode(65 + i)}
                </div>
                <span>{opt}</span>
              </button>
            ))}
          </div>
        )}

        {(block.questionType === "file_upload" || block.questionType === "document_upload") && (
          <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
            <Upload className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Click to upload or drag and drop</p>
            <p className="text-xs text-muted-foreground mt-1">PDF, DOC, JPG, PNG (max 10MB)</p>
          </div>
        )}

        {block.questionType === "date" && (
          <Input
            type="date"
            className="text-lg h-14 bg-transparent border-0 border-b-2 rounded-none focus-visible:ring-0 focus-visible:border-primary px-0"
          />
        )}

        {block.questionType === "rating" && (
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((n) => (
              <button key={n} className="h-12 w-12 rounded-xl border-2 border-border hover:border-primary/50 hover:bg-primary/5 text-lg font-medium transition-colors">
                {n}
              </button>
            ))}
          </div>
        )}
      </div>

      {!isLast && (
        <div className="ml-8">
          <Button 
            onClick={onNext}
            style={{ backgroundColor: design.primaryColor }}
            className="rounded-lg"
          >
            OK
            <CheckSquare className="ml-2 h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
}

// Settings Components
function WelcomeBlockSettings({ block, onUpdate }: { block: FormBlock; onUpdate: (updates: Partial<FormBlock>) => void }) {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Title</Label>
        <Input
          value={block.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
          placeholder="Welcome to our form"
        />
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Textarea
          value={block.description || ""}
          onChange={(e) => onUpdate({ description: e.target.value })}
          placeholder="Add a description..."
          rows={3}
        />
      </div>
      <div className="space-y-2">
        <Label>Button Text</Label>
        <Input
          value={block.buttonText || "Start"}
          onChange={(e) => onUpdate({ buttonText: e.target.value })}
          placeholder="Start"
        />
      </div>
      <div className="space-y-2">
        <Label>Image</Label>
        <div className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:border-primary/50 transition-colors">
          <Image className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Click to upload image</p>
        </div>
      </div>
    </div>
  )
}

function QuestionBlockSettings({ block, onUpdate }: { block: FormBlock; onUpdate: (updates: Partial<FormBlock>) => void }) {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Question Type</Label>
        <Select
          value={block.questionType}
          onValueChange={(v) => onUpdate({ questionType: v as QuestionType })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {questionTypes.map(qt => (
              <SelectItem key={qt.type} value={qt.type}>
                <div className="flex items-center gap-2">
                  {qt.icon}
                  {qt.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label>Question Title</Label>
        <Input
          value={block.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
          placeholder="Your question here"
        />
      </div>
      
      <div className="space-y-2">
        <Label>Description (Optional)</Label>
        <Textarea
          value={block.description || ""}
          onChange={(e) => onUpdate({ description: e.target.value })}
          placeholder="Add helpful text..."
          rows={2}
        />
      </div>
      
      <div className="space-y-2">
        <Label>Placeholder</Label>
        <Input
          value={block.placeholder || ""}
          onChange={(e) => onUpdate({ placeholder: e.target.value })}
          placeholder="Type here..."
        />
      </div>
      
      <div className="flex items-center justify-between">
        <Label>Required</Label>
        <Switch
          checked={block.required || false}
          onCheckedChange={(checked) => onUpdate({ required: checked })}
        />
      </div>

      {(block.questionType === "multiple_choice" || block.questionType === "dropdown" || block.questionType === "checkbox") && (
        <div className="space-y-2">
          <Label>Options</Label>
          <div className="space-y-2">
            {block.options?.map((opt, i) => (
              <div key={i} className="flex gap-2">
                <Input
                  value={opt}
                  onChange={(e) => {
                    const newOptions = [...(block.options || [])]
                    newOptions[i] = e.target.value
                    onUpdate({ options: newOptions })
                  }}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const newOptions = block.options?.filter((_, idx) => idx !== i)
                    onUpdate({ options: newOptions })
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <Button
              variant="outline"
              size="sm"
              onClick={() => onUpdate({ options: [...(block.options || []), `Option ${(block.options?.length || 0) + 1}`] })}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Option
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

function PaymentBlockSettings({ block, onUpdate }: { block: FormBlock; onUpdate: (updates: Partial<FormBlock>) => void }) {
  const config = block.paymentConfig || { amount: 0, currency: "INR", description: "", paymentModes: [], paymentType: "fixed" as const }
  
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Title</Label>
        <Input
          value={block.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
        />
      </div>
      
      <div className="space-y-2">
        <Label>Description</Label>
        <Textarea
          value={block.description || ""}
          onChange={(e) => onUpdate({ description: e.target.value })}
          rows={2}
        />
      </div>
      
      <Separator />
      
      <div className="space-y-2">
        <Label>Payment Type</Label>
        <Select
          value={config.paymentType}
          onValueChange={(v) => onUpdate({ paymentConfig: { ...config, paymentType: v as "fixed" | "dynamic" | "optional" } })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="fixed">Fixed Amount</SelectItem>
            <SelectItem value="dynamic">Dynamic (Based on Class)</SelectItem>
            <SelectItem value="optional">Optional Payment</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label>Amount (₹)</Label>
        <Input
          type="number"
          value={config.amount}
          onChange={(e) => onUpdate({ paymentConfig: { ...config, amount: Number(e.target.value) } })}
        />
      </div>
      
      <div className="space-y-2">
        <Label>Payment Description</Label>
        <Input
          value={config.description}
          onChange={(e) => onUpdate({ paymentConfig: { ...config, description: e.target.value } })}
          placeholder="Application Fee, Registration Fee, etc."
        />
      </div>
      
      <div className="space-y-2">
        <Label>Payment Methods</Label>
        <div className="space-y-2">
          {["upi", "card", "netbanking", "wallet"].map(mode => (
            <div key={mode} className="flex items-center justify-between">
              <span className="text-sm capitalize">{mode}</span>
              <Switch
                checked={config.paymentModes.includes(mode)}
                onCheckedChange={(checked) => {
                  const newModes = checked
                    ? [...config.paymentModes, mode]
                    : config.paymentModes.filter(m => m !== mode)
                  onUpdate({ paymentConfig: { ...config, paymentModes: newModes } })
                }}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function ThankYouBlockSettings({ block, onUpdate }: { block: FormBlock; onUpdate: (updates: Partial<FormBlock>) => void }) {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Success Message</Label>
        <Input
          value={block.title}
          onChange={(e) => onUpdate({ title: e.target.value })}
          placeholder="Thank you!"
        />
      </div>
      <div className="space-y-2">
        <Label>Description</Label>
        <Textarea
          value={block.description || ""}
          onChange={(e) => onUpdate({ description: e.target.value })}
          placeholder="Your submission has been received..."
          rows={3}
        />
      </div>
      <div className="space-y-2">
        <Label>Redirect URL (Optional)</Label>
        <Input
          placeholder="https://yourwebsite.com/success"
        />
      </div>
    </div>
  )
}

function DesignSettings({ design, onUpdate }: { design: FormDesign; onUpdate: (design: FormDesign) => void }) {
  return (
    <div className="p-4 space-y-6">
      <div className="space-y-2">
        <Label>Logo</Label>
        <div className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:border-primary/50 transition-colors">
          <Image className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Upload logo</p>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label>Primary Color</Label>
        <div className="flex gap-2">
          <Input
            type="color"
            value={design.primaryColor}
            onChange={(e) => onUpdate({ ...design, primaryColor: e.target.value })}
            className="w-12 h-10 p-1 cursor-pointer"
          />
          <Input
            value={design.primaryColor}
            onChange={(e) => onUpdate({ ...design, primaryColor: e.target.value })}
            className="flex-1"
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label>Background Color</Label>
        <div className="flex gap-2">
          <Input
            type="color"
            value={design.backgroundColor}
            onChange={(e) => onUpdate({ ...design, backgroundColor: e.target.value })}
            className="w-12 h-10 p-1 cursor-pointer"
          />
          <Input
            value={design.backgroundColor}
            onChange={(e) => onUpdate({ ...design, backgroundColor: e.target.value })}
            className="flex-1"
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label>Font Family</Label>
        <Select
          value={design.fontFamily}
          onValueChange={(v) => onUpdate({ ...design, fontFamily: v })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Inter">Inter</SelectItem>
            <SelectItem value="Roboto">Roboto</SelectItem>
            <SelectItem value="Poppins">Poppins</SelectItem>
            <SelectItem value="Open Sans">Open Sans</SelectItem>
            <SelectItem value="Lato">Lato</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label>Button Style</Label>
        <Select
          value={design.buttonStyle}
          onValueChange={(v) => onUpdate({ ...design, buttonStyle: v as FormDesign["buttonStyle"] })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="rounded">Rounded</SelectItem>
            <SelectItem value="square">Square</SelectItem>
            <SelectItem value="pill">Pill</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label>Border Radius: {design.borderRadius}px</Label>
        <input
          type="range"
          min="0"
          max="24"
          value={design.borderRadius}
          onChange={(e) => onUpdate({ ...design, borderRadius: Number(e.target.value) })}
          className="w-full"
        />
      </div>
      
      <div className="space-y-2">
        <Label>Background Image</Label>
        <div className="border-2 border-dashed border-border rounded-lg p-4 text-center cursor-pointer hover:border-primary/50 transition-colors">
          <Image className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Upload background image</p>
        </div>
      </div>
    </div>
  )
}

function LogicBuilder({ blocks, rules, onRulesChange }: { blocks: FormBlock[]; rules: LogicRule[]; onRulesChange: (rules: LogicRule[]) => void }) {
  const questionBlocks = blocks.filter(b => b.type === "question")
  
  const addRule = () => {
    const newRule: LogicRule = {
      id: `rule_${Date.now()}`,
      sourceBlockId: questionBlocks[0]?.id || "",
      condition: "equals",
      value: "",
      targetBlockId: questionBlocks[1]?.id || "",
    }
    onRulesChange([...rules, newRule])
  }
  
  return (
    <div className="p-4 space-y-4">
      <div className="text-center py-6">
        <Zap className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
        <h3 className="font-semibold mb-1">Conditional Logic</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Show or hide questions based on previous answers
        </p>
        <Button onClick={addRule}>
          <Plus className="h-4 w-4 mr-2" />
          Add Logic Rule
        </Button>
      </div>
      
      {rules.map((rule, index) => (
        <Card key={rule.id} className="bg-secondary/30">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Rule {index + 1}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => onRulesChange(rules.filter(r => r.id !== rule.id))}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
            
            <div className="space-y-2">
              <Label className="text-xs">If</Label>
              <Select value={rule.sourceBlockId} onValueChange={(v) => {
                const updated = rules.map(r => r.id === rule.id ? { ...r, sourceBlockId: v } : r)
                onRulesChange(updated)
              }}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue placeholder="Select question" />
                </SelectTrigger>
                <SelectContent>
                  {questionBlocks.map(b => (
                    <SelectItem key={b.id} value={b.id}>{b.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-xs">Condition</Label>
                <Select value={rule.condition} onValueChange={(v) => {
                  const updated = rules.map(r => r.id === rule.id ? { ...r, condition: v } : r)
                  onRulesChange(updated)
                }}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="equals">Equals</SelectItem>
                    <SelectItem value="contains">Contains</SelectItem>
                    <SelectItem value="not_equals">Not Equals</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Value</Label>
                <Input
                  className="h-8 text-xs"
                  value={rule.value}
                  onChange={(e) => {
                    const updated = rules.map(r => r.id === rule.id ? { ...r, value: e.target.value } : r)
                    onRulesChange(updated)
                  }}
                  placeholder="Enter value"
                />
              </div>
            </div>
            
            <div className="space-y-1">
              <Label className="text-xs">Then show</Label>
              <Select value={rule.targetBlockId} onValueChange={(v) => {
                const updated = rules.map(r => r.id === rule.id ? { ...r, targetBlockId: v } : r)
                onRulesChange(updated)
              }}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue placeholder="Select question" />
                </SelectTrigger>
                <SelectContent>
                  {questionBlocks.map(b => (
                    <SelectItem key={b.id} value={b.id}>{b.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

function ShareSettings() {
  const formUrl = "https://forms.edviron.com/abc-school/admission"
  
  return (
    <div className="p-4 space-y-6">
      <div className="space-y-3">
        <Label>Form Link</Label>
        <div className="flex gap-2">
          <Input value={formUrl} readOnly className="text-sm" />
          <Button variant="outline" size="icon">
            <Copy className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <Separator />
      
      <div className="space-y-3">
        <Label>Share Options</Label>
        <div className="grid grid-cols-2 gap-3">
          <Button variant="outline" className="h-auto py-4 flex-col gap-2">
            <Link2 className="h-5 w-5" />
            <span className="text-xs">Copy Link</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex-col gap-2">
            <QrCode className="h-5 w-5" />
            <span className="text-xs">QR Code</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex-col gap-2">
            <Code className="h-5 w-5" />
            <span className="text-xs">Embed</span>
          </Button>
          <Button variant="outline" className="h-auto py-4 flex-col gap-2">
            <MessageSquare className="h-5 w-5" />
            <span className="text-xs">WhatsApp</span>
          </Button>
        </div>
      </div>
      
      <Separator />
      
      <div className="space-y-3">
        <Label>Embed Code</Label>
        <Textarea
          readOnly
          rows={4}
          className="font-mono text-xs"
          value={`<iframe src="${formUrl}" width="100%" height="600" frameborder="0"></iframe>`}
        />
        <Button variant="outline" className="w-full">
          <Copy className="h-4 w-4 mr-2" />
          Copy Embed Code
        </Button>
      </div>
      
      <Separator />
      
      <div className="space-y-3">
        <Label>Email Sharing</Label>
        <Input placeholder="Enter email addresses" />
        <Button className="w-full">
          <Mail className="h-4 w-4 mr-2" />
          Send Invite
        </Button>
      </div>
    </div>
  )
}
