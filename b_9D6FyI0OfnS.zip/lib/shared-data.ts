// Unified Shared Data Module
// Syncs data across Transaction, Refund, Settlement, Chargeback, and Split Payment modules
// Based on actual transaction CSV data structure

// ============================================
// TYPE DEFINITIONS
// ============================================

export type TransactionStatus = "success" | "pending" | "failed" | "refunded" | "user_dropped"
export type RefundStatus = "completed" | "pending" | "initiated" | "failed" | "rejected"
export type ChargebackStatus = "open" | "under_review" | "response_submitted" | "won" | "lost" | "expired"
export type SettlementStatus = "settled" | "pending" | "processing" | "failed"
export type SplitStatus = "settled" | "pending" | "processing" | "failed"
export type MdrBearing = "merchant" | "surcharge" | "parent"

export interface Student {
  id: string
  name: string
  email: string
  phone: string
  class: string
  division: string
  rollNumber: string
  enrollmentNumber: string
}

export interface Institute {
  id: string
  name: string
  code: string
}

export interface PaymentInstrument {
  type: string
  details: string
  cardBrand?: string
  cardType?: string
  cardIssuer?: string
  cardIssuingBank?: string
  psp?: string
  upiId?: string
  walletName?: string
  bankName?: string
}

export interface FinancingDetails {
  category: string
  type: string
  tenure?: number
  amount?: number
  costBearing?: string
  partialCostSharing?: string
  nbfcPartner?: string
  collectionType?: string
  charges?: {
    totalCharges: number
    parentChargePercentage: number
    parentCharge: number
    instituteChargePercentage: number
    instituteCharge: number
    bankChargePercentage: number
    bankCharge: number
    subventionAmount?: number
  }
}

export interface SplitBeneficiary {
  beneficiary: string
  account: string
  ifsc: string
  amount: number
  percentage: number
  status: SplitStatus
}

export interface SplitPaymentInstallment {
  splitNumber: number
  amount: number
  dueDate: string
  paidDate?: string
  paidTime?: string
  status: "completed" | "pending" | "failed" | "overdue"
  paymentMode?: string
  mdrPercentage?: number
  mdrAmount?: number
  erpCommissionPercentage?: number
  erpCommission?: number
  netAmount?: number
  gatewayTransactionId?: string
  transactionId?: string
}

export interface RefundDetails {
  refundId: string
  refundStatus: RefundStatus
  refundDate: string
  refundArn?: string
  refundReason: string
  originalOrderAmount: number
  pgChargesDeducted: number
  erpCommissionDeducted: number
  netRefundToParent: number
}

export interface ChargebackDetails {
  chargebackId: string
  chargebackStatus: ChargebackStatus
  chargebackDate: string
  chargebackAmount: number
  chargebackReason: string
  disputeDeadline: string
  evidenceSubmitted: boolean
  responseSubmittedAt?: string
  arbNumber?: string
  chargebackFee: number
}

export interface TransactionLifecycleEvent {
  event: string
  timestamp: string
  description: string
  status: "success" | "warning" | "error"
  metadata?: Record<string, string>
}

export interface CustomFields {
  fatherName?: string
  motherName?: string
  session?: string
  admissionNumber?: string
  [key: string]: string | undefined
}

export interface Transaction {
  id: string
  orderId: string
  edvironOrderId: string
  gatewayTransactionId: string
  bankReferenceNumber: string
  status: TransactionStatus
  statusReason: string
  orderAmount: number
  transactionAmount: number
  vendorAmount: number
  gateway: string
  paymentMode: string
  channel: string
  date: string
  time: string
  student: Student
  institute: Institute
  feeType: string
  mdrAmount: number
  mdrPercentage: number
  mdrBearing: MdrBearing
  erpCommission: number
  erpCommissionPercentage: number
  instrument: PaymentInstrument
  isSettled: boolean
  settlementId?: string
  settlementUtr?: string
  settlementDate?: string
  isSplitPayment: boolean
  isInternational: boolean
  internationalMethod?: string
  currency: string
  originalAmount?: number
  exchangeRate?: number
  captureApiUsed: boolean
  captureStatus?: string
  authorizedAt?: string
  capturedAt?: string
  financing?: FinancingDetails
  autopayDetails?: {
    mandateId: string
    mandateType: string
    mandateStatus: string
    maxAmount: number
    frequency: string
    validUntil: string
  }
  schoolCounterDetails?: {
    mode: string
    receiptNumber: string
    collectedBy: string
    collectionDate: string
  }
  bankTransferDetails?: {
    type: string
    bankName: string
    utrNumber: string
    branchName: string
  }
  splitPayTimeline?: SplitPaymentInstallment[]
  splitPayModes?: { mode: string; amount: number; status: string; [key: string]: unknown }[]
  refundDetails?: RefundDetails
  chargebackDetails?: ChargebackDetails
  transactionLifecycle?: TransactionLifecycleEvent[]
  splitDetails?: SplitBeneficiary[]
  customFields?: CustomFields
}

export interface Settlement {
  id: string
  settlementDate: string
  processedDate?: string
  gateway: string
  utr: string
  transactionCount: number
  totalAmount: number
  pgCharges: number
  erpCommission: number
  netAmount: number
  adjustments: {
    refunds: number
    chargebacks: number
    recoveries: number
  }
  finalAmount: number
  status: SettlementStatus
  institute: Institute
  transactionIds: string[]
  refundIds: string[]
  chargebackIds: string[]
  merchantSettlement: {
    amount: number
    utr: string
    transactions: string[]
  }
  vendorSettlements: {
    vendorName: string
    amount: number
    utr: string
    transactions: string[]
  }[]
}

export interface Refund {
  id: string
  transactionId: string
  orderId: string
  institute: string
  studentName: string
  studentId: string
  orderAmount: number
  refundAmount: number
  gateway: string
  paymentMode: string
  accountType: "merchant" | "vendor"
  vendorName?: string
  status: RefundStatus
  reason: string
  refundArn?: string
  requestedBy: string
  requestedAt: string
  processedAt?: string
  pgChargesDeducted: number
  erpCommissionDeducted: number
  netRefundToParent: number
  deductedFromSettlement?: {
    id: string
    date: string
    amount: number
  }
  isSplitRefund?: boolean
}

export interface Chargeback {
  id: string
  transactionId: string
  orderId: string
  institute: string
  studentName: string
  studentId: string
  amount: number
  gateway: string
  paymentMode: string
  reason: string
  reasonCode?: string
  status: ChargebackStatus
  raisedBy: string
  raisedDate: string
  dueDate: string
  closedDate?: string
  evidenceSubmitted: boolean
  responseSubmittedAt?: string
  arbNumber?: string
  chargebackFee: number
  originalSettlement?: {
    id: string
    date: string
  }
  deductedFromSettlement?: {
    id: string
    date: string
    amount: number
  }
  recoveryInfo?: {
    creditedToSettlement: string
    creditedDate: string
    amount: number
  }
}

export interface SplitPayment {
  id: string
  transactionId: string
  orderId: string
  institute: Institute
  student: Student
  totalAmount: number
  gateway: string
  paymentMode: string
  date: string
  status: TransactionStatus
  splits: SplitBeneficiary[]
  vendorSplits: {
    vendorName: string
    amount: number
    percentage: number
    status: SplitStatus
    settlementId?: string
    settlementUtr?: string
    settlementDate?: string
  }[]
  merchantSplit: {
    amount: number
    percentage: number
    status: SplitStatus
    settlementId?: string
    settlementUtr?: string
    settlementDate?: string
  }
}

// ============================================
// SAMPLE DATA FROM CSV
// ============================================

export const unifiedTransactions: Transaction[] = [
  {
    id: "TXNE3P5ZPPZBYUM",
    orderId: "ORD2TFJED64CL",
    edvironOrderId: "EDVGM23860PHKWN",
    gatewayTransactionId: "KF4ISS0ZX4Z1H1FJ",
    bankReferenceNumber: "825202024190",
    status: "refunded",
    statusReason: "Fee waived by institute",
    orderAmount: 24500,
    transactionAmount: 24500,
    vendorAmount: 23764,
    gateway: "PhonePe PG",
    paymentMode: "Card EMI",
    channel: "Mobile App",
    date: "2024-07-01",
    time: "03:28:48",
    student: {
      id: "STUZB53UFLZ",
      name: "Pari Sen",
      email: "pari.sen56@gmail.com",
      phone: "+918294431094",
      class: "8th",
      division: "B",
      rollNumber: "53",
      enrollmentNumber: "EN30011209"
    },
    institute: {
      id: "INST-GDG-NOI",
      name: "GD Goenka Public School, Noida",
      code: "GDG-NOI"
    },
    feeType: "Lab Fee",
    mdrAmount: 368,
    mdrPercentage: 1.5,
    mdrBearing: "merchant",
    erpCommission: 368,
    erpCommissionPercentage: 1.5,
    instrument: {
      type: "Card EMI",
      details: "Mastercard EMI ending 5680",
      cardBrand: "Mastercard",
      cardType: "Credit",
      cardIssuer: "Punjab National Bank",
      cardIssuingBank: "Punjab National Bank"
    },
    isSettled: true,
    settlementId: "STL16CG3OFKSS",
    settlementUtr: "4944825828878257",
    settlementDate: "2024-07-04",
    isSplitPayment: true,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    financing: {
      category: "card_emi",
      type: "low_cost_emi",
      tenure: 6,
      amount: 4083,
      costBearing: "parent",
      charges: {
        totalCharges: 1225,
        parentChargePercentage: 32,
        parentCharge: 392,
        instituteChargePercentage: 25,
        instituteCharge: 306,
        bankChargePercentage: 43,
        bankCharge: 527,
        subventionAmount: 61
      }
    },
    refundDetails: {
      refundId: "RFDZZ67ECY6Y7",
      refundStatus: "completed",
      refundDate: "2024-07-14",
      refundArn: "71935653191669748786",
      refundReason: "Duplicate payment",
      originalOrderAmount: 24500,
      pgChargesDeducted: 368,
      erpCommissionDeducted: 368,
      netRefundToParent: 23764
    },
    splitDetails: [
      { beneficiary: "GD Goenka Public School, Noida", account: "85434700051492", ifsc: "KKBK0755964", amount: 15684, percentage: 66, status: "settled" },
      { beneficiary: "GD Goenka Public School, Noida - Trust Fund", account: "XXXXXXXXXXXX", ifsc: "UTIBXXXXXXX", amount: 8080, percentage: 34, status: "settled" }
    ],
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-07-01 03:28:48", description: "Payment order created for ₹24500", status: "success", metadata: { gateway: "PhonePe PG", paymentMode: "Card EMI" } },
      { event: "Payment Initiated", timestamp: "2024-07-01 03:29:21", description: "Payment initiated via Card EMI", status: "success" },
      { event: "Payment Authorized", timestamp: "2024-07-01 03:30:19", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "825202024190" } },
      { event: "Payment Captured", timestamp: "2024-07-01 03:30:45", description: "Payment captured successfully", status: "success" }
    ]
  },
  {
    id: "TXNHO8S7LR7YYG7",
    orderId: "ORDVLLFEVA30A",
    edvironOrderId: "EDVOIFKIT8EV209",
    gatewayTransactionId: "P25IVZDCA4J41VRD",
    bankReferenceNumber: "",
    status: "pending",
    statusReason: "Payment processing",
    orderAmount: 89500,
    transactionAmount: 91111,
    vendorAmount: 88157,
    gateway: "Razorpay",
    paymentMode: "Credit Card",
    channel: "Mobile App",
    date: "2024-07-02",
    time: "07:26:48",
    student: {
      id: "STUZQQZRSAM",
      name: "Nikhil Reddy",
      email: "nikhil.reddy62@hotmail.com",
      phone: "+919560905875",
      class: "Nursery",
      division: "D",
      rollNumber: "26",
      enrollmentNumber: "EN13542032"
    },
    institute: {
      id: "INST-RIS-ND",
      name: "Ryan International School, New Delhi",
      code: "RIS-ND"
    },
    feeType: "Transport Fee",
    mdrAmount: 1611,
    mdrPercentage: 1.8,
    mdrBearing: "surcharge",
    erpCommission: 1343,
    erpCommissionPercentage: 1.5,
    instrument: {
      type: "Card",
      details: "Amex ending 3777",
      cardBrand: "Amex",
      cardType: "Credit",
      cardIssuer: "Canara Bank"
    },
    isSettled: false,
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: true,
    captureStatus: "authorized",
    authorizedAt: "2024-07-02 07:26:48",
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-07-02 07:26:48", description: "Payment order created for ₹89500", status: "success", metadata: { gateway: "Razorpay", paymentMode: "Credit Card" } },
      { event: "Payment Initiated", timestamp: "2024-07-02 07:26:59", description: "Payment initiated via Credit Card", status: "success" },
      { event: "Awaiting Confirmation", timestamp: "2024-07-02 07:28:00", description: "Waiting for bank confirmation", status: "warning" }
    ],
    customFields: {
      fatherName: "Rahul Reddy",
      motherName: "Sahil Reddy",
      session: "2025-26",
      admissionNumber: "ADM569924"
    }
  },
  {
    id: "TXNBD78BHETDNNU",
    orderId: "ORDJHX6A9NN9C",
    edvironOrderId: "EDVTRVS1GIB6E8X",
    gatewayTransactionId: "CR6TWQKRE4ODFPGS",
    bankReferenceNumber: "897772814457",
    status: "success",
    statusReason: "Amount debited and credited to merchant",
    orderAmount: 18500,
    transactionAmount: 18500,
    vendorAmount: 17945,
    gateway: "PayU",
    paymentMode: "UPI",
    channel: "Mobile App",
    date: "2024-07-04",
    time: "08:10:25",
    student: {
      id: "STUZHVZ7PRT",
      name: "Riya Thakur",
      email: "riya.thakur9@hotmail.com",
      phone: "+917226177472",
      class: "12th",
      division: "A",
      rollNumber: "41",
      enrollmentNumber: "EN76516681"
    },
    institute: {
      id: "INST-OIS-GGN",
      name: "Orchids International School, Gurgaon",
      code: "OIS-GGN"
    },
    feeType: "Library Fee",
    mdrAmount: 370,
    mdrPercentage: 2,
    mdrBearing: "merchant",
    erpCommission: 185,
    erpCommissionPercentage: 1,
    instrument: {
      type: "UPI",
      details: "riya.thakur@oksbi",
      psp: "PhonePe",
      upiId: "riya.thakur@oksbi"
    },
    isSettled: true,
    settlementId: "STL7FC9GXW48T",
    settlementUtr: "2856448835519289",
    settlementDate: "2024-07-06",
    isSplitPayment: true,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    splitDetails: [
      { beneficiary: "Orchids International School, Gurgaon", account: "03647596901454", ifsc: "KKBK0430438", amount: 12920, percentage: 72, status: "settled" },
      { beneficiary: "Orchids International School, Gurgaon - Trust Fund", account: "11084756727028", ifsc: "UTIB0941848", amount: 5025, percentage: 28, status: "settled" }
    ]
  },
  {
    id: "TXNN5MJJAB0N8X1",
    orderId: "ORDZOUCY9SQ8E",
    edvironOrderId: "EDVZ3EDPDK0NH1K",
    gatewayTransactionId: "9Z7XV15KVFYD30U7",
    bankReferenceNumber: "353045623961",
    status: "success",
    statusReason: "Transaction completed successfully",
    orderAmount: 8000,
    transactionAmount: 8000,
    vendorAmount: 7720,
    gateway: "Cashfree",
    paymentMode: "Credit Card",
    channel: "Payment Link",
    date: "2024-07-04",
    time: "21:04:29",
    student: {
      id: "STU4KF7SC53",
      name: "Aditya Menon",
      email: "aditya.menon31@outlook.com",
      phone: "+918005813781",
      class: "4th",
      division: "E",
      rollNumber: "2",
      enrollmentNumber: "EN30856614"
    },
    institute: {
      id: "INST-MS-NOI",
      name: "Modern School, Noida",
      code: "MS-NOI"
    },
    feeType: "Exam Fee",
    mdrAmount: 200,
    mdrPercentage: 2.5,
    mdrBearing: "merchant",
    erpCommission: 80,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Card",
      details: "Visa ending 7503",
      cardBrand: "Visa",
      cardType: "Credit",
      cardIssuer: "Canara Bank"
    },
    isSettled: false,
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: true,
    captureStatus: "captured",
    authorizedAt: "2024-07-04 21:04:29",
    capturedAt: "2024-07-04 21:07:11",
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-07-04 21:04:29", description: "Payment order created for ₹8000", status: "success", metadata: { gateway: "Cashfree", paymentMode: "Credit Card" } },
      { event: "Payment Initiated", timestamp: "2024-07-04 21:05:28", description: "Payment initiated via Credit Card", status: "success" },
      { event: "Payment Authorized", timestamp: "2024-07-04 21:06:14", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "353045623961" } },
      { event: "Payment Captured", timestamp: "2024-07-04 21:06:35", description: "Payment captured successfully", status: "success" }
    ]
  },
  {
    id: "TXNW7HZ8U47RIQH",
    orderId: "ORDV0NY1XO8RS",
    edvironOrderId: "EDV50AMBIRGU3KM",
    gatewayTransactionId: "EA8KDITFUMX4PNS2",
    bankReferenceNumber: "367819014991",
    status: "success",
    statusReason: "Transaction completed successfully",
    orderAmount: 23000,
    transactionAmount: 23575,
    vendorAmount: 22770,
    gateway: "CCAvenue",
    paymentMode: "Credit Card",
    channel: "Online",
    date: "2024-07-05",
    time: "09:08:53",
    student: {
      id: "STU36ROGOBO",
      name: "Yash Nair",
      email: "yash.nair3@outlook.com",
      phone: "+918579351417",
      class: "2nd",
      division: "E",
      rollNumber: "16",
      enrollmentNumber: "EN08669081"
    },
    institute: {
      id: "INST-THS-NOI",
      name: "The Heritage School, Noida",
      code: "THS-NOI"
    },
    feeType: "Admission Fee",
    mdrAmount: 575,
    mdrPercentage: 2.5,
    mdrBearing: "surcharge",
    erpCommission: 230,
    erpCommissionPercentage: 1,
    instrument: {
      type: "Card",
      details: "Amex ending 4332",
      cardBrand: "Amex",
      cardType: "Credit",
      cardIssuer: "IndusInd Bank"
    },
    isSettled: true,
    settlementId: "STLKIWGA0B3LM",
    settlementUtr: "5786876760584174",
    settlementDate: "2024-07-06",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    chargebackDetails: {
      chargebackId: "CBK8W3CW2NN9",
      chargebackStatus: "won",
      chargebackDate: "2024-09-03",
      chargebackAmount: 23000,
      chargebackReason: "Service not received",
      disputeDeadline: "2024-10-04",
      evidenceSubmitted: true,
      responseSubmittedAt: "2024-09-03 09:08:53",
      chargebackFee: 750
    },
    customFields: {
      fatherName: "Swara Nair",
      motherName: "Siya Nair",
      session: "2025-26",
      admissionNumber: "ADM445689"
    }
  },
  {
    id: "TXN4LYHOF5HB7U2",
    orderId: "ORD0QASQ7ZVD6",
    edvironOrderId: "EDV397KZYFX0RXK",
    gatewayTransactionId: "3CZ4693VVTQEDIDU",
    bankReferenceNumber: "368516896451",
    status: "refunded",
    statusReason: "Duplicate payment refunded",
    orderAmount: 60500,
    transactionAmount: 61589,
    vendorAmount: 60046,
    gateway: "PayU",
    paymentMode: "Card EMI",
    channel: "Payment Link",
    date: "2024-07-05",
    time: "12:53:32",
    student: {
      id: "STULX96F65K",
      name: "Krishna Pandey",
      email: "krishna.pandey11@outlook.com",
      phone: "+919564396721",
      class: "8th",
      division: "E",
      rollNumber: "10",
      enrollmentNumber: "EN93232623"
    },
    institute: {
      id: "INST-DBS-GGN",
      name: "Don Bosco School, Gurgaon",
      code: "DBS-GGN"
    },
    feeType: "Admission Fee",
    mdrAmount: 1089,
    mdrPercentage: 1.8,
    mdrBearing: "surcharge",
    erpCommission: 454,
    erpCommissionPercentage: 0.75,
    instrument: {
      type: "Card EMI",
      details: "Mastercard EMI ending 1708",
      cardBrand: "Mastercard",
      cardType: "Credit",
      cardIssuer: "SBI",
      cardIssuingBank: "SBI"
    },
    isSettled: false,
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    financing: {
      category: "card_emi",
      type: "no_cost_emi",
      tenure: 12,
      amount: 5042,
      costBearing: "institute",
      charges: {
        totalCharges: 6655,
        parentChargePercentage: 49,
        parentCharge: 3261,
        instituteChargePercentage: 19,
        instituteCharge: 1264,
        bankChargePercentage: 32,
        bankCharge: 2130
      }
    },
    refundDetails: {
      refundId: "RFDKRTHT4B5IM",
      refundStatus: "completed",
      refundDate: "2024-07-13",
      refundReason: "Incorrect amount charged",
      originalOrderAmount: 60500,
      pgChargesDeducted: 1089,
      erpCommissionDeducted: 454,
      netRefundToParent: 58957
    },
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-07-05 12:53:32", description: "Payment order created for ₹60500", status: "success", metadata: { gateway: "PayU", paymentMode: "Card EMI" } },
      { event: "Payment Initiated", timestamp: "2024-07-05 12:54:26", description: "Payment initiated via Card EMI", status: "success" },
      { event: "Payment Authorized", timestamp: "2024-07-05 12:55:18", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "368516896451" } },
      { event: "Payment Captured", timestamp: "2024-07-05 12:55:34", description: "Payment captured successfully", status: "success" }
    ]
  },
  {
    id: "TXNVNQB7AR6WSA3",
    orderId: "ORD9TIN1BG0KL",
    edvironOrderId: "EDVMYVOMJO5MQQF",
    gatewayTransactionId: "B6TIV7TZTP3IEZOX",
    bankReferenceNumber: "",
    status: "failed",
    statusReason: "Invalid card details",
    orderAmount: 5000,
    transactionAmount: 5000,
    vendorAmount: 4887,
    gateway: "Cashfree",
    paymentMode: "Wallet",
    channel: "Online",
    date: "2024-07-07",
    time: "06:58:13",
    student: {
      id: "STU5L4S2NTI",
      name: "Dhruv Joshi",
      email: "dhruv.joshi65@gmail.com",
      phone: "+917188698891",
      class: "7th",
      division: "E",
      rollNumber: "41",
      enrollmentNumber: "EN89677844"
    },
    institute: {
      id: "INST-DPS-NOI",
      name: "Delhi Public School, Noida",
      code: "DPS-NOI"
    },
    feeType: "Lab Fee",
    mdrAmount: 75,
    mdrPercentage: 1.5,
    mdrBearing: "merchant",
    erpCommission: 38,
    erpCommissionPercentage: 0.75,
    instrument: {
      type: "Wallet",
      details: "PhonePe Wallet",
      walletName: "PhonePe Wallet"
    },
    isSettled: false,
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-07-07 06:58:13", description: "Payment order created for ₹5000", status: "success", metadata: { gateway: "Cashfree", paymentMode: "Wallet" } },
      { event: "Payment Initiated", timestamp: "2024-07-07 06:58:40", description: "Payment initiated via Wallet", status: "success" },
      { event: "Payment Failed", timestamp: "2024-07-07 06:59:42", description: "Authentication failed", status: "error" }
    ]
  },
  {
    id: "TXN38UWWQZRZ77V",
    orderId: "ORDTJQM2G4T5E",
    edvironOrderId: "EDV3F2W7KHRJZFO",
    gatewayTransactionId: "DYXM9PEZW9DNPRMK",
    bankReferenceNumber: "683405563396",
    status: "success",
    statusReason: "Transaction completed successfully",
    orderAmount: 115500,
    transactionAmount: 115500,
    vendorAmount: 111226,
    gateway: "Easebuzz",
    paymentMode: "UPI",
    channel: "SDK",
    date: "2024-07-08",
    time: "22:56:02",
    student: {
      id: "STUAE7U9L4V",
      name: "Vivaan Chopra",
      email: "vivaan.chopra70@rediffmail.com",
      phone: "+916767381893",
      class: "5th",
      division: "C",
      rollNumber: "46",
      enrollmentNumber: "EN37657439"
    },
    institute: {
      id: "INST-SS-GGN",
      name: "Sanskriti School, Gurgaon",
      code: "SS-GGN"
    },
    feeType: "Lab Fee",
    mdrAmount: 2541,
    mdrPercentage: 2.2,
    mdrBearing: "merchant",
    erpCommission: 1733,
    erpCommissionPercentage: 1.5,
    instrument: {
      type: "UPI",
      details: "vivaan.chopra@upi",
      psp: "PhonePe",
      upiId: "vivaan.chopra@upi"
    },
    isSettled: true,
    settlementId: "STLN86K8N4JGH",
    settlementUtr: "9212748443029416",
    settlementDate: "2024-07-10",
    isSplitPayment: true,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    splitDetails: [
      { beneficiary: "Sanskriti School, Gurgaon", account: "87535218670004", ifsc: "KKBK0217813", amount: 81195, percentage: 73, status: "settled" },
      { beneficiary: "Sanskriti School, Gurgaon - Trust Fund", account: "70891220825520", ifsc: "HDFC0176033", amount: 30031, percentage: 27, status: "settled" }
    ],
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-07-08 22:56:02", description: "Payment order created for ₹115500", status: "success", metadata: { gateway: "Easebuzz", paymentMode: "UPI" } },
      { event: "Payment Initiated", timestamp: "2024-07-08 22:56:28", description: "Payment initiated via UPI", status: "success" },
      { event: "Payment Authorized", timestamp: "2024-07-08 22:58:07", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "683405563396" } },
      { event: "Payment Captured", timestamp: "2024-07-08 22:58:37", description: "Payment captured successfully", status: "success" }
    ]
  },
  {
    id: "TXNVN4JKUBIWG35",
    orderId: "ORD3V9Y2W77WA",
    edvironOrderId: "EDVK078TJBX60NC",
    gatewayTransactionId: "BC32011F3WHP397U",
    bankReferenceNumber: "721855517772",
    status: "success",
    statusReason: "Payment successful",
    orderAmount: 13500,
    transactionAmount: 13500,
    vendorAmount: 13094,
    gateway: "PhonePe PG",
    paymentMode: "UPI Autopay",
    channel: "QR Code",
    date: "2024-07-12",
    time: "09:22:17",
    student: {
      id: "STUMKT9P2JY",
      name: "Nikhil Joshi",
      email: "nikhil.joshi81@hotmail.com",
      phone: "+919320015332",
      class: "7th",
      division: "E",
      rollNumber: "26",
      enrollmentNumber: "EN71136595"
    },
    institute: {
      id: "INST-BCS-NOI",
      name: "Bishop Cotton School, Noida",
      code: "BCS-NOI"
    },
    feeType: "Annual Fee",
    mdrAmount: 338,
    mdrPercentage: 2.5,
    mdrBearing: "merchant",
    erpCommission: 68,
    erpCommissionPercentage: 0.5,
    instrument: {
      type: "UPI Mandate",
      details: "nikhil80@oksbi",
      psp: "Paytm",
      upiId: "nikhil80@oksbi"
    },
    isSettled: true,
    settlementId: "STLTKBUJ1LAAB",
    settlementUtr: "5927436058332122",
    settlementDate: "2024-07-15",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    autopayDetails: {
      mandateId: "MNDRP7ULA2A7Y",
      mandateType: "one_time",
      mandateStatus: "active",
      maxAmount: 68000,
      frequency: "quarterly",
      validUntil: "2026-12-12"
    },
    chargebackDetails: {
      chargebackId: "CBDOMJ0Z8EWT",
      chargebackStatus: "under_review",
      chargebackDate: "2024-08-05",
      chargebackAmount: 13500,
      chargebackReason: "Card stolen - fraudulent use",
      disputeDeadline: "2024-09-05",
      evidenceSubmitted: false,
      arbNumber: "934194513878",
      chargebackFee: 500
    },
    customFields: {
      fatherName: "Vedant Joshi",
      motherName: "Zara Joshi",
      session: "2025-26",
      admissionNumber: "ADM627797"
    }
  },
  {
    id: "TXNRY0T658TNP9E",
    orderId: "ORDU4RNQTPZVH",
    edvironOrderId: "EDVOWYO0N6VAGGF",
    gatewayTransactionId: "0PUYEFBTOZA5K3BL",
    bankReferenceNumber: "220407894752",
    status: "success",
    statusReason: "Payment received and verified",
    orderAmount: 207000,
    transactionAmount: 211140,
    vendorAmount: 205965,
    gateway: "PhonePe PG",
    paymentMode: "UPI",
    channel: "Mobile App",
    date: "2024-07-12",
    time: "01:13:45",
    student: {
      id: "STUXNE7CAT1",
      name: "Ayaan Iyer",
      email: "ayaan.iyer67@outlook.com",
      phone: "+916809132859",
      class: "6th",
      division: "D",
      rollNumber: "13",
      enrollmentNumber: "EN78554844"
    },
    institute: {
      id: "INST-ES-GGN",
      name: "Euro School, Gurgaon",
      code: "ES-GGN"
    },
    feeType: "Hostel Fee",
    mdrAmount: 4140,
    mdrPercentage: 2,
    mdrBearing: "surcharge",
    erpCommission: 1035,
    erpCommissionPercentage: 0.5,
    instrument: {
      type: "UPI",
      details: "ayaan.iyer@ibl",
      psp: "CRED",
      upiId: "ayaan.iyer@ibl"
    },
    isSettled: true,
    settlementId: "STLA6F8297OWD",
    settlementUtr: "8598334297532183",
    settlementDate: "2024-07-14",
    isSplitPayment: false,
    isInternational: false,
    currency: "INR",
    captureApiUsed: false,
    transactionLifecycle: [
      { event: "Order Created", timestamp: "2024-07-12 01:13:45", description: "Payment order created for ₹207000", status: "success", metadata: { gateway: "PhonePe PG", paymentMode: "UPI" } },
      { event: "Payment Initiated", timestamp: "2024-07-12 01:14:00", description: "Payment initiated via UPI", status: "success" },
      { event: "Payment Authorized", timestamp: "2024-07-12 01:14:52", description: "Payment authorized by bank", status: "success", metadata: { bankRef: "220407894752" } },
      { event: "Payment Captured", timestamp: "2024-07-12 01:15:16", description: "Payment captured successfully", status: "success" }
    ]
  }
]

// ============================================
// DERIVED DATA - REFUNDS
// ============================================

export const unifiedRefunds: Refund[] = unifiedTransactions
  .filter(txn => txn.refundDetails)
  .map(txn => ({
    id: txn.refundDetails!.refundId,
    transactionId: txn.id,
    orderId: txn.orderId,
    institute: txn.institute.name,
    studentName: txn.student.name,
    studentId: txn.student.id,
    orderAmount: txn.orderAmount,
    refundAmount: txn.refundDetails!.netRefundToParent,
    gateway: txn.gateway,
    paymentMode: txn.paymentMode,
    accountType: "merchant" as const,
    status: txn.refundDetails!.refundStatus,
    reason: txn.refundDetails!.refundReason,
    refundArn: txn.refundDetails!.refundArn,
    requestedBy: "Institute Admin",
    requestedAt: txn.refundDetails!.refundDate,
    processedAt: txn.refundDetails!.refundStatus === "completed" ? txn.refundDetails!.refundDate : undefined,
    pgChargesDeducted: txn.refundDetails!.pgChargesDeducted,
    erpCommissionDeducted: txn.refundDetails!.erpCommissionDeducted,
    netRefundToParent: txn.refundDetails!.netRefundToParent,
    deductedFromSettlement: txn.settlementId ? {
      id: txn.settlementId,
      date: txn.settlementDate || "",
      amount: txn.refundDetails!.netRefundToParent
    } : undefined
  }))

// ============================================
// DERIVED DATA - CHARGEBACKS
// ============================================

export const unifiedChargebacks: Chargeback[] = unifiedTransactions
  .filter(txn => txn.chargebackDetails)
  .map(txn => ({
    id: txn.chargebackDetails!.chargebackId,
    transactionId: txn.id,
    orderId: txn.orderId,
    institute: txn.institute.name,
    studentName: txn.student.name,
    studentId: txn.student.id,
    amount: txn.chargebackDetails!.chargebackAmount,
    gateway: txn.gateway,
    paymentMode: txn.paymentMode,
    reason: txn.chargebackDetails!.chargebackReason,
    status: txn.chargebackDetails!.chargebackStatus,
    raisedBy: txn.instrument.cardIssuingBank || txn.instrument.psp || "Bank",
    raisedDate: txn.chargebackDetails!.chargebackDate,
    dueDate: txn.chargebackDetails!.disputeDeadline,
    evidenceSubmitted: txn.chargebackDetails!.evidenceSubmitted,
    responseSubmittedAt: txn.chargebackDetails!.responseSubmittedAt,
    arbNumber: txn.chargebackDetails!.arbNumber,
    chargebackFee: txn.chargebackDetails!.chargebackFee,
    originalSettlement: txn.settlementId ? {
      id: txn.settlementId,
      date: txn.settlementDate || ""
    } : undefined,
    deductedFromSettlement: txn.settlementId && txn.chargebackDetails!.chargebackStatus !== "won" ? {
      id: txn.settlementId,
      date: txn.settlementDate || "",
      amount: txn.chargebackDetails!.chargebackAmount
    } : undefined,
    recoveryInfo: txn.chargebackDetails!.chargebackStatus === "won" ? {
      creditedToSettlement: txn.settlementId || "",
      creditedDate: txn.settlementDate || "",
      amount: txn.chargebackDetails!.chargebackAmount
    } : undefined
  }))

// ============================================
// DERIVED DATA - SETTLEMENTS
// ============================================

export const unifiedSettlements: Settlement[] = [
  {
    id: "STL16CG3OFKSS",
    settlementDate: "2024-07-04",
    processedDate: "2024-07-04",
    gateway: "PhonePe PG",
    utr: "4944825828878257",
    transactionCount: 12,
    totalAmount: 324500,
    pgCharges: 4868,
    erpCommission: 4868,
    netAmount: 314764,
    adjustments: { refunds: 23764, chargebacks: 0, recoveries: 0 },
    finalAmount: 291000,
    status: "settled",
    institute: { id: "INST-GDG-NOI", name: "GD Goenka Public School, Noida", code: "GDG-NOI" },
    transactionIds: ["TXNE3P5ZPPZBYUM"],
    refundIds: ["RFDZZ67ECY6Y7"],
    chargebackIds: [],
    merchantSettlement: { amount: 210000, utr: "4944825828878257", transactions: ["TXNE3P5ZPPZBYUM"] },
    vendorSettlements: [{ vendorName: "GD Goenka Trust Fund", amount: 81000, utr: "4944825828878258", transactions: ["TXNE3P5ZPPZBYUM"] }]
  },
  {
    id: "STL7FC9GXW48T",
    settlementDate: "2024-07-06",
    processedDate: "2024-07-06",
    gateway: "PayU",
    utr: "2856448835519289",
    transactionCount: 8,
    totalAmount: 148000,
    pgCharges: 2960,
    erpCommission: 1480,
    netAmount: 143560,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 143560,
    status: "settled",
    institute: { id: "INST-OIS-GGN", name: "Orchids International School, Gurgaon", code: "OIS-GGN" },
    transactionIds: ["TXNBD78BHETDNNU"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 103392, utr: "2856448835519289", transactions: ["TXNBD78BHETDNNU"] },
    vendorSettlements: [{ vendorName: "Orchids Trust Fund", amount: 40168, utr: "2856448835519290", transactions: ["TXNBD78BHETDNNU"] }]
  },
  {
    id: "STLKIWGA0B3LM",
    settlementDate: "2024-07-06",
    processedDate: "2024-07-06",
    gateway: "CCAvenue",
    utr: "5786876760584174",
    transactionCount: 5,
    totalAmount: 115750,
    pgCharges: 2894,
    erpCommission: 1158,
    netAmount: 111698,
    adjustments: { refunds: 0, chargebacks: 23000, recoveries: 23000 },
    finalAmount: 111698,
    status: "settled",
    institute: { id: "INST-THS-NOI", name: "The Heritage School, Noida", code: "THS-NOI" },
    transactionIds: ["TXNW7HZ8U47RIQH"],
    refundIds: [],
    chargebackIds: ["CBK8W3CW2NN9"],
    merchantSettlement: { amount: 111698, utr: "5786876760584174", transactions: ["TXNW7HZ8U47RIQH"] },
    vendorSettlements: []
  },
  {
    id: "STLN86K8N4JGH",
    settlementDate: "2024-07-10",
    processedDate: "2024-07-10",
    gateway: "Easebuzz",
    utr: "9212748443029416",
    transactionCount: 15,
    totalAmount: 578250,
    pgCharges: 12722,
    erpCommission: 8674,
    netAmount: 556854,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 556854,
    status: "settled",
    institute: { id: "INST-SS-GGN", name: "Sanskriti School, Gurgaon", code: "SS-GGN" },
    transactionIds: ["TXN38UWWQZRZ77V"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 406598, utr: "9212748443029416", transactions: ["TXN38UWWQZRZ77V"] },
    vendorSettlements: [{ vendorName: "Sanskriti Trust Fund", amount: 150256, utr: "9212748443029417", transactions: ["TXN38UWWQZRZ77V"] }]
  },
  {
    id: "STLTKBUJ1LAAB",
    settlementDate: "2024-07-15",
    processedDate: "2024-07-15",
    gateway: "PhonePe PG",
    utr: "5927436058332122",
    transactionCount: 10,
    totalAmount: 135000,
    pgCharges: 3375,
    erpCommission: 675,
    netAmount: 130950,
    adjustments: { refunds: 0, chargebacks: 13500, recoveries: 0 },
    finalAmount: 117450,
    status: "settled",
    institute: { id: "INST-BCS-NOI", name: "Bishop Cotton School, Noida", code: "BCS-NOI" },
    transactionIds: ["TXNVN4JKUBIWG35"],
    refundIds: [],
    chargebackIds: ["CBDOMJ0Z8EWT"],
    merchantSettlement: { amount: 117450, utr: "5927436058332122", transactions: ["TXNVN4JKUBIWG35"] },
    vendorSettlements: []
  },
  {
    id: "STLA6F8297OWD",
    settlementDate: "2024-07-14",
    processedDate: "2024-07-14",
    gateway: "PhonePe PG",
    utr: "8598334297532183",
    transactionCount: 18,
    totalAmount: 1035700,
    pgCharges: 20714,
    erpCommission: 5179,
    netAmount: 1009807,
    adjustments: { refunds: 0, chargebacks: 0, recoveries: 0 },
    finalAmount: 1009807,
    status: "settled",
    institute: { id: "INST-ES-GGN", name: "Euro School, Gurgaon", code: "ES-GGN" },
    transactionIds: ["TXNRY0T658TNP9E"],
    refundIds: [],
    chargebackIds: [],
    merchantSettlement: { amount: 1009807, utr: "8598334297532183", transactions: ["TXNRY0T658TNP9E"] },
    vendorSettlements: []
  }
]

// ============================================
// DERIVED DATA - SPLIT PAYMENTS
// ============================================

export const unifiedSplitPayments: SplitPayment[] = unifiedTransactions
  .filter(txn => txn.isSplitPayment && txn.splitDetails && txn.splitDetails.length > 0)
  .map(txn => ({
    id: `SPL-${txn.id}`,
    transactionId: txn.id,
    orderId: txn.orderId,
    institute: txn.institute,
    student: txn.student,
    totalAmount: txn.orderAmount,
    gateway: txn.gateway,
    paymentMode: txn.paymentMode,
    date: txn.date,
    status: txn.status,
    splits: txn.splitDetails!,
    vendorSplits: txn.splitDetails!
      .filter(s => s.beneficiary.includes("Trust") || s.beneficiary.includes("Vendor"))
      .map(s => ({
        vendorName: s.beneficiary,
        amount: s.amount,
        percentage: s.percentage,
        status: s.status,
        settlementId: txn.settlementId,
        settlementUtr: txn.settlementUtr,
        settlementDate: txn.settlementDate
      })),
    merchantSplit: {
      amount: txn.splitDetails!.find(s => !s.beneficiary.includes("Trust") && !s.beneficiary.includes("Vendor"))?.amount || txn.orderAmount,
      percentage: txn.splitDetails!.find(s => !s.beneficiary.includes("Trust") && !s.beneficiary.includes("Vendor"))?.percentage || 100,
      status: txn.splitDetails!.find(s => !s.beneficiary.includes("Trust") && !s.beneficiary.includes("Vendor"))?.status || "settled",
      settlementId: txn.settlementId,
      settlementUtr: txn.settlementUtr,
      settlementDate: txn.settlementDate
    }
  }))

// ============================================
// HELPER FUNCTIONS
// ============================================

export function getAllVendors(): string[] {
  const vendors = new Set<string>()
  unifiedTransactions.forEach(txn => {
    if (txn.splitDetails) {
      txn.splitDetails.forEach(split => {
        if (split.beneficiary.includes("Trust") || split.beneficiary.includes("Vendor")) {
          vendors.add(split.beneficiary)
        }
      })
    }
  })
  return Array.from(vendors).sort()
}

export function getAllInstitutes(): Institute[] {
  const institutes = new Map<string, Institute>()
  unifiedTransactions.forEach(txn => {
    if (!institutes.has(txn.institute.id)) {
      institutes.set(txn.institute.id, txn.institute)
    }
  })
  return Array.from(institutes.values())
}

export function getAllGateways(): string[] {
  return [...new Set(unifiedTransactions.map(txn => txn.gateway))].sort()
}

export function getTransactionsByStatus(status: TransactionStatus): Transaction[] {
  return unifiedTransactions.filter(txn => txn.status === status)
}

export function getSplitTransactions(): Transaction[] {
  return unifiedTransactions.filter(txn => txn.isSplitPayment)
}

export function getTransactionsWithRefunds(): Transaction[] {
  return unifiedTransactions.filter(txn => txn.refundDetails)
}

export function getTransactionsWithChargebacks(): Transaction[] {
  return unifiedTransactions.filter(txn => txn.chargebackDetails)
}

export function getTransactionById(id: string): Transaction | undefined {
  return unifiedTransactions.find(txn => txn.id === id)
}

export function getRefundById(id: string): Refund | undefined {
  return unifiedRefunds.find(refund => refund.id === id)
}

export function getChargebackById(id: string): Chargeback | undefined {
  return unifiedChargebacks.find(chargeback => chargeback.id === id)
}

export function getSettlementById(id: string): Settlement | undefined {
  return unifiedSettlements.find(settlement => settlement.id === id)
}

export function getSettlementImpact(transactionId: string): {
  refundImpact: number
  chargebackImpact: number
  recoveryImpact: number
  netImpact: number
} {
  const txn = getTransactionById(transactionId)
  if (!txn) return { refundImpact: 0, chargebackImpact: 0, recoveryImpact: 0, netImpact: 0 }

  const refundImpact = txn.refundDetails?.netRefundToParent || 0
  const chargebackImpact = txn.chargebackDetails?.chargebackStatus !== "won" ? (txn.chargebackDetails?.chargebackAmount || 0) : 0
  const recoveryImpact = txn.chargebackDetails?.chargebackStatus === "won" ? (txn.chargebackDetails?.chargebackAmount || 0) : 0

  return {
    refundImpact,
    chargebackImpact,
    recoveryImpact,
    netImpact: refundImpact + chargebackImpact - recoveryImpact
  }
}

export function getTransactionsByDateRange(startDate: string, endDate: string): Transaction[] {
  return unifiedTransactions.filter(txn => txn.date >= startDate && txn.date <= endDate)
}

export function getTransactionsByGateway(gateway: string): Transaction[] {
  return unifiedTransactions.filter(txn => txn.gateway === gateway)
}

export function getTransactionsByInstitute(instituteId: string): Transaction[] {
  return unifiedTransactions.filter(txn => txn.institute.id === instituteId)
}

// Summary statistics
export function getTransactionSummary() {
  const total = unifiedTransactions.length
  const success = unifiedTransactions.filter(t => t.status === "success").length
  const pending = unifiedTransactions.filter(t => t.status === "pending").length
  const failed = unifiedTransactions.filter(t => t.status === "failed").length
  const refunded = unifiedTransactions.filter(t => t.status === "refunded").length
  const totalAmount = unifiedTransactions.reduce((sum, t) => sum + t.orderAmount, 0)
  const successAmount = unifiedTransactions.filter(t => t.status === "success").reduce((sum, t) => sum + t.orderAmount, 0)

  return { total, success, pending, failed, refunded, totalAmount, successAmount }
}

export function getRefundSummary() {
  const total = unifiedRefunds.length
  const completed = unifiedRefunds.filter(r => r.status === "completed").length
  const pending = unifiedRefunds.filter(r => r.status === "pending").length
  const totalAmount = unifiedRefunds.reduce((sum, r) => sum + r.refundAmount, 0)

  return { total, completed, pending, totalAmount }
}

export function getChargebackSummary() {
  const total = unifiedChargebacks.length
  const won = unifiedChargebacks.filter(c => c.status === "won").length
  const lost = unifiedChargebacks.filter(c => c.status === "lost").length
  const underReview = unifiedChargebacks.filter(c => c.status === "under_review").length
  const totalAmount = unifiedChargebacks.reduce((sum, c) => sum + c.amount, 0)

  return { total, won, lost, underReview, totalAmount }
}

export function getSettlementSummary() {
  const total = unifiedSettlements.length
  const settled = unifiedSettlements.filter(s => s.status === "settled").length
  const pending = unifiedSettlements.filter(s => s.status === "pending").length
  const totalAmount = unifiedSettlements.reduce((sum, s) => sum + s.finalAmount, 0)

  return { total, settled, pending, totalAmount }
}
