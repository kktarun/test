"use client"

import useSWR from "swr"

// Fetcher function
const fetcher = (url: string) => fetch(url).then(res => res.json())

// Transaction interface matching the actual JSON structure
export interface RawTransaction {
  id: string
  order_id: string
  edviron_order_id: string
  gateway_transaction_id: string
  bank_reference_number: string
  status: string
  status_reason: string
  order_amount: number
  transaction_amount: number
  vendor_amount: number
  gateway: string
  payment_mode: string
  channel: string
  date: string
  time: string
  student_name: string
  student_id: string
  student_class: string
  student_division: string
  roll_number: string
  enrollment_number: string
  payer_email: string
  payer_mobile: string
  institute: string
  fee_type: string
  mdr_amount: number
  mdr_percentage: number
  mdr_bearing: string
  erp_commission: number
  erp_commission_percentage: number
  instrument_type: string
  instrument_details: string
  card_brand: string | null
  card_type: string | null
  card_issuer: string | null
  card_issuing_bank: string | null
  psp: string | null
  upi_id: string | null
  wallet_name: string | null
  bank_name: string | null
  is_settled: number
  settlement_id: string | null
  settlement_utr: string | null
  settlement_date: string | null
  is_split_payment: number
  is_international: number
  international_method: string | null
  currency: string
  original_amount: number | null
  exchange_rate: number | null
  capture_api_used: number
  capture_status: string | null
  authorized_at: string | null
  captured_at: string | null
  financing_category: string | null
  financing_type: string | null
  emi_tenure: number | null
  emi_amount: number | null
  emi_cost_bearing: string | null
  partial_cost_sharing: string | null
  nbfc_partner: string | null
  financing_collection_type: string | null
  autopay_details: {
    registration_status: string
    mandate_id?: string
    next_debit_date?: string
  } | null
  school_counter_details: {
    counter_id: string
    operator_name: string
    cash_drawer_id?: string
    receipt_number: string
  } | null
  bank_transfer_details: {
    va_number: string
    remitter_name: string
    remitter_account: string
    remitter_ifsc: string
    transfer_mode: string
  } | null
  split_pay_timeline: string | null
  split_pay_modes: string | null
  financing_charges: {
    totalCharges: number
    parentChargePercentage: number
    parentCharge: number
    instituteChargePercentage: number
    instituteCharge: number
    bankChargePercentage: number
    bankCharge: number
    subventionAmount?: number
  } | null
  refund_details: {
    refundId: string
    refundStatus: string
    refundDate: string
    refundArn?: string
    refundReason: string
    originalOrderAmount: number
    pgChargesDeducted: number
    erpCommissionDeducted: number
    netRefundToParent: number
  } | null
  chargeback_details: {
    chargebackId: string
    chargebackStatus: string
    chargebackReason: string
    chargebackReasonCode?: string
    chargebackAmount: number
    raisedBy: string
    raisedDate: string
    dueDate: string
    evidenceSubmitted: boolean
    responseSubmittedAt?: string
    arbNumber?: string
    chargebackFee: number
    deductedFromSettlement?: string
    recoveredAmount?: number
    recoveredInSettlement?: string
  } | null
  transaction_lifecycle: {
    event: string
    timestamp: string
    description: string
    status: string
    metadata?: Record<string, unknown>
  }[] | null
  split_details: {
    splits: {
      beneficiary: string
      account: string
      ifsc: string
      amount: number
      percentage: number
      status: string
    }[]
  } | null
  custom_fields: Record<string, string> | null
}

// Hook to fetch transactions data
export function useTransactionsData() {
  const { data, error, isLoading } = useSWR<RawTransaction[]>(
    "/data/transactions.json",
    fetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    }
  )

  return {
    transactions: data || [],
    isLoading,
    error,
    totalCount: data?.length || 0,
  }
}

// Hook to get refunds (transactions with refund_details)
export function useRefundsData() {
  const { transactions, isLoading, error } = useTransactionsData()
  
  const refunds = transactions.filter(t => t.refund_details !== null)
  
  return {
    refunds,
    isLoading,
    error,
    totalCount: refunds.length,
  }
}

// Hook to get chargebacks (transactions with chargeback_details)
export function useChargebacksData() {
  const { transactions, isLoading, error } = useTransactionsData()
  
  const chargebacks = transactions.filter(t => t.chargeback_details !== null)
  
  return {
    chargebacks,
    isLoading,
    error,
    totalCount: chargebacks.length,
  }
}

// Hook to get split payments (transactions with is_split_payment = 1)
export function useSplitPaymentsData() {
  const { transactions, isLoading, error } = useTransactionsData()
  
  const splitPayments = transactions.filter(t => t.is_split_payment === 1)
  
  return {
    splitPayments,
    isLoading,
    error,
    totalCount: splitPayments.length,
  }
}

// Hook to get settlements data
export function useSettlementsData() {
  const { transactions, isLoading, error } = useTransactionsData()
  
  // Group transactions by settlement_id
  const settlementMap = new Map<string, RawTransaction[]>()
  transactions.forEach(t => {
    if (t.settlement_id) {
      const existing = settlementMap.get(t.settlement_id) || []
      settlementMap.set(t.settlement_id, [...existing, t])
    }
  })
  
  const settlements = Array.from(settlementMap.entries()).map(([id, txns]) => ({
    id,
    date: txns[0]?.settlement_date || "",
    utr: txns[0]?.settlement_utr || "",
    transactions: txns,
    totalAmount: txns.reduce((sum, t) => sum + (t.transaction_amount || 0), 0),
    totalMdr: txns.reduce((sum, t) => sum + (t.mdr_amount || 0), 0),
    totalErpCommission: txns.reduce((sum, t) => sum + (t.erp_commission || 0), 0),
    transactionCount: txns.length,
    gateway: txns[0]?.gateway || "",
    institute: txns[0]?.institute || "",
  }))
  
  return {
    settlements,
    isLoading,
    error,
    totalCount: settlements.length,
  }
}

// Get unique institutes
export function getUniqueInstitutes(transactions: RawTransaction[]): string[] {
  return [...new Set(transactions.map(t => t.institute).filter(Boolean))]
}

// Get unique gateways
export function getUniqueGateways(transactions: RawTransaction[]): string[] {
  return [...new Set(transactions.map(t => t.gateway).filter(Boolean))]
}

// Get unique statuses
export function getUniqueStatuses(transactions: RawTransaction[]): string[] {
  return [...new Set(transactions.map(t => t.status).filter(Boolean))]
}

// Get unique payment modes
export function getUniquePaymentModes(transactions: RawTransaction[]): string[] {
  return [...new Set(transactions.map(t => t.payment_mode).filter(Boolean))]
}
